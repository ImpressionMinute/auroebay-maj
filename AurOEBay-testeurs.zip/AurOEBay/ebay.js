"use strict";
(() => {
  // src/core/text.ts
  var compact = (s) => s.replace(/\s+/g, " ").trim();
  var norm = (s) => compact(s.normalize("NFKC")).toLowerCase().replace(/[\s\W_]+/g, " ").trim();
  var escapeHTML = (s) => s.replace(
    /[&<>"']/g,
    (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]
  );
  function validTitle(s, max = 80) {
    return !!s.trim() && !/[\r\n]/.test(s) && s.length <= Math.min(80, max);
  }
  function redact(s) {
    return s.replace(/\bsk-[A-Za-z0-9_-]+/g, "[REDACTED_KEY]").replace(/Bearer\s+\S+/gi, "Bearer [REDACTED]").replace(/[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}/g, "[EMAIL]").replace(/https?:\/\/[^\s<>"']+/g, "[URL]");
  }
  function cleanURL(url) {
    try {
      const u = new URL(url);
      return u.origin + u.pathname;
    } catch {
      return "";
    }
  }
  function debounce(fn, ms = 500) {
    let timer;
    return () => {
      clearTimeout(timer);
      timer = setTimeout(fn, ms);
    };
  }
  var delay = (ms) => new Promise((r) => setTimeout(r, ms));

  // src/core/descriptionDesign.ts
  var DESCRIPTION_TEMPLATE = '<style>\n.auro-listing{font-family:Arial,Helvetica,sans-serif;color:#213a37;background:#f3f5f3;max-width:960px;margin:0 auto;padding:24px;box-sizing:border-box;line-height:1.65}\n.auro-listing *{box-sizing:border-box}.auro-listing .auro-brand{font-size:12px;letter-spacing:3px;font-weight:bold;margin-bottom:20px;color:#44645b}.auro-listing .auro-header{background:#183e35;color:white;border-radius:14px;padding:30px}.auro-listing h1{font-size:26px;line-height:1.3;margin:10px 0 0}.auro-listing .auro-eyebrow{font-size:11px;letter-spacing:2px;text-transform:uppercase}.auro-listing .auro-body{background:white;border:1px solid #dce5dd;border-radius:14px;margin-top:18px;padding:24px;overflow-wrap:anywhere}.auro-listing .auro-body img{max-width:100%!important;height:auto!important;display:block;margin:18px auto}.auro-listing .auro-body table{max-width:100%;width:auto}.auro-listing .auro-body p{margin:12px 0}.auro-listing .auro-note{font-size:13px;color:#587064;padding:18px 4px}.auro-listing .auro-note strong{color:#213a37}@media(max-width:600px){.auro-listing{padding:12px}.auro-listing .auro-header,.auro-listing .auro-body{padding:18px}.auro-listing h1{font-size:22px}}\n</style>\n<div class="auro-listing">\n{store}\n<div class="auro-header"><div class="auro-eyebrow">Product details</div><h1>{title}</h1></div>\n<div class="auro-body">{description}</div>\n<div class="auro-note"><strong>Choose your option</strong><br>Please check the selected variation, dimensions and item details before ordering.<br>Delivery estimates, shipping charges and return terms are shown in this eBay listing.</div>\n</div>\n';
  function designDescription(html, title) {
    const template = document.createElement("template");
    template.innerHTML = html;
    const root = template.content;
    const removed = [];
    const previous2 = root.querySelector(".auro-listing .auro-body");
    const legacy = root.querySelector("#wrapper > .box > .content.main_content");
    let body = root;
    if (previous2) body = previous2;
    else if (legacy) {
      const wrapper = root.querySelector("#wrapper");
      const boxes = [...wrapper.children].filter((e) => e.matches(".box"));
      const disposable = boxes.filter(
        (box2) => /^(shipping|returns|payments|feedbacks)$/i.test(
          box2.querySelector(":scope > .title")?.textContent?.trim() ?? ""
        )
      );
      if (boxes.every((b) => b.contains(legacy) || disposable.includes(b))) {
        body = legacy;
        removed.push(
          ...disposable.map(
            (b) => b.querySelector(".title").textContent.trim()
          )
        );
      }
    }
    const content = document.createElement("div");
    content.append(...Array.from(body.childNodes).map((n) => n.cloneNode(true)));
    content.querySelectorAll(
      "script,style,iframe,object,embed,form,input,button,link,meta"
    ).forEach((e) => e.remove());
    content.querySelectorAll("*").forEach((el2) => {
      for (const attr of [...el2.attributes]) {
        if (/^on/i.test(attr.name) || attr.name === "srcdoc" || /^href$/i.test(attr.name) && /^javascript:/i.test(attr.value))
          el2.removeAttribute(attr.name);
      }
    });
    const output = listingDescriptionHTML(title, content.innerHTML);
    const normalized = document.createElement("template");
    normalized.innerHTML = output;
    return {
      html: normalized.innerHTML,
      removed,
      images: content.querySelectorAll("img").length
    };
  }
  function replaceDesign(root, html) {
    const t = root.ownerDocument.createElement("template");
    t.innerHTML = html;
    const originals = [...root.querySelectorAll("img")];
    t.content.querySelectorAll("img").forEach((img) => {
      const index = originals.findIndex((o) => o.outerHTML === img.outerHTML);
      if (index >= 0) img.replaceWith(originals.splice(index, 1)[0]);
    });
    root.replaceChildren(t.content);
  }
  var listingStore = "";
  var DESCRIPTION_THEMES = {
    classic: { label: "Vert classique", font: "Arial,Helvetica,sans-serif", ink: "#213a37", page: "#f3f5f3", brand: "#44645b", header: "#183e35", headerInk: "white", card: "white", border: "#dce5dd", radius: "14px", note: "#587064" },
    minimal: { label: "Blanc minimal", font: "Helvetica,Arial,sans-serif", ink: "#1d1d1f", page: "#ffffff", brand: "#86868b", header: "#ffffff;border-bottom:2px solid #1d1d1f", headerInk: "#1d1d1f", card: "white", border: "#e5e5e7", radius: "4px", note: "#6e6e73" },
    ocean: { label: "Bleu oc\xE9an", font: "Arial,Helvetica,sans-serif", ink: "#13293d", page: "#eef4fa", brand: "#2f6690", header: "linear-gradient(135deg,#0b4f9c,#1677d2)", headerInk: "white", card: "white", border: "#d4e3f2", radius: "14px", note: "#4a6582" },
    noir: { label: "Noir & or", font: "Georgia,'Times New Roman',serif", ink: "#1a1a1a", page: "#f5f3ee", brand: "#a8842c", header: "#111111", headerInk: "#f5c451", card: "white", border: "#e6dfcf", radius: "6px", note: "#6b6252" },
    sunset: { label: "Orange \xE9nergie", font: "Arial,Helvetica,sans-serif", ink: "#2b1d16", page: "#fff6ef", brand: "#e8590c", header: "linear-gradient(135deg,#ff5f3a,#ff8a3d 50%,#ffb347)", headerInk: "white", card: "white", border: "#ffe0cc", radius: "18px", note: "#7a5a48" },
    rose: { label: "Rose doux", font: "'Trebuchet MS',Arial,sans-serif", ink: "#3b1f2b", page: "#fff0f5", brand: "#c2255c", header: "linear-gradient(135deg,#f06595,#faa2c1)", headerInk: "white", card: "white", border: "#fcd6e3", radius: "20px", note: "#86566a" },
    tech: { label: "Tech sombre", font: "Verdana,Arial,sans-serif", ink: "#1b2733", page: "#e9eef2", brand: "#0c8599", header: "linear-gradient(135deg,#1b2733,#22394d)", headerInk: "#66d9e8", card: "white", border: "#cfd9e1", radius: "10px", note: "#52667a" }
  };
  var listingTheme = "classic";
  function setListingTheme(id) {
    listingTheme = typeof id === "string" && id in DESCRIPTION_THEMES ? id : "classic";
  }
  function descriptionTemplate(id = listingTheme) {
    const t = DESCRIPTION_THEMES[id];
    if (!t || id === "classic") return DESCRIPTION_TEMPLATE;
    return DESCRIPTION_TEMPLATE.replace("font-family:Arial,Helvetica,sans-serif", `font-family:${t.font}`).replace("color:#213a37;background:#f3f5f3", `color:${t.ink};background:${t.page}`).replace("color:#44645b", `color:${t.brand}`).replace("background:#183e35;color:white;border-radius:14px", `background:${t.header};color:${t.headerInk};border-radius:${t.radius}`).replace("background:white;border:1px solid #dce5dd;border-radius:14px", `background:${t.card};border:1px solid ${t.border};border-radius:${t.radius}`).replace("color:#587064", `color:${t.note}`).replace(".auro-note strong{color:#213a37}", `.auro-note strong{color:${t.ink}}`);
  }
  function setListingStore(name) {
    listingStore = typeof name === "string" ? name.trim().slice(0, 40) : "";
  }
  function listingDescriptionHTML(title, bodyHTML, store = listingStore, theme = listingTheme) {
    const text2 = escapeHTML(title).replace(/&#39;/g, "'").replace(/&quot;/g, '"').replace(/\u00a0/g, "&nbsp;");
    const brand = store ? `<div class="auro-brand">${escapeHTML(store.toUpperCase().replace(/\s+/g, ""))}</div>
` : "";
    return descriptionTemplate(theme).replace(
      /\{title\}|\{description\}|\{store\}\n?/g,
      (placeholder) => placeholder === "{title}" ? text2 : placeholder === "{description}" ? bodyHTML : brand
    );
  }

  // src/core/brand.ts
  var BRAND = {
    ember: "#ff5f3a",
    flame: "#ff8a3d",
    sun: "#ffb347",
    night: "#15121c",
    night2: "#1e1a27",
    night3: "#2a2534",
    nightLine: "#373042",
    paper: "#fbf7f3",
    paper2: "#ffffff",
    paper3: "#f4ede6",
    paperLine: "#ebe1d7",
    inkDark: "#f1ecf4",
    inkLight: "#1d1828",
    mutedDark: "#a49bb0",
    mutedLight: "#75697d",
    ok: "#22b07d",
    warn: "#f0a63a",
    danger: "#ef4f5f",
    info: "#7c8cff",
    gradient: "linear-gradient(135deg,#ff5f3a 0%,#ff8a3d 48%,#ffb347 100%)",
    ease: "cubic-bezier(.2,.8,.2,1)",
    spring: "cubic-bezier(.34,1.56,.64,1)"
  };
  function brandMarkSVG(size = 28, id = "ao") {
    return `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 48 48" aria-hidden="true"><defs><linearGradient id="${id}g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${BRAND.ember}"/><stop offset=".5" stop-color="${BRAND.flame}"/><stop offset="1" stop-color="${BRAND.sun}"/></linearGradient></defs><rect x="2" y="2" width="44" height="44" rx="13" fill="url(#${id}g)"/><path d="M14.5 36 24 12.5 33.5 36" fill="none" stroke="#fff" stroke-width="4.6" stroke-linecap="round" stroke-linejoin="round"/><path d="M18.6 30.2a5.4 5.4 0 0 1 10.8 0" fill="none" stroke="#fff" stroke-width="3.4" stroke-linecap="round"/><path class="ao-spark" d="M38 6.5l1.5 3.6 3.6 1.5-3.6 1.5L38 16.7l-1.5-3.6-3.6-1.5 3.6-1.5z" fill="#fff"/></svg>`;
  }
  var markURL = `url("data:image/svg+xml,${encodeURIComponent(brandMarkSVG(48, "u"))}")`;
  var BRAND_CSS = `
:root,:host{--ao-ember:${BRAND.ember};--ao-flame:${BRAND.flame};--ao-sun:${BRAND.sun};--ao-gradient:${BRAND.gradient};--ao-ease:${BRAND.ease};--ao-spring:${BRAND.spring};--ao-ok:${BRAND.ok};--ao-warn:${BRAND.warn};--ao-danger:${BRAND.danger};--ao-info:${BRAND.info};--ao-glow:0 10px 30px rgba(255,95,58,.35)}
.ao-mark{display:inline-block;flex:none;width:28px;height:28px;background:${markURL} center/contain no-repeat}
.ao-loader{position:relative;display:inline-grid;place-items:center;flex:none;width:var(--ao-size,64px);height:var(--ao-size,64px)}
.ao-loader::before{content:"";position:absolute;inset:0;border-radius:50%;background:conic-gradient(from 0deg,transparent 0 40%,${BRAND.sun} 70%,${BRAND.ember} 100%);-webkit-mask:radial-gradient(circle closest-side,transparent calc(100% - max(2px,calc(var(--ao-size,64px) * .05))),#000 calc(100% - max(2px,calc(var(--ao-size,64px) * .05)) + 1px));mask:radial-gradient(circle closest-side,transparent calc(100% - max(2px,calc(var(--ao-size,64px) * .05))),#000 calc(100% - max(2px,calc(var(--ao-size,64px) * .05)) + 1px));animation:ao-spin 1.15s linear infinite}
.ao-loader::after{content:"";position:absolute;top:50%;left:50%;width:max(3px,calc(var(--ao-size,64px) * .08));height:max(3px,calc(var(--ao-size,64px) * .08));margin:calc(max(3px,calc(var(--ao-size,64px) * .08)) / -2);border-radius:50%;background:#fff;box-shadow:0 0 8px 2px ${BRAND.sun};animation:ao-orbit 2.2s linear infinite}
.ao-loader>.ao-mark{width:64%;height:64%;animation:ao-breathe 2.4s var(--ao-ease) infinite;filter:drop-shadow(0 4px 10px rgba(255,95,58,.45))}
.ao-spinner{display:inline-block;flex:none;width:var(--ao-size,14px);height:var(--ao-size,14px);border-radius:50%;background:conic-gradient(from 0deg,transparent 0 35%,${BRAND.sun} 65%,${BRAND.ember});-webkit-mask:radial-gradient(circle closest-side,transparent 68%,#000 72%);mask:radial-gradient(circle closest-side,transparent 68%,#000 72%);animation:ao-spin .8s linear infinite;vertical-align:-2px}
.ao-sweep{position:relative;overflow:hidden;isolation:isolate}
.ao-sweep::after{content:"";position:absolute;inset:-20% auto -20% -60%;width:45%;background:linear-gradient(100deg,transparent,rgba(255,255,255,.28),transparent);transform:skewX(-18deg);animation:ao-sweep 4.8s var(--ao-ease) infinite;pointer-events:none;z-index:1}
.ao-rise{animation:ao-rise .5s var(--ao-ease) both}
.ao-progress{position:relative;height:6px;border-radius:99px;background:rgba(127,112,140,.18);overflow:hidden}
.ao-progress>i{position:absolute;inset:0 auto 0 0;width:var(--p,0%);border-radius:inherit;background:var(--ao-gradient);transition:width .7s var(--ao-ease)}
.ao-progress>i::after{content:"";position:absolute;inset:0;background:linear-gradient(90deg,transparent,rgba(255,255,255,.55),transparent);transform:translateX(-100%);animation:ao-shine 1.6s ease-in-out infinite}
.ao-progress.indeterminate>i{width:38%;animation:ao-slide 1.4s cubic-bezier(.65,0,.35,1) infinite}
.ao-spark{transform-box:fill-box;transform-origin:center;animation:ao-twinkle 3.2s ease-in-out infinite}
.profit-box{margin:10px 0;padding:10px 12px;border-radius:12px;border:1px solid rgba(127,112,140,.3);background:rgba(127,112,140,.08);font-size:12.5px;line-height:1.45;animation:ao-rise .4s var(--ao-ease) both}
.profit-box strong{display:block;font-size:13px;margin-bottom:2px}
.profit-box.ok{border-color:rgba(34,176,125,.45);background:rgba(34,176,125,.08)}
.profit-box.ok strong{color:${BRAND.ok}}
.profit-box.loss{border-color:rgba(255,95,58,.55);background:rgba(255,95,58,.09)}
.profit-box.loss strong{color:${BRAND.ember}}
.profit-box p{margin:4px 0}
.profit-box ul{margin:6px 0;padding-left:18px}
.profit-box li{margin:2px 0}
.profit-box small{display:block;margin-top:6px;opacity:.7;font-size:11px}
.net-pill{display:inline-block;padding:1px 7px;border-radius:99px;font-size:11.5px;font-weight:650;white-space:nowrap}
.net-pill.ok{background:rgba(34,176,125,.15);color:${BRAND.ok}}
.net-pill.loss{background:rgba(255,95,58,.16);color:${BRAND.ember}}
@keyframes ao-spin{to{transform:rotate(360deg)}}
@keyframes ao-orbit{from{transform:rotate(0) translateX(calc(var(--ao-size,64px) / 2)) rotate(0)}to{transform:rotate(360deg) translateX(calc(var(--ao-size,64px) / 2)) rotate(-360deg)}}
@keyframes ao-breathe{50%{transform:scale(.92) translateY(-1px)}}
@keyframes ao-sweep{0%,55%{left:-60%}100%{left:130%}}
@keyframes ao-rise{from{opacity:0;transform:translateY(10px) scale(.985)}to{opacity:1;transform:none}}
@keyframes ao-shine{to{transform:translateX(100%)}}
@keyframes ao-slide{from{transform:translateX(-105%)}to{transform:translateX(270%)}}
@keyframes ao-twinkle{0%,70%,100%{opacity:1;transform:scale(1) rotate(0)}80%{opacity:.35;transform:scale(.55) rotate(45deg)}90%{opacity:1;transform:scale(1.25) rotate(90deg)}}
@keyframes ao-pop{0%{transform:scale(.6);opacity:0}100%{transform:scale(1);opacity:1}}
@keyframes ao-pulse{0%{box-shadow:0 0 0 0 rgba(255,95,58,.5)}70%{box-shadow:0 0 0 10px rgba(255,95,58,0)}100%{box-shadow:0 0 0 0 rgba(255,95,58,0)}}
@media (prefers-reduced-motion:reduce){.ao-loader::before,.ao-loader::after,.ao-loader>.ao-mark,.ao-spinner,.ao-sweep::after,.ao-rise,.ao-progress>i::after,.ao-progress.indeterminate>i,.ao-spark{animation:none!important}}
`;
  var WINDOW_TOKENS = `--bg:${BRAND.night2};--bg2:${BRAND.night3};--line:${BRAND.nightLine};--ink:${BRAND.inkDark};--muted:${BRAND.mutedDark};--accent:${BRAND.ember};--ok:#3fd09a;--warn:${BRAND.warn};--err:#ff6b78`;
  function brandButtonStyle(kind = "primary", margin = "8px 8px 8px 0") {
    const base = `display:inline-flex;align-items:center;gap:8px;border-radius:11px;padding:10px 16px;font:600 14px/1.2 -apple-system,system-ui,sans-serif;margin:${margin};text-decoration:none;cursor:pointer;transition:transform .15s,box-shadow .2s,filter .2s;`;
    return kind === "primary" ? `${base}background:${BRAND.gradient};color:#fff;border:0;box-shadow:0 6px 16px rgba(255,95,58,.32)` : `${base}background:transparent;color:inherit;border:1.5px solid ${BRAND.flame}`;
  }
  function brandButtonIcon(doc, size = 18) {
    const span = doc.createElement("span");
    span.style.cssText = `display:inline-flex;width:${size}px;height:${size}px;flex:none`;
    span.innerHTML = brandMarkSVG(size, `b${Math.random().toString(36).slice(2, 7)}`);
    return span;
  }
  function brandButtonHover(el2) {
    el2.addEventListener("mouseenter", () => {
      el2.style.transform = "translateY(-1px)";
      el2.style.filter = "brightness(1.06)";
    });
    el2.addEventListener("mouseleave", () => {
      el2.style.transform = "";
      el2.style.filter = "";
    });
  }

  // src/core/ebaySeed.ts
  function ebayItemId(url) {
    try {
      const u = new URL(url);
      return u.protocol === "https:" && !u.username && !u.password && !u.port && /(^|\.)ebay\.com$/.test(u.hostname) ? u.pathname.match(/^\/itm\/(?:[^/]+\/)?(\d+)(?:\/)?$/)?.[1] ?? null : null;
    } catch {
      return null;
    }
  }
  function validEbaySeed(s, now = Date.now()) {
    try {
      const u = new URL(s.copyUrl);
      return ebayItemId(s.url) === s.itemId && validTitle(s.title, 80) && !u.username && !u.password && u.origin === "https://www.ebay.com" && u.pathname === "/sl/list" && ["SellLikeItem", "SellSimilarItem"].includes(
        u.searchParams.get("mode") ?? ""
      ) && u.searchParams.get("itemId") === s.itemId && typeof s.category === "string" && (s.categoryId === void 0 || /^\d{1,7}$/.test(s.categoryId)) && (!!s.category || s.categoryFromCopy === true && u.searchParams.get("mode") === "SellLikeItem") && Array.isArray(s.specifics) && s.specifics.length <= 100 && s.specifics.every(
        (x) => typeof x.label === "string" && typeof x.value === "string" && x.label.length <= 150 && x.value.length <= 1e3
      ) && Number.isFinite(s.capturedAt) && s.capturedAt <= now + 3e4 && now - s.capturedAt < 36e5 && (s.price === null || /^\d+(?:\.\d{1,2})?$/.test(s.price)) && (s.currency === null || s.currency === "USD") && typeof s.hasVariations === "boolean";
    } catch {
      return false;
    }
  }

  // src/core/messaging.ts
  async function message(body) {
    const reply = await chrome.runtime.sendMessage(body);
    if (!reply?.ok)
      throw Error(reply?.error ?? "AurOEBay ne r\xE9pond pas. Recharge la page.");
    return reply.data;
  }

  // src/ebay/selectors.ts
  var SELECTORS = {
    title: [
      '[data-testid="title"] input',
      'input[data-testid="title"]',
      '[data-testid="listing-title"] input',
      'input[name="title"]',
      'input[name="listingTitle"]',
      "input#title",
      "input#listingTitle",
      'input[aria-label="Title"]'
    ],
    description: [
      'textarea[data-testid="description"]',
      '[data-testid="description"] textarea',
      'textarea[name="description"]',
      "textarea#description",
      '[contenteditable="true"][aria-label="Description"]',
      '[contenteditable="true"][data-testid="description"]',
      "iframe#description_ifr",
      "iframe#se-rte-frame__summary",
      'iframe[title="Rich Text Area"]'
    ],
    specifics: [
      '[data-testid*="item-specific"]',
      '[data-testid*="itemSpecific"]',
      '[data-testid="specifics"]',
      ".item-specifics",
      "#itemSpecifics",
      ".summary__attributes",
      '[aria-label="Item specifics"]'
    ],
    seller: [
      '[data-testid="seller-info"]',
      ".x-sellercard-atf",
      ".x-sellercard",
      ".x-sellercard-atf__info",
      ".ux-seller-section",
      "#RightSummaryPanel .mbg"
    ],
    sellerLinks: ['a[href*="/usr/"]'],
    results: ["li.s-item", "li.s-card", '[data-testid="item-card"]'],
    variations: [
      '[data-testid*="variation"]',
      ".variation-row",
      ".summary__variations",
      '[aria-label="Variations"]'
    ],
    aliTitle: [
      'h1[data-pl="product-title"]',
      '[data-testid="product-title"]',
      "h1"
    ],
    aliSpecs: [
      '[data-testid="specifications"] li',
      '[class*="specification--prop"]',
      '[class*="specification--line"]',
      ".product-prop",
      '[class*="specification"] tr'
    ],
    aliDescription: [
      '[data-testid="product-description"]',
      "#product-description",
      ".product-description"
    ],
    aliDescriptionFrames: [
      "#nav-description iframe",
      "#product-description iframe",
      '[data-testid="product-description"] iframe'
    ],
    seedTitle: ["h1.x-item-title__mainTitle", 'h1[data-testid="item-title"]'],
    seedSpecifics: [
      ".ux-layout-section-evo__item--description-list",
      '[data-testid="seed-specifics"]'
    ],
    seedCategory: [
      "nav.breadcrumbs a.seo-breadcrumb-text",
      '[data-testid="seed-category"] a'
    ],
    seedPrice: [".x-price-primary", '[data-testid="seed-price"]'],
    simplePrice: [
      'input[name="price"]',
      'input[aria-label="Price"]',
      'input[id$="-price"]'
    ],
    aliVariants: [
      "[data-sku-row]",
      '[data-testid="sku-property"]',
      '[class*="sku-item--property"]'
    ],
    aliStore: [
      '[data-testid="store-name"]',
      'a[class*="store-name"]',
      'a[href*="/store/"]'
    ],
    aliGallery: [
      '[data-testid="product-gallery"]',
      '[class*="slider--img"]',
      '[class*="magnifier--wrap"]'
    ],
    aliShipping: [
      '[data-testid="shipping"]',
      '[class*="delivery--shipping"]',
      '[class*="delivery--content"]',
      '[class*="dynamic-shipping-titleLayout"]'
    ],
    nativeSearch: [
      'input[placeholder="Enter brand, model, description, etc."]',
      'input[aria-label="Enter brand, model, description, etc."]'
    ],
    photoInput: [
      'input#fehelix-uploader[type="file"]',
      'input[data-testid="photo-upload"][type="file"]'
    ],
    photoCounter: [
      '.summary__photos .uploader-thumbnails-ux__header__photo-count span[aria-hidden="true"]'
    ],
    uploadedPhotos: [
      '.summary__variations .uploader-thumbnails__thumbnail button.uploader-thumbnails__image[style*="background-image"]',
      '[data-testid="uploaded-photo"] img',
      '.summary__photos .uploader-thumbnails-ux__image--ready button.uploader-thumbnails-ux__image[style*="background-image"]'
    ]
  };
  var SPECIFIC_LABELS = [
    "Brand",
    "Type",
    "Material",
    "Color",
    "Colour",
    "Size",
    "Features",
    "Compatible Brand",
    "Compatible Model",
    "MPN",
    "Model",
    "Country/Region of Manufacture",
    "Country of Origin",
    "Unit Quantity",
    "Unit Type",
    "Number of Pieces",
    "Dimensions",
    "Length",
    "Width",
    "Height",
    "Capacity",
    "Pattern",
    "Style",
    "Department"
  ];
  function queryAll(root, selectors) {
    const result = /* @__PURE__ */ new Set();
    for (const selector of selectors) {
      try {
        root.querySelectorAll(selector).forEach((e) => result.add(e));
      } catch {
      }
    }
    return [...result];
  }
  function first(root, selectors) {
    for (const selector of selectors) {
      try {
        const el2 = root.querySelector(selector);
        if (el2) return el2;
      } catch {
      }
    }
    return null;
  }

  // src/core/ebayCategory.ts
  function categoryLink(value) {
    try {
      const url = new URL(value, "https://www.ebay.com");
      if (url.protocol !== "https:" || !/^(www\.)?ebay\.com$/.test(url.hostname) || url.username || url.password || url.port)
        return null;
      const hit = url.pathname.match(/^\/b\/[^/]+\/([1-9]\d{0,6})(?:\/[^/]+)?\/?$/) ?? url.pathname.match(/^\/sch\/([1-9]\d{0,6})\/i\.html$/);
      return hit?.[1] ?? null;
    } catch {
      return null;
    }
  }
  function uniqueLeaf(leaves) {
    const ids = new Set(leaves);
    return ids.size === 1 ? leaves[0] : null;
  }
  function ebayCategoryFromDocument(doc) {
    const leaves = [];
    for (const nav of doc.querySelectorAll(
      'nav.breadcrumbs, nav[data-testid="x-breadcrumb"], .x-breadcrumb nav, [data-testid="x-breadcrumb"] nav'
    )) {
      const ids = [...nav.querySelectorAll("a[href]")].map((a) => categoryLink(a.getAttribute("href") ?? "")).filter((id) => id !== null);
      if (ids.length) leaves.push(ids[ids.length - 1]);
    }
    return uniqueLeaf(leaves);
  }
  function trackedCategory(html) {
    if (typeof html !== "string") return null;
    const found = html.match(/(?:ui_)?tcat(?:%3D|=)([1-9]\d{2,8})\b/)?.[1];
    return found ?? null;
  }

  // src/core/purchaseHistory.ts
  var MONTHS = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"];
  var ZONES = { PDT: -7, PST: -8, MDT: -6, MST: -7, CDT: -5, CST: -6, EDT: -4, EST: -5, GMT: 0, UTC: 0, BST: 1, CET: 1, CEST: 2 };
  function purchaseDate(text2) {
    let day, month, year, h, min, sec, zone;
    const a = text2.match(/(\d{1,2}) ([A-Za-z]{3})[a-z]* (\d{4})(?: at)? (\d{1,2}):(\d{2})(?::(\d{2}))?\s*(am|pm)?\s*([A-Z]{2,4})?/i);
    const b = text2.match(/([A-Za-z]{3})-(\d{1,2})-(\d{2,4}) (\d{1,2}):(\d{2})(?::(\d{2}))?\s*(am|pm)?\s*([A-Z]{2,4})?/i);
    if (a) [day, month, year, h, min, sec] = [+a[1], MONTHS.indexOf(a[2].toLowerCase()), +a[3], +a[4], +a[5], +(a[6] ?? 0)];
    else if (b) [day, month, year, h, min, sec] = [+b[2], MONTHS.indexOf(b[1].toLowerCase()), +b[3] < 100 ? 2e3 + +b[3] : +b[3], +b[4], +b[5], +(b[6] ?? 0)];
    else return null;
    const m = a ?? b;
    const ampm = (m[7] ?? "").toLowerCase();
    zone = (m[8] ?? "UTC").toUpperCase();
    if (month < 0) return null;
    if (ampm === "pm" && h < 12) h += 12;
    if (ampm === "am" && h === 12) h = 0;
    return Date.UTC(year, month, day, h, min, sec) - (ZONES[zone] ?? 0) * 36e5;
  }
  function parsePurchaseHistory(root) {
    const table = root.querySelector("table.app-table__table") ?? root.querySelector("table");
    if (!table) return [];
    const rows2 = [...table.querySelectorAll("tr")];
    const cells = (tr) => [...tr.children].map((c) => (c.textContent ?? "").replace(/\s+/g, " ").trim());
    const head = rows2.length ? cells(rows2[0]).map((h) => h.toLowerCase()) : [];
    const col = (re) => head.findIndex((h) => re.test(h));
    const variation = col(/variation/), price2 = col(/price/), quantity = col(/quantity/), date = col(/date/);
    if (date < 0) return [];
    return rows2.slice(1).flatMap((tr) => {
      const c = cells(tr);
      if (c.length < head.length) return [];
      const p = (c[price2] ?? "").match(/(US \$|\$|€|£|C \$|AU \$)\s?([\d,]+(?:\.\d{1,2})?)/);
      return [
        {
          variation: variation >= 0 ? c[variation] : "",
          price: p ? Number(p[2].replace(/,/g, "")) : null,
          currency: p ? /€/.test(p[1]) ? "EUR" : /£/.test(p[1]) ? "GBP" : "USD" : "USD",
          quantity: Math.max(1, Number(c[quantity]) || 1),
          at: purchaseDate(c[date] ?? "")
        }
      ];
    });
  }
  var DAY = 864e5;
  var PERIODS = [7, 14, 30, 60, 90, null];
  function periodStats(list, days, now = Date.now()) {
    const rows2 = list.filter((p) => days === null || p.at !== null && now - p.at <= days * DAY);
    const prices = rows2.filter((p) => p.price !== null).map((p) => p.price).sort((a, b) => a - b);
    const units = rows2.reduce((n, p) => n + p.quantity, 0);
    const revenue = Math.round(rows2.reduce((n, p) => n + (p.price ?? 0) * p.quantity, 0) * 100) / 100;
    const byVariation = /* @__PURE__ */ new Map();
    for (const p of rows2) if (p.variation) byVariation.set(p.variation, (byVariation.get(p.variation) ?? 0) + p.quantity);
    const mid = prices.length >> 1;
    return {
      days,
      units,
      transactions: rows2.length,
      revenue,
      average: prices.length ? Math.round(revenue / Math.max(1, units) * 100) / 100 : null,
      median: prices.length ? prices.length % 2 ? prices[mid] : Math.round((prices[mid - 1] + prices[mid]) / 2 * 100) / 100 : null,
      lowest: prices[0] ?? null,
      highest: prices.at(-1) ?? null,
      variations: [...byVariation].map(([name, n]) => ({ name, units: n })).sort((a, b) => b.units - a.units)
    };
  }

  // src/ebay/salesHistory.ts
  var historyURL = (itemId) => `https://www.ebay.com/bin/purchaseHistory?item=${itemId}`;
  var CSS2 = `${BRAND_CSS}
  :host{${WINDOW_TOKENS}}
  .box{margin:18px 0;border:1px solid var(--line);border-radius:16px;overflow:hidden;background:var(--bg);color:var(--ink);font:14px/1.4 -apple-system,system-ui,sans-serif}
  header{display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;gap:10px;padding:14px 18px;background:var(--ao-gradient);color:#fff}
  header b{font-size:18px}header small{display:block;opacity:.9}
  .chips button{border:1px solid rgba(255,255,255,.5);background:transparent;color:#fff;border-radius:999px;padding:4px 11px;margin-left:4px;cursor:pointer;font:600 13px system-ui}
  .chips button.on{background:var(--bg);border-color:var(--bg)}
  .kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px;padding:16px 18px}
  .kpi{border:1px solid var(--line);border-radius:12px;padding:12px;background:var(--bg2)}
  .kpi span{display:block;font-size:11px;letter-spacing:.05em;color:var(--muted);text-transform:uppercase}
  .kpi b{font-size:24px}.kpi b.hot{color:var(--accent)}
  h4{margin:4px 18px 8px;font-size:13px;letter-spacing:.04em;text-transform:uppercase;color:var(--muted)}
  .vars{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:8px;padding:0 18px 12px}
  .var{display:flex;justify-content:space-between;gap:8px;border:1px solid var(--line);border-radius:10px;padding:8px 10px}
  .var i{font-style:normal;background:var(--accent);border-radius:6px;padding:0 7px;margin-right:6px}
  .var b{color:var(--accent);white-space:nowrap}
  .cols{display:grid;grid-template-columns:3fr 2fr;gap:18px;padding:0 18px 18px}
  .bar{display:grid;grid-template-columns:70px 1fr 70px;align-items:center;gap:8px;margin:6px 0;font-size:13px}
  .track{height:9px;border-radius:9px;background:var(--line);overflow:hidden}.fill{height:100%;background:var(--accent)}
  .bar b{text-align:right}
  .prices{display:grid;grid-template-columns:1fr 1fr;gap:8px}
  .muted{color:var(--muted);font-size:12px}
  @media(max-width:760px){.cols{grid-template-columns:1fr}}
`;
  var money = (n) => n === null ? "\u2014" : n.toLocaleString("fr-FR", { style: "currency", currency: "USD" });
  var label = (d) => d === null ? "Tout" : `${d} j`;
  function setupSalesHistory(doc, enabled2) {
    if (!enabled2() || location.pathname !== "/bin/purchaseHistory") return () => {
    };
    const table = doc.querySelector("table.app-table__table") ?? doc.querySelector("table");
    const purchases = parsePurchaseHistory(doc);
    if (!table) return () => {
    };
    doc.getElementById("auroebay-history")?.remove();
    const host = doc.createElement("div");
    host.id = "auroebay-history";
    const root = host.attachShadow({ mode: "open" });
    let period = 30;
    const stats = PERIODS.map((d) => periodStats(purchases, d));
    const dated = purchases.filter((p) => p.at !== null).map((p) => p.at);
    const oldest = dated.length ? Math.min(...dated) : null;
    const draw = () => {
      const s = stats.find((x) => x.days === period);
      const max = Math.max(1, ...stats.map((x) => x.units));
      root.innerHTML = `<style>${CSS2}</style><div class="box">
      <header class="ao-sweep"><div><b style="display:inline-flex;align-items:center;gap:9px"><span class="ao-mark" style="width:26px;height:26px"></span>Analyse des ventes</b><small>Ventes visibles sur cette page${oldest ? ` (depuis le ${new Date(oldest).toLocaleDateString("fr-FR")})` : ""}</small></div>
        <div class="chips">${PERIODS.map((d) => `<button data-d="${d ?? "all"}" class="${d === period ? "on" : ""}">${label(d)}</button>`).join("")}</div></header>
      <div class="kpis">
        <div class="kpi"><span>Unit\xE9s vendues \xB7 ${label(period)}</span><b class="hot">${s.units}</b></div>
        <div class="kpi"><span>Ventes (transactions)</span><b>${s.transactions}</b></div>
        <div class="kpi"><span>Chiffre d\u2019affaires estim\xE9</span><b class="hot">${money(s.revenue)}</b></div>
        <div class="kpi"><span>Prix moyen</span><b>${money(s.average)}</b></div>
        <div class="kpi"><span>Ventes / jour</span><b>${s.days ? (s.units / s.days).toLocaleString("fr-FR", { maximumFractionDigits: 1 }) : "\u2014"}</b></div>
      </div>
      ${s.variations.length ? `<h4>Variantes les plus vendues \xB7 ${label(period)}</h4><div class="vars">${s.variations.slice(0, 6).map((v, i) => `<div class="var"><span><i>${i + 1}</i>${v.name.replace(/[<>&]/g, "")}</span><b>${v.units} vendu(s)</b></div>`).join("")}</div>` : ""}
      <div class="cols">
        <div><h4 style="margin-left:0">Rythme des ventes</h4>${stats.map((x) => `<div class="bar"><span>${label(x.days)}</span><div class="track"><div class="fill" style="width:${Math.round(x.units / max * 100)}%"></div></div><b>${x.units} unit\xE9s</b></div>`).join("")}</div>
        <div><h4 style="margin-left:0">Prix \xB7 ${label(period)}</h4><div class="prices">
          <div class="kpi"><span>Le plus haut</span><b>${money(s.highest)}</b></div>
          <div class="kpi"><span>Le plus bas</span><b>${money(s.lowest)}</b></div>
          <div class="kpi"><span>M\xE9dian</span><b>${money(s.median)}</b></div>
          <div class="kpi"><span>Ventes avec prix</span><b>${s.transactions}</b></div>
        </div><p class="muted">Prix hors livraison, tels qu\u2019affich\xE9s par eBay.</p></div>
      </div></div>`;
      root.querySelectorAll(".chips button").forEach(
        (b) => b.addEventListener("click", () => {
          period = b.dataset.d === "all" ? null : Number(b.dataset.d);
          draw();
        })
      );
    };
    draw();
    (table.closest("section, div") ?? table).before(host);
    return () => host.remove();
  }
  function historyButton(doc) {
    const itemId = ebayItemId(location.href);
    if (!itemId) return null;
    const a = doc.createElement("a");
    a.href = historyURL(itemId);
    a.target = "_blank";
    a.rel = "noopener";
    a.append(brandButtonIcon(doc), "Historique des ventes");
    a.style.cssText = brandButtonStyle("quiet", "8px 0");
    brandButtonHover(a);
    return a;
  }

  // src/core/shippingText.ts
  var PRICE = String.raw`(?:US\s*)?\$\s*(\d+(?:\.\d{1,2})?)`;
  var NAMED = new RegExp(String.raw`(?:standard|shipping|delivery|livraison)[^$·\d]{0,20}?${PRICE}`, "gi");
  var LABEL = new RegExp(String.raw`\b[A-Za-z][A-Za-z' -]{1,30}:\s*${PRICE}`, "g");

  // src/ebay/prices.ts
  function resolvePrices(doc) {
    const rows2 = [];
    for (const table of doc.querySelectorAll("table")) {
      const header = table.querySelector("thead tr");
      if (!header) continue;
      const headers = [...header.children].map(
        (c) => norm(c.getAttribute("sortby") ?? c.textContent ?? "")
      );
      const priceIndex = headers.findIndex((h) => /^(price|prix)$/.test(h));
      const axes = headers.map((h, i) => ({ h, i, cell: header.children[i] })).filter(
        ({ h, cell }) => h && cell.getAttribute("ignore") !== "1" && !cell.matches(".act,.pic,.sku,.upc,.qty,.prc,.eco-fee,.cell-ph") && !/^(actions|photos|sku|upc|ean|isbn|quantity|quantite|price|prix|eco(?: participation)? fee|eco participation|ecoparticipation)$/.test(
          h
        )
      );
      if (priceIndex < 0 || !axes.length) continue;
      for (const row of table.querySelectorAll("tbody tr")) {
        if (row.hidden || row.classList.contains("hide")) continue;
        const input = row.cells[priceIndex]?.querySelector(
          'input[cn="prc"],input[name*="price" i],input'
        );
        if (!input || input.disabled || input.readOnly || input.type === "hidden")
          continue;
        const values = axes.map(({ h, i }) => ({
          label: h,
          value: compact(row.cells[i]?.textContent ?? "")
        }));
        if (values.some((v) => !v.value)) continue;
        const key = `price:${JSON.stringify(values.map((v) => [v.label, norm(v.value)]).sort())}`;
        rows2.push({
          el: input,
          field: {
            key,
            label: values.map((v) => `${v.label}: ${v.value}`).join(" \xB7 "),
            value: input.value,
            kind: "text",
            writable: true,
            selector: 'table tbody input[cn="prc"]',
            options: values.map((v) => ({ label: v.label, value: v.value }))
          }
        });
      }
    }
    const counts = /* @__PURE__ */ new Map();
    rows2.forEach(
      (r) => counts.set(r.field.key, (counts.get(r.field.key) ?? 0) + 1)
    );
    return rows2.filter((r) => counts.get(r.field.key) === 1).slice(0, 300);
  }
  var USUAL_SHIPPING = { cost: 1.99, freeOver: 10, usual: true };
  var shippingFor = (cost, s) => s && !(s.freeOver !== null && cost >= s.freeOver) ? s.cost : 0;
  function resolveQuantities(doc) {
    return resolvePrices(doc).flatMap((r) => {
      const row = r.el.closest("tr");
      const input = row?.querySelector('input[cn="qty"]');
      if (!input || input.disabled || input.readOnly || input.type === "hidden")
        return [];
      return [
        {
          el: input,
          field: {
            ...r.field,
            key: r.field.key.replace(/^price:/, "quantity:"),
            value: input.value,
            selector: 'input[cn="qty"]'
          }
        }
      ];
    });
  }
  function resolveSimplePrice(doc) {
    if (doc.querySelector(
      '.summary__variations button[aria-label^="Pricing: Price:"], [data-testid="variation-selector"]'
    ))
      return null;
    const candidates = queryAll(doc, SELECTORS.simplePrice).filter(
      (el3) => el3.tagName === "INPUT" && !el3.hasAttribute("disabled") && !el3.hasAttribute("readonly") && el3.type !== "hidden" && !el3.closest("table")
    );
    if (candidates.length !== 1) return null;
    const el2 = candidates[0];
    return {
      el: el2,
      field: {
        key: "price:simple",
        label: "Price",
        value: el2.value,
        kind: "text",
        writable: true,
        selector: "single price"
      }
    };
  }
  function resolveSimpleQuantity(doc) {
    if (doc.querySelector(
      '.summary__variations button[aria-label^="Pricing: Price:"], [data-testid="variation-selector"]'
    ))
      return null;
    const candidates = queryAll(doc, [
      'input[name="quantity"]',
      'input[aria-label="Quantity"]',
      'input[id$="-quantity"]'
    ]).filter(
      (el3) => el3.tagName === "INPUT" && !el3.hasAttribute("disabled") && !el3.hasAttribute("readonly") && !el3.closest('table,[hidden],[aria-hidden="true"]') && ["text", "number", ""].includes(el3.getAttribute("type") ?? "") && doc.defaultView?.getComputedStyle(el3).display !== "none"
    );
    if (candidates.length !== 1) return null;
    const el2 = candidates[0];
    return {
      el: el2,
      field: {
        key: "quantity:simple",
        label: "Quantity",
        value: el2.value,
        kind: "text",
        writable: true,
        selector: "single inventory quantity"
      }
    };
  }

  // src/core/supplierImport.ts
  var DEFAULT_IMPORT_QUANTITY = 3;

  // src/core/country.ts
  var codes = "AD AE AF AG AI AL AM AO AQ AR AS AT AU AW AX AZ BA BB BD BE BF BG BH BI BJ BL BM BN BO BQ BR BS BT BV BW BY BZ CA CC CD CF CG CH CI CK CL CM CN CO CR CU CV CW CX CY CZ DE DJ DK DM DO DZ EC EE EG EH ER ES ET FI FJ FK FM FO FR GA GB GD GE GF GG GH GI GL GM GN GP GQ GR GS GT GU GW GY HK HM HN HR HT HU ID IE IL IM IN IO IQ IR IS IT JE JM JO JP KE KG KH KI KM KN KP KR KW KY KZ LA LB LC LI LK LR LS LT LU LV LY MA MC MD ME MF MG MH MK ML MM MN MO MP MQ MR MS MT MU MV MW MX MY MZ NA NC NE NF NG NI NL NO NP NR NU NZ OM PA PE PF PG PH PK PL PM PN PR PS PT PW PY QA RE RO RS RU RW SA SB SC SD SE SG SH SI SJ SK SL SM SN SO SR SS ST SV SX SY SZ TC TD TF TG TH TJ TK TL TM TN TO TR TT TV TW TZ UA UG UM US UY UZ VA VC VE VG VI VN VU WF WS YE YT ZA ZM ZW".split(
    " "
  );
  var names = new Intl.DisplayNames(["en"], { type: "region" });
  var map = /* @__PURE__ */ new Map();
  for (const code of codes) {
    const name = names.of(code);
    map.set(norm(code), name);
    map.set(norm(name), name);
  }
  for (const [alias, name] of Object.entries({
    "mainland china": "China",
    "cn origin": "China",
    "china mainland": "China",
    "china origin": "China",
    prc: "China",
    "people s republic of china": "China",
    usa: "United States",
    "u s a": "United States",
    "united states of america": "United States",
    uk: "United Kingdom",
    "great britain": "United Kingdom",
    "south korea": "South Korea",
    "republic of korea": "South Korea",
    taiwan: "Taiwan",
    vietnam: "Vietnam",
    turkey: "T\xFCrkiye"
  }))
    map.set(norm(alias), name);
  function normalizeCountry(value) {
    return map.get(norm(value)) ?? null;
  }
  function manufactureLabel(label4) {
    return [
      "origin",
      "country region of manufacture",
      "country of manufacture",
      "country of origin",
      "manufactured in",
      "made in",
      "origine",
      "pays de fabrication",
      "pays d origine"
    ].includes(norm(label4));
  }

  // src/aliexpress/images.ts
  function supplierImageURL(value) {
    try {
      const u = new URL(value.startsWith("//") ? "https:" + value : value);
      if (u.protocol !== "https:" || u.username || u.password || u.port || !/(^|\.)(alicdn\.com|aliexpress-media\.com)$/.test(u.hostname))
        return null;
      u.pathname = u.pathname.replace(
        /\.(jpg|jpeg|png|webp)(?:_\d+x\d+[^/]*)?(?:_\.avif)?$/i,
        ".$1"
      );
      u.hash = "";
      for (const key of [...u.searchParams.keys()]) {
        if (!["has_lang", "ver"].includes(key)) u.searchParams.delete(key);
        else
          u.searchParams.set(
            key,
            u.searchParams.get(key).replace(/_\d+x\d+.*$/, "")
          );
      }
      if (!/\.(jpe?g|png|webp)$/i.test(u.pathname)) return null;
      return u.href;
    } catch {
      return null;
    }
  }
  function descriptionImageURL(value) {
    const strict = supplierImageURL(value.replace(/^http:\/\//i, "https://"));
    if (strict) return strict;
    try {
      const u = new URL(value.startsWith("//") ? "https:" + value : value.replace(/^http:\/\//i, "https://"));
      if (u.protocol !== "https:" || u.username || u.password || u.port || !/(^|\.)(alicdn\.com|aliexpress-media\.com)$/.test(u.hostname) || /\.(svg|js|html?)$/i.test(u.pathname))
        return null;
      u.hash = "";
      return u.href;
    } catch {
      return null;
    }
  }
  function ebayListingImageURL(value) {
    try {
      const u = new URL(value.startsWith("//") ? "https:" + value : value);
      const id = u.pathname.match(/^\/images\/g\/([A-Za-z0-9~_-]{6,40})\/s-l\d+\.(?:jpe?g|png|webp)$/i)?.[1];
      if (u.protocol !== "https:" || u.username || u.password || u.port || u.hostname !== "i.ebayimg.com" || !id)
        return null;
      return `https://i.ebayimg.com/images/g/${id}/s-l1600.jpg`;
    } catch {
      return null;
    }
  }

  // src/ebay/savedDraft.ts
  var SCAN_LIMIT = 3 * 1024 * 1024;

  // src/ebay/draftApi.ts
  var HTML_LIMIT = 8 * 1024 * 1024;
  function supplierIdFromSku(sku) {
    return sku?.trim().match(/^AE-(\d{6,20})(?:-\d+)?$/)?.[1] ?? null;
  }

  // src/core/sales.ts
  var CURRENCY = {
    $: "USD",
    "US $": "USD",
    "\u20AC": "EUR",
    "EU \u20AC": "EUR",
    "\xA3": "GBP",
    "C $": "CAD",
    "AU $": "AUD"
  };
  function parseMoney(text2) {
    if (!text2) return null;
    const t = text2.replace(/ /g, " ").trim();
    const m = t.match(
      /^(-)?\s*(US \$|EU €|C \$|AU \$|\$|€|£)\s*(\d{1,3}(?:[,\s]\d{3})+(?:\.\d+)?|\d+(?:\.\d+)?)/
    );
    if (!m) return null;
    const amount = Number(m[3].replace(/[,\s]/g, ""));
    if (!Number.isFinite(amount)) return null;
    return {
      amount: Math.round((m[1] ? -amount : amount) * 100) / 100,
      currency: CURRENCY[m[2]] ?? "USD"
    };
  }
  function parseRate(text2) {
    const m = text2.match(/\$\s?1(?:[.,]00)?\s*=\s*(?:EU\s*)?[€£]\s?(\d+(?:[.,]\d+)?)/);
    const rate = m ? Number(m[1].replace(",", ".")) : 0;
    return rate > 0 ? rate : null;
  }
  var TAX = /\b(sales tax|tax(es)?|VAT|GST|TVA|import charges?)\b/i;
  var own = (e) => (e?.textContent ?? "").replace(/\s+/g, " ").trim();
  function dataItems(root, section) {
    return [...root.querySelectorAll(`${section} .data-item`)].map((item2) => ({
      label: own(item2.querySelector("dt")).replace(/\*+$/, ""),
      value: own(item2.querySelector("dd"))
    }));
  }
  function leafAfterLabel(root, label4) {
    for (const el2 of root.querySelectorAll("dt, .info-label, span, div")) {
      if (el2.childElementCount || !label4.test(own(el2))) continue;
      const host = el2.closest("dt, .info-label") ?? el2;
      const next = host.nextElementSibling ?? host.parentElement?.nextElementSibling ?? null;
      const value = own(next?.querySelector(".tooltip__host") ?? next);
      if (value) return value.replace(/Copy to clipboard$/i, "").trim();
    }
    return "";
  }
  function parseEbayOrder(root, url) {
    const orderId = new URL(url).searchParams.get("orderid") ?? own(root.querySelector(".order-info .data-item dd")) ?? "";
    if (!/^\d{2}-\d{5}-\d{5}$/.test(orderId))
      throw Error("Num\xE9ro de commande eBay introuvable sur cette page.");
    const items = [...root.querySelectorAll(".lineItemCardInfo__content")].map(
      (card2) => {
        const title = own(card2.querySelector(".PSEUDOLINK, a[href*='/itm/']"));
        const itemId = own(card2.querySelector(".lineItemCardInfo__itemId")).match(/(\d{9,15})/)?.[1] ?? null;
        const sku = own(card2.querySelector(".lineItemCardInfo__sku")).replace(
          /^Custom label \(SKU\):\s*/i,
          ""
        ) || null;
        const variation = [...card2.querySelectorAll(".lineItemCardInfo__aspects .sh-bold")].map(own).join(" ").replace(/\s*·\s*$/, "").replace(/:\s+/g, ": ").trim();
        const quantity = Number(own(card2.querySelector(".quantity__value .sh-bold")) || "1");
        return {
          title,
          itemId,
          variation,
          quantity: Number.isInteger(quantity) && quantity > 0 ? quantity : 1,
          price: parseMoney(own(card2.querySelector(".soldPrice__value"))),
          sku,
          supplierId: supplierIdFromSku(sku)
        };
      }
    );
    const paid = dataItems(root, ".buyer-paid");
    const earn = dataItems(root, ".earnings");
    const pick = (rows2, re) => parseMoney(rows2.find((r) => re.test(r.label))?.value);
    const fees = earn.filter((r) => !/^Order (total|earnings)/i.test(r.label) && !TAX.test(r.label)).map((r) => ({
      label: r.label.replace(/(Transaction fees).*/i, "$1").slice(0, 60),
      amount: parseMoney(r.value)
    })).filter((f) => f.amount && f.amount.amount < 0);
    let earnings = pick(earn, /^Order earnings/i);
    if (!earnings) {
      let node = [...root.querySelectorAll("dt, .label, span, button")].find(
        (e) => !e.childElementCount && own(e) === "Order earnings"
      ) ?? null;
      for (let i = 0; node && i < 10 && !earnings; i++, node = node.parentElement) {
        const after = own(node).split("Order earnings").pop() ?? "";
        const money3 = after.match(/-?\s*(?:EU €|US \$|\$|€|£)\s?[\d.,]+/);
        if (money3) earnings = parseMoney(money3[0]);
      }
    }
    const refundRow = pick(paid, /^Refund/i) ?? pick(earn, /^Refund/i);
    const refund = refundRow && refundRow.amount !== 0 ? { ...refundRow, amount: Math.abs(refundRow.amount) } : null;
    const earnText = own(root.querySelector(".earnings"));
    const box2 = root.querySelector(".shipping-address");
    let address = null;
    if (box2) {
      const fields = {};
      for (const host of box2.querySelectorAll(".tooltip__host")) {
        const tip = own(host.parentElement?.querySelector(".tooltip__content"));
        const value = own(host);
        if (!value) continue;
        const key = tip.match(/Copy (name|street|city|state|zip|country)/i)?.[1].toLowerCase() ?? (/^Copy to clipboard$/i.test(tip) && fields.name && !fields.city ? "street" : void 0);
        if (key) (fields[key] ??= []).push(value);
      }
      address = {
        name: fields.name?.[0] ?? "",
        street1: fields.street?.[0] ?? "",
        street2: fields.street?.slice(1).join(", ") ?? "",
        city: fields.city?.[0] ?? "",
        state: fields.state?.[0] ?? "",
        zip: fields.zip?.[0] ?? "",
        country: fields.country?.[0] ?? "",
        phone: leafAfterLabel(root, /^Phone$/)
      };
    }
    const soldText = leafAfterLabel(root, /^Sold$/);
    const soldAt = soldText ? Date.parse(soldText) : NaN;
    const numbers = new Set(
      [...root.querySelectorAll(".tracking-info .value .fake-link:not(.edit-link), .tracking-info .value a, .tracking-number")].map(own).filter((t) => /^[A-Z0-9-]{8,40}$/i.test(t) && !/^-+$/.test(t))
    );
    let trackedItems = 0;
    for (const card2 of root.querySelectorAll(".lineItemCardInfo__content")) {
      const block = card2.parentElement ?? card2;
      const found = own(block).match(/Tracking\s*:?\s*([A-Z0-9]{8,40})/i)?.[1]?.replace(/(Edit|Quantity|Tracking|Carrier|Shipped).*$/i, "");
      if (found && /\d/.test(found)) {
        numbers.add(found);
        trackedItems++;
      }
    }
    const tracking = [...numbers].join(", ");
    const pageText = own(root.querySelector("main") ?? root.body ?? null);
    return {
      address,
      sale: {
        orderId,
        soldAt: Number.isFinite(soldAt) ? soldAt : null,
        buyer: address?.name ?? "",
        country: address?.country ?? "",
        zip: address?.zip ?? "",
        city: address?.city ?? "",
        items,
        subtotal: pick(paid, /^Subtotal/i),
        shipping: pick(paid, /^Shipping/i),
        tax: pick(paid, TAX),
        orderTotal: pick(earn, /^Order total/i),
        ...refund ? { refund } : {},
        fees,
        earnings,
        rate: parseRate(earnText),
        status: /order (was )?cancell?ed|Cancellation complete/i.test(pageText) ? "cancelled" : tracking && !/^-+$/.test(tracking) ? "shipped" : "to_ship",
        tracking: tracking && !/^-+$/.test(tracking) ? tracking : "",
        ...items.length > 1 ? { trackedItems } : {}
      }
    };
  }
  function guessCarrier(tracking, aliCarrier = "") {
    const t = tracking.toUpperCase().trim();
    const c = aliCarrier.toLowerCase();
    if (/cainiao/.test(c)) return "Cainiao";
    if (/yun/.test(c)) return "Yun Express";
    if (/4px/.test(c)) return "4PX";
    if (/yanwen/.test(c)) return "YANWEN";
    if (/sunyou|shunyou/.test(c)) return "Shunyou Post";
    if (/^SY/.test(t)) return "Shunyou Post";
    if (/^YT/.test(t)) return "Yun Express";
    if (/^(UUS|UB)/.test(t)) return "UBI";
    if (/^WNB/.test(t)) return "Wanb Express";
    if (/^1Z/.test(t)) return "UPS";
    if (/^9[2-5]\d{18,24}$/.test(t)) return "USPS";
    if (/^[A-Z]{2}\d{9}CN$/.test(t)) return "China Post";
    if (/^(4PX|P0)/.test(t)) return "4PX";
    if (/^(LP|CN|AE|CAINIAO)/.test(t)) return "Cainiao";
    return "Cainiao";
  }

  // src/core/profit.ts
  var EBAY_PERCENT = (0.136 + 0.0165) * 1.07;
  var round = (n) => Math.round(n * 100) / 100;
  function estimateProfit(priceUSD, costUSD, m, shipping = USUAL_SHIPPING) {
    const revenue = priceUSD * m.rate;
    const fees = revenue * m.feeRate + (m.feeFixed ?? 0) * m.rate;
    const supplier = (costUSD + shippingFor(costUSD, shipping)) * (1 + m.aliExtra) * m.rate;
    const charges = revenue * m.charges;
    return {
      revenue: round(revenue),
      fees: round(fees),
      supplier: round(supplier),
      charges: round(charges),
      net: round(revenue - fees - supplier - charges)
    };
  }
  function minimumPrice(costUSD, m, target = 0, shipping = USUAL_SHIPPING) {
    const keep = 1 - m.feeRate - m.charges;
    if (keep <= 0 || m.rate <= 0) return null;
    const exact = ((costUSD + shippingFor(costUSD, shipping)) * (1 + m.aliExtra) * m.rate + (m.feeFixed ?? 0) * m.rate + target) / (m.rate * keep);
    const whole = Math.floor(exact);
    for (const candidate of [whole + 0.49, whole + 0.99, whole + 1.49])
      if (candidate >= exact - 1e-9) return round(candidate);
    return round(whole + 1.99);
  }

  // src/core/supplierSearch.ts
  var STOP = new Set(
    "a an and the for with of to in on by from at as or is new hot sale free shipping fast usa us uk lot pcs pc set piece pieces 1pc 1pcs 2pcs women men womens mens unisex".split(
      " "
    )
  );
  var SAME_PHOTO = 0.92;
  var CLOSE_PHOTO = 0.85;
  function pickSupplier(candidates) {
    const priced = candidates.filter((c) => c.price !== null);
    const exact = priced.filter((c) => (c.photo ?? 0) >= SAME_PHOTO).sort((a, b) => a.price - b.price)[0];
    const close = exact ? null : priced.filter((c) => (c.photo ?? 0) >= CLOSE_PHOTO).sort((a, b) => b.photo - a.photo)[0];
    const best = exact ?? close;
    return {
      kind: exact ? "exact" : close ? "close" : "none",
      best: best ? { url: best.url, price: best.price, currency: best.currency, photo: best.photo, title: best.title } : null,
      count: candidates.length
    };
  }
  function rankAllPhotos(searches) {
    const byUrl = /* @__PURE__ */ new Map();
    for (const { ebayPhoto, candidates } of searches)
      for (const c of candidates) {
        if (!c.price || c.currency !== "USD" && c.currency !== null) continue;
        const had = byUrl.get(c.url);
        if (!had) byUrl.set(c.url, { ...c, ebayPhotos: [ebayPhoto] });
        else {
          if (!had.ebayPhotos.includes(ebayPhoto)) had.ebayPhotos.push(ebayPhoto);
          if ((c.photo ?? -1) > (had.photo ?? -1))
            Object.assign(had, { photo: c.photo, photoIndex: c.photoIndex, photoTotal: c.photoTotal });
        }
      }
    const list = [...byUrl.values()];
    const cheapest = Math.min(...list.map((c) => c.price));
    const scored = list.map((c) => {
      const photo = c.photo ?? 0.35;
      const exact = photo >= SAME_PHOTO ? 2 : photo >= CLOSE_PHOTO ? 0.6 : 0;
      const several = Math.min(3, c.ebayPhotos.length - 1) * 0.25;
      const price2 = cheapest / c.price * 0.6;
      return { ...c, ebayPhotos: c.ebayPhotos.sort((a, b) => a - b), score: Math.round((exact + photo + several + price2) * 1e3) / 1e3 };
    });
    return scored.sort((a, b) => b.score - a.score || a.price - b.price);
  }

  // src/ebay/gallery.ts
  function ebayGallery(doc, max = 40) {
    const seen = /* @__PURE__ */ new Set();
    const out = [];
    for (const img of doc.querySelectorAll(".ux-image-carousel-item img")) {
      const url = [img.getAttribute("data-zoom-src"), img.getAttribute("data-src"), img.getAttribute("src")].find(
        (u) => !!u && /^https:\/\/i\.ebayimg\.com\/images\/g\/[^/]+\/s-l\d+\.\w+/.test(u)
      );
      const id = url ? ebayPictureId(url) : null;
      if (!url || !id || seen.has(id)) continue;
      seen.add(id);
      out.push(url.replace(/\/s-l\d+(\.\w+)(\?.*)?$/, "/s-l500$1"));
      if (out.length >= max) break;
    }
    return out;
  }
  var ebayPictureId = (url) => url.match(/\/images\/g\/([^/]+)\//)?.[1] ?? null;
  async function fetchEbayGallery(itemId) {
    if (!/^\d{9,15}$/.test(itemId)) return [];
    const response = await fetch(`/itm/${itemId}`, { credentials: "include" });
    if (!response.ok) return [];
    return ebayGallery(new DOMParser().parseFromString(await response.text(), "text/html"));
  }

  // src/core/aliVerify.ts
  var ALI_VERIFY_URL = "https://www.aliexpress.us/";
  var asksAliVerify = (text2) => typeof text2 === "string" && /AliExpress (demande|a demandé) une vérification/.test(text2);
  var aliVerifyLink = (style = "") => `<a href="${ALI_VERIFY_URL}" target="_blank" rel="noopener" class="ali-verify"${style ? ` style="${style}"` : ""}>\u{1F513} Ouvrir AliExpress pour faire la v\xE9rification \u2197</a>`;
  var ALI_COOKIES = "AliExpress refuse les recherches : trop de cookies AliExpress dans Chrome";
  var ALI_COOKIES_TEXT = `${ALI_COOKIES} (erreur \xAB Cookie Too Large \xBB). Clique \xAB \u{1F9F9} Nettoyer AliExpress dans Chrome \xBB, supprime les donn\xE9es d\u2019aliexpress (ic\xF4ne corbeille), reconnecte-toi sur aliexpress.us, puis relance.`;
  var asksAliCookies = (text2) => typeof text2 === "string" && text2.includes(ALI_COOKIES);
  var aliCookiesButton = (style = "") => `<button type="button" class="ali-cookies" data-ali-cookies${style ? ` style="${style}"` : ""}>\u{1F9F9} Nettoyer AliExpress dans Chrome</button>`;
  var ALI_REGION = "AliExpress n\u2019est pas pr\xEAt pour les \xC9tats-Unis";
  var asksAliRegion = (text2) => typeof text2 === "string" && text2.includes(ALI_REGION);
  var aliRegionLink = (style = "") => `<a href="${ALI_VERIFY_URL}" target="_blank" rel="noopener" class="ali-verify"${style ? ` style="${style}"` : ""}>\u{1F1FA}\u{1F1F8} Ouvrir AliExpress US \u2197</a>`;

  // src/ebay/supplierFinderPanel.ts
  var errorHTML = (e) => {
    const text2 = String(e instanceof Error ? e.message : e);
    return `<p class="err">\u26A0 ${text2.replace(/[<>&]/g, "")}${asksAliRegion(text2) ? `<br>${aliRegionLink()}` : asksAliCookies(text2) ? `<br>${aliCookiesButton()}` : asksAliVerify(text2) ? `<br>${aliVerifyLink()}` : ""}</p>`;
  };
  var CSS3 = `${BRAND_CSS}
  :host{${WINDOW_TOKENS}}
  .ov{position:fixed;inset:5vh 50% auto auto;transform:translateX(50%);width:min(980px,94vw);max-height:90vh;z-index:2147483646;display:flex;flex-direction:column;background:var(--bg);color:var(--ink);border:1px solid var(--line);border-radius:18px;box-shadow:0 30px 80px rgba(10,6,16,.55);font:14px/1.45 -apple-system,system-ui,sans-serif;overflow:hidden;animation:ao-rise .4s var(--ao-ease)}
  header{display:flex;justify-content:space-between;align-items:center;gap:12px;padding:14px 18px;background:var(--ao-gradient);color:#fff}
  header b{display:flex;align-items:center;gap:10px;font-size:17px}
  header button{background:none;border:0;color:#fff;font-size:22px;cursor:pointer}
  .sub{padding:10px 18px;color:var(--muted);border-bottom:1px solid var(--line);font-size:13px}
  .sub a{color:var(--ink)}
  .wait{display:grid;place-items:center;gap:14px;padding:48px 18px;color:var(--muted)}
  .wait .ao-loader{--ao-size:76px}
  .body{flex:1;min-height:0;overflow:auto}
  .foot{flex:none}
  .grid{padding:14px 18px;display:grid;grid-template-columns:repeat(auto-fill,minmax(290px,1fr));gap:12px}
  .card{display:flex;gap:12px;padding:10px;border:1px solid var(--line);border-radius:14px;background:var(--bg2);animation:ao-rise .45s var(--ao-ease) both;transition:transform .25s var(--ao-ease),border-color .25s}
  .card:hover{transform:translateY(-2px);border-color:color-mix(in srgb,var(--accent) 40%,var(--line))}
  .card.best{border-color:var(--accent);box-shadow:0 0 0 1px var(--accent) inset}
  .card img{width:96px;height:96px;object-fit:cover;border-radius:10px;background:#000;flex:none}
  .t{display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;font-size:13px;margin-bottom:4px}
  .price{font-size:17px;font-weight:750}
  .meta{font-size:12px;color:var(--muted);margin:2px 0}
  .tags{display:flex;flex-wrap:wrap;gap:4px;margin:4px 0}
  .tag{padding:1px 7px;border-radius:99px;font-size:11px;font-weight:700;background:rgba(255,255,255,.08)}
  .tag.photo{background:var(--ao-gradient);color:#fff}
  .tag.choice{background:#ffcf3f;color:#2a1a05}
  .net{font-size:12.5px;margin:4px 0}
  .net b.pos{color:var(--ok)}.net b.neg{color:var(--err)}
  .acts{display:flex;gap:6px;margin-top:6px}
  .acts a,.acts button{font:600 12px system-ui;padding:5px 10px;border-radius:9px;border:1px solid var(--line);background:transparent;color:var(--ink);cursor:pointer;text-decoration:none}
  .acts{flex-wrap:wrap}
  .acts a.go{background:var(--ao-gradient);border-color:transparent;color:#fff}
  .acts button.draft{border-color:var(--accent);font-weight:700}
  .acts button.draft:disabled{opacity:.7;cursor:default}
  .draft-note{margin-top:6px;font-size:12px;color:var(--muted)}
  .draft-note.bad{color:var(--err)}
  .foot{padding:10px 18px;border-top:1px solid var(--line);font-size:11.5px;color:var(--muted)}
  .err{padding:30px 18px;color:var(--err)}
  .err .ali-cookies{display:inline-block;margin-top:12px;padding:8px 14px;border:0;border-radius:10px;background:#ff6a00;color:#fff;font:inherit;font-weight:700;cursor:pointer}
  .err .ali-verify{display:inline-block;margin-top:12px;padding:8px 14px;border-radius:10px;background:#ff6a00;color:#fff;font-weight:700;text-decoration:none}
  .redo{margin-left:6px;border:1px solid var(--line);background:transparent;color:var(--ink);border-radius:99px;padding:2px 10px;font:600 12px system-ui;cursor:pointer}
  .redo:hover{border-color:var(--accent)}
  .checking{color:var(--ink)}
  .pick{display:flex;align-items:center;gap:8px;padding:8px 18px;border-bottom:1px solid var(--line);font-size:12.5px;color:var(--muted)}
  .pick>span{flex:none;max-width:150px;line-height:1.3}
  .strip{display:flex;gap:6px;overflow-x:auto;padding:2px}
  .strip button{flex:none;width:52px;height:52px;padding:0;border-radius:9px;border:2px solid transparent;background:#000;cursor:pointer;overflow:hidden;opacity:.65;transition:opacity .2s,border-color .2s,transform .2s var(--ao-ease)}
  .strip button:hover{opacity:1;transform:translateY(-1px)}
  .strip button.on{border-color:var(--accent);opacity:1;box-shadow:0 0 0 2px color-mix(in srgb,var(--accent) 35%,transparent)}
  .strip img{width:100%;height:100%;object-fit:cover;display:block}
  .joker{margin-left:6px;border:0;background:var(--ao-gradient);color:#fff;border-radius:99px;padding:3px 11px;font:700 12px system-ui;cursor:pointer}
  .joker:hover{filter:brightness(1.08)}
  .allbar{width:min(360px,80%);height:6px;border-radius:99px;background:var(--line);overflow:hidden}
  .allbar i{display:block;height:100%;width:0;background:var(--ao-gradient);transition:width .4s var(--ao-ease)}
  .allsub{font-size:12.5px;color:var(--muted);min-height:1.2em;text-align:center}
  .tag.hits{background:color-mix(in srgb,var(--accent) 25%,transparent)}
`;
  var money2 = (n, cur) => n.toLocaleString("fr-FR", { style: "currency", currency: cur });
  function openSupplierFinder(doc, input) {
    input = { ...input, image: input.image.replace(/\/s-l\d+(\.\w+)(\?.*)?$/, "/s-l500$1") };
    doc.getElementById("auroebay-supplier-finder")?.remove();
    const host = doc.createElement("div");
    host.id = "auroebay-supplier-finder";
    const root = host.attachShadow({ mode: "open" });
    root.innerHTML = `<style>${CSS3}</style><div class="ov" role="dialog" aria-label="Fournisseurs AliExpress">
    <header class="ao-sweep"><b><span class="ao-mark" style="width:28px;height:28px"></span>${(input.heading ?? "Fournisseurs AliExpress").replace(/[<>&]/g, "")}</b><button type="button" title="Fermer">\u2715</button></header>
    <div class="pick" hidden><span>Photo \xE0 chercher :</span><div class="strip"></div></div>
    <div class="sub"></div>
    <div class="body"><div class="wait"><div class="ao-loader"><span class="ao-mark"></span></div><span>Recherche sur AliExpress et comparaison des photos\u2026</span></div></div>
    <div class="foot">Recherche par photo : choisis en haut la photo \xE0 chercher si la principale a \xE9t\xE9 retouch\xE9e. La photo choisie est ensuite compar\xE9e \xE0 toutes les photos des premiers produits : \xAB \u{1F4F8} Photo exacte \xB7 3/6 \xBB = c\u2019est la 3e photo de ce produit AliExpress, on tient le bon. Prix affich\xE9s par AliExpress pour ton compte, hors taxe US et livraison. R\xE9sultats m\xE9moris\xE9s 7 jours. ${input.draft ? "Rien n\u2019est achet\xE9 ni publi\xE9 : \xAB \u{1F4DD} Faire le brouillon \xBB cr\xE9e seulement un brouillon eBay, c\u2019est toi qui publies." : "Lecture seule : rien n\u2019est achet\xE9 ni cr\xE9\xE9."}</div>
  </div>`;
    root.querySelector("header button").addEventListener("click", () => host.remove());
    const sub = root.querySelector(".sub");
    const pick = root.querySelector(".pick");
    const strip = root.querySelector(".strip");
    let chosen = input.image;
    const mainId = ebayPictureId(input.image);
    let gallery = [];
    let lastShown = null;
    const pictures = (list) => {
      const all = list.length ? list : [input.image];
      if (all.length < 2 || !host.isConnected) return;
      gallery = all;
      if (lastShown) show(lastShown.result, lastShown.model);
      pick.hidden = false;
      strip.replaceChildren(
        ...all.map((url, i) => {
          const b = Object.assign(doc.createElement("button"), {
            type: "button",
            title: i === 0 ? "Photo principale" : `Photo ${i + 1}`
          });
          b.dataset.url = url;
          if (ebayPictureId(url) === ebayPictureId(chosen)) b.className = "on";
          const img = Object.assign(doc.createElement("img"), { src: url.replace(/\/s-l\d+(\.\w+)$/, "/s-l140$1"), alt: "" });
          img.referrerPolicy = "no-referrer";
          b.append(img);
          b.addEventListener("click", () => {
            if (b.className === "on" && chosen) return;
            chosen = url;
            strip.querySelectorAll("button").forEach((x) => x.className = x === b ? "on" : "");
            run(false);
          });
          return b;
        })
      );
    };
    const body = root.querySelector(".body");
    body.addEventListener("click", (e) => {
      if (e.target.closest("[data-ali-cookies]")) void message({ type: "OPEN_ALI_COOKIES" }).catch(() => {
      });
    });
    sub.textContent = `${input.heading ? "Produit" : "Annonce eBay"} : ${input.title.slice(0, 120)}`;
    doc.documentElement.append(host);
    const show = (result, model) => {
      if (!host.isConnected) return;
      lastShown = { result, model };
      const all = result.photos !== void 0;
      sub.innerHTML = "";
      const when = new Date(result.at).toLocaleString("fr-FR", { dateStyle: "short", timeStyle: "short" });
      sub.append(
        all ? result.checking ? `\u{1F0CF} Recherche compl\xE8te en cours \xB7 ${result.photos} photo(s) faite(s) \xB7 ${result.compared} produits class\xE9s jusqu\u2019ici (photos puis prix)` : `\u{1F0CF} Recherche compl\xE8te \xB7 ${result.photos} photos${result.failed ? ` (${result.failed} sans r\xE9sultat)` : ""} \xB7 ${result.compared} produits AliExpress class\xE9s (photos puis prix) \xB7 faite le ${when}` : `${result.mode === "image" ? "Recherche par photo" : "Recherche par mots (photo indisponible)"} \xB7 ${result.compared} r\xE9sultats \xB7 ${result.cached ? `m\xE9moris\xE9e le ${when}` : `faite le ${when}`}`
      );
      if (result.checking) {
        const busy = doc.createElement("span");
        busy.className = "checking";
        busy.innerHTML = ' \xB7 <span class="ao-spinner"></span> v\xE9rification des photos\u2026';
        sub.append(busy);
      } else {
        const redo = Object.assign(doc.createElement("button"), { className: "redo", type: "button", textContent: "\u21BB Relancer" });
        redo.addEventListener("click", () => all ? runAll(true) : run(true));
        sub.append(redo);
        if (!all && gallery.length >= 2) {
          const joker = Object.assign(doc.createElement("button"), {
            className: "joker",
            type: "button",
            textContent: `\u{1F0CF} Joker : chercher avec les ${Math.min(10, gallery.length)} photos`,
            title: "Cherche sur AliExpress avec chaque photo de l\u2019annonce, puis classe tous les r\xE9sultats selon les photos et le prix. Plus long (environ 15 s par photo)."
          });
          joker.addEventListener("click", () => runAll(false));
          sub.append(joker);
        }
      }
      if (result.mode === "text")
        sub.append(
          " \xB7 ",
          Object.assign(doc.createElement("a"), { href: result.searchUrl, target: "_blank", rel: "noopener", textContent: "voir la recherche \u2197" })
        );
      if (!result.candidates.length) {
        body.innerHTML = `<p class="err">Aucun r\xE9sultat. Essaie \xAB \u21BB Relancer \xBB${!all && gallery.length >= 2 ? ", une autre photo, ou le \xAB \u{1F0CF} Joker \xBB (toutes les photos)." : " ou une autre photo."}${result.mode === "text" ? `<br><small>La recherche par photo n\u2019a pas march\xE9 : si \xE7a se r\xE9p\xE8te, AliExpress demande s\xFBrement sa v\xE9rification.</small><br>${aliVerifyLink()}` : ""}</p>`;
        return;
      }
      const grid = doc.createElement("div");
      grid.className = "grid";
      result.candidates.forEach((c, i) => grid.append(card(doc, c, i, input.price, model, !result.checking, input.draft === true)));
      body.replaceChildren(grid);
    };
    let allRun = 0;
    const runAll = (fresh) => {
      const run2 = ++allRun;
      const photos = gallery.slice(0, 10);
      strip.querySelectorAll("button").forEach((x) => x.className = "");
      chosen = "";
      sub.textContent = `\u{1F0CF} Recherche compl\xE8te : chacune des ${photos.length} photos sur AliExpress\u2026`;
      body.innerHTML = `<div class="wait"><div class="ao-loader"><span class="ao-mark"></span></div><span class="allstep">Pr\xE9paration\u2026</span><span class="allsub muted"></span><div class="allbar"><i></i></div></div>`;
      let step = body.querySelector(".allstep");
      let detail = body.querySelector(".allsub");
      let bar = body.querySelector(".allbar i");
      const model = message({ type: "PROFIT_MODEL" }).catch(() => null);
      const searches = [];
      let failed = 0;
      let request = "";
      let index = 0;
      const listen = (msg) => {
        if (msg?.type !== "FIND_SUPPLIERS_STEP" || msg.request !== request || run2 !== allRun || !detail.isConnected) return;
        detail.textContent = `${msg.text ?? ""}${msg.total ? ` ${msg.done}/${msg.total}` : ""}`;
        bar.style.width = `${Math.round((index + (msg.total ? (msg.done ?? 0) / msg.total : 0.3)) / photos.length * 100)}%`;
      };
      chrome.runtime.onMessage.addListener(listen);
      const results = (m, done) => {
        const ranked = rankAllPhotos(searches);
        return { mode: "image", words: [], searchUrl: "", candidates: ranked.slice(0, 30), compared: ranked.length, at: Date.now(), photos: done ? photos.length : index + 1, failed, checking: !done };
      };
      void (async () => {
        const m = await model;
        for (index = 0; index < photos.length; index++) {
          if (run2 !== allRun || !host.isConnected) return;
          const url = photos[index];
          request = `${Date.now()}-${Math.random()}`;
          const found = searches.reduce((n, s) => n + s.candidates.length, 0);
          step.textContent = `Photo ${index + 1}/${photos.length} sur AliExpress\u2026 \xB7 ${found} produits trouv\xE9s jusqu\u2019ici`;
          detail.textContent = "";
          bar.style.width = `${Math.round(index / photos.length * 100)}%`;
          try {
            const r = await Promise.race([
              message({
                type: "FIND_SUPPLIERS",
                title: input.title,
                image: url,
                itemId: input.itemId ?? null,
                photo: index > 0 && ebayPictureId(url) !== mainId ? ebayPictureId(url) : null,
                fresh,
                request
              }),
              new Promise((_, reject) => setTimeout(() => reject(Error("trop long")), 24e4))
            ]);
            if (r.mode === "image" && r.candidates.length) searches.push({ ebayPhoto: index + 1, candidates: r.candidates });
            else failed++;
          } catch {
            failed++;
          }
          if (searches.length && run2 === allRun && index + 1 < photos.length) {
            show(results(m, false), m);
            body.prepend(
              Object.assign(doc.createElement("div"), {
                className: "wait",
                innerHTML: `<span class="allstep"></span><span class="allsub muted"></span><div class="allbar"><i></i></div>`
              })
            );
            step = body.querySelector(".allstep");
            detail = body.querySelector(".allsub");
            bar = body.querySelector(".allbar i");
          }
        }
        if (run2 === allRun && host.isConnected) show(results(m, true), m);
      })().catch((e) => {
        if (host.isConnected) body.innerHTML = errorHTML(e);
      }).finally(() => chrome.runtime.onMessage.removeListener(listen));
    };
    const run = (fresh) => {
      allRun++;
      const request = `${Date.now()}-${Math.random()}`;
      body.innerHTML = `<div class="wait"><div class="ao-loader"><span class="ao-mark"></span></div><span>Recherche par photo sur AliExpress\u2026</span></div>`;
      const model = message({ type: "PROFIT_MODEL" }).catch(() => null);
      let done = false;
      const partial = (msg) => {
        if (msg?.type !== "FIND_SUPPLIERS_PARTIAL" || msg.request !== request || done || !msg.data) return;
        void model.then((m) => !done && show(msg.data, m));
      };
      chrome.runtime.onMessage.addListener(partial);
      void Promise.all([
        message({
          type: "FIND_SUPPLIERS",
          title: input.title,
          image: chosen,
          itemId: input.itemId ?? null,
          // Another photo than the main one is remembered on its own.
          photo: ebayPictureId(chosen) !== mainId ? ebayPictureId(chosen) : null,
          fresh,
          request
        }),
        model
      ]).then(([result, m]) => {
        done = true;
        show(result, m);
      }).catch((e) => {
        done = true;
        if (host.isConnected) body.innerHTML = errorHTML(e);
      }).finally(() => chrome.runtime.onMessage.removeListener(partial));
    };
    run(false);
    if (input.images?.length) pictures(input.images);
    else if (input.itemId)
      void fetchEbayGallery(input.itemId).then(pictures).catch(() => {
      });
  }
  var drafting = false;
  function draftButton(doc, url, place) {
    const button = Object.assign(doc.createElement("button"), {
      type: "button",
      className: "draft",
      textContent: "\u{1F4DD} Faire le brouillon",
      title: "Cr\xE9e le brouillon eBay avec cette annonce et ce fournisseur, comme le panneau AurOEBay. Rien n\u2019est publi\xE9 : tu v\xE9rifies et tu publies toi-m\xEAme."
    });
    button.addEventListener("click", () => {
      if (drafting) return;
      drafting = true;
      button.disabled = true;
      button.textContent = "\u23F3 Brouillon en pr\xE9paration\u2026";
      place.querySelector(".draft-note")?.remove();
      const note = (text2, error = false) => place.append(Object.assign(doc.createElement("div"), { className: `draft-note${error ? " bad" : ""}`, textContent: text2 }));
      void message({ type: "DRAFT_FROM_SUPPLIER", aliUrl: url }).then(() => {
        button.textContent = "\u2713 Brouillon lanc\xE9";
        note("Suis-le dans le panneau AurOEBay, \xE0 droite : il s\u2019ouvrira tout seul quand il sera pr\xEAt. Rien n\u2019est publi\xE9.");
      }).catch((e) => {
        button.disabled = false;
        button.textContent = "\u{1F4DD} R\xE9essayer le brouillon";
        note(e instanceof Error ? e.message : String(e), true);
      }).finally(() => {
        drafting = false;
      });
    });
    return button;
  }
  function card(doc, c, index, ebayPrice, model, checked = true, draft = false) {
    const el2 = doc.createElement("div");
    el2.className = "card" + (index === 0 && checked ? " best" : "");
    el2.style.animationDelay = `${index * 0.05}s`;
    const img = doc.createElement("img");
    img.src = c.image;
    img.alt = "";
    img.referrerPolicy = "no-referrer";
    const info = doc.createElement("div");
    const title = Object.assign(doc.createElement("div"), { className: "t", textContent: c.title });
    const price2 = Object.assign(doc.createElement("div"), {
      className: "price",
      textContent: c.price === null ? "prix ?" : c.currency && c.currency !== "USD" ? `${c.price.toFixed(2)} ${c.currency}` : `US $${c.price.toFixed(2)}`
    });
    const tags2 = doc.createElement("div");
    tags2.className = "tags";
    if (c.photo !== null && c.photo >= SAME_PHOTO)
      tags2.append(
        Object.assign(doc.createElement("span"), {
          className: "tag photo",
          textContent: c.photoIndex && c.photoTotal && c.photoTotal > 1 ? `\u{1F4F8} Photo exacte \xB7 ${c.photoIndex}/${c.photoTotal}` : "\u{1F4F8} Photo exacte \xB7 photo principale",
          title: "La photo de l\u2019annonce eBay est l\u2019une des photos de ce produit AliExpress"
        })
      );
    else if (c.photo !== null && c.photo >= CLOSE_PHOTO) tags2.append(Object.assign(doc.createElement("span"), { className: "tag", textContent: "Photo proche" }));
    if (c.ebayPhotos?.length)
      tags2.append(
        Object.assign(doc.createElement("span"), {
          className: "tag hits",
          textContent: c.ebayPhotos.length > 1 ? `\u{1F501} trouv\xE9 avec ${c.ebayPhotos.length} photos (${c.ebayPhotos.join(", ")})` : c.ebayPhotos[0] === 1 ? "trouv\xE9 avec la photo principale" : `trouv\xE9 avec la photo ${c.ebayPhotos[0]}`,
          title: "Photos de l\u2019annonce eBay (1 = principale) dont la recherche AliExpress a trouv\xE9 ce produit"
        })
      );
    if (c.choice) tags2.append(Object.assign(doc.createElement("span"), { className: "tag choice", textContent: "Choice" }));
    if (index === 0 && checked) tags2.append(Object.assign(doc.createElement("span"), { className: "tag", textContent: "\u2605 Meilleur choix" }));
    const meta = Object.assign(doc.createElement("div"), {
      className: "meta",
      textContent: [c.sold !== null ? `${c.sold.toLocaleString("fr-FR")}+ vendus` : "", c.rating ? `\u2605 ${c.rating.toFixed(1)}` : ""].filter(Boolean).join(" \xB7 ")
    });
    info.append(title, tags2, price2, meta);
    if (model && ebayPrice && c.price && (c.currency === "USD" || c.currency === null)) {
      const net = estimateProfit(ebayPrice, c.price, model).net;
      const min = net < 0 ? minimumPrice(c.price, model) : null;
      const line = doc.createElement("div");
      line.className = "net";
      line.innerHTML = `Au prix eBay (${ebayPrice.toFixed(2)} $) : <b class="${net >= 0 ? "pos" : "neg"}">${net >= 0 ? "+" : ""}${money2(net, model.currency)}</b> net${min ? ` \xB7 mini ${min.toFixed(2)} $` : ""}`;
      info.append(line);
    }
    const acts = doc.createElement("div");
    acts.className = "acts";
    const open = Object.assign(doc.createElement("a"), { className: "go", href: c.url, target: "_blank", rel: "noopener", textContent: "Ouvrir" });
    const copy = Object.assign(doc.createElement("button"), { type: "button", textContent: "Copier le lien" });
    copy.addEventListener("click", () => {
      void navigator.clipboard.writeText(c.url).then(() => copy.textContent = "\u2713 Copi\xE9").catch(() => copy.textContent = c.url);
    });
    acts.append(open, copy);
    info.append(acts);
    if (draft) acts.append(draftButton(doc, c.url, info));
    el2.append(img, info);
    return el2;
  }
  function finderButton(doc, read) {
    const button = doc.createElement("button");
    button.type = "button";
    button.id = "auro-find-supplier";
    button.style.cssText = brandButtonStyle("primary", "8px 0 8px 8px");
    button.append(brandButtonIcon(doc), "Trouver le fournisseur AliExpress");
    brandButtonHover(button);
    button.addEventListener("click", () => openSupplierFinder(doc, read()));
    return button;
  }

  // src/core/brandRisk.ts
  var DANGER = [
    // Characters and licences
    "Disney",
    "Pixar",
    "Marvel",
    "Avengers",
    "Spider-Man",
    "Spiderman",
    "Batman",
    "Superman",
    "Deadpool",
    "Iron Man",
    "Captain America",
    "DC Comics",
    "Star Wars",
    "Baby Yoda",
    "Grogu",
    "Mandalorian",
    "Harry Potter",
    "Hogwarts",
    "Mickey Mouse",
    "Minnie Mouse",
    "Lilo and Stitch",
    "Lilo & Stitch",
    "Toy Story",
    "Winnie the Pooh",
    "Pokemon",
    "Pikachu",
    "Super Mario",
    "Mario Kart",
    "Zelda",
    "Sonic the Hedgehog",
    "Minecraft",
    "Fortnite",
    "Roblox",
    "Among Us",
    "Squid Game",
    "Hello Kitty",
    "Sanrio",
    "Kuromi",
    "Cinnamoroll",
    "My Melody",
    "Labubu",
    "Pop Mart",
    "Squishmallow",
    "Squishmallows",
    "Bluey",
    "Paw Patrol",
    "Peppa Pig",
    "Cocomelon",
    "Minions",
    "Barbie",
    "Hot Wheels",
    "LEGO",
    "Nerf",
    "Fisher-Price",
    "Naruto",
    "Dragon Ball",
    "Demon Slayer",
    "Jujutsu Kaisen",
    "My Hero Academia",
    "Sailor Moon",
    "Studio Ghibli",
    "Totoro",
    "Looney Tunes",
    "Snoopy",
    "Sesame Street",
    "Taylor Swift",
    "NFL",
    "NBA",
    "MLB",
    "NHL",
    "NCAA",
    "Harley-Davidson",
    "John Deere",
    "Coca-Cola",
    "Starbucks",
    // Fashion, luxury, sport
    "Nike",
    "Adidas",
    "Puma",
    "Reebok",
    "Under Armour",
    "New Balance",
    "Air Jordan",
    "Converse",
    "The North Face",
    "Patagonia",
    "Lululemon",
    "Gucci",
    "Louis Vuitton",
    "Chanel",
    "Dior",
    "Hermes",
    "Prada",
    "Versace",
    "Burberry",
    "Balenciaga",
    "Fendi",
    "Givenchy",
    "Yves Saint Laurent",
    "YSL",
    "Michael Kors",
    "Kate Spade",
    "Tory Burch",
    "Ralph Lauren",
    "Tommy Hilfiger",
    "Calvin Klein",
    "Rolex",
    "Cartier",
    "Tag Heuer",
    "Pandora",
    "Swarovski",
    "Ray-Ban",
    "Rayban",
    "Oakley",
    "Crocs",
    "Jibbitz",
    "UGG",
    "Birkenstock",
    "Dr Martens",
    "Timberland",
    // Copied household products
    "Stanley",
    "Yeti",
    "Hydro Flask",
    "Owala",
    "OtterBox",
    "PopSocket",
    "PopSockets",
    "Dyson",
    // Added 11/2026 (user's request « des mots / marques à bannir »)
    // Toys, collectibles, kids' licences
    "NeeDoh",
    "Nee Doh",
    "Schylling",
    "Jellycat",
    "Sonny Angel",
    "Smiski",
    "Funko",
    "Beanie Babies",
    "Ty Beanie",
    "Ms Rachel",
    "Blippi",
    "Gabby's Dollhouse",
    "Gabbys Dollhouse",
    "PJ Masks",
    "Thomas the Tank Engine",
    "SpongeBob",
    "Garfield",
    "Pusheen",
    "Care Bears",
    "My Little Pony",
    "Transformers",
    "Hasbro",
    "Mattel",
    "Play-Doh",
    "Magna-Tiles",
    "Tamagotchi",
    "Bandai",
    "Yu-Gi-Oh",
    "Magic the Gathering",
    "Bratz",
    "LOL Surprise",
    "Polly Pocket",
    "Tonka",
    "Crayola",
    "Hatchimals",
    "Kirby",
    "Animal Crossing",
    "Splatoon",
    "Call of Duty",
    "Pac-Man",
    "Tetris",
    "Rubik's",
    "Rubiks",
    "Pochacco",
    "Pompompurin",
    "Keroppi",
    "Badtz-Maru",
    "Chainsaw Man",
    "Attack on Titan",
    "Hunter x Hunter",
    "Tokyo Ghoul",
    "Spy x Family",
    "Stranger Things",
    "Moana",
    "Encanto",
    "Frozen Elsa",
    "Bluey Bingo",
    "Grinch",
    "Dr Seuss",
    "Elf on the Shelf",
    "Charlie Brown",
    "Jack Skellington",
    "Nightmare Before Christmas",
    "Hocus Pocus",
    "Beetlejuice",
    "Freddy Krueger",
    "Michael Myers",
    "Chucky",
    "Ghostface",
    "Lord of the Rings",
    "Game of Thrones",
    "Wednesday Addams",
    // Fashion, beauty, luxury
    "Vans Old Skool",
    "Skechers",
    "Hoka",
    "Asics",
    "Fila",
    "Carhartt",
    "Levi's",
    "Levis",
    "Wrangler Jeans",
    "Off-White",
    "Bape",
    "Stussy",
    "Fear of God",
    "Moncler",
    "Canada Goose",
    "Arc'teryx",
    "Arcteryx",
    "Longchamp",
    "Goyard",
    "Celine",
    "Bottega Veneta",
    "Valentino",
    "Miu Miu",
    "Loewe",
    "Van Cleef",
    "Bvlgari",
    "Bulgari",
    "Chrome Hearts",
    "Casio",
    "G-Shock",
    "Seiko",
    "Alo Yoga",
    "Gymshark",
    "Skims",
    "Victoria's Secret",
    "Bath and Body Works",
    "Sol de Janeiro",
    "Olaplex",
    "Beautyblender",
    "Fenty",
    "Rare Beauty",
    "Charlotte Tilbury",
    "Revlon",
    "Gillette",
    "Oral-B",
    "Sonicare",
    // Tech and home brands often copied
    "Anker",
    "Beats by Dre",
    "Beats Studio",
    "Beats Solo",
    "Beats Fit Pro",
    "Skullcandy",
    "Logitech",
    "Razer",
    "Corsair",
    "SteelSeries",
    "HyperX",
    "Roomba",
    "iRobot",
    "Vitamix",
    "Le Creuset",
    "Pyrex",
    "Tupperware",
    "Bissell",
    "Contigo",
    "Ember Mug",
    "Ka-Bar",
    "Kabar",
    "Lego Star Wars",
    // Sport teams, cars (logos)
    "FIFA",
    "UEFA",
    "Real Madrid",
    "FC Barcelona",
    "Manchester United",
    "Manchester City",
    "Liverpool FC",
    "Chelsea FC",
    "Dallas Cowboys",
    "Kansas City Chiefs",
    "New York Yankees",
    "Los Angeles Lakers",
    "Chicago Bulls",
    "Golden State Warriors",
    "Ferrari",
    "Lamborghini",
    "Porsche",
    "Red Bull",
    "Monster Energy",
    "Jack Daniels",
    "Jack Daniel's"
  ];
  var COMPATIBLE = [
    "iPhone",
    "iPad",
    "MacBook",
    "iMac",
    "Apple Watch",
    "Apple Pencil",
    "MagSafe",
    "AirPods",
    "AirTag",
    "Samsung",
    "Google Pixel",
    "Fitbit",
    "Garmin",
    "Nintendo",
    "PlayStation",
    "PS4",
    "PS5",
    "Xbox",
    "Tesla",
    "GoPro",
    "DJI",
    "Kindle",
    "JBL",
    "Bose",
    "Sony",
    "Microsoft",
    "Keurig",
    "Nespresso",
    "KitchenAid",
    "Instant Pot",
    "Cricut",
    "DeWalt",
    "Makita",
    "Bosch",
    // Added 11/2026: devices and cars accessories name (« for Toyota RAV4 »)
    "Steam Deck",
    "Meta Quest",
    "Oculus",
    "Echo Dot",
    "Alexa",
    "Roku",
    "Chromecast",
    "Ring Doorbell",
    "Polaroid",
    "Instax",
    "Fujifilm",
    "Canon",
    "Nikon",
    "Milwaukee",
    "Ryobi",
    "Ninja Creami",
    "Ninja Foodi",
    "Xiaomi",
    "Huawei",
    "OnePlus",
    "Motorola",
    "Lenovo",
    "Dell",
    "Toyota",
    "Honda",
    "Ford",
    "Chevrolet",
    "Chevy",
    "Jeep",
    "BMW",
    "Mercedes",
    "Audi",
    "Volkswagen",
    "Subaru",
    "Nissan",
    "Hyundai",
    "Kia",
    "Mazda",
    "Lexus",
    "Dodge",
    "RAM 1500"
  ];
  var words = (text2) => ` ${text2.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, " ").trim()} `;
  var LIST = [
    ...DANGER.map((name) => ({ name, level: "danger", w: words(name) })),
    ...COMPATIBLE.map((name) => ({ name, level: "compatible", w: words(name) }))
  ];
  function brandRisks(text2) {
    if (!text2) return [];
    const t = words(text2);
    const hits = [];
    const seen = /* @__PURE__ */ new Set();
    for (const b of LIST) {
      const key = b.w.replace(/ /g, "");
      if (seen.has(key) || !t.includes(b.w)) continue;
      if (hits.some((h) => words(h.name).includes(b.w) || b.w.includes(words(h.name)))) continue;
      seen.add(key);
      hits.push({ name: b.name, level: b.level });
    }
    return hits.sort((a, b) => Number(a.level !== "danger") - Number(b.level !== "danger"));
  }
  function brandAdvice(hits) {
    const names2 = (level) => hits.filter((h) => h.level === level).map((h) => h.name);
    const out = [];
    const danger = names2("danger");
    if (danger.length)
      out.push({
        level: "danger",
        text: `Marque ou personnage prot\xE9g\xE9 : ${danger.join(", ")}. Sans autorisation du propri\xE9taire, eBay retire l\u2019annonce et peut suspendre ton compte (programme VeRO). Retire ce nom du titre, de la description, des caract\xE9ristiques et des photos, ou choisis un autre produit.`
      });
    const compatible = names2("compatible");
    if (compatible.length)
      out.push({
        level: "compatible",
        text: `Marque cit\xE9e : ${compatible.join(", ")}. Autoris\xE9 seulement pour dire que ton produit est compatible (\xAB for iPhone 15 \xBB, \xAB compatible with \u2026 \xBB) : mets \xAB Unbranded \xBB dans Marque, aucun logo sur les photos, et n\u2019\xE9cris jamais la marque comme si c\u2019\xE9tait ton produit.`
      });
    return out;
  }

  // src/ebay/seed.ts
  function extractEbaySeed(doc, url) {
    const itemId = ebayItemId(url);
    if (!itemId) throw Error("Ouvre une fiche produit eBay US.");
    const title = compact(
      queryAll(doc, SELECTORS.seedTitle)[0]?.textContent ?? ""
    );
    const specifics2 = queryAll(doc, SELECTORS.seedSpecifics).flatMap(
      (scope) => [...scope.querySelectorAll("dt")].flatMap((dt) => {
        const dd = dt.nextElementSibling;
        const label4 = compact(dt.textContent ?? "");
        const value = dd?.tagName === "DD" ? compact(dd.textContent ?? "") : "";
        return label4 && value && !/^condition$/i.test(label4) ? [{ label: label4, value }] : [];
      })
    );
    const category = queryAll(doc, SELECTORS.seedCategory).map((e) => compact(e.textContent ?? "")).filter(Boolean).join(" > ");
    const priceText = compact(
      queryAll(doc, SELECTORS.seedPrice)[0]?.textContent ?? ""
    );
    const match = priceText.match(/^US\s*\$\s*([\d,]+(?:\.\d{1,2})?)/i);
    const copies = [...doc.querySelectorAll("a[href]")].filter(
      (a) => {
        try {
          const u = new URL(a.href);
          return u.origin === "https://www.ebay.com" && u.pathname === "/sl/list" && ["SellLikeItem", "SellSimilarItem"].includes(
            u.searchParams.get("mode") ?? ""
          ) && u.searchParams.get("itemId") === itemId;
        } catch {
          return false;
        }
      }
    );
    const copy = copies.find(
      (a) => new URL(a.href).searchParams.get("mode") === "SellLikeItem"
    ) ?? copies[0];
    const copyUrl = copy?.href ?? `https://www.ebay.com/sl/list?itemId=${itemId}&mode=SellLikeItem&rt=nc`;
    const foreignSite = /^(GBP|EUR|AU\s*\$|C\s*\$|CAD|AUD|£|€)/i.test(priceText);
    const categoryId = ebayCategoryFromDocument(doc) ?? (foreignSite ? null : trackedCategory(doc.documentElement?.outerHTML ?? ""));
    if (foreignSite && !category && !categoryId)
      throw Error(
        `Cette annonce d\u2019exemple vient d\u2019un autre site eBay (prix ${priceText.split(/\s/)[0]}) : eBay US ne reconna\xEEt pas sa cat\xE9gorie. Choisis une annonce du m\xEAme produit vendue en dollars sur eBay.com.`
      );
    const seed = {
      itemId,
      url: new URL(url).origin + new URL(url).pathname,
      copyUrl,
      title,
      category,
      // No breadcrumb (seen live 10/2026): eBay's page-view tracking of the
      // displayed page still names the listing's category (« tcat »).
      ...categoryId ? { categoryId } : {},
      ...!category && copy && new URL(copy.href).searchParams.get("mode") === "SellLikeItem" ? { categoryFromCopy: true } : {},
      specifics: specifics2.slice(0, 100),
      price: match ? match[1].replace(/,/g, "") : null,
      currency: match ? "USD" : null,
      hasVariations: !!doc.querySelector(
        '.x-sku, .x-msku, [data-testid="x-msku"], [data-testid="variation-selector"]'
      ),
      capturedAt: Date.now()
    };
    if (!validTitle(title, 80))
      throw Error(
        "Titre eBay non reconnu ou sup\xE9rieur \xE0 80 caract\xE8res. Recharge la fiche avant de r\xE9essayer."
      );
    if (!category && !seed.categoryFromCopy)
      throw Error(
        "Cat\xE9gorie et lien natif Sell one like this indisponibles. Recharge la fiche avant de r\xE9essayer."
      );
    if (!validEbaySeed(seed))
      throw Error(
        "Fiche eBay non reconnue. Recharge la fiche avant de r\xE9essayer."
      );
    return seed;
  }
  function setupEbayPushButton(doc, enabled2) {
    doc.getElementById("auro-push-ebay")?.remove();
    if (!enabled2() || !ebayItemId(location.href)) return () => {
    };
    const heading = queryAll(doc, SELECTORS.seedTitle)[0];
    if (!heading) return () => {
    };
    const button = doc.createElement("button");
    button.id = "auro-push-ebay";
    button.type = "button";
    button.append(brandButtonIcon(doc), "Cr\xE9er un brouillon \xB7 AurOEBay");
    button.style.cssText = brandButtonStyle("quiet", "8px 0");
    brandButtonHover(button);
    const note = doc.createElement("p");
    note.setAttribute("role", "status");
    note.style.cssText = "font:13px system-ui";
    button.addEventListener("click", () => {
      if (!enabled2()) return;
      button.disabled = true;
      void Promise.resolve().then(
        () => message({
          type: "EBAY_SEED_CAPTURE",
          seed: extractEbaySeed(doc, location.href)
        })
      ).then(() => {
        note.textContent = "Fiche eBay retenue. Colle le lien AliExpress dans le panneau AurOEBay, \xE0 droite.";
      }).catch((e) => {
        note.textContent = e instanceof Error ? e.message : String(e);
      }).finally(() => {
        button.disabled = !enabled2();
      });
    });
    const history2 = historyButton(doc);
    doc.getElementById("auro-find-supplier")?.remove();
    const finder = finderButton(doc, () => {
      const seed = (() => {
        try {
          return extractEbaySeed(doc, location.href);
        } catch {
          return null;
        }
      })();
      const image = doc.querySelector('meta[property="og:image"]')?.content ?? doc.querySelector(".ux-image-carousel-item img")?.src ?? "";
      return {
        title: seed?.title || compact(queryAll(doc, SELECTORS.seedTitle)[0]?.textContent ?? ""),
        image,
        price: seed?.price ? Number(seed.price) : null,
        itemId: seed?.itemId ?? ebayItemId(location.href),
        images: ebayGallery(doc),
        draft: true
      };
    });
    const vero = veroNotice(doc, compact(heading.textContent ?? ""));
    if (history2) {
      history2.id = "auro-sales-history";
      history2.style.marginLeft = "8px";
      doc.getElementById("auro-sales-history")?.remove();
      heading.after(button, history2, finder, note, ...vero);
    } else heading.after(button, finder, note, ...vero);
    return () => {
      button.remove();
      history2?.remove();
      finder.remove();
      note.remove();
      vero.forEach((v) => v.remove());
    };
  }
  function veroNotice(doc, title) {
    doc.getElementById("auro-vero")?.remove();
    const advice = brandAdvice(brandRisks(title));
    if (!advice.length) return [];
    const box2 = doc.createElement("div");
    box2.id = "auro-vero";
    const danger = advice.some((a) => a.level === "danger");
    const color = danger ? "#c4283a" : "#a35a00";
    box2.style.cssText = `margin:8px 0;padding:10px 12px;border-radius:10px;border:1px solid ${color};background:${danger ? "#fff1f2" : "#fff8eb"};color:#222;font:13px/1.45 system-ui;max-width:640px`;
    const head = doc.createElement("b");
    head.style.color = color;
    head.textContent = danger ? "\u{1F6AB} AurOEBay : marque prot\xE9g\xE9e, \xE0 \xE9viter" : "\u26A0\uFE0F AurOEBay : marque cit\xE9e";
    box2.append(head);
    for (const a of advice) {
      const p = doc.createElement("p");
      p.style.margin = "4px 0 0";
      p.textContent = a.text;
      box2.append(p);
    }
    return [box2];
  }

  // src/core/pageModule.ts
  function pageModule(text2, key, accept = () => true) {
    const marker = `"${key}":{`;
    for (let at = text2.indexOf(marker); at >= 0; at = text2.indexOf(marker, at + 1)) {
      const start = at + marker.length - 1;
      let depth = 0, inString = false, escaped = false;
      for (let i = start; i < text2.length; i++) {
        const c = text2[i];
        if (inString) {
          if (escaped) escaped = false;
          else if (c === "\\") escaped = true;
          else if (c === '"') inString = false;
          continue;
        }
        if (c === '"') inString = true;
        else if (c === "{") depth++;
        else if (c === "}" && --depth === 0) {
          try {
            const value = JSON.parse(text2.slice(start, i + 1));
            if (accept(value)) return value;
          } catch {
          }
          break;
        }
      }
    }
    return null;
  }

  // src/aliexpress/fullDescription.ts
  var tags = new Set(
    "DIV SECTION SPAN P BR UL OL LI STRONG B I EM U H1 H2 H3 H4 H5 H6 TABLE TBODY THEAD TFOOT TR TD TH HR BLOCKQUOTE FIGURE FIGCAPTION IMG".split(
      " "
    )
  );
  var discard = new Set(
    "SCRIPT STYLE IFRAME OBJECT EMBED SVG MATH FORM INPUT BUTTON SELECT TEXTAREA LINK META TEMPLATE NOSCRIPT VIDEO AUDIO".split(
      " "
    )
  );
  var styles = new Set(
    "color background-color text-align font-size font-family font-weight font-style text-decoration line-height border border-color border-width border-style border-collapse padding padding-left padding-right padding-top padding-bottom margin margin-left margin-right margin-top margin-bottom width height max-width vertical-align".split(
      " "
    )
  );
  function sanitizeSupplierDescription(doc, html, imageURL = descriptionImageURL) {
    const input = doc.createElement("template");
    input.innerHTML = html;
    const out = doc.createElement("div");
    let imageCount = 0, unsupportedImages = 0;
    const visit = (node, parent) => {
      if (node.nodeType === 3) {
        parent.appendChild(doc.createTextNode(node.textContent ?? ""));
        return;
      }
      if (node.nodeType !== 1) return;
      const el2 = node;
      if (el2.namespaceURI !== "http://www.w3.org/1999/xhtml" || discard.has(el2.tagName))
        return;
      if (!tags.has(el2.tagName)) {
        [...el2.childNodes].forEach((n) => visit(n, parent));
        return;
      }
      const target = doc.createElement(el2.tagName.toLowerCase());
      if (el2.tagName === "IMG") {
        const url = imageURL(
          el2.getAttribute("data-src") || el2.getAttribute("data-lazy-src") || el2.getAttribute("src") || ""
        );
        if (!url) {
          unsupportedImages++;
          return;
        }
        target.setAttribute("src", url);
        target.setAttribute("alt", el2.getAttribute("alt") ?? "");
        target.setAttribute("style", "max-width: 100%; height: auto;");
        imageCount++;
      } else {
        const css = el2.style;
        for (const name of Array.from(
          { length: css.length },
          (_, i) => css.item(i)
        )) {
          const value = css.getPropertyValue(name);
          if (styles.has(name) && !/url\s*\(|expression|javascript|@import|\\/i.test(value) && value.length < 200)
            target.style.setProperty(name, value);
        }
        for (const attr of ["colspan", "rowspan"]) {
          const value = el2.getAttribute(attr);
          if (value && /^\d{1,2}$/.test(value)) target.setAttribute(attr, value);
        }
        [...el2.childNodes].forEach((n) => visit(n, target));
      }
      parent.appendChild(target);
    };
    [...input.content.childNodes].forEach((n) => visit(n, out));
    return {
      html: out.innerHTML,
      imageCount,
      unsupportedImages,
      hasContent: !!out.textContent?.trim() || imageCount > 0
    };
  }

  // src/ebay/listingCopy.ts
  function moduleFromScripts(doc, key, probe) {
    for (const script of doc.querySelectorAll("script")) {
      const text2 = script.textContent ?? "";
      if (!text2.includes(`"${key}":{`) || !text2.includes(probe)) continue;
      const found = pageModule(text2, key);
      if (found) return found;
    }
    return null;
  }
  function descriptionImageURL2(value) {
    try {
      const u = new URL(value.startsWith("//") ? "https:" + value : value);
      return u.protocol === "https:" && !u.username && !u.password && !u.port ? u.href : null;
    } catch {
      return null;
    }
  }
  function listingDescription(doc, page) {
    const parsed = new DOMParser().parseFromString(page, "text/html");
    const body = parsed.querySelector(".x-item-description-child") ?? parsed.body;
    return sanitizeSupplierDescription(
      doc,
      body?.innerHTML ?? "",
      descriptionImageURL2
    );
  }
  var price = (model) => {
    const value = model?.binModel?.price?.value;
    if (value?.currency !== "USD" || !(Number(value.value) > 0)) return null;
    return Number(value.value).toFixed(2);
  };
  function extractListingCopy(doc, url, descriptionPage) {
    const seed = extractEbaySeed(doc, url);
    const picture = moduleFromScripts(doc, "PICTURE", '"mediaList"');
    const media = (picture?.mediaList ?? []).map(
      (item2) => ebayListingImageURL(
        item2?.image?.originalImg?.URL ?? item2?.image?.thumbnail?.URL ?? ""
      )
    );
    if (!media.some(Boolean))
      throw Error("Photos de l\u2019annonce eBay introuvables. Recharge la fiche.");
    const msku = moduleFromScripts(doc, "MSKU", '"variationsMap"');
    const axes = [];
    const rows2 = [];
    const variantImages = [];
    const variationPictures = /* @__PURE__ */ new Set();
    let outOfStock = 0;
    const zeroRows = [];
    if (msku?.selectMenus?.length) {
      const menus = msku.selectMenus;
      const items = msku.menuItemMap ?? {};
      const name = (id) => compact(String(items[id]?.valueName ?? ""));
      for (const menu of menus) {
        const values = (menu.menuItemValueIds ?? []).map(name);
        if (!compact(menu.displayLabel ?? "") || values.some((v) => !v))
          throw Error("Options de variantes eBay illisibles. Recharge la fiche.");
        axes.push({ name: compact(menu.displayLabel), values });
      }
      for (const [key, vid] of Object.entries(msku.variationCombinations ?? {})) {
        const ids = key.split("_").map(Number);
        if (ids.length !== menus.length || ids.some((id, i) => !menus[i].menuItemValueIds?.includes(id)))
          throw Error("Combinaisons de variantes eBay incoh\xE9rentes.");
        const model = msku.variationsMap?.[String(vid)];
        const soldOut = !!model?.quantity?.outOfStock;
        const amount = price(model);
        if (soldOut) {
          outOfStock++;
          if (amount)
            zeroRows.push({ values: ids.map(name), cost: Number(amount), price: amount, quantity: 0 });
          continue;
        }
        if (!amount)
          throw Error(
            "Prix d\u2019une variante eBay introuvable ou hors USD. Recharge la fiche."
          );
        const values = ids.map(name);
        rows2.push({
          values,
          cost: Number(amount),
          price: amount,
          quantity: DEFAULT_IMPORT_QUANTITY
        });
      }
      for (const [valueId, indexes] of Object.entries(
        msku.menuItemPictureIndexMap ?? {}
      )) {
        const menu = menus.find(
          (m) => m.menuItemValueIds?.includes(Number(valueId))
        );
        if (!menu) continue;
        for (const index of indexes ?? []) {
          variationPictures.add(index);
          const image = media[index];
          if (image)
            variantImages.push({
              axis: compact(menu.displayLabel),
              value: name(Number(valueId)),
              url: image
            });
        }
      }
    } else {
      if (!seed.price)
        throw Error("Prix de l\u2019annonce eBay introuvable (en USD).");
      rows2.push({
        values: [],
        cost: Number(seed.price),
        price: seed.price,
        quantity: DEFAULT_IMPORT_QUANTITY
      });
    }
    if (!rows2.length)
      throw Error("Toutes les variantes de cette annonce sont en rupture.");
    if (rows2.length + zeroRows.length <= 250) rows2.push(...zeroRows);
    if (rows2.length > 250)
      throw Error(
        `Cette annonce a ${rows2.length} variantes disponibles : eBay en accepte 250 au maximum.`
      );
    if (axes.length > 5 || axes.some((a) => a.name.length > 30 || a.values.some((v) => v.length > 50)))
      throw Error(
        "Variantes hors limites eBay (5 axes, noms de 30 caract\xE8res, options de 50)."
      );
    const planAxes = axes.map((axis, i) => ({
      name: axis.name,
      values: axis.values.filter((v) => rows2.some((r) => r.values[i] === v))
    }));
    const ordered = [...new Set(media.filter((u) => !!u))];
    const own2 = [
      ...new Set(
        media.filter(
          (u, i) => !!u && !variationPictures.has(i)
        )
      )
    ];
    const gallery = (own2.length ? own2 : ordered).slice(0, 24);
    const images = gallery.map((u) => ({
      url: u,
      role: "gallery",
      width: null,
      height: null
    }));
    const description = listingDescription(doc, descriptionPage);
    const descriptionHTML = description.hasContent ? description.html : `<p>${escapeHTML(seed.title)}</p>`;
    const text2 = compact(
      new DOMParser().parseFromString(descriptionHTML, "text/html").body.textContent ?? ""
    );
    const source = {
      extractionVersion: 1,
      id: `ebay-${seed.itemId}`,
      url: seed.url,
      title: seed.title,
      capturedAt: Date.now(),
      specs: seed.specifics,
      description: text2.slice(0, 12e3),
      variants: planAxes,
      supplierNames: [],
      images,
      variantImages: variantImages.filter(
        (image) => planAxes.some((a) => a.name === image.axis && a.values.includes(image.value))
      ),
      descriptionHTML,
      descriptionStatus: "loaded",
      descriptionImageCount: description.imageCount
    };
    return {
      seed,
      source,
      gallery,
      outOfStock,
      plan: {
        axes: planAxes,
        rows: rows2,
        omitted: outOfStock - zeroRows.filter((r) => rows2.includes(r)).length,
        rule: { coefficient: 1, fixed: 0, rounding: "none" }
      }
    };
  }

  // src/core/ebayLibrary.ts
  var EBAY_LIBRARY_LIMITS = {
    htmlCharacters: 4e5,
    bytes: 15e5
  };
  function fail(message2 = "Capture eBay invalide.") {
    throw Error(message2);
  }
  function record(value) {
    if (!value || typeof value !== "object" || Array.isArray(value) || ![Object.prototype, null].includes(Object.getPrototypeOf(value)))
      fail();
    return value;
  }
  function text(value, max, empty = true) {
    if (typeof value !== "string" || value.length > max || !empty && !value.trim() || /[\u0000-\u0008\u000b\u000c\u000e-\u001f]/.test(value))
      fail();
    return value;
  }
  function timestamp(value) {
    if (typeof value !== "number" || !Number.isSafeInteger(value) || value < 0 || value > 864e13)
      fail("Date de capture eBay invalide.");
    return value;
  }
  function array(value, max, read) {
    if (!Array.isArray(value) || value.length > max) fail();
    return value.map(read);
  }
  function nullable(value, read) {
    return value === null ? null : read(value);
  }
  function https(value) {
    let url;
    try {
      url = new URL(text(value, 4096, false).trim());
    } catch {
      fail("Lien eBay HTTPS invalide.");
    }
    if (url.protocol !== "https:" || url.username || url.password || url.port)
      fail("Lien eBay HTTPS public requis.");
    return url;
  }
  function canonicalEbayLibraryURL(value) {
    const u = https(value);
    if (!/(^|\.)ebay\.com$/.test(u.hostname)) fail("Lien eBay US invalide.");
    const item2 = u.pathname.match(/^\/itm\/(?:[^/]+\/)?(\d{5,30})\/?$/)?.[1];
    if (item2) return { url: `https://www.ebay.com/itm/${item2}`, kind: "item" };
    const camel = u.searchParams.get("draftId"), alias = u.searchParams.get("draft_id");
    if (camel && alias && camel !== alias)
      fail("Identifiant de brouillon eBay ambigu.");
    const id = camel ?? alias;
    if (u.pathname === "/lstng" && id && /^\d{5,30}$/.test(id)) {
      const mode = u.searchParams.get("mode");
      if (mode && !["AddItem", "SellLikeItem", "SellSimilarItem"].includes(mode))
        fail("Mode de brouillon eBay invalide.");
      return {
        url: `https://www.ebay.com/lstng?draftId=${id}${mode ? `&mode=${mode}` : ""}`,
        kind: "draft"
      };
    }
    fail("Colle le lien d\u2019une annonce eBay ou d\u2019un brouillon eBay.");
  }
  function ebayLibraryImageURL(value) {
    try {
      const u = https(value);
      if (!/(^|\.)ebayimg\.com$/.test(u.hostname) || !/\.(?:jpe?g|png|webp|gif|avif)$/i.test(u.pathname))
        return null;
      u.hash = "";
      u.search = "";
      return u.href;
    } catch {
      return null;
    }
  }
  function specifics(value) {
    return array(value, 200, (v) => {
      const x = record(v);
      return { label: text(x.label, 300, false), value: text(x.value, 3e3) };
    });
  }
  function validateHistoricalEbaySeed(value) {
    const x = record(value), canonical = canonicalEbayLibraryURL(x.url);
    if (canonical.kind !== "item")
      fail("La r\xE9f\xE9rence eBay doit \xEAtre une annonce publique.");
    const itemId = canonical.url.split("/").pop();
    if (text(x.itemId, 30, false) !== itemId)
      fail("Identifiant eBay incoh\xE9rent.");
    const copy = https(x.copyUrl);
    if (copy.hostname !== "www.ebay.com" || copy.pathname !== "/sl/list" || copy.searchParams.get("itemId") !== itemId || !["SellLikeItem", "SellSimilarItem"].includes(
      copy.searchParams.get("mode") ?? ""
    ))
      fail("Lien de copie eBay invalide.");
    const title = text(x.title, 80, false);
    if (!validTitle(title)) fail("Titre de r\xE9f\xE9rence eBay invalide.");
    if (typeof x.hasVariations !== "boolean") fail();
    const seed = {
      itemId,
      url: canonical.url,
      copyUrl: `https://www.ebay.com/sl/list?mode=SellLikeItem&itemId=${itemId}&rt=nc`,
      title,
      category: text(x.category, 2e3),
      specifics: specifics(x.specifics),
      price: nullable(x.price, (v) => text(v, 300)),
      currency: nullable(x.currency, (v) => {
        if (v !== "USD") fail();
        return "USD";
      }),
      hasVariations: x.hasVariations,
      capturedAt: timestamp(x.capturedAt)
    };
    if (seed.specifics.length > 100) fail();
    if (x.categoryFromCopy !== void 0) {
      if (x.categoryFromCopy !== true) fail();
      seed.categoryFromCopy = true;
    }
    return seed;
  }
  function validateEbayLibrarySnapshot(value) {
    let serialized;
    try {
      serialized = JSON.stringify(value);
    } catch {
      fail();
    }
    if (typeof serialized !== "string" || new TextEncoder().encode(serialized).byteLength > EBAY_LIBRARY_LIMITS.bytes)
      fail("Capture eBay trop volumineuse.");
    const x = record(value), canonical = canonicalEbayLibraryURL(x.url);
    if (x.kind !== canonical.kind) fail("Type de capture eBay incoh\xE9rent.");
    const images = array(x.images, 100, (v) => {
      const image = ebayLibraryImageURL(text(v, 4096, false));
      if (!image) fail("Photo eBay non reconnue.");
      return image;
    });
    if (new Set(images).size !== images.length) fail("Photos eBay dupliqu\xE9es.");
    const snapshot = {
      ...canonical,
      title: text(x.title, 2e3, false),
      capturedAt: timestamp(x.capturedAt),
      category: text(x.category, 2e3),
      specifics: specifics(x.specifics),
      price: nullable(x.price, (v) => text(v, 500, false)),
      currency: nullable(x.currency, (v) => text(v, 8, false)),
      quantity: nullable(x.quantity, (v) => text(v, 300, false)),
      images,
      descriptionHTML: text(
        x.descriptionHTML,
        EBAY_LIBRARY_LIMITS.htmlCharacters
      ),
      descriptionText: text(
        x.descriptionText,
        EBAY_LIBRARY_LIMITS.htmlCharacters
      ),
      variants: array(x.variants, 10, (v) => {
        const a = record(v);
        return {
          name: text(a.name, 300, false),
          values: array(a.values, 200, (s) => text(s, 300, false)),
          ...a.price === void 0 ? {} : { price: text(a.price, 500) }
        };
      }),
      warnings: array(x.warnings, 100, (v) => text(v, 2e3, false))
    };
    if (x.seed !== void 0) {
      snapshot.seed = validateHistoricalEbaySeed(x.seed);
      if (snapshot.seed.url !== snapshot.url || snapshot.kind !== "item")
        fail(
          "La capture et la r\xE9f\xE9rence eBay d\xE9signent des annonces diff\xE9rentes."
        );
    }
    return snapshot;
  }

  // src/core/descriptionHTML.ts
  function isEditorDecoration(node) {
    return node.nodeType === 1 && node.matches("style.darkreader");
  }
  function removeInlineEditorDecoration(el2) {
    for (const attr of [...el2.attributes])
      if (/^data-darkreader-inline-[a-z-]+$/.test(attr.name))
        el2.removeAttribute(attr.name);
    const style = el2.style;
    if (style) {
      let removed = false;
      for (const name of Array.from(
        { length: style.length },
        (_, i) => style.item(i)
      ))
        if (/^--darkreader-inline-[a-z-]+$/.test(name)) {
          style.removeProperty(name);
          removed = true;
        }
      if (removed && !el2.getAttribute("style")?.trim())
        el2.removeAttribute("style");
    }
  }
  function listingAttributes(el2) {
    const copy = el2.cloneNode(false);
    removeInlineEditorDecoration(copy);
    return [...copy.attributes].map((a) => [a.name, a.value]).sort(([a], [b]) => a.localeCompare(b));
  }
  function listingCopy(el2) {
    const copy = el2.cloneNode(true);
    copy.querySelectorAll("style.darkreader").forEach((node) => node.remove());
    removeInlineEditorDecoration(copy);
    copy.querySelectorAll("*").forEach(removeInlineEditorDecoration);
    return copy;
  }
  function listingOuterHTML(el2) {
    return listingCopy(el2).outerHTML;
  }
  function editableHTML(el2) {
    if (!el2.matches('[contenteditable="true"]') && el2.tagName !== "BODY" || ![...el2.querySelectorAll("*")].some(
      (node) => isEditorDecoration(node) || [...node.attributes].some(
        (a) => /^data-darkreader-inline-[a-z-]+$/.test(a.name)
      ) || node.getAttribute("style")?.includes("--darkreader-inline-")
    ))
      return el2.innerHTML;
    return listingCopy(el2).innerHTML;
  }

  // src/core/description.ts
  var discard2 = /* @__PURE__ */ new Set([
    "SCRIPT",
    "STYLE",
    "IFRAME",
    "OBJECT",
    "EMBED",
    "SVG",
    "MATH",
    "FORM",
    "BUTTON",
    "INPUT",
    "TEXTAREA",
    "SELECT",
    "TEMPLATE",
    "NOSCRIPT",
    "IMG",
    "VIDEO",
    "AUDIO",
    "LINK",
    "META"
  ]);
  function fragment(html) {
    const t = document.createElement("template");
    t.innerHTML = html;
    return t.content;
  }
  function editedDescription(html, edits) {
    const root = fragment(html);
    for (const edit of edits) {
      let node = root;
      for (const i of edit.path) {
        node = node.childNodes[i];
        if (!node) throw Error("Texte d\xE9plac\xE9. Relance l\u2019analyse.");
      }
      if (node.nodeType !== 3 || node.textContent !== edit.before)
        throw Error("Texte modifi\xE9. Relance l\u2019analyse.");
      node.textContent = edit.after;
    }
    const t = document.createElement("template");
    t.content.append(root);
    return t.innerHTML;
  }
  function replaceDescriptionText(root, after, apply = true) {
    const target = fragment(after);
    const writes = [];
    const compareChildren = (a, b) => {
      const children = (node) => [...node.childNodes].filter((n) => !isEditorDecoration(n));
      const fixedA = children(a).filter((n) => n.nodeType !== 3), fixedB = children(b).filter((n) => n.nodeType !== 3);
      if (fixedA.length !== fixedB.length)
        throw Error("Description: modification de structure refus\xE9e");
      const slots = (parent) => {
        const result = [[]];
        for (const c of children(parent)) {
          if (c.nodeType === 3) result.at(-1).push(c);
          else result.push([]);
        }
        return result;
      };
      const aSlots = slots(a), bSlots = slots(b);
      aSlots.forEach((nodes, i) => {
        const text2 = bSlots[i].map((n) => n.textContent ?? "").join("");
        writes.push(() => {
          if (nodes.length) {
            nodes[0].textContent = text2;
            nodes.slice(1).forEach((n) => {
              n.textContent = "";
            });
          } else if (text2)
            a.insertBefore(
              a.ownerDocument.createTextNode(text2),
              fixedA[i] ?? null
            );
        });
      });
      fixedA.forEach((x, i) => compare(x, fixedB[i]));
    };
    const compare = (a, b) => {
      if (a.nodeType !== b.nodeType || a.nodeName !== b.nodeName)
        throw Error("Description: modification de structure refus\xE9e");
      if (a.nodeType === 1) {
        const x = a, y = b;
        if (JSON.stringify(listingAttributes(x)) !== JSON.stringify(listingAttributes(y)))
          throw Error(
            "Description: modification des images ou attributs refus\xE9e"
          );
        if (discard2.has(x.tagName) && listingOuterHTML(x) !== listingOuterHTML(y))
          throw Error("Description: modification de m\xE9dia refus\xE9e");
      }
      if (a.nodeType === 8 && a.textContent !== b.textContent)
        throw Error("Description: commentaire modifi\xE9");
      compareChildren(a, b);
    };
    compareChildren(root, target);
    if (apply) writes.forEach((write) => write());
  }
  function validateDescriptionChange(before, after) {
    replaceDescriptionText(fragment(before), after, false);
  }

  // src/core/facts.ts
  var aliases = {
    "brand name": "brand",
    marque: "brand",
    matiere: "material",
    mat\u00E9riau: "material",
    couleur: "color",
    colour: "color",
    taille: "size",
    quantity: "unit quantity",
    quantite: "unit quantity",
    "number of pcs": "number of pieces",
    pieces: "number of pieces",
    "model number": "model",
    "country region of manufacture": "country",
    "country of manufacture": "country",
    "country of origin": "country",
    origin: "country",
    origine: "country",
    "made in": "country",
    "pays de fabrication": "country"
  };
  function matchLabel(label4) {
    const n = norm(label4).replace(/\b(?:required|optional)\b/g, "").trim();
    return aliases[n] ?? n;
  }
  var connecting = new Set(
    "a an the and or for of with in on to from by is are this these it its as at your can be use product features specifications specification package includes include included color material size quantity details description".split(
      " "
    )
  );

  // src/core/itemCondition.ts
  var ITEM_CONDITION_KEY = "condition";
  var ITEM_CONDITION_LABEL = "Item condition";
  var ITEM_CONDITION_PREFERENCE = [
    "New without tags",
    "New",
    "New with tags"
  ];
  function exactConditionLabel(a, b) {
    return compact(a.normalize("NFKC")).toLowerCase() === compact(b.normalize("NFKC")).toLowerCase();
  }
  function preferredItemCondition(field) {
    if (!field?.writable) return null;
    for (const preferred of ITEM_CONDITION_PREFERENCE) {
      const matches = field.options?.filter(
        (option) => exactConditionLabel(option.label, preferred)
      );
      if (matches?.length === 1) return matches[0];
    }
    return null;
  }
  function itemConditionChanges(field) {
    const option = preferredItemCondition(field);
    return field && option ? [{ key: ITEM_CONDITION_KEY, before: field.value, after: option.label }] : [];
  }
  function itemConditionStatus(field) {
    if (!field)
      return "Item condition : champ absent ou ambigu ; v\xE9rifie New ou New without tags dans eBay.";
    const option = preferredItemCondition(field);
    if (!option)
      return "Item condition : aucun choix New, New without tags ou New with tags s\xE9lectionnable ; v\xE9rifie ce champ dans eBay.";
    if (exactConditionLabel(field.value, option.label))
      return `Item condition : ${option.label} confirm\xE9 dans eBay.`;
    return `Item condition : ${option.label} non conserv\xE9 ; s\xE9lectionne ce choix dans eBay.`;
  }

  // src/ebay/condition.ts
  var controls = /* @__PURE__ */ new WeakMap();
  var dialogOwners = /* @__PURE__ */ new WeakMap();
  var dialogBaselines = /* @__PURE__ */ new WeakMap();
  var observedOptions = /* @__PURE__ */ new WeakMap();
  var nativeSummaryOwners = /* @__PURE__ */ new WeakMap();
  var observedOverflows = /* @__PURE__ */ new WeakMap();
  var overflowNotes = /* @__PURE__ */ new WeakMap();
  var scopeSelector = 'section,fieldset,.summary__condition,[data-testid="condition"],[data-testid="item-condition"],[data-field="condition"]';
  var choiceSelector = 'input[type="radio"],[role="radio"],[role="menuitemradio"],[role="option"],button,[role="button"]';
  var dialogSelector = '[role="dialog"],[aria-modal="true"],dialog';
  var nativeSummarySelector = '.summary__condition,[data-testid="condition"],[data-testid="item-condition"],[data-field="condition"]';
  var conditionLabel = (label4) => /^(?:item condition|condition|etat de l objet|provide a condition for your item|add the condition of your item)$/.test(
    norm(label4)
  );
  var knownChoice = (label4) => /^(?:new|new without tags|new with tags|new other|new with defects|open box|used|pre owned|preowned|for parts or not working|like new|very good|good|acceptable|excellent|very good condition|good condition)$/.test(
    norm(label4)
  );
  function visible(node) {
    if (node.closest('[hidden],[aria-hidden="true"]')) return false;
    const win = node.ownerDocument.defaultView;
    for (let current2 = node; current2; current2 = current2.parentElement) {
      const style = win?.getComputedStyle(current2);
      if (style?.display === "none" || style?.visibility === "hidden" || style?.visibility === "collapse")
        return false;
    }
    return true;
  }
  function visibleInside(node, scope) {
    const win = node.ownerDocument.defaultView;
    for (let current2 = node; current2 && current2 !== scope; current2 = current2.parentElement) {
      if (current2.hasAttribute("hidden") || current2.getAttribute("aria-hidden") === "true")
        return false;
      const style = win?.getComputedStyle(current2);
      if (style?.display === "none" || style?.visibility === "hidden" || style?.visibility === "collapse")
        return false;
    }
    return true;
  }
  function enabled(node) {
    return !node.closest(
      '[disabled],[readonly],[aria-disabled="true"],[aria-readonly="true"]'
    ) && !node.hasAttribute("disabled") && !node.hasAttribute("readonly") && node.getAttribute("aria-disabled") !== "true" && node.getAttribute("aria-readonly") !== "true";
  }
  function label2(node) {
    const labelled = node.getAttribute("aria-labelledby")?.split(/\s+/).map((id) => node.ownerDocument.getElementById(id)?.textContent ?? "").join(" ");
    return compact(
      node.getAttribute("aria-label") || labelled || node.labels?.[0]?.textContent || node.closest("label")?.textContent || ""
    );
  }
  function nativeSummaryButton(node) {
    return node.matches('button[name="condition"]') && !!node.closest(nativeSummarySelector);
  }
  function nativeSummaryTrigger(node) {
    if (!nativeSummaryButton(node) || node.getAttribute("type") !== "button" || !node.id || !node.isConnected)
      return false;
    const scope = node.closest(nativeSummarySelector);
    const ids = (node.getAttribute("aria-labelledby") ?? "").trim().split(/\s+/).filter(Boolean);
    if (ids.length !== 2 || new Set(ids).size !== 2 || !ids.includes(node.id))
      return false;
    const references = ids.map((id) => {
      const matches = node.ownerDocument.querySelectorAll(`#${CSS.escape(id)}`);
      return matches.length === 1 ? matches[0] : null;
    });
    const heading = references.find((reference) => reference !== node);
    return references.includes(node) && !!heading && scope.contains(heading) && heading.matches('h2,h3,[role="heading"]') && exactConditionLabel(heading.textContent ?? "", ITEM_CONDITION_LABEL);
  }
  function rememberNativeSummary(current2) {
    if (!nativeSummaryTrigger(current2.el) || !visible(current2.el)) return;
    nativeSummaryOwners.set(current2.el.ownerDocument, {
      el: current2.el,
      scope: current2.el.closest(nativeSummarySelector),
      value: current2.field.value,
      labelledBy: current2.el.getAttribute("aria-labelledby")
    });
  }
  function maskedNativeSummary(doc, dialog) {
    const saved = nativeSummaryOwners.get(doc);
    if (!saved) return null;
    if (saved.el.ownerDocument !== doc || !nativeSummaryTrigger(saved.el) || saved.el.closest(nativeSummarySelector) !== saved.scope || saved.el.getAttribute("aria-labelledby") !== saved.labelledBy || triggerText(saved.el) !== saved.value || !enabled(saved.el) || !saved.el.closest('[aria-hidden="true"]') || saved.dialog && saved.dialog !== dialog) {
      nativeSummaryOwners.delete(doc);
      return null;
    }
    saved.dialog = dialog;
    return saved;
  }
  function dialogName(node) {
    return label2(node) || compact(
      [...node.querySelectorAll('h1,h2,h3,[role="heading"]')].filter(
        (heading) => heading.closest(dialogSelector) === node && visibleInside(heading, node)
      ).map((heading) => heading.textContent ?? "").find((text2) => exactConditionLabel(text2, ITEM_CONDITION_LABEL)) ?? ""
    );
  }
  function isConditionDialog(node) {
    return node.matches(dialogSelector) && exactConditionLabel(dialogName(node), ITEM_CONDITION_LABEL);
  }
  function openDialogs(doc) {
    return [...doc.querySelectorAll(dialogSelector)].filter(
      (node) => visible(node) && !(node.tagName === "DIALOG" && !node.hasAttribute("open")) && !node.parentElement?.closest(dialogSelector)
    );
  }
  function openConditionDialogs(doc) {
    return openDialogs(doc).filter(isConditionDialog);
  }
  function soleConditionDialog(doc) {
    const dialogs = openDialogs(doc);
    return dialogs.length === 1 && isConditionDialog(dialogs[0]) ? dialogs[0] : null;
  }
  function radioTitle(node) {
    const direct = node.getAttribute("aria-label");
    if (direct) return compact(direct);
    const described = new Set(
      (node.getAttribute("aria-describedby") ?? "").split(/\s+/).filter(Boolean)
    );
    const refs = (node.getAttribute("aria-labelledby") ?? "").split(/\s+/).filter(Boolean).map((id) => node.ownerDocument.getElementById(id)).filter((el2) => !!el2);
    const explanatory = (el2) => typeof el2 === "string" ? compact(el2).length > 40 : described.has(el2.id) || el2.matches(
      "p,[data-condition-description],.radio__description,.radio__help-text"
    ) || compact(el2.textContent ?? "").length > 40;
    if (refs.length > 1) {
      const text2 = compact(refs.map((el2) => el2.textContent ?? "").join(" "));
      if (knownChoice(text2)) return text2;
      return refs.slice(1).every(explanatory) ? compact(refs[0].textContent ?? "") : text2;
    }
    const labels = [...node.labels ?? []];
    const source = refs.length === 1 ? refs[0] : labels.length === 1 ? labels[0] : node.closest("label");
    if (!source || !refs.length && labels.length > 1) return label2(node);
    const full = compact(source.textContent ?? "");
    if (knownChoice(full)) return full;
    let container = source;
    for (let depth = 0; depth < 4; depth++) {
      const parts = [...container.childNodes].flatMap(
        (part) => {
          if (part.nodeType === 3)
            return compact(part.textContent ?? "") ? [part.textContent ?? ""] : [];
          if (part.nodeType !== 1) return [];
          const el2 = part;
          return el2 === node || el2.matches('input,svg,[aria-hidden="true"]') || !visibleInside(el2, node.closest(dialogSelector) ?? source) ? [] : [el2];
        }
      );
      if (parts.length === 1 && typeof parts[0] !== "string") {
        container = parts[0];
        continue;
      }
      if (parts.length > 1 && parts.slice(1).every(explanatory))
        return compact(
          typeof parts[0] === "string" ? parts[0] : parts[0].textContent ?? ""
        );
      break;
    }
    return full;
  }
  function choiceLabel(node) {
    if (node.matches('input[type="radio"]')) {
      const dialog = node.closest(dialogSelector);
      return dialog && isConditionDialog(dialog) ? radioTitle(node) : label2(node);
    }
    return compact(
      node.getAttribute("aria-label") || node.querySelector(
        ".btn__text,.toggle-button__text,[data-condition-label]"
      )?.textContent || node.textContent || ""
    );
  }
  function dialogChoices(dialog) {
    return [
      ...dialog.querySelectorAll('input[type="radio"]')
    ].filter(
      (node) => node.closest(dialogSelector) === dialog && visible(node) && enabled(node) && !!choiceLabel(node)
    );
  }
  function dialogDone(dialog, requireEnabled = true) {
    const done = [
      ...dialog.querySelectorAll('button,[role="button"]')
    ].filter(
      (node) => node.closest(dialogSelector) === dialog && visible(node) && exactConditionLabel(label2(node) || node.textContent || "", "Done") && (!compact(node.textContent ?? "") || exactConditionLabel(node.textContent ?? "", "Done"))
    );
    return done.length === 1 && (!requireEnabled || enabled(done[0])) ? done[0] : null;
  }
  function staticConditionValue(scope) {
    if (!scope.matches(nativeSummarySelector)) return null;
    const staticNode = (node) => visible(node) && !node.closest(dialogSelector) && !node.closest(
      'button,[role="button"],label,[role="radio"],[role="option"]'
    ) && !node.querySelector('input,select,button,[role="radio"],[role="button"]');
    let values = [
      ...scope.querySelectorAll("[data-condition-value],.summary__value")
    ].filter(
      (node) => staticNode(node) && !!compact(node.textContent ?? "") && !conditionLabel(node.textContent ?? "")
    );
    if (!values.length)
      values = [...scope.querySelectorAll("p,span")].filter(
        (node) => staticNode(node) && knownChoice(node.textContent ?? "")
      );
    values.push(
      ...[...scope.querySelectorAll('button[name="condition"]')].filter(
        (node) => visible(node) && nativeSummaryTrigger(node)
      )
    );
    values = values.filter(
      (node) => !values.some((other) => other !== node && other.contains(node))
    );
    return values.length === 1 ? nativeSummaryButton(values[0]) ? triggerText(values[0]) : compact(values[0].textContent ?? "") : null;
  }
  function selected(node) {
    return node.matches('input[type="radio"]') && node.checked || node.getAttribute("aria-checked") === "true" || node.getAttribute("aria-selected") === "true" || node.getAttribute("aria-pressed") === "true" || node.getAttribute("data-selected") === "true" || node.matches(
      ".selected,.is-selected,.toggle-button--selected,.btn--selected"
    );
  }
  function choices(scope, includeHidden = false) {
    return [...scope.querySelectorAll(choiceSelector)].filter(
      (node) => enabled(node) && !nativeSummaryButton(node) && (includeHidden ? visibleInside(node, scope) : visible(node)) && (node.matches(
        'input[type="radio"],[role="radio"],[role="menuitemradio"],[role="option"]'
      ) || knownChoice(choiceLabel(node))) && !!choiceLabel(node) && !node.querySelector('input[type="radio"],[role="radio"]')
    );
  }
  function overflowCandidates(scope) {
    return [
      ...scope.querySelectorAll('button,[role="button"]')
    ].filter(
      (node) => visible(node) && enabled(node) && [label2(node), node.textContent ?? ""].some(
        (text2) => /^(?:\.{3}|…|more options)$/i.test(compact(text2))
      )
    );
  }
  function overflowTrigger(scope, controlsId) {
    const candidates = overflowCandidates(scope);
    if (candidates.length !== 1) return null;
    const trigger = candidates[0];
    const ids = trigger.getAttribute("aria-controls")?.trim().split(/\s+/);
    if (ids?.length !== 1 || !ids[0] || controlsId && ids[0] !== controlsId)
      return null;
    const attached = [
      ...scope.ownerDocument.querySelectorAll(`#${CSS.escape(ids[0])}`)
    ];
    if (attached.length > 1 || attached.some(
      (popup) => popup === scope.ownerDocument.body || popup === scope.ownerDocument.documentElement || popup.contains(scope)
    ))
      return null;
    return trigger;
  }
  function controlledOverflow(scope, controlsId) {
    const trigger = overflowTrigger(scope, controlsId);
    if (!trigger) return null;
    const popup = scope.ownerDocument.getElementById(
      trigger.getAttribute("aria-controls").trim()
    );
    return popup && popup !== scope.ownerDocument.body && popup !== scope.ownerDocument.documentElement && !popup.contains(scope) ? popup : null;
  }
  function primaryChoices(scope) {
    const popup = controlledOverflow(scope);
    return choices(scope).filter((node) => !popup?.contains(node));
  }
  function actualOverflowChoices(scope) {
    const observed = observedOverflows.get(scope);
    const popup = controlledOverflow(scope, observed?.controlsId);
    return popup ? choices(popup, true) : [];
  }
  function distinctOptions(options) {
    return options.filter(
      (option, i) => !options.slice(0, i).some((before) => exactConditionLabel(before.label, option.label))
    );
  }
  function mergeConditionOptions(primary, additional) {
    return [
      ...primary,
      ...additional.filter(
        (option) => !primary.some(
          (known) => exactConditionLabel(known.label, option.label)
        )
      )
    ];
  }
  function conditionScopes(doc) {
    const scopes = /* @__PURE__ */ new Set();
    for (const node of doc.querySelectorAll(
      '.summary__condition,[data-testid="condition"],[data-testid="item-condition"],[data-field="condition"]'
    ))
      if (visible(node)) scopes.add(node);
    for (const heading of doc.querySelectorAll(
      'h1,h2,h3,legend,[role="heading"]'
    )) {
      if (!visible(heading) || !conditionLabel(heading.textContent ?? ""))
        continue;
      const scope = heading.closest(scopeSelector) ?? heading.parentElement;
      if (scope && scope !== doc.body && scope !== doc.documentElement)
        scopes.add(scope);
    }
    return [...scopes];
  }
  function triggerText(node) {
    const value = compact(
      node.querySelector(".btn__text,[data-condition-value]")?.textContent ?? node.textContent ?? ""
    );
    const clean = value.replace(/^item condition\s*[:—–-]?\s*/i, "").trim();
    return conditionLabel(clean) || /^(?:select|select one|choose|—|–|-)$/i.test(clean) ? "" : clean;
  }
  function menuFor(node) {
    const id = node.getAttribute("aria-controls");
    if (id) return node.ownerDocument.getElementById(id);
    const dialogs = [
      ...node.ownerDocument.querySelectorAll('[role="dialog"]')
    ].filter(
      (dialog) => visible(dialog) && [...dialog.querySelectorAll('h2,h3,[role="heading"]')].some(
        (heading) => conditionLabel(heading.textContent ?? "")
      )
    );
    return dialogs.length === 1 ? dialogs[0] : null;
  }
  function conditionValue(node) {
    const mode = controls.get(node);
    if (!mode) return void 0;
    if (mode === "select") {
      const select = node;
      return select.value ? compact(select.selectedOptions[0]?.textContent ?? "") : "";
    }
    if (mode === "menu") {
      const summary = node.closest(nativeSummarySelector);
      return (summary && staticConditionValue(summary)) ?? triggerText(node);
    }
    if (mode === "dialog") return dialogBaselines.get(node) ?? "";
    if (mode === "unsupported") {
      const value = staticConditionValue(node);
      if (value !== null) return value;
    }
    const picked = [
      ...primaryChoices(node),
      ...actualOverflowChoices(node)
    ].filter(selected);
    const labels = distinctOptions(
      picked.map((option) => ({
        label: choiceLabel(option),
        value: choiceLabel(option)
      }))
    );
    return labels.length === 1 ? labels[0].label : "";
  }
  function resolveConditionControl(doc, excludedDialog, ambiguity) {
    const scopes = conditionScopes(doc).filter(
      (scope) => !excludedDialog?.contains(scope)
    ), candidates = /* @__PURE__ */ new Map();
    for (const node of doc.querySelectorAll(
      'select,button,[role="combobox"][aria-controls]'
    )) {
      if (!visible(node) || excludedDialog?.contains(node)) continue;
      if (nativeSummaryButton(node) && !nativeSummaryTrigger(node)) continue;
      if (conditionLabel(label2(node)) || nativeSummaryTrigger(node) || controls.get(node) === "menu" && scopes.some((scope) => scope.contains(node)) || node.tagName === "SELECT" && scopes.some((scope) => scope.contains(node)))
        candidates.set(node, node.tagName === "SELECT" ? "select" : "menu");
    }
    for (const scope of scopes) {
      if (scopes.some(
        (other) => other !== scope && controlledOverflow(other)?.contains(scope)
      ))
        continue;
      if ([...candidates].some(
        ([node, mode2]) => mode2 === "menu" && menuFor(node)?.contains(scope)
      ))
        continue;
      if ([...candidates.keys()].some((node) => scope.contains(node))) continue;
      const options2 = primaryChoices(scope).filter(
        (node) => !excludedDialog?.contains(node)
      );
      if (options2.length) candidates.set(scope, "choices");
      else {
        const triggers = [
          ...scope.querySelectorAll('button,[role="button"]')
        ].filter(
          (node) => !excludedDialog?.contains(node) && visible(node) && (!nativeSummaryButton(node) || nativeSummaryTrigger(node)) && (conditionLabel(label2(node)) || conditionLabel(node.textContent ?? "") || /^item condition\s*[:—–-]/i.test(compact(node.textContent ?? "")))
        );
        if (triggers.length === 1) candidates.set(triggers[0], "menu");
        else if (!triggers.length) {
          const edits = staticConditionValue(scope) !== null ? [
            ...scope.querySelectorAll(
              'button,[role="button"]'
            )
          ].filter(
            (node) => !excludedDialog?.contains(node) && visible(node) && /^(?:edit|edit condition|edit item condition)$/i.test(
              label2(node) || compact(node.textContent ?? "")
            )
          ) : [];
          if (edits.length === 1) candidates.set(edits[0], "menu");
          else if (edits.length > 1) {
            if (ambiguity) ambiguity.value = true;
            return null;
          } else candidates.set(scope, "unsupported");
        }
      }
    }
    const unique = [...candidates].filter(
      ([node]) => ![...candidates.keys()].some(
        (other) => other !== node && node.contains(other)
      )
    );
    if (unique.length !== 1) {
      if (unique.length > 1 && ambiguity) ambiguity.value = true;
      return null;
    }
    const [el2, mode] = unique[0];
    controls.set(el2, mode);
    const nativeOptions = mode === "select" ? [...el2.options].filter((option) => option.value && !option.disabled).map((option) => ({
      value: option.value,
      label: compact(option.textContent ?? "")
    })) : mode === "choices" ? primaryChoices(el2).filter((node) => !excludedDialog?.contains(node)).map((node) => ({
      value: choiceLabel(node),
      label: choiceLabel(node)
    })) : mode === "menu" && menuFor(el2) ? choices(menuFor(el2), true).map((node) => ({
      value: choiceLabel(node),
      label: choiceLabel(node)
    })) : [];
    if (mode === "menu" && nativeOptions.length)
      observedOptions.set(el2, nativeOptions);
    let options = mode === "menu" && !menuFor(el2) ? observedOptions.get(el2) ?? nativeOptions : nativeOptions;
    const overflow = mode === "choices" && observedOverflows.get(el2);
    if (overflow && overflowTrigger(el2, overflow.controlsId)) {
      const popup = controlledOverflow(el2, overflow.controlsId);
      const additional = popup ? actualOverflowChoices(el2).map((node) => ({
        value: choiceLabel(node),
        label: choiceLabel(node)
      })) : overflow.options;
      options = mergeConditionOptions(options, additional);
    }
    return {
      el: el2,
      field: {
        key: ITEM_CONDITION_KEY,
        label: ITEM_CONDITION_LABEL,
        value: mode === "choices" && excludedDialog ? (() => {
          const picked = primaryChoices(el2).filter(
            (node) => !excludedDialog.contains(node) && selected(node)
          );
          const labels = distinctOptions(
            picked.map((node) => ({
              value: choiceLabel(node),
              label: choiceLabel(node)
            }))
          );
          return labels.length === 1 ? labels[0].label : "";
        })() : conditionValue(el2) ?? "",
        kind: mode === "select" ? "select" : mode === "unsupported" ? "unsupported" : "menu",
        writable: mode !== "unsupported" && enabled(el2) && visible(el2) && (mode !== "select" || !el2.multiple),
        selector: el2.id ? `#${CSS.escape(el2.id)}` : `${el2.tagName.toLowerCase()} (label: Item condition)`,
        options: options.length ? options : void 0
      }
    };
  }
  function resolveCondition(doc) {
    const nativeDialogs = openConditionDialogs(doc).filter(
      (dialog2) => !!dialog2.querySelector('input[type="radio"]')
    );
    if (!nativeDialogs.length) {
      nativeSummaryOwners.delete(doc);
      return resolveConditionControl(doc);
    }
    const dialog = soleConditionDialog(doc);
    if (!dialog || nativeDialogs.length !== 1) {
      nativeSummaryOwners.delete(doc);
      return null;
    }
    const ambiguity = { value: false };
    let underlying = resolveConditionControl(doc, dialog, ambiguity);
    if (ambiguity.value || underlying?.el.tagName === "SELECT") {
      nativeSummaryOwners.delete(doc);
      return null;
    }
    const remembered = nativeSummaryOwners.get(doc);
    if (remembered && (remembered.el.ownerDocument !== doc || !remembered.el.isConnected || !visible(remembered.el))) {
      const saved = maskedNativeSummary(doc, dialog);
      if (!saved || underlying && underlying.el !== saved.el) {
        nativeSummaryOwners.delete(doc);
        return null;
      }
      underlying = {
        el: saved.el,
        field: {
          key: ITEM_CONDITION_KEY,
          label: ITEM_CONDITION_LABEL,
          value: saved.value,
          kind: "menu",
          writable: false,
          selector: `#${CSS.escape(saved.el.id)}`
        }
      };
    }
    const el2 = underlying?.el ?? dialog;
    const options = dialogChoices(dialog).map((node) => ({
      value: choiceLabel(node),
      label: choiceLabel(node)
    }));
    if (underlying) observedOptions.set(underlying.el, options);
    controls.set(el2, "dialog");
    dialogOwners.set(el2, dialog);
    dialogBaselines.set(el2, underlying?.field.value ?? "");
    return {
      el: el2,
      field: {
        key: ITEM_CONDITION_KEY,
        label: ITEM_CONDITION_LABEL,
        value: underlying?.field.value ?? "",
        kind: "menu",
        writable: enabled(dialog) && !!dialogDone(dialog, false) && !!options.length,
        selector: el2.id ? `#${CSS.escape(el2.id)}` : `${el2.tagName.toLowerCase()} (label: Item condition)`,
        options: options.length ? options : void 0
      }
    };
  }
  async function restoreOverflowPopup(doc, controlsId, wasOpen, originalScope) {
    if (wasOpen) return;
    const fresh = resolveCondition(doc);
    const scope = fresh && controls.get(fresh.el) === "choices" ? fresh.el : originalScope?.isConnected ? originalScope : null;
    if (!scope) return;
    const trigger = overflowTrigger(scope, controlsId);
    const popup = trigger && controlledOverflow(scope, controlsId);
    if (trigger && (trigger.getAttribute("aria-expanded") === "true" || popup && visible(popup))) {
      trigger.click();
      await delay(80);
    }
  }
  async function prepareOverflow(doc, current2, valid) {
    const candidates = overflowCandidates(current2.el);
    if (!candidates.length) {
      overflowNotes.delete(current2.el);
      return current2;
    }
    const trigger = overflowTrigger(current2.el);
    if (!trigger) {
      observedOverflows.delete(current2.el);
      overflowNotes.set(
        current2.el,
        "Autres choix de condition non inspect\xE9s : bouton d\u2019options ambigu ou sans lien natif explicite. Pr\xE9f\xE9rence limit\xE9e aux choix visibles."
      );
      return current2;
    }
    const controlsId = trigger.getAttribute("aria-controls").trim();
    const popup = controlledOverflow(current2.el, controlsId);
    const wasOpen = trigger.getAttribute("aria-expanded") === "true" || !!(popup && visible(popup));
    if (!valid())
      throw Error("Condition : brouillon chang\xE9 ou AurOEBay en pause.");
    if (!wasOpen) trigger.click();
    try {
      await delay(180);
      if (!valid())
        throw Error("Condition : brouillon chang\xE9 ou AurOEBay en pause.");
      const fresh = resolveCondition(doc);
      if (!fresh || controls.get(fresh.el) !== "choices" || !overflowTrigger(fresh.el, controlsId))
        return current2;
      const opened = controlledOverflow(fresh.el, controlsId);
      if (!opened || !visible(opened)) {
        observedOverflows.delete(fresh.el);
        overflowNotes.set(
          fresh.el,
          "Autres choix de condition non inspect\xE9s : le menu natif d\u2019options n\u2019est pas disponible. Pr\xE9f\xE9rence limit\xE9e aux choix visibles."
        );
        return resolveCondition(doc);
      }
      const options = choices(opened).map((node) => ({
        value: choiceLabel(node),
        label: choiceLabel(node)
      }));
      observedOverflows.set(fresh.el, { controlsId, options });
      const primary = primaryChoices(fresh.el).map(choiceLabel);
      const ambiguous = options.some(
        (option) => !primary.some((known) => exactConditionLabel(known, option.label)) && options.filter(
          (other) => exactConditionLabel(other.label, option.label)
        ).length > 1
      );
      if (ambiguous)
        overflowNotes.set(
          fresh.el,
          "Autres choix de condition ambigus : plusieurs options portent le m\xEAme libell\xE9. Pr\xE9f\xE9rence limit\xE9e aux choix non ambigus."
        );
      else if (options.length) overflowNotes.delete(fresh.el);
      else
        overflowNotes.set(
          fresh.el,
          "Autres choix de condition non inspect\xE9s : aucun choix natif lisible dans ce menu. Pr\xE9f\xE9rence limit\xE9e aux choix visibles."
        );
      return resolveCondition(doc);
    } finally {
      await restoreOverflowPopup(doc, controlsId, wasOpen, current2.el);
    }
  }
  function conditionInspectionNote(doc) {
    const current2 = resolveCondition(doc);
    const note = current2 && overflowNotes.get(current2.el);
    return note ? ` ${note}` : "";
  }
  async function finishConditionInspection(doc, current2, valid) {
    if (!current2 || controls.get(current2.el) !== "dialog") return current2;
    if (current2.field.value && await commitConditionDialog(doc, current2.field.value, valid))
      return resolveCondition(doc);
    const dialog = dialogOwners.get(current2.el);
    const exits = dialog && soleConditionDialog(doc) === dialog ? [
      ...dialog.querySelectorAll('button,[role="button"]')
    ].filter(
      (node) => node.closest(dialogSelector) === dialog && visible(node) && enabled(node) && /^(?:cancel|close)$/i.test(
        label2(node) || compact(node.textContent ?? "")
      )
    ) : [];
    if (exits.length === 1) {
      assertConditionContext(valid);
      exits[0].click();
      for (let attempt = 0; attempt < 40; attempt++) {
        await delay(100);
        assertConditionContext(valid);
        if (openDialogs(doc).length) continue;
        const retained = resolveCondition(doc);
        if (retained && exactConditionLabel(retained.field.value, current2.field.value))
          return retained;
      }
    }
    throw Error(
      "Item condition : dialogue natif non refermable sans modifier ce choix ; ferme-le dans eBay puis recommence."
    );
  }
  async function prepareCondition(doc, valid) {
    let current2 = resolveCondition(doc);
    if (current2 && controls.get(current2.el) === "dialog")
      return finishConditionInspection(doc, current2, valid);
    const summary = current2?.el.closest(nativeSummarySelector);
    const savedSummary = summary && staticConditionValue(summary);
    if (current2 && controls.get(current2.el) === "menu" && savedSummary && exactConditionLabel(savedSummary, "New without tags") && !current2.el.getAttribute("aria-controls")?.trim() && !menuFor(current2.el)) {
      observedOptions.set(current2.el, [
        { value: savedSummary, label: savedSummary }
      ]);
      overflowNotes.delete(current2.el);
      return resolveCondition(doc);
    }
    if (current2?.field.writable && controls.get(current2.el) === "choices")
      return prepareOverflow(doc, current2, valid);
    if (!current2 || controls.get(current2.el) !== "menu" || menuFor(current2.el) && choices(menuFor(current2.el), true).length || !current2.field.writable)
      return current2;
    if (!valid())
      throw Error("Condition : brouillon chang\xE9 ou AurOEBay en pause.");
    const trigger = current2.el, wasOpen = trigger.getAttribute("aria-expanded") === "true" || !!(menuFor(trigger) && visible(menuFor(trigger)));
    if (!wasOpen) {
      rememberNativeSummary(current2);
      trigger.click();
    }
    let inspectedDialog = false;
    try {
      await delay(180);
      if (!valid())
        throw Error("Condition : brouillon chang\xE9 ou AurOEBay en pause.");
      current2 = resolveCondition(doc);
      inspectedDialog = !!current2 && controls.get(current2.el) === "dialog";
      return finishConditionInspection(doc, current2, valid);
    } finally {
      const fresh = resolveCondition(doc);
      if (!inspectedDialog && !wasOpen && fresh && controls.get(fresh.el) === "menu" && fresh.el.getAttribute("aria-expanded") === "true")
        fresh.el.click();
    }
  }
  function assertConditionContext(valid) {
    if (!valid())
      throw Error("Condition : brouillon chang\xE9 ou AurOEBay en pause.");
  }
  async function commitConditionDialog(doc, value, valid) {
    assertConditionContext(valid);
    let current2 = resolveCondition(doc);
    let dialog = current2 && dialogOwners.get(current2.el);
    if (!value || !current2?.field.writable || controls.get(current2.el) !== "dialog" || !dialog || soleConditionDialog(doc) !== dialog || !dialogDone(dialog, false))
      return false;
    let matches = dialogChoices(dialog).filter(
      (node) => exactConditionLabel(choiceLabel(node), value)
    );
    const groupNames = new Set(dialogChoices(dialog).map((node) => node.name));
    if (matches.length !== 1 || groupNames.size !== 1) return false;
    assertConditionContext(valid);
    if (!selected(matches[0])) matches[0].click();
    await delay(100);
    assertConditionContext(valid);
    current2 = resolveCondition(doc);
    dialog = current2 && dialogOwners.get(current2.el);
    if (!current2?.field.writable || controls.get(current2.el) !== "dialog" || !dialog || soleConditionDialog(doc) !== dialog)
      return false;
    matches = dialogChoices(dialog).filter(
      (node) => exactConditionLabel(choiceLabel(node), value)
    );
    const picked = dialogChoices(dialog).filter(selected);
    const done = dialogDone(dialog);
    if (matches.length !== 1 || new Set(dialogChoices(dialog).map((node) => node.name)).size !== 1 || picked.length !== 1 || picked[0] !== matches[0] || !done)
      return false;
    assertConditionContext(valid);
    done.click();
    for (let attempt = 0; attempt < 40; attempt++) {
      await delay(100);
      assertConditionContext(valid);
      if (openDialogs(doc).length) continue;
      const retained = resolveCondition(doc);
      if (retained && controls.get(retained.el) !== "dialog" && exactConditionLabel(retained.field.value, value))
        return true;
    }
    throw Error("Item condition : eBay did not retain the value after Done.");
  }
  async function completeOpenConditionDialog(doc, valid) {
    const dialogs = openConditionDialogs(doc);
    if (!dialogs.length) return { handled: false, confirmed: false };
    const current2 = resolveCondition(doc);
    const dialog = current2 && dialogOwners.get(current2.el);
    const unavailable = "Item condition : dialogue natif absent, ambigu ou non validable ; v\xE9rifie ce choix dans eBay.";
    if (dialogs.length !== 1 || !dialog || soleConditionDialog(doc) !== dialog || !current2?.field.writable || controls.get(current2.el) !== "dialog")
      return { handled: true, confirmed: false, note: unavailable };
    const option = preferredItemCondition(current2.field);
    if (!option)
      return {
        handled: true,
        confirmed: false,
        note: "Item condition : aucun choix New, New without tags ou New with tags s\xE9lectionnable ; v\xE9rifie ce champ dans eBay."
      };
    const before = current2.el === dialog ? void 0 : current2.field.value;
    try {
      const confirmed = await commitConditionDialog(doc, option.label, valid);
      return {
        handled: true,
        confirmed,
        before,
        ...confirmed ? { value: option.label } : { note: unavailable }
      };
    } catch (error) {
      assertConditionContext(valid);
      return {
        handled: true,
        confirmed: false,
        before,
        note: error instanceof Error ? error.message : unavailable
      };
    }
  }
  async function chooseCondition(doc, value, valid = () => true) {
    assertConditionContext(valid);
    let current2 = resolveCondition(doc);
    if (!current2?.field.writable) return false;
    const mode = controls.get(current2.el);
    if (mode === "dialog") return commitConditionDialog(doc, value, valid);
    if (mode === "select") {
      const select = current2.el;
      const options = [...select.options].filter(
        (option) => !option.disabled && option.value === value
      );
      if (options.length !== 1) return false;
      const win = doc.defaultView;
      Object.getOwnPropertyDescriptor(
        win.HTMLSelectElement.prototype,
        "value"
      ).set.call(select, value);
      select.dispatchEvent(
        new win.Event("input", { bubbles: true, composed: true })
      );
      select.dispatchEvent(
        new win.Event("change", { bubbles: true, composed: true })
      );
      return;
    }
    const trigger = mode === "menu" ? current2.el : null;
    const wasOpen = trigger?.getAttribute("aria-expanded") === "true" || !!(trigger && menuFor(trigger) && visible(menuFor(trigger)));
    if (trigger && !wasOpen) {
      rememberNativeSummary(current2);
      trigger.click();
    }
    let overflowControlsId;
    let overflowWasOpen = false;
    let usedDialog = false;
    if (mode === "choices") {
      const visibleMatches = primaryChoices(current2.el).filter(
        (node) => exactConditionLabel(choiceLabel(node), value)
      );
      const needsOverflow = value ? visibleMatches.length === 0 : !primaryChoices(current2.el).some(selected) && actualOverflowChoices(current2.el).some(selected);
      const observed = observedOverflows.get(current2.el);
      if (needsOverflow && observed && (!value || observed.options.some(
        (option) => exactConditionLabel(option.label, value)
      ))) {
        const overflow = overflowTrigger(current2.el, observed.controlsId);
        if (!overflow) return false;
        overflowControlsId = observed.controlsId;
        const popup = controlledOverflow(current2.el, overflowControlsId);
        overflowWasOpen = overflow.getAttribute("aria-expanded") === "true" || !!(popup && visible(popup));
        if (!overflowWasOpen) overflow.click();
      } else if (needsOverflow) return false;
    }
    try {
      if (trigger || overflowControlsId) await delay(180);
      assertConditionContext(valid);
      current2 = resolveCondition(doc);
      if (!current2?.field.writable) return false;
      if (controls.get(current2.el) === "dialog") {
        usedDialog = true;
        return commitConditionDialog(doc, value, valid);
      }
      const scope = overflowControlsId ? controlledOverflow(current2.el, overflowControlsId) : controls.get(current2.el) === "menu" ? menuFor(current2.el) : current2.el;
      if (!scope || !visible(scope)) return false;
      if (!value) {
        const clear = [
          ...scope.querySelectorAll('button,[role="button"]')
        ].filter(
          (node) => visible(node) && enabled(node) && /^(?:clear|clear selection|select|select one)$/i.test(
            choiceLabel(node)
          )
        );
        if (clear.length === 1) clear[0].click();
        else {
          const picked = choices(scope).filter(selected);
          if (picked.every((node) => node.matches('input[type="radio"]'))) {
            const win = doc.defaultView;
            for (const node of picked) {
              Object.getOwnPropertyDescriptor(
                win.HTMLInputElement.prototype,
                "checked"
              ).set.call(node, false);
              node.dispatchEvent(
                new win.Event("input", { bubbles: true, composed: true })
              );
              node.dispatchEvent(
                new win.Event("change", { bubbles: true, composed: true })
              );
            }
          } else if (picked.length === 1 && picked[0].hasAttribute("aria-pressed"))
            picked[0].click();
          else
            throw Error(
              "Item condition : s\xE9lection initiale vide non restaurable automatiquement."
            );
        }
        return;
      }
      const matches = choices(scope).filter(
        (node) => exactConditionLabel(choiceLabel(node), value)
      );
      if (matches.length !== 1) return false;
      if (!matches[0].isConnected || !visible(matches[0]) || !enabled(matches[0]))
        return false;
      matches[0].click();
      await delay(140);
    } finally {
      if (overflowControlsId)
        await restoreOverflowPopup(doc, overflowControlsId, overflowWasOpen);
      const fresh = resolveCondition(doc);
      if (!usedDialog && trigger && !wasOpen && fresh && controls.get(fresh.el) === "menu" && fresh.el.getAttribute("aria-expanded") === "true")
        fresh.el.click();
    }
  }

  // src/ebay/fieldResolver.ts
  var controlSelector = 'input:not([type="hidden"]):not([type="checkbox"]):not([type="radio"]):not([type="submit"]):not([type="button"]),textarea,select,[contenteditable="true"],[role="combobox"],button[name^="attributes."],button[aria-controls]';
  function labelOf(el2) {
    if (el2.matches('button[name^="attributes."]'))
      return compact(el2.getAttribute("name").slice("attributes.".length));
    const direct = el2.getAttribute("aria-label");
    if (direct) return compact(direct);
    const by = el2.getAttribute("aria-labelledby")?.split(/\s+/).map((id) => el2.ownerDocument.getElementById(id)?.textContent ?? "").join(" ");
    if (by) return compact(by);
    const labels = el2.labels;
    if (labels?.length) return compact(labels[0].textContent ?? "");
    const wrap = el2.closest("label");
    if (wrap) return compact(wrap.textContent ?? "");
    const near = el2.closest("[data-field],.field,.form-field,.ux-labels-values,fieldset")?.querySelector("label,legend,[data-label]");
    if (near) return compact(near.textContent ?? "");
    return el2.getAttribute("name") ?? el2.id;
  }
  function isNativeMenuControl(el2) {
    return el2.matches("button[aria-controls]") && (el2.matches('button[name^="attributes."]') || manufactureLabel(labelOf(el2)));
  }
  function readValue(el2) {
    const condition = conditionValue(el2);
    if (condition !== void 0) return condition;
    if (el2.matches('button[name^="attributes."]') || isNativeMenuControl(el2)) {
      const value = compact(
        el2.querySelector(".btn__text")?.textContent ?? el2.textContent ?? ""
      );
      return norm(value) === norm(labelOf(el2)) || /^(select|select one|choose|selectionner)$/.test(norm(value)) ? "" : value;
    }
    if (el2.tagName === "SELECT") {
      const s = el2;
      return s.value ? s.selectedOptions[0]?.textContent?.trim() ?? s.value : "";
    }
    if ("value" in el2) return String(el2.value);
    return editableHTML(el2);
  }
  function rawValue(el2) {
    const condition = conditionValue(el2);
    if (condition !== void 0 && el2.tagName !== "SELECT") return condition;
    if (el2.matches('button[name^="attributes."]') || isNativeMenuControl(el2))
      return readValue(el2);
    return "value" in el2 ? String(el2.value) : editableHTML(el2);
  }
  function usable(el2) {
    if (el2.closest('[hidden],[aria-hidden="true"]') || el2.getAttribute("type") === "hidden")
      return false;
    const win = el2.ownerDocument.defaultView;
    if (win)
      for (let node = el2; node; node = node.parentElement) {
        const style = win.getComputedStyle(node);
        if (style.display === "none" || style.visibility === "hidden" || style.visibility === "collapse")
          return false;
      }
    return true;
  }
  function selectorFor(el2) {
    if (el2.id) return `#${CSS.escape(el2.id)}`;
    for (const attr of ["data-testid", "name", "aria-label"]) {
      const val = el2.getAttribute(attr);
      if (val) return `${el2.tagName.toLowerCase()}[${attr}="${CSS.escape(val)}"]`;
    }
    return `${el2.tagName.toLowerCase()} (label: ${labelOf(el2)})`;
  }
  function resolveElement(el2, key, label4) {
    if (el2.tagName === "IFRAME") {
      try {
        if (!usable(el2)) return null;
        const body = el2.contentDocument?.body;
        const editors = body ? [...body.querySelectorAll('[contenteditable="true"]')].filter(usable) : [];
        if (editors.length === 1) el2 = editors[0];
        else if (editors.length > 1) return null;
        else if (body && (body.isContentEditable || body.contentEditable === "true" || body.ownerDocument.designMode === "on"))
          el2 = body;
        else return null;
      } catch {
        return null;
      }
    }
    if (!el2.matches(controlSelector) && el2.tagName !== "BODY") return null;
    if (el2.matches("button[aria-controls]") && !el2.matches('button[name^="attributes."]') && !isNativeMenuControl(el2))
      return null;
    const select = el2.tagName === "SELECT";
    const text2 = ["INPUT", "TEXTAREA"].includes(el2.tagName);
    const html = !text2 && !select && (el2.getAttribute("contenteditable") === "true" || el2.tagName === "BODY");
    const menu = isNativeMenuControl(el2);
    const kind = menu ? "menu" : select ? "select" : el2.tagName === "TEXTAREA" ? "textarea" : text2 ? "text" : html ? "html" : "unsupported";
    const unsupported = el2.getAttribute("role") === "combobox" || select && el2.multiple || ["INPUT"].includes(el2.tagName) && !["text", "search", "number", ""].includes(
      el2.getAttribute("type") ?? ""
    );
    const writable = kind !== "unsupported" && !unsupported && !el2.hasAttribute("disabled") && !el2.hasAttribute("readonly") && el2.getAttribute("aria-readonly") !== "true" && el2.getAttribute("aria-disabled") !== "true" && usable(el2);
    const menuOptions = menu ? [
      ...el2.ownerDocument.getElementById(el2.getAttribute("aria-controls"))?.querySelectorAll(
        '[role="menuitemradio"],[role="menuitemcheckbox"],[role="option"],.se-toggle-group-menu__menu-container button.toggle-button'
      ) ?? []
    ].filter((o) => o.getAttribute("aria-disabled") !== "true").map((o) => ({
      value: compact(o.textContent ?? ""),
      label: compact(o.textContent ?? "")
    })).filter(
      (o, i, all) => o.value && all.findIndex((x) => norm(x.value) === norm(o.value)) === i
    ) : [];
    return {
      el: el2,
      field: {
        key,
        label: label4,
        value: readValue(el2),
        kind: unsupported ? "unsupported" : kind,
        writable,
        selector: selectorFor(el2),
        options: select ? Array.from(el2.options).filter((o) => !o.disabled && o.value).map((o) => ({
          value: o.value,
          label: compact(o.textContent ?? "")
        })) : menuOptions.length ? menuOptions : void 0,
        maxLength: text2 && el2.maxLength > 0 ? el2.maxLength : void 0
      }
    };
  }
  function resolveNamed(root, label4, selectors, aliases2) {
    const candidates = queryAll(root, selectors).filter(usable);
    for (const el2 of root.querySelectorAll(controlSelector)) {
      if (usable(el2) && aliases2.includes(norm(labelOf(el2)))) candidates.push(el2);
    }
    const unique = [...new Set(candidates)];
    const resolved = unique.map(
      (el2) => resolveElement(el2, label4, label4 === "title" ? "Title" : "Description")
    ).filter((x) => !!x);
    const writable = resolved.filter((x) => x.field.writable);
    if (writable.length > 1) return null;
    return writable[0] ?? (resolved.length === 1 ? resolved[0] : null);
  }
  function resolveFields(doc, settings) {
    const title = resolveNamed(
      doc,
      "title",
      [
        ...SELECTORS.title,
        ...settings.fallbackSelectors.title ? [settings.fallbackSelectors.title] : []
      ],
      ["title", "listing title", "item title", "titre"]
    );
    const description = resolveNamed(
      doc,
      "description",
      [
        ...SELECTORS.description,
        ...settings.fallbackSelectors.description ? [settings.fallbackSelectors.description] : []
      ],
      [
        "description",
        "item description",
        "listing description",
        "description de l objet"
      ]
    );
    const scopes = queryAll(doc, [
      ...SELECTORS.specifics,
      ...settings.fallbackSelectors.specifics ? [settings.fallbackSelectors.specifics] : []
    ]);
    const condition = resolveCondition(doc);
    for (const heading of doc.querySelectorAll("h2,h3,legend"))
      if (["item specifics", "caracteristiques de l objet"].includes(
        norm(heading.textContent ?? "")
      )) {
        const scope = heading.closest("section,fieldset");
        if (scope) scopes.push(scope);
      }
    const controls2 = /* @__PURE__ */ new Set();
    for (const scope of scopes)
      scope.querySelectorAll(controlSelector).forEach((el2) => controls2.add(el2));
    for (const el2 of doc.querySelectorAll(controlSelector))
      if (manufactureLabel(labelOf(el2)) || SPECIFIC_LABELS.some((l) => matchLabel(l) === matchLabel(labelOf(el2))))
        controls2.add(el2);
    const resolved = [];
    for (const el2 of controls2) {
      if (el2 === title?.el || el2 === description?.el || el2 === condition?.el || condition?.el.contains(el2) || !usable(el2) || el2.closest('[role="menu"],.fake-menu-button__menu') || el2.getAttribute("name")?.startsWith("search-box-"))
        continue;
      const label4 = labelOf(el2).replace(/\s*\*\s*$/, "");
      if (!label4 || /(?:price|payment|shipping|location|return|policy|quantity available|stock|sku)/i.test(
        label4
      ))
        continue;
      const key = manufactureLabel(label4) ? "specific:country" : `specific:${matchLabel(label4)}`;
      const r = resolveElement(el2, key, label4);
      if (r) resolved.push(r);
    }
    const origins = resolved.filter((r) => manufactureLabel(r.field.label));
    if (new Set(origins.map((r) => norm(r.field.label))).size > 1)
      origins.forEach((r) => {
        r.field.key = `specific:country:${norm(r.field.label)}`;
      });
    const counts = /* @__PURE__ */ new Map();
    resolved.forEach(
      (r) => counts.set(r.field.key, (counts.get(r.field.key) ?? 0) + 1)
    );
    resolved.forEach((r) => {
      if (counts.get(r.field.key) !== 1) {
        r.field.writable = false;
        r.field.kind = "unsupported";
      }
    });
    return { title, description, condition, specifics: resolved };
  }

  // src/ebay/detection.ts
  function pageType(url) {
    try {
      const u = new URL(url);
      if (!/(^|\.)ebay\.com$/.test(u.hostname)) return "other";
      if (/^\/sl\/(?:sell|list|revise)|^\/lstng|^\/sell\/|^\/sh\/lst\/drafts\//.test(
        u.pathname
      ) || u.pathname === "/sl/sell" || u.hostname === "bulkedit.ebay.com" && u.pathname === "/msku")
        return "draft";
      if (/^\/itm\//.test(u.pathname)) return "product";
      if (/^\/sch\//.test(u.pathname)) return "results";
      return "other";
    } catch {
      return "other";
    }
  }
  function draftIdentity(url) {
    const u = new URL(url);
    const keys = [
      "draftId",
      "draftid",
      "draft_id",
      "itemId",
      "itemid",
      "item_id",
      "listingId",
      "mode"
    ];
    return `${u.origin}${u.pathname}?${keys.filter((k) => u.searchParams.has(k)).map((k) => `${k}=${u.searchParams.get(k)}`).join("&")}${u.hash}`;
  }

  // src/ebay/extract.ts
  function extractVariants(doc) {
    const summaries = [
      ...doc.querySelectorAll(".summary__variations dl")
    ].flatMap(
      (dl) => [...dl.querySelectorAll("dt")].flatMap((dt) => {
        const value = dt.nextElementSibling;
        const name = compact(dt.textContent ?? "");
        if (!value || value.tagName !== "DD" || !name || /^(price|quantity)$/i.test(name))
          return [];
        return [
          {
            name,
            values: compact(value.textContent ?? "").split(/,\s*/).filter(Boolean)
          }
        ];
      })
    );
    return [
      ...summaries,
      ...queryAll(doc, SELECTORS.variations).filter((el2) => !el2.matches(".summary__variations") || !summaries.length).slice(0, 100).map((el2) => ({
        name: compact(
          el2.getAttribute("data-name") ?? el2.querySelector("label,legend,[data-variation-name]")?.textContent ?? "Variation"
        ),
        values: [
          ...el2.querySelectorAll(
            'option:not([value=""]),[data-variation-value]'
          )
        ].map((x) => compact(x.textContent ?? "")).filter(Boolean).slice(0, 50),
        price: el2.querySelector('input[name*="price" i]')?.value ?? el2.querySelector("[data-price]")?.textContent?.trim()
      }))
    ];
  }
  function extractDraft(doc, url, settings) {
    if (pageType(url) !== "draft")
      throw Error("Open an eBay US listing draft/editor.");
    const fields = resolveFields(doc, settings);
    if (!fields.title)
      throw Error(
        "Title field missing or ambiguous. Open the editor, wait for it to load, then retry."
      );
    const warnings = [];
    if (!fields.description)
      warnings.push(
        "Description editor missing, ambiguous or cross-origin \u2014 manual review."
      );
    if (!fields.specifics.length)
      warnings.push(
        "No Item Specifics found. Expand the section and analyze again."
      );
    const variants = extractVariants(doc);
    if (variants.length)
      warnings.push(
        `${variants.length} groupes de variantes : v\xE9rifie les noms et quantit\xE9s. Les prix se r\xE8glent dans le panneau Prix des variantes.`
      );
    return {
      url: cleanURL(url),
      identity: draftIdentity(url),
      capturedAt: Date.now(),
      title: fields.title.field,
      description: fields.description?.field ?? null,
      condition: fields.condition?.field ?? null,
      specifics: fields.specifics.map((r) => r.field),
      variants,
      warnings
    };
  }

  // src/ebay/libraryCapture.ts
  function contentText(doc, html) {
    const template = doc.createElement("template");
    template.innerHTML = html;
    template.content.querySelectorAll("script,style,meta,link,noscript").forEach((e) => e.remove());
    return compact(template.content.textContent ?? "");
  }
  function textAt(doc, selectors) {
    return compact(queryAll(doc, selectors)[0]?.textContent ?? "");
  }
  function controlValue(doc, selectors) {
    const candidates = queryAll(doc, selectors).filter(
      (e) => !e.closest("table,[hidden],[aria-hidden=true]")
    );
    if (candidates.length !== 1) return null;
    const node = candidates[0];
    return compact("value" in node ? String(node.value) : node.textContent ?? "") || null;
  }
  function readDescription(doc, kind, fallback, warnings) {
    if (kind === "draft" && fallback) {
      if (fallback.length > EBAY_LIBRARY_LIMITS.htmlCharacters) {
        warnings.push(
          "Description eBay trop volumineuse : elle n\u2019a pas \xE9t\xE9 tronqu\xE9e ni enregistr\xE9e."
        );
        return "";
      }
      return fallback;
    }
    const roots = queryAll(
      doc,
      kind === "item" ? [
        "#desc_div",
        '[data-testid="item-description"]',
        ".x-item-description__main"
      ] : []
    );
    const html = [];
    for (const root of roots) {
      if (roots.some((other) => other !== root && other.contains(root))) continue;
      const clone = root.cloneNode(true);
      clone.querySelectorAll("iframe,script,style.darkreader").forEach((e) => e.remove());
      if (compact(clone.textContent ?? "") || clone.querySelector("img"))
        html.push(clone.innerHTML);
    }
    const frames = queryAll(
      doc,
      kind === "item" ? [
        "iframe#desc_ifr",
        'iframe[title="Seller description"]',
        '[data-testid="item-description"] iframe'
      ] : SELECTORS.description.filter((s) => s.startsWith("iframe"))
    );
    for (const element of frames) {
      try {
        const body = element.contentDocument?.body;
        if (!body) {
          warnings.push(
            "Description eBay dans un cadre inaccessible : elle n\u2019a pas \xE9t\xE9 copi\xE9e."
          );
          continue;
        }
        const content = editableHTML(body);
        if (compact(body.textContent ?? "") || body.querySelector("img"))
          html.push(content);
      } catch {
        warnings.push(
          "Description eBay dans un cadre inaccessible : elle n\u2019a pas \xE9t\xE9 copi\xE9e."
        );
      }
    }
    const result = [...new Set(html)].join("");
    if (result.length > EBAY_LIBRARY_LIMITS.htmlCharacters) {
      warnings.push(
        "Description eBay trop volumineuse : elle n\u2019a pas \xE9t\xE9 tronqu\xE9e ni enregistr\xE9e."
      );
      return "";
    }
    return result;
  }
  function readGallery(doc, kind, warnings) {
    const scopes = kind === "item" ? [
      ".ux-image-carousel-container",
      ".ux-image-carousel",
      "#mainImgHldr",
      "#PicturePanel",
      "#icImg",
      '[data-testid="item-gallery"]',
      '[data-testid="ebay-gallery"]'
    ] : SELECTORS.uploadedPhotos;
    const images = [];
    for (const root of queryAll(doc, scopes)) {
      const nodes = root.matches("img") ? [root] : [root, ...root.querySelectorAll("img")];
      for (const node of nodes) {
        const image = node;
        const values = [
          image.getAttribute("data-zoom-src"),
          image.getAttribute("data-src"),
          image.getAttribute("src"),
          image.currentSrc
        ];
        for (const match of (node.getAttribute("style") ?? "").matchAll(
          /background-image\s*:\s*url\(\s*["']?([^"')]+)["']?\s*\)/gi
        ))
          values.push(match[1]);
        let accepted = false;
        for (const value of values.filter((s) => !!s)) {
          const url = ebayLibraryImageURL(value);
          if (!url) continue;
          accepted = true;
          if (!images.includes(url)) images.push(url);
          break;
        }
        if (!accepted && values.some(Boolean))
          warnings.push(
            "Une photo eBay non h\xE9berg\xE9e sur un CDN reconnu n\u2019a pas \xE9t\xE9 enregistr\xE9e."
          );
      }
    }
    return images.slice(0, 100);
  }
  function publicVariants(doc) {
    const variants = [];
    for (const select of doc.querySelectorAll(
      '.x-msku select,.x-sku select,[data-testid="variation-selector"] select'
    )) {
      const label4 = select.labels?.[0]?.textContent ?? select.getAttribute("aria-label") ?? select.closest(
        ".x-msku__box-cont,.x-sku__box-cont,[data-testid=variation-selector]"
      )?.querySelector("label")?.textContent ?? "Variation";
      const values = [...select.options].filter(
        (o) => o.value && !/^(?:select|choose|sélectionner)(?:\s|$)/i.test(
          compact(o.textContent ?? "")
        )
      ).map((o) => compact(o.textContent ?? "")).filter(Boolean);
      const name = compact(label4).replace(/:\s*$/, "");
      if (values.length && !variants.some((v) => v.name === name))
        variants.push({ name, values: [...new Set(values)].slice(0, 200) });
    }
    return variants.length ? variants.slice(0, 10) : extractVariants(doc).filter((a) => a.values.length).slice(0, 10);
  }
  async function captureEbayLibrary(doc, url, settings) {
    const canonical = canonicalEbayLibraryURL(url), warnings = [];
    let title = "", category = "", specifics2 = [], variants = [], fallback = "";
    let price2 = null, currency = null, quantity = null;
    let seed;
    if (canonical.kind === "draft") {
      const draft = extractDraft(doc, url, settings);
      title = draft.title.value;
      specifics2 = draft.specifics.filter((s) => !!s.value && s.kind !== "unsupported").map((s) => ({ label: s.label, value: s.value }));
      variants = draft.variants.filter((a) => a.values.length).slice(0, 10);
      warnings.push(...draft.warnings);
      fallback = draft.description?.value ?? "";
      category = textAt(doc, [
        '[data-testid="listing-category"]',
        '[data-testid="category"]',
        ".summary__category",
        ".summary__category-primary"
      ]);
      price2 = controlValue(doc, [...SELECTORS.simplePrice, "input#price"]);
      quantity = controlValue(doc, [
        'input[name="quantity"]',
        'input[aria-label="Quantity"]',
        'input[id$="-quantity"]'
      ]);
      currency = textAt(doc, [
        '[data-testid="listing-currency"]',
        ".summary__pricing [data-currency]"
      ]) || null;
    } else {
      title = textAt(doc, SELECTORS.seedTitle);
      category = queryAll(doc, SELECTORS.seedCategory).map((n) => compact(n.textContent ?? "")).filter(Boolean).join(" > ");
      specifics2 = queryAll(doc, SELECTORS.seedSpecifics).flatMap(
        (scope) => [...scope.querySelectorAll("dt")].flatMap((dt) => {
          const dd = dt.nextElementSibling, label4 = compact(dt.textContent ?? ""), value = dd?.tagName === "DD" ? compact(dd.textContent ?? "") : "";
          return label4 && value ? [{ label: label4, value }] : [];
        })
      ).slice(0, 200);
      const observedPrice = textAt(doc, SELECTORS.seedPrice);
      const usd = observedPrice.match(/^US\s*\$\s*([\d,]+(?:\.\d{1,2})?)/i);
      price2 = usd ? usd[1].replace(/,/g, "") : observedPrice || null;
      currency = usd ? "USD" : null;
      quantity = controlValue(doc, [
        "input#qtyTextBox",
        'input[name="quantity"]'
      ]);
      if (quantity)
        warnings.push(
          "Quantit\xE9 eBay lue dans le champ de s\xE9lection : elle ne prouve pas le stock total du vendeur."
        );
      variants = publicVariants(doc);
      try {
        const value = extractEbaySeed(doc, url);
        if (validEbaySeed(value)) seed = value;
      } catch {
        warnings.push(
          "R\xE9f\xE9rence eBay incompl\xE8te pour l\u2019import : la pr\xE9paration relira la fiche avant de cr\xE9er un brouillon."
        );
      }
    }
    if (!title.trim())
      throw Error(
        "Titre eBay non reconnu. Ouvre la fiche ou le brouillon complet puis r\xE9essaie."
      );
    const descriptionHTML = readDescription(
      doc,
      canonical.kind,
      fallback,
      warnings
    ), images = readGallery(doc, canonical.kind, warnings);
    if (!category)
      warnings.push(
        "Cat\xE9gorie eBay non visible : aucune cat\xE9gorie n\u2019a \xE9t\xE9 invent\xE9e."
      );
    if (!specifics2.length)
      warnings.push("Caract\xE9ristiques eBay non visibles dans cette page.");
    if (!descriptionHTML)
      warnings.push(
        "Description eBay absente, non charg\xE9e ou inaccessible dans cette page."
      );
    if (!images.length)
      warnings.push("Galerie eBay non visible dans cette page.");
    if (price2 === null)
      warnings.push(
        "Prix eBay non visible ; les prix des variantes n\u2019ont pas \xE9t\xE9 devin\xE9s."
      );
    else if (!currency)
      warnings.push(
        "Devise eBay non confirm\xE9e dans la page : aucune conversion n\u2019a \xE9t\xE9 appliqu\xE9e."
      );
    if (quantity === null)
      warnings.push("Quantit\xE9 eBay non visible dans cette page.");
    if (!variants.length && doc.querySelector('.x-msku,.x-sku,[data-testid="variation-selector"]'))
      warnings.push(
        "Options eBay non accessibles sans ouvrir leurs menus : elles n\u2019ont pas \xE9t\xE9 invent\xE9es."
      );
    if (variants.length)
      warnings.push(
        "Options eBay visibles seulement : co\xFBts et stock exacts restent \xE0 v\xE9rifier."
      );
    return validateEbayLibrarySnapshot({
      ...canonical,
      title,
      capturedAt: Date.now(),
      category,
      specifics: specifics2,
      price: price2,
      currency,
      quantity,
      images,
      descriptionHTML,
      descriptionText: contentText(doc, descriptionHTML),
      variants,
      warnings: [...new Set(warnings)].slice(0, 100),
      ...seed ? { seed } : {}
    });
  }

  // src/ebay/libraryButton.ts
  function setupLibraryButton(doc, enabled2, capture) {
    doc.getElementById("auro-library-capture")?.remove();
    if (!enabled2() || !ebayItemId(location.href)) return () => {
    };
    const heading = queryAll(doc, SELECTORS.seedTitle)[0];
    if (!heading) return () => {
    };
    const wrap = doc.createElement("div");
    wrap.id = "auro-library-capture";
    wrap.setAttribute("data-auroebay-library-capture", "");
    wrap.style.cssText = "margin:12px 0;font:14px system-ui;line-height:1.5";
    const button = doc.createElement("button");
    button.type = "button";
    button.append(brandButtonIcon(doc), "Enregistrer eBay + AliExpress");
    button.style.cssText = brandButtonStyle("primary", "0");
    brandButtonHover(button);
    const status = doc.createElement("p");
    status.setAttribute("role", "status");
    status.style.margin = "6px 0";
    wrap.append(button, status);
    heading.after(wrap);
    button.addEventListener("click", () => {
      if (!enabled2() || button.disabled) return;
      button.disabled = true;
      const url = location.href;
      status.textContent = "Lecture de cette fiche eBay\u2026";
      void capture().then(async (snapshot) => {
        if (!enabled2() || location.href !== url)
          throw Error("La fiche eBay a chang\xE9 pendant la lecture.");
        await message({ type: "EBAY_LIBRARY_CAPTURE", snapshot });
        status.textContent = "Fiche eBay pr\xEAte. Colle le lien AliExpress dans le panneau AurOEBay, \xE0 droite.";
      }).catch((error) => {
        status.textContent = error instanceof Error ? error.message : String(error);
      }).finally(() => {
        button.disabled = !enabled2();
      });
    });
    return () => wrap.remove();
  }

  // src/core/library.ts
  function canonicalLibraryEbayURL(value) {
    return canonicalEbayLibraryURL(value);
  }

  // src/core/listingCost.ts
  function isPriceText(text2) {
    return /^(US\s?)?\$\s?\d[\d,]*(\.\d{1,2})?(\s*(-|–|to)\s*(US\s?)?\$\s?\d[\d,]*(\.\d{1,2})?)?$/i.test(text2.replace(/\s+/g, " ").trim());
  }

  // src/core/libraryNavigation.ts
  function sellerHubListingsURL(value) {
    try {
      const url = new URL(value);
      return url.protocol === "https:" && /(^|\.)ebay\.com$/.test(url.hostname) && !url.username && !url.password && !url.port && /^\/sh\/lst\/(?:active|drafts|inactive|scheduled)\/?$/.test(url.pathname);
    } catch {
      return false;
    }
  }
  function libraryLinkIdentity(value) {
    const link = canonicalLibraryEbayURL(value);
    const url = new URL(link.url);
    return link.kind === "item" ? "item:" + url.pathname.split("/").at(-1) : "draft:" + (url.searchParams.get("draftId") ?? url.searchParams.get("draft_id"));
  }

  // src/ebay/libraryLinks.ts
  function rows(doc) {
    const result = [];
    for (const node of doc.querySelectorAll(
      'tr,[role="row"],[data-testid="listing-row"],[data-listing-id]'
    )) {
      if (node.closest("[data-auroebay-library-links]")) continue;
      const links = [
        ...node.querySelectorAll("a[href]")
      ].filter((a) => !a.closest("[data-auroebay-library-links]"));
      const candidates = links.flatMap((anchor) => {
        try {
          return [{ anchor, url: canonicalLibraryEbayURL(anchor.href).url }];
        } catch {
          return [];
        }
      });
      if (new Set(candidates.map((c) => libraryLinkIdentity(c.url))).size !== 1)
        continue;
      const candidate = candidates.find((c) => c.anchor.textContent?.trim()) ?? candidates[0];
      if (!candidate || result.some((r) => r.node === node || r.node.contains(node)))
        continue;
      const shown = [...node.querySelectorAll("a[href]")].find(
        (a) => !a.closest("[data-auroebay-library-links]") && /^https:\/\/([a-z]+\.)?aliexpress\.(com|us)\/item\/\d+\.html/.test(a.href)
      );
      const sku = (node.textContent ?? "").match(/\bAE-(\d{6,20})\b/)?.[1];
      result.push({
        node,
        ...candidate,
        ...sku ? { supplierId: sku } : {},
        title: (candidate.anchor.textContent ?? "").trim().slice(0, 200),
        ...shown ? { supplierUrl: shown.href } : {}
      });
      if (result.length === 200) break;
    }
    return result;
  }
  function setupLibraryLinks(doc, enabled2) {
    let active2 = true, epoch = 0, signature = "", timer;
    const clear = () => doc.querySelectorAll("[data-auroebay-library-links],[data-auroebay-cost]").forEach((n) => n.remove());
    const showCost = (row, cost) => {
      let price2 = null;
      for (const el2 of row.querySelectorAll("span,div,td,p,strong,b")) {
        if (el2.closest("[data-auroebay-library-links],[data-auroebay-cost],a,button,input,select")) continue;
        if (isPriceText(el2.textContent ?? "") && ![...el2.children].some((c) => isPriceText(c.textContent ?? ""))) {
          price2 = el2;
          break;
        }
      }
      if (!price2) return;
      const tag = doc.createElement("span");
      tag.setAttribute("data-auroebay-cost", "");
      tag.textContent = `AE ${cost}`;
      tag.title = "Co\xFBt AliExpress du fournisseur principal (sans livraison)";
      tag.style.cssText = "margin-left:6px;color:#ff8a3d;font:600 11px system-ui;opacity:.85;white-space:nowrap";
      price2.after(tag);
    };
    const link = (text2, url, label4, library) => {
      const a = doc.createElement("a");
      a.href = url;
      a.target = "_blank";
      a.rel = "noopener noreferrer";
      a.textContent = text2;
      a.title = label4;
      a.style.cssText = "display:inline-block;padding:5px 9px;border-radius:7px;background:#173e35;color:#fff;font:600 12px system-ui;text-decoration:none;border:1px solid #347464";
      const navigate = (event) => {
        event.stopPropagation();
        if (!library || event.type === "auxclick" && event.button !== 1) return;
        event.preventDefault();
        void message({
          type: "OPEN_LIBRARY_PRODUCT",
          ...library,
          active: event.button !== 1 && !event.ctrlKey && !event.metaKey
        }).catch(() => {
          a.title = "Impossible d\u2019ouvrir cette fiche. Recharge eBay puis r\xE9essaie.";
        });
      };
      a.addEventListener("click", navigate);
      a.addEventListener("auxclick", navigate);
      return a;
    };
    async function refresh(force = false) {
      if (!active2 || !enabled2() || !sellerHubListingsURL(location.href)) {
        clear();
        return;
      }
      const current2 = rows(doc);
      const next = current2.map((r) => r.url).sort().join("|");
      if (!force && next === signature && current2.every(
        (r) => r.node.getAttribute("data-auro-library-checked") === r.url && (!r.node.hasAttribute("data-auro-library-matched") || !!r.node.querySelector("[data-auroebay-library-links]"))
      ))
        return;
      signature = next;
      const version2 = ++epoch;
      try {
        const result = await message({
          type: "LIBRARY_LINKS",
          urls: current2.map((r) => r.url),
          hints: current2.map((r) => ({
            url: r.url,
            title: r.title,
            ...r.supplierUrl ? { supplierUrl: r.supplierUrl } : {},
            ...r.supplierId ? { supplierId: r.supplierId } : {}
          }))
        });
        if (!active2 || !enabled2() || version2 !== epoch || !sellerHubListingsURL(location.href))
          return;
        clear();
        for (const row of rows(doc)) {
          const found = result.find((r) => r.url === row.url);
          row.node.setAttribute("data-auro-library-checked", row.url);
          row.node.toggleAttribute(
            "data-auro-library-matched",
            !!found?.products.length || !!found?.supplierUrl
          );
          if (!found?.products.length && found?.supplierUrl) {
            const only = doc.createElement("div");
            only.setAttribute("data-auroebay-library-links", "");
            only.addEventListener("click", (event) => event.stopPropagation());
            only.style.cssText = "display:flex;flex-wrap:wrap;gap:6px;margin:8px 0;font:12px system-ui";
            only.append(
              link("AliExpress \u2197", found.supplierUrl, "Page fournisseur AliExpress")
            );
            const cell2 = row.anchor.closest('td,[role="cell"]');
            (cell2 && row.node.contains(cell2) ? cell2 : row.node).append(only);
            continue;
          }
          if (!found?.products.length) continue;
          const group = doc.createElement("div");
          group.setAttribute("data-auroebay-library-links", "");
          group.addEventListener("click", (event) => event.stopPropagation());
          group.style.cssText = "display:flex;flex-wrap:wrap;gap:6px;margin:8px 0;font:12px system-ui";
          const appendProduct = (p, target, multiple) => {
            target.append(
              link(
                multiple ? p.name + " \xB7 AurOEBay \u2197" : "Fiche AurOEBay \u2197",
                chrome.runtime.getURL("dashboard.html") + "?product=" + encodeURIComponent(p.id),
                "Ouvrir " + p.name + " dans ma biblioth\xE8que",
                { productId: p.id, listingUrl: row.url }
              )
            );
            const supplierUrl = p.supplierUrl ?? found.supplierUrl;
            if (supplierUrl)
              target.append(
                link(
                  "Fournisseur AliExpress \u2197",
                  supplierUrl,
                  p.supplierName + " \xB7 fournisseur principal"
                )
              );
          };
          const cost = found.products.find((p) => p.cost)?.cost;
          if (cost) showCost(row.node, cost);
          if (found.products.length === 1)
            appendProduct(found.products[0], group, false);
          else {
            const details = doc.createElement("details"), summary = doc.createElement("summary");
            summary.textContent = found.products.length + " fiches AurOEBay reli\xE9es";
            details.append(summary);
            for (const p of found.products) {
              const entry = doc.createElement("div");
              entry.style.cssText = "display:flex;flex-wrap:wrap;gap:6px;margin-top:6px";
              appendProduct(p, entry, true);
              details.append(entry);
            }
            group.append(details);
          }
          const cell = row.anchor.closest('td,[role="cell"]');
          (cell && row.node.contains(cell) ? cell : row.node).append(group);
        }
      } catch {
      }
    }
    const schedule = () => {
      clearTimeout(timer);
      timer = setTimeout(() => void refresh(), 250);
    };
    const observer = new MutationObserver(schedule);
    if (sellerHubListingsURL(location.href)) {
      observer.observe(doc.body, { childList: true, subtree: true });
      void refresh(true);
    }
    return {
      refresh: () => refresh(true),
      cleanup: () => {
        active2 = false;
        epoch++;
        clearTimeout(timer);
        observer.disconnect();
        clear();
        doc.querySelectorAll("[data-auro-library-matched]").forEach((n) => n.removeAttribute("data-auro-library-matched"));
        doc.querySelectorAll("[data-auro-library-checked]").forEach((n) => n.removeAttribute("data-auro-library-checked"));
      }
    };
  }

  // src/ebay/publishLink.ts
  var PUBLISH = /^(list it|list item|list your item|post listing|submit listing|mettre en vente)$/i;
  var SUCCESS = /(listing is (now )?live|congratulations|your (item|listing) (is|has been) (now )?listed|you('ve| have) (just )?listed|is now listed|annonce est en ligne|félicitations)/i;
  var VIEW = /(view|see|go to) (your |the )?(listing|item)|voir (l’|l')?annonce/i;
  function publishedItemIds(doc, url) {
    const ids = /* @__PURE__ */ new Set();
    try {
      const u = new URL(url);
      const id = u.searchParams.get("itemId") ?? u.searchParams.get("itemid");
      if (/^\d{9,15}$/.test(id ?? "") && !u.pathname.startsWith("/itm/")) ids.add(id);
    } catch {
    }
    const text2 = doc.body?.innerText ?? doc.body?.textContent ?? "";
    const success = SUCCESS.test(text2);
    for (const a of doc.querySelectorAll("a[href*='/itm/']")) {
      const id = a.href.match(/\/itm\/(?:[^/?#]+\/)?(\d{9,15})(?:[/?#]|$)/)?.[1];
      if (id && (success || VIEW.test(a.textContent ?? ""))) ids.add(id);
    }
    return [...ids];
  }
  function setupPublishLink(doc, enabled2) {
    const onClick = (event) => {
      if (!enabled2()) return;
      const button = event.target?.closest?.(
        "button, [role=button], input[type=submit]"
      );
      const label4 = (button?.textContent || button?.value || "").replace(/\s+/g, " ").trim();
      if (!button || !PUBLISH.test(label4)) return;
      const u = new URL(location.href);
      const draftId = u.searchParams.get("draftId") ?? u.searchParams.get("draft_id");
      if (!/^\d{6,20}$/.test(draftId ?? "")) return;
      const sku = [...doc.querySelectorAll("input")].map((i) => i.value.trim().match(/^AE-(\d{6,20})(?:-\d+)?$/)?.[1]).find(Boolean);
      const title = queryAll(doc, SELECTORS.title)[0]?.value?.trim() ?? "";
      void message({ type: "LISTING_PUBLISH_CLICK", draftId, supplierId: sku ?? null, title: title.slice(0, 200) }).catch(() => {
      });
    };
    doc.addEventListener("click", onClick, true);
    let reported = "";
    let checks = 0;
    const passive = /^\/(sch|itm|b|str|usr|fdbk)\//.test(location.pathname);
    const check = () => {
      if (checks++ > 120) return clearInterval(timer);
      if (!enabled2()) return;
      const ids = publishedItemIds(doc, location.href);
      const key = ids.join(",");
      if (!ids.length || key === reported) return;
      reported = key;
      void message({
        type: "LISTING_PUBLISHED",
        itemIds: ids
      }).then((result) => {
        if (result?.linked) toast(doc, `AurOEBay : annonce li\xE9e \xE0 \xAB ${result.linked} \xBB et \xE0 son fournisseur AliExpress \u2713`);
      }).catch(() => {
      });
    };
    const timer = passive ? void 0 : setInterval(check, 1e3);
    if (!passive) check();
    return () => {
      clearInterval(timer);
      doc.removeEventListener("click", onClick, true);
    };
  }
  function toast(doc, text2) {
    const box2 = doc.createElement("div");
    box2.textContent = text2;
    box2.style.cssText = "position:fixed;right:18px;bottom:18px;z-index:2147483646;max-width:420px;padding:12px 16px;border-radius:12px;background:#16a34a;color:#fff;font:600 14px/1.4 system-ui;box-shadow:0 6px 18px rgba(0,0,0,.25)";
    doc.documentElement.append(box2);
    setTimeout(() => box2.remove(), 8e3);
  }

  // src/core/staleContext.ts
  var stale = (reason) => /Extension context invalidated/i.test(reason instanceof Error ? reason.message : String(reason));
  var extensionAlive = () => {
    try {
      return !!chrome.runtime?.id;
    } catch {
      return false;
    }
  };
  function quietStaleContext(win = window) {
    win.addEventListener("error", (e) => {
      if (stale(e.error ?? e.message)) e.preventDefault();
    });
    win.addEventListener("unhandledrejection", (e) => {
      if (stale(e.reason)) e.preventDefault();
    });
  }

  // src/core/floating.ts
  var KEY = "floatingPosition:v1";
  var FLOAT_CSS = `${BRAND_CSS}
  :host{${WINDOW_TOKENS}}
  .card{position:relative;width:316px;max-height:75vh;overflow:auto;background:var(--bg);color:var(--ink);border:1px solid var(--line);border-radius:16px;box-shadow:0 18px 44px rgba(10,6,16,.45),0 0 0 1px rgba(255,255,255,.02) inset;font:13px/1.45 -apple-system,system-ui,sans-serif;animation:ao-rise .38s var(--ao-ease)}
  .card::before{content:"";position:sticky;top:0;display:block;height:2px;margin-bottom:-2px;background:linear-gradient(90deg,var(--ao-ember),var(--ao-sun),var(--ao-ember)) 0 0/200% 100%;animation:fline 6s linear infinite;z-index:2}
  .head{display:flex;justify-content:space-between;align-items:center;gap:8px;font-weight:700;padding:10px 12px;cursor:grab;user-select:none;border-bottom:1px solid var(--line)}
  .head>span{display:flex;align-items:center;gap:8px}
  .head:active{cursor:grabbing}
  .logo{width:22px;height:22px;transition:transform .45s var(--ao-spring)}
  .head:hover .logo{transform:rotate(-8deg) scale(1.08)}
  .body{padding:8px 12px 12px}
  .mini .body,.mini .t,.mini .x{display:none}
  .mini .card{width:auto;border-radius:16px;overflow:visible;background:transparent;border-color:transparent;box-shadow:none;animation:fpop .5s var(--ao-spring)}
  .mini .card::before{display:none}
  .mini .head{padding:0;border:0;cursor:pointer}
  .mini .logo{width:44px;height:44px;border-radius:13px;filter:drop-shadow(0 8px 18px rgba(255,95,58,.45));animation:fhalo 3.6s ease-out 1s infinite}
  .mini .head:hover .logo{transform:scale(1.12) rotate(-6deg)}
  button{font:600 13px system-ui;border-radius:10px;border:1px solid var(--line);background:var(--bg2);color:var(--ink);padding:8px 10px;cursor:pointer;width:100%;margin-top:6px;text-align:left;transition:background-position .4s var(--ao-ease),border-color .2s,transform .12s,box-shadow .2s}
  button:hover{border-color:color-mix(in srgb,var(--accent) 45%,var(--line))}
  button:active{transform:translateY(1px) scale(.99)}
  button.primary{background:var(--ao-gradient);background-size:170% 100%;border-color:transparent;color:#fff;box-shadow:0 6px 16px rgba(255,95,58,.3)}
  button.primary:hover{background-position:100% 0;box-shadow:0 8px 22px rgba(255,95,58,.42)}
  button.track{background:linear-gradient(135deg,#f0a63a,#ffcf6b);border-color:transparent;color:#2a1a05}
  button:disabled{opacity:.75;cursor:wait;position:relative;overflow:hidden}
  button:disabled::after{content:"";position:absolute;inset:0;background:linear-gradient(100deg,transparent 30%,rgba(255,255,255,.22) 50%,transparent 70%);transform:translateX(-100%);animation:ao-shine 1.4s ease-in-out infinite}
  button.primary:disabled::before{content:"";display:inline-block;width:12px;height:12px;margin-right:7px;vertical-align:-2px;border-radius:50%;background:conic-gradient(transparent 0 40%,#fff);-webkit-mask:radial-gradient(circle closest-side,transparent 62%,#000 70%);mask:radial-gradient(circle closest-side,transparent 62%,#000 70%);animation:ao-spin .8s linear infinite}
  @keyframes fline{to{background-position:-200% 0}}
  @keyframes fpop{0%{opacity:0;transform:scale(.4) rotate(-20deg)}100%{opacity:1;transform:none}}
  @keyframes fhalo{0%,60%,100%{filter:drop-shadow(0 8px 18px rgba(255,95,58,.45))}75%{filter:drop-shadow(0 0 22px rgba(255,179,71,.85))}}
  @media (prefers-reduced-motion:reduce){*,*::before,*::after{animation:none!important;transition:none!important}}
  .x{background:none;border:0;width:auto;margin:0;padding:0 4px;color:var(--muted);font-size:15px;transition:color .2s}.x:hover{color:var(--ink)}
  .status{margin:4px 0;color:var(--muted)}.ok{color:var(--ok)}.warn{color:var(--warn)}.err{color:var(--err)}
  ul{margin:6px 0 0;padding-left:18px}.small,.s{font-size:12px;color:var(--muted)}
  .label{margin:10px 0 4px;font:700 11px system-ui;letter-spacing:.06em;color:var(--muted)}
  label.row{display:flex;align-items:center;justify-content:space-between;gap:8px;margin:5px 0}
  input,select{font:13px system-ui;background:#15121c;color:var(--ink);border:1px solid var(--line);border-radius:9px;padding:6px 8px;transition:border-color .2s,box-shadow .2s}input:focus,select:focus{outline:0;border-color:var(--accent);box-shadow:0 0 0 3px rgba(255,95,58,.2)}
  label.row input,label.row select{width:150px;text-align:right}
  label.row.check{justify-content:flex-start;margin:8px 0;cursor:pointer}
  label.row.check input{width:auto;margin:0}
  input[type=search]{width:100%;box-sizing:border-box;margin-top:6px}
  .il-zip{margin-top:8px;padding:8px;border:1px solid var(--line);border-radius:12px}.il-zip-row{display:flex;gap:6px;margin-top:6px}.il-zip-row input{flex:1;min-width:0}.il-zip-row button{width:auto;margin:0;white-space:nowrap}
  .sale{margin-top:8px;padding:8px;border:1px solid var(--line);border-radius:12px;background:var(--bg2);animation:ao-rise .35s var(--ao-ease) both}
`;
  function floatingBox(doc, id, heading = "AurOEBay") {
    doc.getElementById(id)?.remove();
    const host = doc.createElement("div");
    host.id = id;
    host.style.cssText = "position:fixed;top:120px;right:20px;z-index:2147483645;";
    const root = host.attachShadow({ mode: "open" });
    root.innerHTML = `<style>${FLOAT_CSS}</style><div class="wrap"><div class="card"><div class="head"><span><span class="logo ao-mark"></span><span class="t"></span></span><button class="x" title="R\xE9duire">\u2013</button></div><div class="body"></div></div></div>`;
    const wrap = root.querySelector(".wrap");
    const head = root.querySelector(".head");
    const title = root.querySelector(".t");
    const toggle = root.querySelector(".x");
    title.textContent = heading;
    const site = location.hostname.replace(/^.*\.(ebay|aliexpress)\..*$/, "$1");
    const save = () => {
      if (!extensionAlive()) return;
      const r = host.getBoundingClientRect();
      void chrome.storage.local.get(KEY).then(
        (v) => chrome.storage.local.set({
          [KEY]: { ...v[KEY] ?? {}, [site]: { x: r.left, y: r.top, mini: wrap.classList.contains("mini") } }
        })
      ).catch(() => {
      });
    };
    const place = (x, y) => {
      const maxX = Math.max(0, innerWidth - 60);
      const maxY = Math.max(0, innerHeight - 40);
      host.style.left = Math.min(Math.max(0, x), maxX) + "px";
      host.style.top = Math.min(Math.max(0, y), maxY) + "px";
      host.style.right = "auto";
    };
    const startMini = site === "ebay";
    const setMini = (mini) => {
      wrap.classList.toggle("mini", mini);
      toggle.textContent = mini ? "+" : "\u2013";
      head.title = mini ? `AurOEBay \xB7 ${heading} \u2014 cliquer pour ouvrir` : "";
      if (!mini) {
        const r = host.getBoundingClientRect();
        if (r.right > innerWidth || r.bottom > innerHeight)
          place(Math.min(r.left, innerWidth - r.width - 8), Math.min(r.top, innerHeight - Math.min(r.height, innerHeight * 0.75) - 8));
      }
    };
    setMini(startMini);
    void chrome.storage.local.get(KEY).then((v) => {
      const pos = v[KEY]?.[site];
      if (pos && Number.isFinite(pos.x) && Number.isFinite(pos.y)) place(pos.x, pos.y);
      if (!startMini && pos?.mini) setMini(true);
    }).catch(() => {
    });
    toggle.addEventListener("click", (e) => {
      e.stopPropagation();
      setMini(!wrap.classList.contains("mini"));
      save();
    });
    head.addEventListener("pointerdown", (e) => {
      if (e.target.closest(".x")) return;
      const r = host.getBoundingClientRect();
      const dx = e.clientX - r.left, dy = e.clientY - r.top;
      const x0 = e.clientX, y0 = e.clientY;
      head.setPointerCapture(e.pointerId);
      const move = (ev) => place(ev.clientX - dx, ev.clientY - dy);
      const up = (ev) => {
        head.removeEventListener("pointermove", move);
        head.removeEventListener("pointerup", up);
        head.removeEventListener("pointercancel", up);
        if (ev.type === "pointerup" && wrap.classList.contains("mini") && Math.hypot(ev.clientX - x0, ev.clientY - y0) < 5) setMini(false);
        save();
      };
      head.addEventListener("pointermove", move);
      head.addEventListener("pointerup", up);
      head.addEventListener("pointercancel", up);
    });
    doc.documentElement.append(host);
    return { host, root, body: root.querySelector(".body"), title, remove: () => host.remove(), open: () => setMini(false) };
  }

  // src/seller/decorate.ts
  var COLORS = {
    US: "#dc2626",
    NON_US: "#16a34a",
    UNKNOWN: "#d97706"
  };
  var cleanupFunctions = [];
  var marked = /* @__PURE__ */ new WeakSet();
  function clearSellerUI() {
    marked = /* @__PURE__ */ new WeakSet();
    cleanupFunctions.forEach((fn) => fn());
    cleanupFunctions = [];
  }
  function locationStatus(location2) {
    if (!location2) return "UNKNOWN";
    const country = location2.split(",").pop().trim().toLowerCase();
    if (!country) return "UNKNOWN";
    return /^(united states|usa|us|u\.s\.a?\.?)$/.test(country) ? "US" : "NON_US";
  }
  function itemLocation(doc) {
    for (const span of doc.querySelectorAll(
      ".ux-textspans, [data-testid='ux-labels-values'] span"
    )) {
      const m2 = span.textContent?.trim().match(/^Located in:\s*(.+)$/i);
      if (m2) return m2[1].trim();
    }
    const html = doc.documentElement.innerHTML;
    const m = html.match(
      /"itemLocation":\{[^{}]*?"values":\[\{[^\]]*?"text":"([^"]{2,120})"/
    );
    return m ? m[1] : null;
  }
  function cardLocation(card2) {
    const text2 = card2.innerText ?? card2.textContent ?? "";
    const located = text2.match(/Located in ([^\n]{2,80})/i);
    if (located) return located[1].trim();
    const from = text2.match(/(?:^|\n)\s*from ([A-Z][A-Za-z .,'-]{1,60})\s*(?:\n|$)/);
    return from ? from[1].trim() : null;
  }
  function cardSeller(card2) {
    const text2 = card2.innerText ?? card2.textContent ?? "";
    const m = text2.match(/(?:^|\n|\|)\s*([A-Za-z0-9_.-]{2,64})\s+\d{1,3}(?:[.,]\d)?%\s+positive/);
    return m ? m[1].toLowerCase() : null;
  }
  var label3 = (status) => status === "US" ? "US SELLER" : status === "NON_US" ? "NON-US SELLER" : "SELLER COUNTRY UNKNOWN";
  function itemSellerUsername(doc) {
    const names2 = /* @__PURE__ */ new Set();
    for (const a of doc.querySelectorAll(
      ".x-sellercard-atf a[href*='_ssn='], [data-testid='x-sellercard-atf'] a[href*='_ssn=']"
    )) {
      try {
        const name2 = new URL(a.href, "https://www.ebay.com").searchParams.get("_ssn");
        if (name2) names2.add(name2.toLowerCase());
      } catch {
      }
    }
    if (!names2.size)
      for (const script of doc.querySelectorAll("script")) {
        const m = script.textContent?.match(/"sellerUserName":"([A-Za-z0-9_.-]{1,80})"/);
        if (m) names2.add(m[1].toLowerCase());
      }
    const [name] = [...names2];
    return names2.size === 1 && /^[a-z0-9_.-]{1,80}$/.test(name) ? name : null;
  }
  function describe(status, account, location2) {
    const parts = [label3(status)];
    if (account === "loading") parts.push("v\xE9rification du pays du vendeur\u2026");
    else if (account?.country) parts.push(`Vendeur inscrit : ${account.country}`);
    else parts.push("pays du vendeur introuvable");
    if (location2) parts.push(`Exp\xE9di\xE9 depuis : ${location2}`);
    return parts.join(" \u2014 ");
  }
  function banner(status, message2) {
    document.getElementById("auroebay-seller-banner")?.remove();
    const host = document.createElement("div");
    host.id = "auroebay-seller-banner";
    host.style.cssText = "position:fixed;top:0;left:0;right:0;z-index:2147483646;";
    const root = host.attachShadow({ mode: "open" });
    const bar = document.createElement("div");
    bar.style.cssText = `display:flex;align-items:center;justify-content:space-between;gap:12px;padding:7px 14px;background:${COLORS[status]};color:#fff;font:700 13px/1.4 -apple-system,system-ui,sans-serif;box-shadow:0 2px 6px rgba(0,0,0,.25)`;
    const text2 = document.createElement("span");
    text2.textContent = `${status === "US" ? "\u26D4" : status === "NON_US" ? "\u2713" : "?"} ${message2}`;
    const close = document.createElement("button");
    close.textContent = "\u2715";
    close.setAttribute("aria-label", "Fermer");
    close.style.cssText = "border:0;background:transparent;color:#fff;font:700 15px system-ui;cursor:pointer";
    close.addEventListener("click", () => {
      dismissedHref = location.href;
      host.remove();
    });
    bar.append(text2, close);
    root.append(bar);
    document.documentElement.append(host);
    cleanupFunctions.push(() => host.remove());
  }
  function badge(el2, status, title, small) {
    const b = document.createElement("span");
    b.setAttribute("data-auroebay-seller", "");
    b.textContent = small ? status === "US" ? "\u{1F4E6} US" : status === "NON_US" ? "\u{1F4E6} NON-US" : "?" : label3(status);
    b.title = title;
    const color = COLORS[status];
    b.style.cssText = `display:inline-block;background:${color};color:#fff;font:700 ${small ? 10 : 11}px/1.5 system-ui;padding:2px 7px;border-radius:6px;margin:4px;position:relative;z-index:1;`;
    el2.append(b);
    cleanupFunctions.push(() => b.remove());
  }
  var dismissedHref = "";
  async function decorateProduct(s, force = false) {
    if (!s.enabled || !s.sellerEnabled) return;
    const done = document.getElementById("auroebay-seller-banner");
    const href = window.location.href;
    if (!force && dismissedHref === href) return;
    const location2 = itemLocation(document);
    if (!force && done?.dataset.href === href && done.dataset.done && location2) return;
    const username = itemSellerUsername(document);
    const key = `${username ?? ""}|${location2 ?? ""}`;
    if (!force && document.getElementById("auroebay-seller-banner")?.dataset.key === key)
      return;
    const show = (status, account2) => {
      clearSellerUI();
      const text2 = describe(status, account2, location2);
      banner(status, text2);
      const host2 = document.getElementById("auroebay-seller-banner");
      if (host2) host2.dataset.key = key;
      const zone = first(document, SELECTORS.seller);
      if (zone) badge(zone, status, text2, false);
    };
    if (!username) {
      show("UNKNOWN", null);
      return;
    }
    show("UNKNOWN", "loading");
    let account = null;
    try {
      account = await message({
        type: "SELLER_LOOKUP",
        username,
        storePath: null,
        force
      });
    } catch {
    }
    if (itemSellerUsername(document) !== username) return;
    show(account?.status ?? "UNKNOWN", account);
    const host = document.getElementById("auroebay-seller-banner");
    if (host) {
      host.dataset.href = window.location.href;
      host.dataset.done = "1";
    }
  }
  function forceUsOnly() {
    const url = new URL(location.href);
    if (url.searchParams.has("LH_PrefLoc")) return;
    const key = `auroebay-usonly:${url.searchParams.get("_nkw") ?? url.pathname}`;
    try {
      if (sessionStorage.getItem(key)) return;
      sessionStorage.setItem(key, "1");
    } catch {
      return;
    }
    url.searchParams.set("LH_PrefLoc", "1");
    location.replace(url.href);
  }
  function setupResults(s) {
    if (!s.enabled || !s.sellerEnabled) return () => {
    };
    forceUsOnly();
    let active2 = true;
    const accountBadge = (card2, info) => {
      const b = card2.querySelector("[data-auroebay-seller]");
      if (!b || !info.country) return;
      const location2 = cardLocation(card2);
      b.textContent = info.status === "US" ? "\u26D4 US" : `\u2713 ${info.country}`;
      b.style.background = COLORS[info.status];
      b.title = `Vendeur inscrit : ${info.country}${location2 ? ` \xB7 exp\xE9di\xE9 depuis : ${location2}` : ""}`;
      b.dataset.account = "1";
    };
    const lookup = async (card2, cacheOnly) => {
      const username = cardSeller(card2);
      if (!username || !active2) return;
      const info = await message({
        type: "SELLER_LOOKUP",
        username,
        storePath: null,
        ...cacheOnly ? { cacheOnly: true } : {}
      }).catch(() => null);
      if (info && active2) accountBadge(card2, info);
    };
    const scan = () => {
      if (!active2) return;
      queryAll(document, SELECTORS.results).forEach((card2) => {
        if (marked.has(card2)) return;
        marked.add(card2);
        const location2 = cardLocation(card2);
        if (location2)
          badge(
            card2,
            locationStatus(location2),
            `Exp\xE9di\xE9 depuis : ${location2}. Survole l'annonce pour v\xE9rifier le pays du vendeur.`,
            true
          );
        void lookup(card2, true);
        let timer;
        const enter = () => {
          if (card2.querySelector("[data-auroebay-seller]")?.dataset.account) return;
          timer = setTimeout(() => void lookup(card2, false), 450);
        };
        const leave = () => clearTimeout(timer);
        card2.addEventListener("mouseenter", enter);
        card2.addEventListener("mouseleave", leave);
        cleanupFunctions.push(() => {
          card2.removeEventListener("mouseenter", enter);
          card2.removeEventListener("mouseleave", leave);
        });
      });
    };
    scan();
    const container = document.querySelector(".srp-results,.srp-river-results,main");
    let pending;
    const changes = new MutationObserver(() => {
      clearTimeout(pending);
      pending = setTimeout(scan, 150);
    });
    if (container) changes.observe(container, { childList: true, subtree: true });
    return () => {
      active2 = false;
      clearTimeout(pending);
      changes.disconnect();
    };
  }

  // src/core/rivalSuppliers.ts
  var RIVAL_SUPPLIERS_KEY = "competitorSuppliers:v1";
  async function rivalSuppliersOn() {
    return message({ type: "PAGE_PREF", key: RIVAL_SUPPLIERS_KEY }).catch(() => true);
  }
  function rivalSuppliersToggle(doc, className = "rival-sup") {
    const label4 = doc.createElement("label");
    label4.className = className;
    label4.title = "Pendant la v\xE9rification, chercher le fournisseur AliExpress des nouvelles annonces (une \xE0 la fois, 20 au plus)";
    const box2 = doc.createElement("input");
    box2.type = "checkbox";
    box2.checked = true;
    label4.append(box2, " Chercher aussi les fournisseurs AliExpress");
    void rivalSuppliersOn().then((on) => box2.checked = on);
    box2.addEventListener("change", () => void message({ type: "PAGE_PREF", key: RIVAL_SUPPLIERS_KEY, value: box2.checked }).catch(() => {
    }));
    try {
      const sync = (changes, area) => {
        if (!label4.isConnected) return chrome.storage.onChanged.removeListener(sync);
        if (area === "local" && changes[RIVAL_SUPPLIERS_KEY]) box2.checked = changes[RIVAL_SUPPLIERS_KEY].newValue !== false;
      };
      chrome.storage.onChanged.addListener(sync);
    } catch {
    }
    return label4;
  }

  // src/core/hiddenProducts.ts
  var HIDDEN_PRODUCTS_KEY = "hiddenProducts:v1";
  var MAX_ITEMS = 1e3;
  var noHidden = () => ({ items: [], brands: [] });
  function cleanHidden(x) {
    const v = x ?? {};
    const items = (Array.isArray(v.items) ? v.items : []).filter((i) => !!i && typeof i.itemId === "string" && /^\d{9,15}$/.test(i.itemId) && typeof i.title === "string").slice(-MAX_ITEMS).map((i) => ({ itemId: i.itemId, title: i.title.slice(0, 200), at: Number(i.at) || 0 }));
    const brands = (Array.isArray(v.brands) ? v.brands : []).filter((b) => typeof b === "string").map((b) => b.slice(0, 60)).slice(0, 300);
    return { items, brands: [...new Set(brands)] };
  }
  var NOISE = new Set(
    "a an and the of in on to for with new brand free fast shipping ship us usa uk seller stock lot set pack pcs pc piece pieces 2024 2025 2026 2027 2028".split(" ")
  );
  var titleWords = (title) => new Set(
    title.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().split(/[^a-z0-9]+/).filter((w) => w.length > 1 && !NOISE.has(w))
  );
  function closeness(a, b) {
    let same = 0;
    for (const w of a) if (b.has(w)) same++;
    return same / (a.size + b.size - same);
  }
  var SAME_TITLE = 0.7;
  function hiddenMatcher(h) {
    const ids = new Set(h.items.map((i) => i.itemId));
    const brands = new Set(h.brands);
    const sets = h.items.map((i) => titleWords(i.title)).filter((s) => s.size >= 3);
    const known = /* @__PURE__ */ new Map();
    return (card2) => {
      const had = known.get(card2.itemId);
      if (had !== void 0) return had;
      const words2 = titleWords(card2.title);
      const hidden2 = ids.has(card2.itemId) || brands.size > 0 && brandRisks(card2.title).some((b) => brands.has(b.name)) || words2.size >= 3 && sets.some((s) => closeness(words2, s) >= SAME_TITLE);
      known.set(card2.itemId, hidden2);
      return hidden2;
    };
  }
  function hideProduct(h, card2, now = Date.now()) {
    const added = brandRisks(card2.title).filter((b) => b.level === "danger").map((b) => b.name);
    return {
      hidden: cleanHidden({
        items: [...h.items.filter((i) => i.itemId !== card2.itemId), { itemId: card2.itemId, title: card2.title, at: now }],
        brands: [...h.brands, ...added]
      }),
      brands: added
    };
  }

  // src/ebay/winners.ts
  var sortBy = "d30";
  var panelTitle = "Produits gagnants";
  var followed = /* @__PURE__ */ new Set();
  var loadFollowed = () => message({ type: "COMPETITOR_LIST" }).then((list) => followed = new Set(list.map((c) => c.seller))).catch(() => followed);
  var hidden = noHidden();
  var isHidden = hiddenMatcher(hidden);
  var useHidden = (next) => {
    hidden = next;
    isHidden = hiddenMatcher(next);
  };
  var loadHidden = () => message({ type: "PAGE_PREF", key: HIDDEN_PRODUCTS_KEY }).then(useHidden).catch(() => {
  });
  var saveHidden = (next) => {
    useHidden(next);
    return message({ type: "PAGE_PREF", key: HIDDEN_PRODUCTS_KEY, value: next });
  };
  var SORTS = [
    ["d30", "Ventes 30 jours"],
    ["d7", "Ventes 7 jours"],
    ["total", "Ventes totales"]
  ];
  var score = (c) => sortBy === "total" ? c.sold ?? -1 : sortBy === "d7" ? c.d7 ?? -1 : c.d30 ?? -1;
  function soldNumber(text2) {
    const m = text2.replace(/\s/g, "").match(/^([\d,.]+)(K)?\+?$/i);
    if (!m) return null;
    const n = Number(m[1].replace(/,/g, ""));
    return Number.isFinite(n) ? Math.round(m[2] ? n * 1e3 : n) : null;
  }
  function itemPageSold(html) {
    const m = html.match(/"text":"([\d,.]+K?\+?) sold","styles":\["(?:BOLD","EMPHASIS|EMPHASIS|SECONDARY|BOLD)"\]/) ?? html.match(/ux-textspans--(?:BOLD ux-textspans--EMPHASIS|EMPHASIS|SECONDARY)">([\d,.]+K?\+?) sold</);
    return m ? soldNumber(m[1]) : null;
  }
  function itemPageSeller(html) {
    const doc = new DOMParser().parseFromString(html, "text/html");
    const seller = html.match(/"sellerUserName":"([A-Za-z0-9_.-]{1,64})"/)?.[1] ?? html.match(/[?&]_ssn=([A-Za-z0-9_.-]{1,64})/)?.[1] ?? null;
    const card2 = doc.querySelector(".x-sellercard-atf, [data-testid='x-sellercard-atf']")?.textContent ?? "";
    const fb = card2.replace(/\s+/g, " ").match(/\((\d[\d,.]*K?)\)/)?.[1];
    return { seller: seller?.toLowerCase() ?? null, feedback: fb ? soldNumber(fb) : null, shipsFrom: itemLocation(doc) };
  }
  var lowPrice = (price2) => {
    const m = price2.replace(/,/g, "").match(/\$\s?(\d+(?:\.\d+)?)/);
    return m ? Number(m[1]) : null;
  };
  var NO_FILTERS = { seller: "all", ships: "all", minD30: null, minPrice: null, maxPrice: null, maxFeedback: null };
  var FILTERS_KEY = "winnersFilters:v1";
  var filters = { ...NO_FILTERS };
  function passes(c, f) {
    const checks = [];
    if (f.seller !== "all")
      checks.push(
        c.sellerStatus === void 0 || c.sellerStatus === "UNKNOWN" ? c.sellerCountry === void 0 ? null : false : f.seller === "us" ? c.sellerStatus === "US" : c.sellerStatus === "NON_US"
      );
    if (f.ships !== "all") {
      const st = c.shipsFrom === void 0 ? null : locationStatus(c.shipsFrom);
      checks.push(st === null ? null : st === "UNKNOWN" ? false : f.ships === "us" ? st === "US" : st === "NON_US");
    }
    if (f.minD30 !== null) checks.push(c.d30 === void 0 ? null : (c.d30 ?? -1) >= f.minD30);
    const price2 = lowPrice(c.price);
    if (f.minPrice !== null) checks.push(price2 !== null && price2 >= f.minPrice);
    if (f.maxPrice !== null) checks.push(price2 !== null && price2 <= f.maxPrice);
    if (f.maxFeedback !== null) checks.push(c.feedback === void 0 ? null : c.feedback !== null && c.feedback <= f.maxFeedback);
    if (checks.includes(false)) return false;
    return checks.includes(null) ? null : true;
  }
  var filtersActive = (f) => JSON.stringify(f) !== JSON.stringify(NO_FILTERS);
  function pageCards(doc) {
    const cards = /* @__PURE__ */ new Map();
    const seenNodes = /* @__PURE__ */ new Set();
    const scope = doc.querySelector(".srp-results, .srp-river-results, main") ?? doc;
    for (const a of scope.querySelectorAll("a[href*='/itm/']")) {
      const itemId = a.href.match(/\/itm\/(?:[^/?#]+\/)?(\d{9,15})(?:[/?#]|$)/)?.[1];
      if (!itemId || a.closest("#auroebay-winners-panel")) continue;
      const card2 = a.closest("li, article, .str-item-card") ?? a;
      if (seenNodes.has(card2)) continue;
      seenNodes.add(card2);
      const text2 = (card2.innerText ?? card2.textContent ?? "").replace(/\s+/g, " ");
      const previous2 = cards.get(itemId);
      const title = (card2.querySelector(".s-card__title, .s-item__title, [class*='title']")?.textContent ?? a.textContent ?? "").replace(/Opens in a new window or tab|New Listing/gi, "").replace(/\s+/g, " ").trim();
      const soldText = text2.match(/(?<![\d.,$])([\d,]+(?:\.\d)?K?\+?) sold\b/i)?.[1];
      const lastSold = text2.match(/Sold\s+([A-Z][a-z]{2} \d{1,2}, \d{4})/)?.[1] ?? "";
      if (previous2) {
        if (lastSold) previous2.soldSeen++;
        continue;
      }
      if (!title || /^shop on ebay$/i.test(title)) continue;
      cards.set(itemId, {
        itemId,
        title: title.slice(0, 160),
        price: text2.match(/\$\s?[\d,]+\.\d{2}(?:\s*to\s*\$\s?[\d,]+\.\d{2})?/)?.[0] ?? "",
        image: card2.querySelector("img")?.getAttribute("src") ?? "",
        sold: soldText ? soldNumber(soldText) : null,
        soldSeen: lastSold ? 1 : 0,
        lastSold
      });
    }
    return [...cards.values()];
  }
  var PANEL_CSS = `${BRAND_CSS}
  :host{${WINDOW_TOKENS}}
  .ov{position:fixed;inset:4vh 3vw;z-index:2147483646;background:var(--bg);color:var(--ink);border-radius:16px;box-shadow:0 20px 60px rgba(0,0,0,.5);display:flex;flex-direction:column;font:14px/1.4 -apple-system,system-ui,sans-serif;overflow:hidden}
  header{display:flex;justify-content:space-between;align-items:center;padding:14px 20px;background:var(--ao-gradient);color:#fff}
  header b{font-size:18px}header button{background:none;border:0;color:#fff;font-size:22px;cursor:pointer}
  .bar{position:relative;padding:10px 20px;color:var(--muted);border-bottom:1px solid var(--line)}
  .bar::after{content:"";position:absolute;left:0;bottom:-1px;height:2px;width:var(--p,0%);background:linear-gradient(90deg,var(--accent),var(--ao-sun));transition:width .5s cubic-bezier(.2,.8,.2,1)}
  .bar.reading::before{content:"";display:inline-block;width:12px;height:12px;margin-right:8px;vertical-align:-1px;border-radius:50%;background:conic-gradient(transparent 0 45%,var(--accent));-webkit-mask:radial-gradient(circle closest-side,transparent 62%,#000 70%);mask:radial-gradient(circle closest-side,transparent 62%,#000 70%);animation:wspin .85s linear infinite}
  .ov{animation:wov .35s cubic-bezier(.2,.8,.2,1)}
  @keyframes wspin{to{transform:rotate(360deg)}}
  @keyframes wov{from{opacity:0;transform:scale(.98)}}
  @media (prefers-reduced-motion:reduce){*,*::before,*::after{animation:none!important;transition:none!important}}
  .list{overflow:auto;padding:12px 20px;display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:12px}
  .card{position:relative;background:var(--bg2);border:1px solid var(--line);border-radius:14px;padding:10px;display:flex;gap:10px;transition:transform .25s var(--ao-ease),border-color .25s,box-shadow .25s}.card:hover{transform:translateY(-2px);border-color:color-mix(in srgb,var(--accent) 40%,var(--line));box-shadow:0 12px 26px rgba(0,0,0,.3)}
  .hide{position:absolute;top:6px;right:6px;width:24px;height:24px;border:0;border-radius:99px;background:transparent;color:var(--muted);font-size:13px;cursor:pointer}
  .hide:hover{background:color-mix(in srgb,#ff6b78 25%,transparent);color:var(--ink)}
  .undo{padding:6px 20px 0;font-size:12.5px;color:var(--muted)}
  .undo button{margin-left:6px;border:1px solid var(--line);background:transparent;color:var(--ink);border-radius:99px;padding:1px 9px;font:600 12px system-ui;cursor:pointer}
  .card img{width:78px;height:78px;object-fit:cover;border-radius:8px;background:var(--line)}
  .rank{display:inline-block;min-width:26px;padding:1px 6px;border-radius:7px;background:var(--ao-gradient);color:#fff;font-weight:700;text-align:center;margin-right:6px}
  .sold{font-weight:700;color:var(--ok)}.muted{color:var(--muted);font-size:12px}
  .tools{display:flex;gap:6px;align-items:center;padding:8px 20px;border-bottom:1px solid var(--line);color:var(--muted)}
  .tools button{border:1px solid var(--line);background:var(--bg2);color:var(--ink);border-radius:999px;padding:4px 12px;cursor:pointer;font:600 13px system-ui}
  .tools button.on{background:var(--accent);border-color:var(--accent);color:#fff}
  .recent{font-size:13px;margin:2px 0}.recent b{color:var(--accent)}
  a.h{color:var(--accent);font-size:12px}
  a{color:var(--ink);text-decoration:none}a:hover{text-decoration:underline}
  .filters{display:flex;flex-wrap:wrap;gap:8px 14px;align-items:center;padding:8px 20px;border-bottom:1px solid var(--line);color:var(--muted);font-size:13px}
  .filters select,.filters input{background:#15121c;color:var(--ink);border:1px solid var(--line);border-radius:8px;padding:4px 6px;font:13px system-ui}
  .filters input{width:64px}
  .filters button{border:1px solid var(--line);background:var(--bg2);color:var(--ink);border-radius:999px;padding:4px 12px;cursor:pointer;font:600 12px system-ui}
  .new{display:inline-block;margin-left:6px;padding:1px 7px;border-radius:99px;background:var(--ao-gradient);color:#fff;font-size:10.5px;font-weight:800;letter-spacing:.04em;animation:ao-pulse 1.8s ease-out 3}
  .follow{margin-left:6px;border:1px solid var(--line);background:transparent;color:var(--ink);border-radius:99px;padding:1px 8px;font:600 11px system-ui;cursor:pointer;transition:background .2s,border-color .2s}
  .follow:hover{border-color:var(--accent)}
  .follow.on{background:color-mix(in srgb,var(--accent) 22%,transparent);border-color:var(--accent);cursor:default}
  .who{font-size:12px;margin:2px 0}.who b.us{color:#ff6b78}.who b.nonus{color:var(--ok)}
  .sup{font-size:12px;margin:3px 0;color:var(--muted)}.sup a{color:var(--ok);font-weight:700}.sup a.close{color:#f5c451}.sup.err{color:#ff6b78}
  .t{display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden;font-size:13px}
`;
  function showPanel(doc) {
    doc.getElementById("auroebay-winners-panel")?.remove();
    const host = doc.createElement("div");
    host.id = "auroebay-winners-panel";
    const root = host.attachShadow({ mode: "open" });
    root.innerHTML = `<style>${PANEL_CSS}</style><div class="ov"><header class="ao-sweep"><b style="display:flex;align-items:center;gap:10px"><span class="ao-mark" style="width:30px;height:30px;filter:drop-shadow(0 3px 8px rgba(0,0,0,.25))"></span>${panelTitle}</b><button title="Fermer">\u2715</button></header><div class="tools">Classer par : ${SORTS.map(([k, l]) => `<button data-sort="${k}">${l}</button>`).join("")}</div>
    <div class="filters">
      <label>Vendeur <select data-f="seller"><option value="all">tous pays</option><option value="non_us">hors US</option><option value="us">US</option></select></label>
      <label>Exp\xE9di\xE9 de <select data-f="ships"><option value="all">partout</option><option value="non_us">hors US</option><option value="us">US</option></select></label>
      <label>Ventes 30 j \u2265 <input data-f="minD30" type="number" min="0" step="1"></label>
      <label>Prix $ <input data-f="minPrice" type="number" min="0" step="0.01" placeholder="min"> \xE0 <input data-f="maxPrice" type="number" min="0" step="0.01" placeholder="max"></label>
      <label title="Petites boutiques : nombre d\u2019avis du vendeur au maximum">Avis vendeur \u2264 <input data-f="maxFeedback" type="number" min="0" step="1"></label>
      <button data-reset type="button">Tout afficher</button>
      <button data-unhide type="button" hidden title="Remet tous les produits et marques masqu\xE9s par \u2715"></button>
    </div><div class="bar"></div><div class="shown muted" style="padding:6px 20px 0"></div><div class="undo" hidden></div><div class="list"></div></div>`;
    root.querySelector("header button").addEventListener("click", () => {
      host.remove();
      forget();
    });
    const list = root.querySelector(".list");
    const unhide = root.querySelector("[data-unhide]");
    unhide.addEventListener("click", () => {
      if (unhide.dataset.sure !== "1") {
        unhide.dataset.sure = "1";
        unhide.textContent = "Tout r\xE9afficher ? Clique encore";
        return;
      }
      delete unhide.dataset.sure;
      void saveHidden(noHidden()).catch(() => {
      });
      if (current) render(list, current.cards);
    });
    const buttons = [...root.querySelectorAll(".tools button")];
    const mark = () => buttons.forEach((b) => b.classList.toggle("on", b.dataset.sort === sortBy));
    buttons.forEach(
      (b) => b.addEventListener("click", () => {
        sortBy = b.dataset.sort;
        mark();
        if (current) render(list, current.cards);
      })
    );
    mark();
    void Promise.all([loadFollowed(), loadHidden()]).then(() => current && host.isConnected && render(list, current.cards));
    const inputs = [...root.querySelectorAll("[data-f]")];
    const show = () => inputs.forEach((i) => i.value = String(filters[i.dataset.f] ?? ""));
    const read = () => {
      const num = (k) => {
        const v = inputs.find((i) => i.dataset.f === k).value;
        return v === "" || !Number.isFinite(Number(v)) ? null : Number(v);
      };
      const sel = (k) => inputs.find((i) => i.dataset.f === k).value;
      filters = { seller: sel("seller"), ships: sel("ships"), minD30: num("minD30"), minPrice: num("minPrice"), maxPrice: num("maxPrice"), maxFeedback: num("maxFeedback") };
      void message({ type: "PAGE_PREF", key: FILTERS_KEY, value: filters }).catch(() => {
      });
      if (current) render(list, current.cards);
    };
    inputs.forEach((i) => i.addEventListener("change", read));
    root.querySelector("[data-reset]").addEventListener("click", () => {
      filters = { ...NO_FILTERS };
      show();
      read();
    });
    show();
    void message({ type: "PAGE_PREF", key: FILTERS_KEY }).then((saved) => {
      if (saved) filters = { ...NO_FILTERS, ...saved };
      show();
      if (current) render(list, current.cards);
    }).catch(() => {
    });
    doc.documentElement.append(host);
    return { bar: root.querySelector(".bar"), list, host };
  }
  var storeKey = () => `auroebay-winners:${location.pathname}${location.search}`;
  function remember(saved) {
    try {
      sessionStorage.setItem(storeKey(), JSON.stringify({ ...saved, title: panelTitle }));
    } catch {
    }
  }
  function recall() {
    try {
      const saved = JSON.parse(sessionStorage.getItem(storeKey()) ?? "null");
      return saved && Date.now() - saved.at < 3 * 36e5 && Array.isArray(saved.cards) ? saved : null;
    } catch {
      return null;
    }
  }
  function forget() {
    try {
      sessionStorage.removeItem(storeKey());
    } catch {
    }
  }
  var current = null;
  async function rank(doc, cards, startedAt) {
    await loadHidden();
    const panel = current?.host.isConnected && current.cards === cards ? (() => {
      const root = current.host.shadowRoot;
      return { bar: root.querySelector(".bar"), list: root.querySelector(".list"), host: current.host };
    })() : showPanel(doc);
    current = { host: panel.host, cards };
    render(panel.list, cards);
    const todo = cards.filter((c) => !isHidden(c) && (c.d30 === void 0 || c.seller === void 0 || c.sellerCountry === void 0));
    const sellers = /* @__PURE__ */ new Map();
    const sellerInfo = (name) => {
      if (!sellers.has(name))
        sellers.set(name, message({ type: "SELLER_LOOKUP", username: name, storePath: null }).catch(() => null));
      return sellers.get(name);
    };
    let done = 0;
    let signedOut = false;
    const total = todo.length;
    const read = (url) => fetch(url, { credentials: "same-origin" });
    const worker = async () => {
      while (todo.length && panel.host.isConnected && current?.cards === cards) {
        const c = todo.shift();
        let historyUnits = null;
        if (c.d30 === void 0) {
          try {
            const r = await read(historyURL(c.itemId));
            if (/signin/i.test(new URL(r.url).hostname)) {
              signedOut = true;
              c.d7 = c.d30 = null;
            } else {
              const list = parsePurchaseHistory(new DOMParser().parseFromString(await r.text(), "text/html"));
              c.d7 = periodStats(list, 7).units;
              c.d30 = periodStats(list, 30).units;
              historyUnits = periodStats(list, null).units;
            }
          } catch {
            c.d7 = c.d30 = null;
          }
        }
        if (c.seller === void 0 || c.sold === null && !c.checked) {
          try {
            const html = await (await read(`/itm/${c.itemId}`)).text();
            if (c.sold === null) c.sold = itemPageSold(html);
            Object.assign(c, itemPageSeller(html));
          } catch {
            c.seller = c.shipsFrom = null;
            c.feedback = null;
          }
          if (historyUnits !== null && (c.sold === null || historyUnits > c.sold)) {
            c.sold = historyUnits;
            c.soldAtLeast = true;
          }
          c.checked = true;
        }
        if (c.sellerCountry === void 0) {
          const info = c.seller ? await sellerInfo(c.seller) : null;
          c.sellerCountry = info?.country ?? null;
          c.sellerStatus = info?.status ?? "UNKNOWN";
        }
        done++;
        panel.bar.classList.add("reading");
        panel.bar.style.setProperty("--p", `${Math.round(done / Math.max(1, total) * 100)}%`);
        panel.bar.textContent = `${cards.length} annonces \xB7 lecture des ventes ${done}/${total}\u2026${signedOut ? " \u26A0 Connecte-toi \xE0 eBay pour les ventes r\xE9centes." : ""}`;
        if (done % 4 === 0) {
          render(panel.list, cards);
          remember({ at: startedAt, cards, done: false });
        }
        await new Promise((r) => setTimeout(r, 250));
      }
    };
    await Promise.all([worker(), worker(), worker()]);
    if (!panel.host.isConnected || current?.cards !== cards) return;
    render(panel.list, cards);
    remember({ at: startedAt, cards, done: true });
    panel.bar.classList.remove("reading");
    panel.bar.style.setProperty("--p", "0%");
    const sum = cards.reduce((n, c) => n + (c.sold ?? 0), 0);
    const month = cards.reduce((n, c) => n + (c.d30 ?? 0), 0);
    panel.bar.textContent = `${cards.length} annonces \xB7 ${month.toLocaleString("fr-FR")} unit\xE9s vendues sur 30 jours, ${sum.toLocaleString("fr-FR")} au total (chiffres d\u2019eBay). Classement du ${new Date(startedAt).toLocaleString("fr-FR", { dateStyle: "short", timeStyle: "short" })}.${signedOut ? " \u26A0 Ventes r\xE9centes indisponibles : connecte-toi \xE0 eBay." : ""}`;
  }
  function render(list, cards) {
    const verdicts = cards.map((c) => isHidden(c) ? false : passes(c, filters));
    const root = list.getRootNode();
    const unhide = root.querySelector?.("[data-unhide]");
    if (unhide) {
      const count = hidden.items.length + hidden.brands.length;
      unhide.hidden = !count;
      if (unhide.dataset.sure !== "1") unhide.textContent = `Masqu\xE9s : ${hidden.items.length} produit(s)${hidden.brands.length ? `, ${hidden.brands.length} marque(s)` : ""} \xB7 r\xE9afficher`;
    }
    const shownBox = list.getRootNode().querySelector?.(".shown");
    if (shownBox)
      shownBox.textContent = filtersActive(filters) ? `Filtres : ${verdicts.filter((v) => v === true).length} annonce(s) affich\xE9e(s) sur ${cards.length}${verdicts.includes(null) ? ` \xB7 ${verdicts.filter((v) => v === null).length} encore en lecture` : ""}.` : "";
    const ranked = cards.filter((_, i) => verdicts[i] === true).sort(
      (a, b) => score(b) - score(a) || (b.sold ?? -1) - (a.sold ?? -1) || b.soldSeen - a.soldSeen
    );
    list.replaceChildren(
      ...ranked.map((c, i) => {
        const el2 = document.createElement("div");
        el2.className = "card";
        const img = document.createElement("img");
        img.src = c.image;
        img.referrerPolicy = "no-referrer";
        const body = document.createElement("div");
        const link = document.createElement("a");
        link.href = `https://www.ebay.com/itm/${c.itemId}`;
        link.target = "_blank";
        link.rel = "noopener";
        link.className = "t";
        link.textContent = c.title;
        const head = document.createElement("div");
        const rank2 = document.createElement("span");
        rank2.className = "rank";
        rank2.textContent = `#${i + 1}`;
        const sold = document.createElement("span");
        sold.className = "sold";
        sold.textContent = c.sold === null ? c.checked ? "total non affich\xE9 par eBay" : "ventes : \u2026" : `${c.soldAtLeast ? "au moins " : ""}${c.sold.toLocaleString("fr-FR")} vendu(s) au total`;
        head.append(rank2, sold);
        if (c.isNew) head.append(Object.assign(document.createElement("span"), { className: "new", textContent: "NOUVEAU" }));
        const recent = document.createElement("div");
        recent.className = "recent";
        recent.innerHTML = c.d30 === void 0 ? "30 j : \u2026 \xB7 7 j : \u2026" : c.d30 === null ? "ventes r\xE9centes indisponibles" : `30 j : <b>${c.d30}</b> \xB7 7 j : <b>${c.d7}</b>`;
        const hist = document.createElement("a");
        hist.className = "h";
        hist.href = historyURL(c.itemId);
        hist.target = "_blank";
        hist.rel = "noopener";
        hist.textContent = "\u{1F4C8} Historique";
        const who = document.createElement("div");
        who.className = "who";
        if (c.seller) {
          const country = document.createElement("b");
          country.className = c.sellerStatus === "US" ? "us" : c.sellerStatus === "NON_US" ? "nonus" : "";
          country.textContent = c.sellerCountry ?? (c.sellerCountry === void 0 ? "\u2026" : "pays ?");
          who.append(`${c.seller}${c.feedback != null ? ` (${c.feedback.toLocaleString("fr-FR")} avis)` : ""} \xB7 `, country);
          if (c.shipsFrom) who.append(` \xB7 exp\xE9di\xE9 de ${c.shipsFrom.split(",").pop().trim()}`);
          const seller = c.seller;
          const follow = document.createElement("button");
          follow.className = "follow" + (followed.has(seller) ? " on" : "");
          follow.textContent = followed.has(seller) ? "\u2713 Suivi" : "\u2B50 Suivre";
          follow.title = "Ajouter ce vendeur \xE0 \xAB Mes concurrents \xBB pour voir ses nouveaut\xE9s";
          follow.addEventListener("click", () => {
            if (followed.has(seller)) return;
            void message({ type: "COMPETITOR_ADD", seller }).then(() => {
              followed.add(seller);
              list.querySelectorAll(".follow").forEach((b) => {
                if (b.dataset.seller === seller) {
                  b.classList.add("on");
                  b.textContent = "\u2713 Suivi";
                }
              });
            }).catch(() => follow.textContent = "\u26A0 R\xE9essaie");
          });
          follow.dataset.seller = seller;
          who.append(follow);
        }
        const meta = document.createElement("div");
        meta.className = "muted";
        meta.textContent = [
          c.price,
          c.soldSeen > 1 ? `${c.soldSeen} ventes sur cette page` : "",
          c.lastSold ? `derni\xE8re : ${c.lastSold}` : ""
        ].filter(Boolean).join(" \xB7 ");
        const find = document.createElement("button");
        find.className = "follow";
        find.textContent = "\u{1F50E} Fournisseur";
        find.title = "Chercher ce produit sur AliExpress (photo + titre)";
        find.addEventListener(
          "click",
          () => openSupplierFinder(document, { title: c.title, image: c.image, price: lowPrice(c.price), itemId: c.itemId })
        );
        body.append(head, recent, link, who, meta);
        if (c.supplier) body.append(supplierLine(c.supplier));
        body.append(hist, " ", find);
        const hide = Object.assign(document.createElement("button"), {
          type: "button",
          className: "hide",
          textContent: "\u2715",
          title: "Ne plus voir ce produit, ici et aux prochaines recherches (avec les annonces presque identiques ; une marque prot\xE9g\xE9e est masqu\xE9e en entier)"
        });
        hide.addEventListener("click", () => hideCard(list, cards, c));
        el2.append(img, body, hide);
        return el2;
      })
    );
  }
  function hideCard(list, cards, c) {
    const before = hidden;
    const shownBefore = cards.filter((x) => !isHidden(x)).length;
    const { hidden: next, brands } = hideProduct(before, c);
    void saveHidden(next).catch(() => {
    });
    render(list, cards);
    const gone = shownBefore - cards.filter((x) => !isHidden(x)).length;
    const box2 = list.getRootNode().querySelector(".undo");
    if (!box2) return;
    box2.hidden = false;
    box2.textContent = `${brands.length ? `Marque ${brands.join(", ")} masqu\xE9e` : "Produit masqu\xE9"} : ${gone} annonce(s) en moins, ici et aux prochaines recherches.`;
    const undo = Object.assign(document.createElement("button"), { type: "button", textContent: "Annuler" });
    undo.addEventListener("click", () => {
      void saveHidden(before).catch(() => {
      });
      box2.hidden = true;
      render(list, cards);
    });
    box2.append(undo);
  }
  function supplierLine(s) {
    const line = document.createElement("div");
    line.className = "sup";
    const best = s.pick?.best;
    if (s.state === "waiting") line.textContent = "\u{1F50E} Fournisseur : en file d\u2019attente\u2026";
    else if (s.state === "searching") line.textContent = "\u{1F50E} Recherche du fournisseur sur AliExpress\u2026";
    else if (s.state === "error") {
      line.classList.add("err");
      line.textContent = `\u26A0 Fournisseur : ${s.error ?? "recherche impossible"}`;
    } else if (best && s.pick.kind !== "none") {
      const a = document.createElement("a");
      a.href = best.url;
      a.target = "_blank";
      a.rel = "noopener";
      if (s.pick.kind === "close") a.className = "close";
      const price2 = best.price !== null ? ` ${best.price.toFixed(2)} ${best.currency === "USD" || !best.currency ? "$" : best.currency}` : "";
      a.textContent = s.pick.kind === "exact" ? `\u2705 Fournisseur AliExpress :${price2} (m\xEAme photo) \u2197` : `\u{1F7E1} Fournisseur probable :${price2} (photo proche) \u2197`;
      a.title = best.title;
      line.append(a);
    } else line.textContent = "Fournisseur pas trouv\xE9 automatiquement : essaie \xAB \u{1F50E} Fournisseur \xBB.";
    return line;
  }
  var SUPPLIER_HUNT = 20;
  async function huntSuppliers(panel, cards, targets, status) {
    const todo = targets.filter((c) => !c.supplier).slice(0, SUPPLIER_HUNT);
    if (!todo.length) return;
    const alive = () => panel.host.isConnected && current?.cards === cards;
    const show = () => alive() && render(panel.list, cards);
    for (const c of todo) c.supplier = { state: "waiting" };
    show();
    let found = 0;
    for (const [i, c] of todo.entries()) {
      if (!alive()) return;
      status.textContent = `\u{1F50E} Fournisseurs AliExpress : ${i + 1}/${todo.length} en recherche \xB7 ${found} trouv\xE9(s)`;
      c.supplier = { state: "searching" };
      show();
      try {
        const r = await Promise.race([
          message({ type: "FIND_SUPPLIERS", title: c.title, image: c.image, itemId: c.itemId, request: `rival-${c.itemId}` }),
          new Promise((_, reject) => setTimeout(() => reject(Error("trop long, r\xE9essaie avec \xAB \u{1F50E} Fournisseur \xBB")), 3e5))
        ]);
        c.supplier = { state: "done", pick: pickSupplier(r.candidates ?? []) };
        if (c.supplier.pick.kind !== "none") found++;
      } catch (e) {
        const error = e instanceof Error ? e.message : String(e);
        c.supplier = { state: "error", error: error.slice(0, 160) };
        if (/anti-robot/i.test(error)) {
          for (const rest of todo) if (rest.supplier?.state === "waiting") delete rest.supplier;
          show();
          status.innerHTML = `\u26A0 AliExpress demande une v\xE9rification anti-robot : fais-la toi-m\xEAme, puis relance la v\xE9rification. ${aliVerifyLink("color:#ff6a00;font-weight:700")}`;
          return;
        }
      }
      show();
    }
    if (alive()) status.textContent = `\u{1F50E} Fournisseurs AliExpress : ${found} trouv\xE9(s) sur ${todo.length} annonce(s).`;
  }
  async function nextPages(doc, count) {
    const out = [];
    let next = doc.querySelector("a.pagination__next, a[aria-label='Go to next search page']")?.href;
    for (let i = 0; i < count && next; i++) {
      const u = new URL(next);
      if (u.origin !== location.origin) break;
      const page = new DOMParser().parseFromString(await (await fetch(u.href, { credentials: "same-origin" })).text(), "text/html");
      out.push(...pageCards(page));
      next = page.querySelector("a.pagination__next, a[aria-label='Go to next search page']")?.getAttribute("href") ?? void 0;
      if (next) next = new URL(next, location.origin).href;
    }
    return out;
  }
  var RIVAL_LISTINGS = 40;
  var rivalListings = (sellers) => Math.max(10, Math.min(RIVAL_LISTINGS, Math.floor(4e3 / Math.max(1, sellers))));
  async function competitorScan(doc) {
    const list = await message({ type: "COMPETITOR_LIST" }).catch(() => []);
    panelTitle = "Nouveaut\xE9s de mes concurrents";
    sortBy = "d7";
    const panel = showPanel(doc);
    const cards = [];
    current = { host: panel.host, cards };
    if (!list.length) {
      panel.bar.textContent = "Aucun concurrent suivi. Clique \xAB \u2B50 Suivre \xBB sur un vendeur dans \xAB Produits gagnants \xBB, ou ajoute-le dans Mes produits.";
      return;
    }
    const startedAt = Date.now();
    await loadHidden();
    let fresh = 0;
    let skipped = 0;
    const empty = [];
    for (const [i, { seller }] of list.entries()) {
      if (!panel.host.isConnected) return;
      panel.bar.classList.add("reading");
      panel.bar.textContent = `Annonces r\xE9centes de ${seller} (${i + 1}/${list.length})\u2026`;
      try {
        const url = `/sch/i.html?_ssn=${encodeURIComponent(seller)}&_sop=10&_ipg=60&LH_PrefLoc=99`;
        const html = await (await fetch(url, { credentials: "same-origin" })).text();
        const found = pageCards(new DOMParser().parseFromString(html, "text/html")).slice(0, rivalListings(list.length));
        if (!found.length) empty.push(seller);
        const seen = await message({
          type: "COMPETITOR_SEEN",
          seller,
          itemIds: found.map((c) => c.itemId)
        });
        for (const c of found) {
          if (cards.some((x) => x.itemId === c.itemId)) continue;
          if (isHidden(c)) {
            skipped++;
            continue;
          }
          c.seller = seller;
          c.isNew = seen.newIds.includes(c.itemId);
          if (c.isNew) fresh++;
          cards.push(c);
        }
      } catch {
      }
      await new Promise((r) => setTimeout(r, 300));
    }
    const status = Object.assign(doc.createElement("div"), { className: "muted" });
    status.style.padding = "4px 20px 0";
    panel.list.before(status);
    const withSuppliers = await rivalSuppliersOn();
    const newOnes = withSuppliers ? cards.filter((c) => c.isNew) : [];
    const hunt = huntSuppliers(panel, cards, newOnes, status);
    panel.bar.textContent = `${cards.length} annonces r\xE9centes de ${list.length} concurrent(s)${fresh ? `, dont ${fresh} nouvelle(s) depuis ta derni\xE8re v\xE9rification` : ""}${skipped ? ` \xB7 ${skipped} masqu\xE9e(s) par \u2715` : ""}. Lecture des ventes\u2026${empty.length ? ` \u26A0 Aucune annonce trouv\xE9e pour : ${empty.join(", ")} (nom de vendeur \xE0 v\xE9rifier).` : ""}`;
    remember({ at: startedAt, cards, done: false });
    await rank(doc, cards, startedAt);
    if (withSuppliers && !newOnes.length) {
      const best = [...cards].filter((c) => (c.d7 ?? 0) > 0 || (c.d30 ?? 0) > 0).sort((a, b) => (b.d7 ?? 0) - (a.d7 ?? 0) || (b.d30 ?? 0) - (a.d30 ?? 0));
      await hunt;
      await huntSuppliers(panel, cards, best.slice(0, 10), status);
    } else await hunt;
    if (panel.host.isConnected && current?.cards === cards) remember({ at: startedAt, cards, done: true });
  }
  function setupWinners(doc, enabled2) {
    const page = location.pathname;
    if (!/^\/sch\/|^\/str\//.test(page)) return () => {
    };
    const box2 = floatingBox(doc, "auroebay-winners", "Produits gagnants");
    const go = doc.createElement("button");
    go.className = "primary";
    go.textContent = "\u{1F3C6} Classer cette page par ventes";
    const more = doc.createElement("label");
    more.className = "row check";
    const moreBox = doc.createElement("input");
    moreBox.type = "checkbox";
    more.append(moreBox, Object.assign(doc.createElement("span"), { textContent: "Inclure les 2 pages suivantes" }));
    const note = Object.assign(doc.createElement("p"), {
      className: "s",
      textContent: "Boutique d\u2019un dropshipper \u2192 \xAB Newly listed \xBB ou ventes r\xE9ussies, puis clique. Le classement reste ouvert quand tu ouvres un article."
    });
    box2.body.append(go, more, note);
    if (!current?.host.isConnected) {
      const saved = recall();
      if (saved) {
        for (const c of saved.cards) if (c.supplier && c.supplier.state !== "done") delete c.supplier;
        panelTitle = saved.title ?? "Produits gagnants";
        void rank(doc, saved.cards, saved.at);
      }
    }
    const rivals = doc.createElement("button");
    rivals.textContent = "\u{1F52D} Nouveaut\xE9s de mes concurrents";
    box2.body.insertBefore(rivals, note);
    box2.body.insertBefore(rivalSuppliersToggle(doc, "row check"), note);
    const runRivals = () => {
      if (!enabled2() || rivals.disabled) return;
      rivals.disabled = true;
      void competitorScan(doc).finally(() => rivals.disabled = false);
    };
    rivals.addEventListener("click", runRivals);
    if (location.hash.includes("auroebay-competitors")) {
      history.replaceState(null, "", location.pathname + location.search);
      runRivals();
    }
    go.addEventListener("click", async () => {
      if (!enabled2()) return;
      go.disabled = true;
      panelTitle = "Produits gagnants";
      try {
        const byId = /* @__PURE__ */ new Map();
        const add = (list) => {
          for (const c of list) {
            const known = byId.get(c.itemId);
            if (!known) byId.set(c.itemId, c);
            else known.soldSeen += c.soldSeen;
          }
        };
        add(pageCards(doc));
        const startedAt = Date.now();
        const cards = [...byId.values()];
        current = null;
        if (moreBox.checked) {
          const panel = showPanel(doc);
          panel.bar.textContent = "Lecture des pages suivantes\u2026";
          current = { host: panel.host, cards };
          for (const c of await nextPages(doc, 2)) {
            const known = byId.get(c.itemId);
            if (!known) {
              byId.set(c.itemId, c);
              cards.push(c);
            } else known.soldSeen += c.soldSeen;
          }
        }
        remember({ at: startedAt, cards, done: false });
        await rank(doc, cards, startedAt);
      } catch (e) {
        const bar = current?.host.shadowRoot?.querySelector(".bar");
        if (bar) bar.textContent = e instanceof Error ? e.message : String(e);
      } finally {
        go.disabled = false;
      }
    });
    return () => box2.remove();
  }

  // src/ebay/productLink.ts
  function setupProductLink(doc, enabled2) {
    const u = new URL(location.href);
    const draft = u.pathname === "/lstng" && /^\d{6,20}$/.test(u.searchParams.get("draftId") ?? "");
    if (!enabled2() || !ebayItemId(location.href) && !draft) return () => {
    };
    let host = null;
    let active2 = true;
    void message({ type: "PAGE_LIBRARY_PRODUCTS" }).then((products) => {
      if (!active2 || !products.length) return;
      doc.getElementById("auroebay-product-link")?.remove();
      host = doc.createElement("span");
      host.id = "auroebay-product-link";
      for (const p of products) {
        const a = doc.createElement("a");
        a.href = "#";
        a.append(brandButtonIcon(doc), products.length > 1 ? p.name.slice(0, 40) : "Fiche AurOEBay");
        a.title = (p.role === "own" ? "Ouvrir la fiche AurOEBay de cette annonce : " : "Fiche AurOEBay qui utilise cette annonce comme r\xE9f\xE9rence : ") + p.name;
        a.style.cssText = brandButtonStyle("primary", "8px 0 8px 8px");
        brandButtonHover(a);
        const open = (event) => {
          event.preventDefault();
          if (event.type === "auxclick" && event.button !== 1) return;
          void message({
            type: "OPEN_PAGE_PRODUCT",
            productId: p.id,
            active: event.button !== 1 && !event.metaKey && !event.ctrlKey
          }).catch(() => a.title = "Impossible d\u2019ouvrir la fiche. Recharge la page.");
        };
        a.addEventListener("click", open);
        a.addEventListener("auxclick", open);
        host.append(a);
      }
      const anchor = doc.getElementById("auro-sales-history") ?? doc.getElementById("auro-push-ebay");
      if (anchor) anchor.after(host);
      else {
        host.style.cssText = "position:fixed;left:16px;bottom:16px;z-index:2147483645";
        doc.documentElement.append(host);
      }
    }).catch(() => {
    });
    return () => {
      active2 = false;
      host?.remove();
    };
  }

  // src/ebay/trackingPage.ts
  var trackingPageURL = (orders, returnUrl = location.href, transactions = {}) => `https://www.ebay.com/ship/tr/update?source=1&flow=&returnUrl=${encodeURIComponent(returnUrl.split("#")[0])}&orders=${orders.join(",")}#auroebay-fill=${encodeURIComponent(JSON.stringify(transactions))}`;
  function handedTransactions(hash) {
    try {
      const raw = decodeURIComponent(hash.match(/auroebay-fill=([^&]*)/)?.[1] ?? "");
      const value = raw ? JSON.parse(raw) : {};
      return value && typeof value === "object" ? value : {};
    } catch {
      return {};
    }
  }
  function orderOfLine(itemId, transactionId, transactions, itemsByOrder) {
    const byTransaction = Object.keys(transactions).filter((id) => transactions[id]?.includes(transactionId));
    if (byTransaction.length === 1) return byTransaction[0];
    const byItem = Object.keys(itemsByOrder).filter((id) => itemsByOrder[id]?.includes(itemId));
    return byItem.length === 1 ? byItem[0] : null;
  }
  function setValue(input, value) {
    const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set;
    setter.call(input, value);
    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.dispatchEvent(new Event("change", { bubbles: true }));
  }
  function setCarrier(input, value) {
    const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set;
    setter.call(input, value);
    input.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, key: "Shift", keyCode: 16 }));
    input.dispatchEvent(new FocusEvent("blur"));
  }
  function trackingGroups(doc) {
    const groups = [];
    for (const row of doc.querySelectorAll("tr.newUser, tr.trk-row")) {
      if (row.classList.contains("newUser")) groups.push([]);
      else (groups.at(-1) ?? groups[groups.push([]) - 1]).push(row);
    }
    return groups;
  }
  function setupTrackingPage(doc, enabled2) {
    if (location.pathname !== "/ship/tr/update" || !location.hash.includes("auroebay-fill") || !enabled2())
      return () => {
      };
    const orders = (new URL(location.href).searchParams.get("orders") ?? "").split(",").filter((id) => /^\d{2}-\d{5}-\d{5}$/.test(id));
    const box2 = floatingBox(doc, "auroebay-tracking", "Suivis AliExpress");
    const report = Object.assign(doc.createElement("div"), { className: "status" });
    box2.body.append(report);
    const filled = [];
    let stopRefill;
    let refillNow = () => {
    };
    let active2 = true;
    let onInput;
    void (async () => {
      for (let i = 0; i < 20 && !doc.querySelector("tr.trk-row"); i++) await new Promise((r) => setTimeout(r, 300));
      const status = await message({ type: "SALES_STATUS", ids: orders }).catch(() => ({}));
      const transactions = handedTransactions(location.hash);
      const itemsByOrder = Object.fromEntries(orders.map((id) => [id, status[id]?.itemIds ?? []]));
      const lines = [];
      const carriers = [];
      const linesByOrder = /* @__PURE__ */ new Map();
      let unknown = 0;
      for (const row of trackingGroups(doc).flat()) {
        const [, itemId = "", transactionId = ""] = row.querySelector("input[id^='trkNum_']")?.id.split("_") ?? [];
        const orderId = orderOfLine(itemId, transactionId, transactions, itemsByOrder);
        if (!orderId) {
          unknown++;
          continue;
        }
        linesByOrder.set(orderId, [...linesByOrder.get(orderId) ?? [], row]);
      }
      for (const [orderId, rows2] of linesByOrder) {
        const numbers = status[orderId]?.supplierTrackings ?? [];
        if (!numbers.length) continue;
        rows2.forEach((row, index) => {
          const number = row.querySelector("input[aria-label='Tracking Number']");
          const carrierInput = row.querySelector("input[aria-label='Carrier']");
          if (!number || number.value.trim()) return;
          const entry = numbers.length === rows2.length ? numbers[index] : numbers[0];
          setValue(number, entry.tracking);
          if (carrierInput && number.id) carriers.push({ numberId: number.id, value: guessCarrier(entry.tracking, entry.carrier) });
          filled.push({ orderId, input: number, tracking: entry.tracking });
          number.style.outline = "2px solid #16a34a";
        });
      }
      if (unknown) lines.push(`\u26A0 ${unknown} ligne(s) dont la commande n\u2019a pas pu \xEAtre identifi\xE9e avec certitude : laiss\xE9e(s) vide(s).`);
      report.className = "status " + (filled.length ? "ok" : "warn");
      report.textContent = filled.length ? `\u2713 ${filled.length} ligne(s) remplie(s) avec les suivis AliExpress (en vert). V\xE9rifie, puis clique \xAB Save \xBB.` : "Aucune ligne vide \xE0 remplir avec un suivi AliExpress connu.";
      for (const line of lines) report.append(Object.assign(doc.createElement("div"), { className: "warn", textContent: line }));
      const touched = /* @__PURE__ */ new Set();
      onInput = (e) => {
        const box3 = e.target;
        if (e.isTrusted && box3?.getAttribute?.("aria-label") === "Carrier") {
          const id = box3.closest("tr")?.querySelector("input[id^='trkNum_']")?.id;
          if (id) touched.add(id);
        }
      };
      doc.addEventListener("input", onInput, true);
      const refill = () => {
        if (!enabled2()) return;
        for (const c of carriers) {
          if (touched.has(c.numberId)) continue;
          const row = doc.getElementById(c.numberId)?.closest("tr");
          const box3 = row?.querySelector("input[aria-label='Carrier']");
          if (box3 && !box3.value.trim() && doc.activeElement !== box3) setCarrier(box3, c.value);
        }
      };
      await new Promise((r) => setTimeout(r, 500));
      if (!active2) return;
      refill();
      refillNow = refill;
      stopRefill = window.setInterval(refill, 700);
    })();
    const onClick = (event) => {
      const button = event.target?.closest("button");
      if (!button || button.textContent?.trim() !== "Save") return;
      refillNow();
      clearInterval(stopRefill);
      for (const f of filled)
        if (f.input.value.trim() === f.tracking)
          void message({ type: "SALE_EBAY_TRACKING", orderId: f.orderId, tracking: f.tracking }).catch(() => {
          });
    };
    doc.addEventListener("click", onClick, true);
    return () => {
      active2 = false;
      clearInterval(stopRefill);
      if (onInput) doc.removeEventListener("input", onInput, true);
      doc.removeEventListener("click", onClick, true);
      box2.remove();
    };
  }

  // src/aliexpress/checkoutQuantity.ts
  var VALID = 2 * 36e5;

  // src/aliexpress/orderPrefill.ts
  var HASH = "auroebay-order=";
  function parseVariation(text2) {
    return text2.split(/\s*[·•|]\s*/).map((part) => part.match(/^\s*([^:]{1,60}):\s*(.+?)\s*$/)).filter((m) => !!m).map((m) => ({ name: m[1].trim(), value: m[2].trim() }));
  }
  var prefillHash = (p) => `#${HASH}${encodeURIComponent(JSON.stringify(p))}`;

  // src/core/buyerMessages.ts
  var first2 = (name) => {
    const word = name.trim().split(/\s+/)[0] ?? "";
    return /^[\p{L}'-]{2,}$/u.test(word) ? word.charAt(0).toUpperCase() + word.slice(1).toLowerCase() : "";
  };
  var hello = (i) => first2(i.buyer) ? `Hello ${first2(i.buyer)},` : "Hello,";
  var item = (i) => {
    const t = i.item.trim().replace(/\s+/g, " ");
    return t.length > 60 ? `${t.slice(0, 60).replace(/\s+\S*$/, "")}\u2026` : t || "item";
  };
  var bye = "Kind regards";
  var BUYER_MESSAGES = [
    {
      id: "thanks",
      label: "Merci pour la commande",
      text: (i) => `${hello(i)}

Thank you for your order of the ${item(i)}! It is being prepared and I will send you the tracking number as soon as it ships.

If you have any question, just message me.

${bye}`
    },
    {
      id: "tracking",
      label: "Colis exp\xE9di\xE9 (num\xE9ro de suivi)",
      text: (i) => `${hello(i)}

Good news: your ${item(i)} has shipped.${i.tracking ? ` Tracking number: ${i.tracking}.` : ""} The tracking can take a few days to show the first updates, this is normal.

${bye}`
    },
    {
      id: "delay",
      label: "Retard de livraison",
      text: (i) => `${hello(i)}

I am sorry, your ${item(i)} is taking longer than expected. It is on its way${i.tracking ? ` (tracking: ${i.tracking})` : ""} and I am following it closely. Thank you for your patience, I will keep you updated.

${bye}`
    },
    {
      id: "phone",
      label: "Demander un num\xE9ro de portable",
      text: (i) => `${hello(i)}

Thank you for your order! The carrier needs a mobile phone number to deliver your ${item(i)} (the one on the order looks like a landline). Could you please send me a mobile number?

Thank you!
${bye}`
    },
    {
      id: "address",
      label: "Demander de confirmer l\u2019adresse",
      text: (i) => `${hello(i)}

Thank you for your order! The carrier cannot validate the delivery address as written. Could you please confirm your full address, including the postcode?

Thank you!
${bye}`
    },
    {
      id: "military",
      label: "Adresse militaire (APO/FPO) : demander une adresse civile",
      text: (i) => `${hello(i)}

Thank you for your order! Unfortunately my carrier cannot deliver to APO/FPO/DPO military addresses. Could you send me a civilian address in the United States? If that is not possible, I will cancel the order and you will receive a full refund.

${bye}`
    },
    {
      id: "country",
      label: "Pays non livrable : j\u2019annule et je rembourse",
      text: (i) => `${hello(i)}

Thank you for your order of the ${item(i)}. I am very sorry, but I am not able to ship this item to your region. I am cancelling the order now and you will receive a full refund.

Sorry for the inconvenience.
${bye}`
    },
    {
      id: "return-hold",
      label: "Retour : ne renvoie pas encore, envoie tes photos",
      text: (i) => `${hello(i)}

Thank you for your message. Please do not return the item yet.

Could you please send me a photo of the item you received, of the package, and of the shipping label if you still have it? This will allow me to contact the warehouse and provide you with the correct return label.

I will get back to you shortly with the next steps. Thank you for your cooperation.

${bye}`
    },
    {
      id: "return-photos",
      label: "Retour : photos bien re\xE7ues, garde l\u2019article",
      text: (i) => `${hello(i)}

Thank you very much for the photos, I have received them all.

I am now contacting the warehouse to arrange your return. Please keep the item and do not send it back yet.

I will get back to you within 2 to 3 business days with the next steps and the correct return label.

Thank you for your patience.

${bye}`
    },
    {
      id: "delivered-missing",
      label: "Indiqu\xE9 livr\xE9, mais pas re\xE7u : v\xE9rifier voisins et poste",
      text: (i) => `${hello(i)}

I am sorry to hear this. The tracking${i.tracking ? ` (${i.tracking})` : ""} shows the package as delivered${i.deliveredOn ? ` on ${i.deliveredOn}` : ""}, but this does not prove who received it.

Could you please check with your neighbors, in your mailbox, around the usual parcel area, and with your local post office?

In the meantime, I am asking the supplier for proof of delivery. I will get back to you as soon as I have an answer.

${bye}`
    },
    {
      id: "stock",
      label: "Rupture : j\u2019annule et je rembourse",
      text: (i) => `${hello(i)}

Thank you for your order. I am very sorry, the ${item(i)} is no longer available. I am cancelling the order now and you will receive a full refund.

Sorry for the inconvenience.
${bye}`
    }
  ];
  function buyerMessage(id, input) {
    const m = BUYER_MESSAGES.find((x) => x.id === id);
    return m ? m.text(input).slice(0, 2e3) : null;
  }

  // src/core/disputes.ts
  var RETURN_AUTO = /buyer started a return|approved automatically/i;
  var returnToHold = (d) => d.source === "ebay" && d.kind === "return" && d.open && !d.held && !d.photos && RETURN_AUTO.test(`${d.status} ${d.detail ?? ""}`);
  var returnMessageUrl = (orderId) => `https://www.ebay.com/mesh/ord/details?mode=SH&orderid=${encodeURIComponent(orderId)}#auroebay-return-hold`;

  // src/ebay/orders.ts
  var DETAILS = /^\/mesh\/ord\/details/;
  var LIST2 = /^\/sh\/ord\/?$/;
  var sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  var trackingFrames = (doc) => [...doc.querySelectorAll("iframe")].filter((f) => f.src.includes("/ship/trk/"));
  async function typeBuyerMessage(doc, text2) {
    const box2 = () => {
      for (const f of doc.querySelectorAll("iframe.ordui-m2m-panel__iframe, iframe[src*='/cnt/ViewMessage/']")) {
        try {
          const t2 = f.contentDocument?.querySelector("#imageupload__sendmessage--textbox, textarea[aria-label='Send message']");
          if (t2) return t2;
        } catch {
        }
      }
      return null;
    };
    if (!box2()) {
      const open = [...doc.querySelectorAll("button")].find((b) => b.textContent?.trim() === "Message buyer" && b.offsetParent);
      if (!open) return false;
      open.click();
      for (let i = 0; i < 40 && !box2(); i++) await sleep(250);
    }
    const t = box2();
    if (!t) return false;
    const setter = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, "value").set;
    t.focus();
    setter.call(t, text2);
    t.dispatchEvent(new Event("input", { bubbles: true }));
    t.dispatchEvent(new Event("change", { bubbles: true }));
    return true;
  }
  var openFromOrderPage = (doc) => () => {
    const add = [...doc.querySelectorAll("button")].find(
      (b) => b.textContent?.trim() === "Add tracking" && b.offsetParent
    );
    if (!add) throw Error("Bouton \xAB Add tracking \xBB introuvable sur cette commande (d\xE9j\xE0 exp\xE9di\xE9e ?).");
    add.click();
  };
  async function fillEbayTracking(doc, tracking, carrier, open = openFromOrderPage(doc)) {
    const before = new Set(trackingFrames(doc));
    open();
    let frame;
    let input = null;
    for (let i = 0; i < 40 && !input; i++) {
      await sleep(250);
      const frames = trackingFrames(doc);
      frame = frames.find((f) => !before.has(f) && f.offsetParent) ?? frames.find((f) => f.offsetParent);
      input = frame?.contentDocument?.querySelector("input.textbox__control") ?? null;
    }
    const d = frame?.contentDocument;
    const w = frame?.contentWindow;
    if (!frame || !d || !w || !input) throw Error("La fen\xEAtre eBay \xAB Add tracking \xBB ne s\u2019est pas ouverte.");
    const set = (el2, v) => {
      const setter = Object.getOwnPropertyDescriptor(w.HTMLInputElement.prototype, "value").set;
      el2.focus();
      setter.call(el2, v);
      el2.dispatchEvent(new w.Event("input", { bubbles: true }));
      el2.dispatchEvent(new w.Event("change", { bubbles: true }));
    };
    set(input, tracking);
    const combo = d.querySelector("input[role=combobox]");
    if (combo) {
      set(combo, carrier);
      await sleep(400);
      const option = [...d.querySelectorAll("[role=option]")].find(
        (o) => o.textContent?.trim().toLowerCase() === carrier.toLowerCase()
      );
      option?.click();
      await sleep(300);
      if (!option) return { warn: `Transporteur \xAB ${carrier} \xBB \xE0 choisir dans la liste eBay.` };
    }
    return { warn: "" };
  }
  function ordersPage(href) {
    try {
      const u = new URL(href);
      if (!/(^|\.)ebay\.com$/.test(u.hostname)) return null;
      if (DETAILS.test(u.pathname)) return "details";
      if (LIST2.test(u.pathname)) return "list";
    } catch {
    }
    return null;
  }
  function box(doc) {
    const b = floatingBox(doc, "auroebay-orders");
    return { host: b.host, body: b.body, open: b.open };
  }
  var el = (tag, props = {}) => Object.assign(document.createElement(tag), props);
  var fmt = (n, cur = "EUR") => n === null || n === void 0 ? "?" : n.toLocaleString("fr-FR", { style: "currency", currency: cur });
  async function saveFrom(doc, url) {
    const { sale } = parseEbayOrder(doc, url);
    return message({ type: "SALE_SAVE", sale });
  }
  async function refreshSavedOrders(ids) {
    let done = 0;
    for (const id of ids.filter((x) => /^\d{2}-\d{5}-\d{5}$/.test(x)).slice(0, 20)) {
      try {
        const url = `https://www.ebay.com/mesh/ord/details?mode=SH&orderid=${id}`;
        const html = await fetch(url, { credentials: "include", signal: AbortSignal.timeout(3e4) }).then((r) => {
          if (!r.ok) throw Error(String(r.status));
          return r.text();
        });
        await saveFrom(new DOMParser().parseFromString(html, "text/html"), url);
        done++;
      } catch {
      }
    }
    return done;
  }
  function detailsUI(doc, enabled2) {
    const { host, body, open: openWindow } = box(doc);
    const orderId = new URL(location.href).searchParams.get("orderid") ?? "";
    const status = el("p", { className: "status", textContent: "\u2026" });
    const save = el("button", { className: "primary", textContent: "\u2B06 Enregistrer la vente" });
    const copy = el("button", { textContent: "\u{1F4CB} Copier l\u2019adresse pour AliExpress" });
    const open = el("button", { textContent: "\u{1F4D2} Voir mes ventes" });
    const talk = el("button", { textContent: "\u2709\uFE0F Message au client" });
    const talkBox = el("div", { className: "sale", hidden: true });
    const track = el("button", { className: "track", hidden: true });
    const shortcuts = el("div");
    const report = el("div");
    const disputesBox = el("div");
    body.append(status, disputesBox, track, shortcuts, save, copy, talk, talkBox, open, report);
    let lastTracking = null;
    const openTalk = () => {
      if (!enabled2()) return;
      talkBox.hidden = !talkBox.hidden;
      if (talkBox.hidden || talkBox.childElementCount) return;
      const pick = document.createElement("select");
      pick.style.cssText = "width:100%;margin-top:6px";
      pick.append(el("option", { value: "", textContent: "Choisis le message\u2026" }));
      for (const m of BUYER_MESSAGES) pick.append(el("option", { value: m.id, textContent: m.label }));
      const text2 = document.createElement("textarea");
      text2.rows = 8;
      text2.maxLength = 2e3;
      text2.style.cssText = "width:100%;box-sizing:border-box;margin-top:6px;font:12px system-ui;background:#15121c;color:inherit;border:1px solid var(--line);border-radius:9px;padding:6px 8px";
      const write = el("button", { className: "primary", textContent: "\u270D\uFE0F \xC9crire dans eBay", disabled: true });
      const said = el("p", { className: "s", textContent: "Le message est en anglais. Tu peux le modifier ici avant." });
      pick.addEventListener("change", () => {
        let input = { buyer: "", item: "", tracking: lastTracking };
        try {
          const order = parseEbayOrder(doc, location.href);
          input = { buyer: order.address?.name ?? "", item: order.sale.items[0]?.title ?? "", tracking: lastTracking };
        } catch {
        }
        text2.value = pick.value ? buyerMessage(pick.value, input) ?? "" : "";
        write.disabled = !text2.value.trim();
      });
      text2.addEventListener("input", () => write.disabled = !text2.value.trim());
      write.addEventListener("click", async () => {
        if (!enabled2()) return;
        write.disabled = true;
        const ok = await typeBuyerMessage(doc, text2.value).catch(() => false);
        said.className = ok ? "s ok" : "s err";
        said.textContent = ok ? "\u2713 Message \xE9crit dans la fen\xEAtre eBay, \xE0 droite. Relis puis clique toi-m\xEAme \xAB Send message \xBB." : "Fen\xEAtre \xAB Message buyer \xBB introuvable : clique \xAB Message buyer \xBB sur la page, puis r\xE9essaie.";
        write.disabled = false;
      });
      const head = el("p", { className: "label", textContent: "\u2709\uFE0F MESSAGE AU CLIENT" });
      talkBox.append(head, pick, text2, write, said);
    };
    talk.addEventListener("click", openTalk);
    const prepareMessage = (id) => {
      if (talkBox.hidden) openTalk();
      const pick = talkBox.querySelector("select");
      if (!pick) return;
      pick.value = id;
      pick.dispatchEvent(new Event("change"));
      openWindow();
      talkBox.scrollIntoView({ block: "nearest" });
    };
    if (location.hash === "#auroebay-return-hold") prepareMessage("return-hold");
    const KIND = { return: "Retour", inr: "Colis non re\xE7u", case: "Litige (case)", refund: "Remboursement" };
    const LEVEL = { urgent: "err", todo: "warn", info: "s", done: "ok" };
    const showDisputes = async () => {
      const r = await message({ type: "DISPUTES_FOR_ORDER", orderId }).catch(() => null);
      disputesBox.replaceChildren();
      if (!r || !enabled2()) return;
      const seen = /\b(return (request(ed)?|started|opened|in progress)|item not received|case (opened|open|closed)|request (opened|closed))\b/i.test(
        (doc.querySelector("main") ?? doc.body)?.textContent ?? ""
      );
      if (!r.list.length && !seen) return;
      const card2 = el("div", { className: "sale" });
      card2.append(el("p", { className: "label", textContent: "\u2696\uFE0F LITIGE" }));
      if (!r.list.length) card2.append(el("p", { className: "s", textContent: "eBay affiche un retour ou une demande sur cette commande : synchronise pour le suivre ici, avec son c\xF4t\xE9 AliExpress." }));
      for (const d of r.list) {
        const line = el("p", { className: "s" });
        const link = el("a", { href: d.url, target: "_blank", rel: "noopener", textContent: d.status || (d.open ? "En cours" : "Termin\xE9") });
        link.style.cssText = "color:inherit;text-decoration:underline";
        line.append(
          el("b", { textContent: `${d.source === "ebay" ? "eBay" : "AliExpress"} \xB7 ${KIND[d.kind]} \xB7 ` }),
          el("span", { className: d.open ? "warn" : "ok", textContent: d.open ? "en cours \xB7 " : "termin\xE9 \xB7 " }),
          link
        );
        const extra = [
          d.reason,
          d.refunded && `rembours\xE9 ${d.refunded.amount.toLocaleString("fr-FR", { style: "currency", currency: d.refunded.currency })}`,
          d.outcome
        ].filter(Boolean);
        if (extra.length) line.append(el("span", { textContent: " \xB7 " + extra.join(" \xB7 ") }));
        if (d.deadline && d.open) line.append(el("span", { className: "err", textContent: ` \xB7 \u23F0 avant le ${d.deadline}` }));
        card2.append(line);
      }
      if (r.advice) card2.append(el("p", { className: LEVEL[r.advice.level], textContent: "\u{1F449} " + r.advice.text }));
      const hold = r.list.find(returnToHold);
      if (hold) {
        const write = el("button", { className: "primary", textContent: "\u2709\uFE0F Pr\xE9parer le message au client" });
        write.addEventListener("click", () => prepareMessage("return-hold"));
        const sent = el("button", { textContent: "\u2713 C\u2019est envoy\xE9" });
        sent.addEventListener("click", async () => {
          await message({ type: "DISPUTE_HELD", key: hold.key }).catch(() => {
          });
          await showDisputes();
        });
        card2.append(write, sent);
      }
      if (r.list.some((d) => d.source === "ebay" && d.kind === "return" && d.open && d.photos)) {
        const thanks = el("button", { textContent: "\u2709\uFE0F Dire au client : photos bien re\xE7ues" });
        thanks.addEventListener("click", () => prepareMessage("return-photos"));
        card2.append(thanks);
      }
      const sync = el("button", { textContent: r.at ? "\u21BB Synchroniser les litiges" : "\u2696\uFE0F Synchroniser les litiges" });
      sync.addEventListener("click", async () => {
        if (!enabled2()) return;
        sync.disabled = true;
        sync.textContent = "Lecture eBay et AliExpress\u2026 (1 \xE0 2 min)";
        await message({ type: "DISPUTES_SYNC" }).catch(() => {
        });
        await showDisputes();
        await refresh();
      });
      card2.append(sync);
      disputesBox.append(card2);
    };
    void showDisputes();
    let trackInfo = null;
    let lastPending = null;
    track.addEventListener("click", async () => {
      if (!enabled2() || !trackInfo) return;
      track.disabled = true;
      report.replaceChildren();
      try {
        const carrier = guessCarrier(trackInfo.tracking, trackInfo.carrier);
        const { warn } = await fillEbayTracking(doc, trackInfo.tracking, carrier);
        report.append(
          el("p", {
            className: warn ? "warn" : "ok",
            textContent: `${warn ? warn + " " : ""}Suivi ${trackInfo.tracking} (${carrier}) rempli dans eBay : v\xE9rifie puis clique \xAB Save and continue \xBB.${(lastPending ?? 0) > 1 ? " Recharge ensuite la page pour le suivi suivant." : ""}`
          })
        );
      } catch (e) {
        report.append(el("p", { className: "err", textContent: e instanceof Error ? e.message : String(e) }));
      } finally {
        track.disabled = false;
      }
    });
    const refresh = async () => {
      const st = await message({ type: "SALES_STATUS", ids: [orderId] }).catch(() => ({}));
      const s = st[orderId];
      status.className = "status " + (s?.saved ? "ok" : "");
      status.textContent = s?.saved ? `\u2713 Vente enregistr\xE9e${s.supplierOrderId ? " \xB7 AliExpress li\xE9" : " \xB7 AliExpress pas encore li\xE9"}${s.profit !== null && s.profit !== void 0 ? " \xB7 b\xE9n\xE9fice " + fmt(s.profit, s.currency) : ""}` : "Pas encore dans AurOEBay.";
      save.textContent = s?.saved ? "\u21BB Mettre \xE0 jour la vente" : "\u2B06 Enregistrer la vente";
      lastTracking = s?.ebayTracking ?? null;
      const pending = s?.pendingTrackings ?? [];
      lastPending = pending.length;
      trackInfo = pending[0] ?? null;
      track.hidden = !trackInfo;
      if (trackInfo)
        track.textContent = pending.length > 1 ? `\u{1F4E6} Mettre le suivi 1/${pending.length} (${trackInfo.tracking}) sur eBay` : `\u{1F4E6} Mettre le suivi AliExpress ${trackInfo.tracking} sur eBay`;
      return s?.saved ?? false;
    };
    save.addEventListener("click", async () => {
      if (!enabled2()) return;
      save.disabled = true;
      try {
        await saveFrom(doc, location.href);
        await refresh();
      } catch (e) {
        status.className = "status err";
        status.textContent = e instanceof Error ? e.message : String(e);
      } finally {
        save.disabled = false;
      }
    });
    const copyAddress = async () => {
      report.replaceChildren();
      const { address } = parseEbayOrder(doc, location.href);
      if (!address) throw Error("Adresse de livraison introuvable sur cette page.");
      const r = await message({
        type: "ADDRESS_COPY",
        orderId,
        address
      });
      report.append(
        el("p", {
          className: r.problems.length ? "warn" : "ok",
          textContent: r.problems.length ? `Adresse copi\xE9e, ${r.problems.length} point(s) \xE0 v\xE9rifier :` : `\u2713 Adresse copi\xE9e${r.changes ? ` (${r.changes} correction(s) pr\xEAtes)` : ""}. Sur AliExpress \u2192 \xAB Coller l\u2019adresse AurOEBay \xBB.`
        })
      );
      if (r.problems.length) {
        const ul = el("ul");
        for (const p of r.problems) ul.append(el("li", { textContent: p }));
        report.append(ul);
      }
      await saveFrom(doc, location.href).catch(() => {
      });
      await refresh();
    };
    copy.addEventListener("click", async () => {
      if (!enabled2()) return;
      copy.disabled = true;
      try {
        await copyAddress();
      } catch (e) {
        report.replaceChildren(el("p", { className: "err", textContent: e instanceof Error ? e.message : String(e) }));
      } finally {
        copy.disabled = false;
      }
    });
    const renderShortcuts = async (attempt = 0) => {
      let items = [];
      try {
        items = parseEbayOrder(doc, location.href).sale.items;
      } catch {
      }
      if (!items.length) {
        if (attempt < 6) setTimeout(() => void renderShortcuts(attempt + 1), 1500);
        return;
      }
      const found = await message({
        type: "ORDER_SUPPLIERS",
        items: items.map((i) => ({ itemId: i.itemId, supplierId: i.supplierId }))
      }).catch(() => []);
      shortcuts.replaceChildren();
      items.forEach((item2, index) => {
        const url = found[index]?.url;
        const label4 = items.length > 1 ? ` \xB7 ${item2.title.slice(0, 28)}\u2026` : "";
        if (!url) {
          shortcuts.append(
            el("p", {
              className: "small warn",
              textContent: `Fournisseur AliExpress inconnu${label4 ? " pour" + label4 : ""} : relie l\u2019annonce \xE0 son produit dans AurOEBay.`
            })
          );
          return;
        }
        const go = el("button", {
          className: "primary",
          textContent: `\u{1F6D2} Commander sur AliExpress${label4}`,
          title: "Copie l\u2019adresse du client et ouvre le produit AliExpress avec la bonne variante et la bonne quantit\xE9"
        });
        go.addEventListener("click", async () => {
          if (!enabled2()) return;
          window.open(
            url.split("#")[0] + prefillHash({ orderId, options: parseVariation(item2.variation), quantity: item2.quantity }),
            "_blank",
            "noopener"
          );
          go.disabled = true;
          try {
            await copyAddress();
            const qty = item2.quantity > 1 ? `Quantit\xE9 : ${item2.quantity}. ` : "";
            report.append(
              el("p", {
                className: "ok",
                textContent: `Adresse copi\xE9e. AliExpress s\u2019ouvre avec ${item2.variation ? `la variante \xAB ${item2.variation} \xBB` : "le produit"}${qty ? ` et ${qty.toLowerCase()}` : ""} d\xE9j\xE0 choisis : v\xE9rifie puis \xAB Buy now \xBB.`
              })
            );
          } catch (e) {
            report.replaceChildren(el("p", { className: "err", textContent: e instanceof Error ? e.message : String(e) }));
          } finally {
            go.disabled = false;
          }
        });
        shortcuts.append(go);
      });
    };
    void renderShortcuts();
    open.addEventListener("click", () => void message({ type: "OPEN_SALES", orderId }).catch(() => {
    }));
    void refresh().then((saved) => {
      if (saved && enabled2())
        void saveFrom(doc, location.href).then(refresh).then(() => {
          if (location.hash === "#auroebay-track" && trackInfo) track.click();
        }).catch(() => {
        });
    });
    return () => host.remove();
  }
  function listUI(doc, enabled2) {
    const { host, body } = box(doc);
    const status = el("p", { className: "status", textContent: "" });
    const bulk = el("button", { className: "primary", textContent: "\u2B06 Enregistrer les commandes de cette page" });
    const open = el("button", { textContent: "\u{1F4D2} Voir mes ventes et la compta" });
    const note = el("p", { className: "small", textContent: "Ouvre aussi une commande pour copier son adresse." });
    const allTracking = el("button", { className: "track", hidden: true });
    const fetchTracking = el("button", { textContent: "\u{1F504} R\xE9cup\xE9rer les suivis AliExpress" });
    body.append(status, allTracking, fetchTracking, bulk, open, note);
    const bar = el("div");
    bar.id = "auroebay-orders-bar";
    bar.setAttribute("data-auroebay-sale", "");
    bar.style.cssText = "display:flex;flex-wrap:wrap;align-items:center;gap:6px 10px;margin:10px 0 4px;font:13px/1.4 -apple-system,system-ui,sans-serif";
    const barFetch = el("button", { type: "button" });
    barFetch.style.cssText = brandButtonStyle("quiet", "0");
    barFetch.append(brandButtonIcon(doc, 16), "R\xE9cup\xE9rer les suivis AliExpress");
    brandButtonHover(barFetch);
    const barSend = el("button", { type: "button", hidden: true });
    barSend.style.cssText = brandButtonStyle("primary", "0");
    brandButtonHover(barSend);
    const barStatus = el("span");
    barStatus.style.cssText = "opacity:.8";
    bar.append(barFetch, barSend, barStatus);
    const placeBar = () => {
      if (bar.isConnected) return;
      const anchor = doc.querySelector(".bulk-actions") ?? doc.querySelector("table.table-grid-component");
      if (!anchor) return;
      if (anchor.matches(".bulk-actions")) anchor.after(bar);
      else anchor.before(bar);
    };
    const say = (text2) => {
      status.textContent = text2;
      barStatus.textContent = text2;
    };
    const runFetch = async () => {
      if (!enabled2() || fetchTracking.disabled) return;
      fetchTracking.disabled = barFetch.disabled = true;
      fetchTracking.textContent = "Lecture des suivis AliExpress\u2026";
      barFetch.lastChild.textContent = "Lecture des suivis AliExpress\u2026";
      try {
        const run = await message({
          type: "ALI_TRACKINGS_REFRESH"
        });
        await badges();
        say(
          run.state === "error" ? `\u26A0 ${run.error}` : run.total ? `\u2713 ${run.total} commande(s) AliExpress relue(s), ${run.found} nouveau(x) num\xE9ro(s).${pendingByOrder.size ? " Clique \xAB Mettre tous les suivis disponibles \xBB." : ""}` : "Aucune commande AliExpress en attente de suivi."
        );
      } catch (e) {
        say(`\u26A0 ${e instanceof Error ? e.message : String(e)}`);
      } finally {
        fetchTracking.disabled = barFetch.disabled = false;
        fetchTracking.textContent = "\u{1F504} R\xE9cup\xE9rer les suivis AliExpress";
        barFetch.lastChild.textContent = "R\xE9cup\xE9rer les suivis AliExpress";
      }
    };
    fetchTracking.addEventListener("click", () => void runFetch());
    barFetch.addEventListener("click", () => void runFetch());
    let active2 = true;
    const pendingByOrder = /* @__PURE__ */ new Map();
    const transactionsOf = (id) => {
      const out = [];
      const start = [...doc.querySelectorAll("tr.order-info")].find(
        (r) => r.classList.contains(`orderid_${id}`)
      );
      for (let row = start ?? null; row; row = row.nextElementSibling) {
        if (row !== start && row.classList.contains("order-info")) break;
        for (const c of row.classList) {
          const m = c.match(/^itemid_\d+-(\d+)$/);
          if (m && !out.includes(m[1])) out.push(m[1]);
        }
      }
      return out;
    };
    const trackingsShown = (id) => {
      const out = [];
      const start = [...doc.querySelectorAll("tr.order-info")].find(
        (r) => r.classList.contains(`orderid_${id}`)
      );
      for (let row = start ?? null; row; row = row.nextElementSibling) {
        if (row !== start && row.classList.contains("order-info")) break;
        for (const info of row.querySelectorAll(".tracking-info")) {
          if (info.closest("[data-auroebay-sale]")) continue;
          for (const b of info.querySelectorAll("button, a")) {
            const value = (b.textContent ?? "").trim();
            if (/^[A-Z0-9-]{8,40}$/i.test(value) && /\d{4}/.test(value) && !out.includes(value)) out.push(value);
          }
        }
      }
      return out;
    };
    const openTracking = (ids2) => {
      location.href = trackingPageURL(ids2, location.href, Object.fromEntries(ids2.map((id) => [id, transactionsOf(id)])));
    };
    barSend.addEventListener("click", () => allTracking.click());
    allTracking.addEventListener("click", () => {
      if (!enabled2() || !pendingByOrder.size) return;
      openTracking([...pendingByOrder.keys()].slice(0, 30));
    });
    const ids = () => {
      const found = /* @__PURE__ */ new Map();
      for (const a of doc.querySelectorAll('a[href*="orderid="]')) {
        try {
          const id = new URL(a.href).searchParams.get("orderid") ?? "";
          if (/^\d{2}-\d{5}-\d{5}$/.test(id) && !found.has(id) && /\d{2}-\d{5}-\d{5}/.test(a.textContent ?? ""))
            found.set(id, a);
        } catch {
        }
      }
      return found;
    };
    let lastSignature = "";
    const badges = async () => {
      if (!active2 || !enabled2()) return;
      const found = ids();
      if (!found.size) return;
      const shown = [...found.keys()].map((id) => ({ orderId: id, trackings: trackingsShown(id) })).filter((r) => r.trackings.length);
      if (shown.length) await message({ type: "SALE_EBAY_TRACKINGS", rows: shown }).catch(() => 0);
      const st = await message({ type: "SALES_STATUS", ids: [...found.keys()] }).catch(() => ({}));
      const signature = JSON.stringify([...found.keys()].map((id) => [id, st[id] ?? null]));
      if (signature === lastSignature && [...found.keys()].every((id) => !st[id]?.saved || doc.querySelector(`[data-auroebay-order="${id}"]`)))
        return;
      lastSignature = signature;
      pendingByOrder.clear();
      for (const [id, a] of found) {
        doc.querySelectorAll(`[data-auroebay-order="${id}"]`).forEach((n) => n.remove());
        const s = st[id];
        if (!s?.saved) continue;
        const row = a.closest("tr");
        const actions = row?.querySelector("td.actions-cell") ?? [...row?.querySelectorAll("button, a") ?? []].find((b2) => /shipping label|leave feedback/i.test(b2.textContent ?? ""))?.closest("td") ?? null;
        const box2 = el("div");
        box2.setAttribute("data-auroebay-sale", "");
        box2.setAttribute("data-auroebay-order", id);
        box2.style.cssText = "display:flex;flex-direction:column;align-items:flex-start;gap:4px;margin-top:8px";
        if (actions) actions.append(box2);
        else a.parentElement?.after(box2);
        const pill = (text2, title, bg, onClick) => {
          const p = el("button", { type: "button", textContent: text2, title });
          p.setAttribute("data-auroebay-sale", "");
          p.style.cssText = `display:inline-block;margin:0;padding:3px 10px;border-radius:8px;border:0;font:700 12px system-ui;color:#fff;background:${bg};cursor:pointer;white-space:nowrap`;
          p.addEventListener("click", (e) => {
            e.preventDefault();
            e.stopPropagation();
            onClick();
          });
          return p;
        };
        const b = pill(
          "AurOEBay \u2713",
          "Ouvrir cette vente dans AurOEBay (co\xFBts, b\xE9n\xE9fice, suivi)",
          s.supplierOrderId ? "#16a34a" : "#d97706",
          () => void message({ type: "OPEN_SALES", orderId: id }).catch(() => {
          })
        );
        box2.append(b);
        let last = b;
        for (const aliId of s.supplierOrderIds ?? (s.supplierOrderId ? [s.supplierOrderId] : [])) {
          const ali = pill(
            `ALI : ${aliId}`,
            "Ouvrir la commande AliExpress",
            "#ea580c",
            () => window.open(`https://www.aliexpress.us/p/order/detail.html?orderId=${aliId}`, "_blank", "noopener")
          );
          last.after(ali);
          last = ali;
        }
        let pendingList = s.pendingTrackings ?? (s.supplierTracking && !s.ebayTracking ? [{ tracking: s.supplierTracking }] : []);
        const itemRows = [...doc.querySelectorAll(`tr.item-info.orderid_${id}`)];
        const untracked = itemRows.filter((r) => /\+\s*Add tracking/i.test(r.textContent ?? "")).length;
        if (!pendingList.length && untracked && s.supplierTrackings?.length) pendingList = s.supplierTrackings;
        if (pendingList.length) {
          pendingByOrder.set(id, pendingList.length);
          const t = pill(
            pendingList.length > 1 ? `\u{1F4E6} Mettre ${pendingList.length} suivis` : "\u{1F4E6} Mettre le suivi",
            `Suivi AliExpress ${pendingList.map((p) => p.tracking).join(", ")} disponible, pas encore sur eBay : ouvre la page eBay des suivis d\xE9j\xE0 remplie`,
            "#dc2626",
            () => openTracking([id])
          );
          last.after(t);
        }
      }
      allTracking.hidden = !pendingByOrder.size;
      allTracking.textContent = `\u{1F4E6} Mettre tous les suivis disponibles (${pendingByOrder.size} commande(s))`;
      barSend.hidden = !pendingByOrder.size;
      barSend.replaceChildren(`\u{1F4E6} Mettre tous les suivis disponibles (${pendingByOrder.size})`);
      placeBar();
      const saved = [...found.keys()].filter((id) => st[id]?.saved).length;
      status.textContent = `${saved}/${found.size} commandes de cette page dans AurOEBay.`;
    };
    bulk.addEventListener("click", async () => {
      if (!enabled2()) return;
      bulk.disabled = true;
      const list = [...ids().keys()];
      let done = 0, failed = 0;
      const queue = [...list];
      const worker = async () => {
        while (queue.length && active2 && enabled2()) {
          const id = queue.shift();
          try {
            const url = `https://www.ebay.com/mesh/ord/details?mode=SH&orderid=${id}`;
            const html = await fetch(url, { credentials: "include" }).then((r) => {
              if (!r.ok) throw Error(String(r.status));
              return r.text();
            });
            await saveFrom(new DOMParser().parseFromString(html, "text/html"), url);
          } catch {
            failed++;
          }
          done++;
          status.textContent = `Enregistrement\u2026 ${done}/${list.length}${failed ? ` (${failed} \xE9chec(s))` : ""}`;
        }
      };
      await Promise.all([worker(), worker(), worker()]);
      status.textContent = `\u2713 ${done - failed} commande(s) enregistr\xE9e(s) ou mises \xE0 jour${failed ? `, ${failed} \xE9chec(s)` : ""}.`;
      bulk.disabled = false;
      await badges();
    });
    open.addEventListener("click", () => void message({ type: "OPEN_SALES" }).catch(() => {
    }));
    let timer;
    const ours = (n) => {
      const e = n.nodeType === 1 ? n : n.parentElement;
      return !!e && (e.hasAttribute("data-auroebay-sale") || !!e.closest("[data-auroebay-sale]"));
    };
    const observer = new MutationObserver((records) => {
      if (records.every((r) => ours(r.target) || [...r.addedNodes, ...r.removedNodes].every(ours))) return;
      clearTimeout(timer);
      timer = setTimeout(() => void badges(), 600);
    });
    observer.observe(doc.body, { childList: true, subtree: true });
    void badges();
    return () => {
      active2 = false;
      observer.disconnect();
      clearTimeout(timer);
      host.remove();
      doc.querySelectorAll("[data-auroebay-sale]").forEach((n) => n.remove());
    };
  }
  function setupOrders(doc, enabled2) {
    const page = ordersPage(location.href);
    if (!page || !enabled2()) return () => {
    };
    return page === "details" ? detailsUI(doc, enabled2) : listUI(doc, enabled2);
  }

  // src/ebay/returnPage.ts
  var PAGE = /^\/(rt\/ReturnDetails|rtn\/Return\/ReturnsDetail)/;
  function setupReturnPage(doc, enabled2) {
    if (!PAGE.test(location.pathname) || !enabled2()) return () => {
    };
    const text2 = doc.body?.innerText ?? "";
    const orderId = text2.match(/\b\d{2}-\d{5}-\d{5}\b/)?.[0];
    if (!orderId || !RETURN_AUTO.test(text2)) return () => {
    };
    const bar = doc.createElement("div");
    bar.id = "auroebay-return";
    bar.style.cssText = "position:fixed;top:14px;left:50%;transform:translateX(-50%);z-index:2147483645;display:flex;align-items:center;gap:12px;max-width:min(720px,calc(100vw - 32px));padding:10px 14px;border-radius:12px;background:#b3261e;color:#fff;font:600 14px/1.35 -apple-system,system-ui,sans-serif;box-shadow:0 12px 34px rgba(0,0,0,.4)";
    const say = doc.createElement("span");
    say.textContent = "\u26A0\uFE0F eBay a accept\xE9 ce retour tout seul : dis tout de suite au client de ne rien renvoyer, et demande-lui ses photos.";
    const go = doc.createElement("a");
    go.href = returnMessageUrl(orderId);
    go.textContent = "\u2709\uFE0F Pr\xE9parer le message";
    go.style.cssText = `${brandButtonStyle("primary", "0")};flex:none;text-decoration:none`;
    brandButtonHover(go);
    const close = doc.createElement("button");
    close.type = "button";
    close.textContent = "\u2715";
    close.title = "Fermer";
    close.style.cssText = "flex:none;border:0;background:none;color:#fff;font-size:16px;cursor:pointer";
    close.addEventListener("click", () => bar.remove());
    bar.append(say, go, close);
    doc.documentElement.append(bar);
    return () => bar.remove();
  }

  // src/ebay/claudeBridge.ts
  function setupClaudeBridge() {
    if (window.top !== window) return;
    window.addEventListener("message", (event) => {
      const data = event.data;
      if (event.source !== window || data?.auroebayBridge !== "request" || typeof data.nonce !== "string") return;
      const reply = (body) => window.postMessage({ auroebayBridge: "response", nonce: data.nonce, ...body }, location.origin);
      try {
        chrome.runtime.sendMessage({ type: "BRIDGE", cmd: data.cmd, args: data.args }).then((r) => reply({ ok: !!r?.ok, data: r?.data, error: r?.error })).catch((e) => reply({ ok: false, error: String(e) }));
      } catch (e) {
        reply({ ok: false, error: String(e) });
      }
    });
  }

  // src/ebay/followSeller.ts
  var NAME = /^[A-Za-z0-9_.-]{2,64}$/;
  function sellerOfPage(url, doc) {
    const ssn = url.searchParams.get("_ssn");
    if (url.pathname.startsWith("/sch/") && ssn && NAME.test(ssn)) return ssn.toLowerCase();
    const user = url.pathname.match(/^\/usr\/([A-Za-z0-9_.-]{2,64})\/?$/)?.[1];
    if (user) return user.toLowerCase();
    if (/^\/str\/[A-Za-z0-9_.-]+\/?$/.test(url.pathname)) {
      const read = (scope) => {
        const names3 = /* @__PURE__ */ new Set();
        for (const a of scope.querySelectorAll("a[href*='feedback_profile/'], a[href*='_ssn=']")) {
          try {
            const u = new URL(a.href || a.getAttribute("href") || "", "https://www.ebay.com");
            const name = u.searchParams.get("_ssn") ?? u.pathname.match(/\/fdbk\/feedback_profile\/([A-Za-z0-9_.-]{2,64})/)?.[1];
            if (name && NAME.test(name)) names3.add(name.toLowerCase());
          } catch {
          }
        }
        return names3;
      };
      const card2 = doc.querySelector(".str-header, .str-seller-card");
      let names2 = card2 ? read(card2) : /* @__PURE__ */ new Set();
      if (!names2.size) names2 = read(doc);
      return names2.size === 1 ? [...names2][0] : null;
    }
    return null;
  }
  function setupFollowSeller(doc, enabled2) {
    if (!enabled2()) return () => {
    };
    const looksLikeSeller = /^\/(usr|str)\//.test(location.pathname) || new URL(location.href).searchParams.has("_ssn");
    if (!looksLikeSeller) return () => {
    };
    let stop = () => {
    };
    let waited = 0;
    const wait = setInterval(() => {
      const seller = sellerOfPage(new URL(location.href), doc);
      if (seller) {
        clearInterval(wait);
        stop = mount(doc, enabled2, seller);
      } else if (++waited > 16) clearInterval(wait);
    }, 500);
    const first3 = sellerOfPage(new URL(location.href), doc);
    if (first3) {
      clearInterval(wait);
      stop = mount(doc, enabled2, first3);
    }
    return () => {
      clearInterval(wait);
      stop();
    };
  }
  function mount(doc, enabled2, seller) {
    doc.getElementById("auroebay-follow-seller")?.remove();
    const wrap = doc.createElement("div");
    wrap.id = "auroebay-follow-seller";
    wrap.style.cssText = "display:flex;align-items:center;gap:10px;margin:10px 0;font:13px/1.4 -apple-system,system-ui,sans-serif";
    const button = doc.createElement("button");
    button.type = "button";
    button.style.cssText = brandButtonStyle("primary", "0");
    brandButtonHover(button);
    const label4 = doc.createElement("span");
    button.append(brandButtonIcon(doc, 18), label4);
    const note = doc.createElement("span");
    note.style.cssText = "opacity:.75";
    wrap.append(button, note);
    const show = (followed2) => {
      label4.textContent = followed2 ? "\u2713 Dans mes concurrents" : "\u2B50 Suivre ce vendeur";
      button.style.cssText = brandButtonStyle(followed2 ? "quiet" : "primary", "0");
      button.disabled = followed2;
      note.textContent = followed2 ? "Ses nouveaut\xE9s : Mes produits \u2192 \u{1F52D} Mes concurrents." : `Ajoute ${seller} \xE0 \xAB Mes concurrents \xBB pour rep\xE9rer ses nouvelles annonces qui d\xE9marrent bien.`;
    };
    void message({ type: "COMPETITOR_LIST" }).then((list) => show(list.some((c) => c.seller === seller))).catch(() => show(false));
    button.addEventListener("click", () => {
      if (!enabled2() || button.disabled) return;
      button.disabled = true;
      void message({ type: "COMPETITOR_ADD", seller }).then(() => show(true)).catch((e) => {
        button.disabled = false;
        note.textContent = `\u26A0 ${e instanceof Error ? e.message : String(e)}`;
      });
    });
    const place = () => {
      if (wrap.isConnected) return true;
      const name = doc.querySelector(".str-seller-card__store-name") ?? doc.querySelector(".str-header h1");
      if (name) {
        name.after(wrap);
        return true;
      }
      const results = doc.querySelector(".srp-controls, .srp-results, .srp-river-results");
      if (results) {
        results.before(wrap);
        return true;
      }
      return false;
    };
    let tries = 0;
    const timer = setInterval(() => {
      if (place() || ++tries > 20) clearInterval(timer);
    }, 500);
    place();
    return () => {
      clearInterval(timer);
      wrap.remove();
    };
  }

  // public/manifest.json
  var version = "0.99.5";

  // src/ebay/promotion.ts
  async function setGeneralPromotion(doc, url, identity, active2) {
    const valid = () => active2() && pageType(url()) === "draft" && draftIdentity(url()) === identity;
    if (!valid()) throw Error("Brouillon chang\xE9 ou extension en pause.");
    const switches = [
      ...doc.querySelectorAll(
        'input[role="switch"][aria-label="Toggle General"]'
      )
    ].filter((e) => !e.disabled);
    if (switches.length !== 1) throw Error("Option General absente ou ambigu\xEB.");
    const toggle = switches[0], wasOn = toggle.checked;
    let previous2;
    try {
      if (!wasOn) toggle.click();
      let inputs = [];
      for (let i = 0; i < 30; i++) {
        inputs = [
          ...doc.querySelectorAll(
            'input[name="adRate"][aria-label="Ad rate in percent"]'
          )
        ].filter((e) => !e.disabled);
        if (inputs.length === 1) break;
        if (!valid()) throw Error("Brouillon chang\xE9 ou extension en pause.");
        await delay(100);
      }
      if (!valid() || inputs.length !== 1)
        throw Error("Taux General indisponible.");
      const input = inputs[0];
      previous2 = input.value;
      writeTextControl(input, "6");
      await delay(350);
      const current2 = doc.querySelector(
        'input[name="adRate"][aria-label="Ad rate in percent"]'
      );
      const currentToggle = doc.querySelector(
        'input[role="switch"][aria-label="Toggle General"]'
      );
      if (!valid() || !currentToggle?.checked || Number(current2?.value.replace(",", ".")) !== 6)
        throw Error("eBay n\u2019a pas conserv\xE9 General \xE0 6 %.");
      return { enabled: true, rate: 6 };
    } catch (e) {
      if (draftIdentity(url()) === identity) {
        const currentToggle = doc.querySelector(
          'input[role="switch"][aria-label="Toggle General"]'
        );
        if (!wasOn && currentToggle?.checked) currentToggle.click();
        else if (wasOn && previous2 !== void 0) {
          const input = doc.querySelector(
            'input[name="adRate"]'
          );
          if (input && input.value === "6") writeTextControl(input, previous2);
        }
      }
      throw e;
    }
  }
  function writeTextControl(el2, value) {
    const win = el2.ownerDocument.defaultView;
    el2.focus();
    const key = value.at(-1) ?? "Backspace";
    const keyboard = {
      key,
      code: !value ? "Backspace" : /^\d$/.test(key) ? `Digit${key}` : "",
      keyCode: !value ? 8 : key.toUpperCase().charCodeAt(0) || 0,
      which: !value ? 8 : key.toUpperCase().charCodeAt(0) || 0,
      bubbles: true,
      composed: true
    };
    el2.dispatchEvent(new win.KeyboardEvent("keydown", keyboard));
    el2.dispatchEvent(
      new win.KeyboardEvent("keypress", {
        ...keyboard,
        charCode: !value ? 0 : key.charCodeAt(0) || 0
      })
    );
    el2.dispatchEvent(
      new win.InputEvent("beforeinput", {
        bubbles: true,
        composed: true,
        inputType: "insertText",
        data: value
      })
    );
    const proto = el2.tagName === "TEXTAREA" ? win.HTMLTextAreaElement.prototype : win.HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(proto, "value").set.call(el2, value);
    el2.dispatchEvent(
      new win.InputEvent("input", {
        bubbles: true,
        composed: true,
        inputType: "insertText",
        data: value
      })
    );
    el2.dispatchEvent(new win.KeyboardEvent("keyup", keyboard));
    el2.dispatchEvent(new win.Event("change", { bubbles: true }));
    el2.blur();
  }
  function promotionStatus(doc) {
    const general = [
      ...doc.querySelectorAll(
        'input[role="switch"][aria-label="Toggle General"]'
      )
    ];
    const rates = [
      ...doc.querySelectorAll(
        'input[name="adRate"][aria-label="Ad rate in percent"]'
      )
    ];
    return {
      generalControls: general.length,
      enabled: general.length === 1 ? general[0].checked : null,
      rateControls: rates.length,
      rate: rates.length === 1 ? rates[0].value : null
    };
  }

  // src/seller/parser.ts
  function sellerUsername(href) {
    try {
      const u = new URL(href, "https://www.ebay.com");
      if (!/(^|\.)ebay\.com$/.test(u.hostname)) return null;
      const name = u.pathname === "/fdbk/mweb_profile" ? u.searchParams.get("username") ?? "" : decodeURIComponent(
        u.pathname.match(/^\/usr\/([^/]+)\/?$/)?.[1] ?? ""
      );
      return /^[A-Za-z0-9_.-]{1,80}$/.test(name) ? name : null;
    } catch {
      return null;
    }
  }
  function unknownSeller(username, reason = "Seller account country not exposed") {
    return {
      username,
      country: null,
      status: "UNKNOWN",
      timestamp: Date.now(),
      source: "none",
      evidence: reason
    };
  }
  function parseProfileCountry(html, username, url) {
    if (sellerUsername(url)?.toLowerCase() !== username.toLowerCase())
      return unknownSeller(username, "Unexpected seller profile");
    html = html.replace(
      /<(script|style|noscript|template)\b[^>]*>[\s\S]*?<\/\1>/gi,
      ""
    );
    if (/captcha|pardon our interruption|verify you are human|robot check/i.test(
      html
    ))
      return unknownSeller(
        username,
        "Profile unavailable or protection encountered"
      );
    const fragments = [];
    const explicit = /<[^>]+(?:data-testid=["'](?:profile-location|seller-country)["']|class=["'][^"']*(?:str-seller-card__location|ux-about-info__location)[^"']*["'])[^>]*>([\s\S]{0,600}?)<\/(?:div|span|p)>/gi;
    for (const m of html.matchAll(explicit)) fragments.push(m[1]);
    const about = html.match(
      /<(?:section|div)[^>]*(?:class=["'][^"']*(?:ux-about|member_info|about-info)[^"']*["']|data-testid=["']seller-about["'])[^>]*>([\s\S]{0,5000}?)<\/(?:section|div)>/i
    )?.[1] ?? "";
    for (const m of about.matchAll(
      />\s*(?:Location|Country|Based in)\s*:\s*(?:<\/[^>]+>\s*)?(?:<[^>]+>\s*){0,3}([^<>\n]{2,70})/gi
    ))
      fragments.push(m[1]);
    const clean = fragments.map(
      (x) => compact(x.replace(/<[^>]*>/g, " ").replace(/&nbsp;|&#160;/g, " ")).replace(
        /^(?:Location|Country|Based in)\s*:?\s*/i,
        ""
      )
    );
    const valid = clean.map((v) => ({ value: normalizeCountry(v), evidence: v })).filter((v) => v.value);
    const countries = [...new Set(valid.map((v) => v.value))];
    if (countries.length !== 1)
      return unknownSeller(
        username,
        countries.length > 1 ? "Conflicting profile countries" : "Profile account country not found"
      );
    return {
      username,
      country: countries[0],
      status: countries[0] === "United States" ? "US" : "NON_US",
      timestamp: Date.now(),
      source: url,
      evidence: `Seller profile location: ${valid[0].evidence}`
    };
  }
  function sellerDocument(html) {
    const doc = new DOMParser().parseFromString(html, "text/html");
    doc.querySelectorAll("script,style,noscript,template").forEach((e) => e.remove());
    return doc;
  }
  function protectionPage(doc) {
    return /captcha|pardon our interruption|verify you are human|robot check/i.test(
      [
        doc.title,
        ...[...doc.querySelectorAll("h1,h2,[role=alert]")].map(
          (e) => e.textContent
        )
      ].join(" ")
    );
  }
  function parseStoreCountry(html, username, url) {
    const unknown = (reason) => unknownSeller(username ?? "", reason);
    let u;
    try {
      u = new URL(url);
    } catch {
      return unknown("Invalid store source");
    }
    if (u.protocol !== "https:" || !/(^|\.)ebay\.com$/.test(u.hostname) || !/^\/str\/[a-zA-Z0-9_.-]+\/?$/.test(u.pathname) || u.searchParams.get("_tab") !== "about")
      return unknown("Invalid store source");
    const doc = sellerDocument(html);
    if (protectionPage(doc))
      return unknown("Store unavailable or protection encountered");
    const found = [];
    for (const section of doc.querySelectorAll(
      ".str-about-description__seller-info"
    )) {
      const pairs = /* @__PURE__ */ new Map();
      for (const label4 of section.querySelectorAll(".str-text-span.SECONDARY")) {
        const key = compact(label4.textContent ?? "").replace(/[:：]$/, "").trim().toLowerCase();
        const value = compact(label4.nextElementSibling?.textContent ?? "");
        pairs.set(key, [...pairs.get(key) ?? [], value]);
      }
      const accounts = [...new Set(pairs.get("seller") ?? [])];
      if (accounts.length !== 1 || !/^[a-zA-Z0-9_.-]{1,80}$/.test(accounts[0]))
        continue;
      const account = accounts[0].toLowerCase();
      if (username && account !== username.toLowerCase())
        return unknown("Store belongs to another seller account");
      const locations = pairs.get("location") ?? [];
      for (const value of locations) {
        const country = normalizeCountry(value);
        if (country)
          found.push({
            username: account,
            country,
            status: country === "United States" ? "US" : "NON_US",
            timestamp: Date.now(),
            source: u.href,
            evidence: `Store About account location: ${value}`
          });
      }
    }
    return found.length && new Set(found.map((x) => x.username + "|" + x.country)).size === 1 ? found[0] : unknown("Store account identity/location missing or ambiguous");
  }
  function parseFeedbackCountry(html, username, url) {
    let u;
    try {
      u = new URL(url);
    } catch {
      return unknownSeller(username, "Invalid feedback profile source");
    }
    const owner = decodeURIComponent(
      u.pathname.match(/^\/fdbk\/feedback_profile\/([^/]+)\/?$/)?.[1] ?? ""
    );
    if (u.protocol !== "https:" || !/(^|\.)ebay\.com$/.test(u.hostname) || owner.toLowerCase() !== username.toLowerCase())
      return unknownSeller(username, "Unexpected feedback profile");
    html = html.replace(
      /<(script|style|noscript|template)\b[^>]*>[\s\S]*?<\/\1>/gi,
      ""
    );
    if (/captcha|pardon our interruption|verify you are human|robot check/i.test(
      html
    ))
      return unknownSeller(username, "eBay verification required");
    const found = [
      ...html.matchAll(
        /Member since:?\s*(?:<[^>]+>\s*)*[A-Za-z0-9 ,.-]{3,30}?\s+in\s+(?:<[^>]+>\s*)*([^<>]{2,60}?)\s*</gi
      )
    ].map((m) => ({
      evidence: compact(m[1].replace(/&nbsp;|&#160;/g, " ")),
      value: normalizeCountry(m[1])
    }));
    const countries = [...new Set(found.map((f) => f.value).filter(Boolean))];
    if (countries.length !== 1)
      return unknownSeller(
        username,
        countries.length > 1 ? "Conflicting profile countries" : "Registration country not found"
      );
    return {
      username,
      country: countries[0],
      status: countries[0] === "United States" ? "US" : "NON_US",
      timestamp: Date.now(),
      source: u.href,
      evidence: `Member since \u2026 in ${found.find((f) => f.value).evidence}`
    };
  }

  // src/seller/fetch.ts
  var active = /* @__PURE__ */ new Set();
  function cancelSellerRequests() {
    active.forEach((c) => c.abort());
  }
  async function fetchSeller(username, storePath) {
    if (location.protocol !== "https:" || !/(^|\.)ebay\.com$/.test(location.hostname))
      throw Error("Ce n\u2019est pas une page eBay.");
    if (username !== null && !/^[A-Za-z0-9_.-]{1,80}$/.test(username))
      throw Error("Nom de vendeur eBay invalide.");
    if (storePath !== null && !/^\/str\/[A-Za-z0-9_.-]+$/.test(storePath))
      throw Error("Adresse de boutique eBay invalide.");
    if (!username && !storePath) throw Error("Vendeur eBay introuvable sur la page.");
    const controller = new AbortController();
    active.add(controller);
    const timer = setTimeout(() => controller.abort(), 12e3);
    const unknown = (reason) => unknownSeller(username ?? "", reason);
    try {
      const read = async (url) => {
        const res = await fetch(url, {
          credentials: "same-origin",
          redirect: "follow",
          signal: controller.signal
        });
        const end = new URL(res.url || url);
        if (!res.ok) throw Error(`eBay HTTP ${res.status}`);
        if (end.origin !== location.origin || !/^\/(str|usr|fdbk\/feedback_profile)\/[A-Za-z0-9_.-]+\/?$/.test(
          end.pathname
        ))
          throw Error("Unexpected seller destination");
        const html = await res.text();
        if (html.length > 2e6) throw Error("Page du vendeur eBay trop volumineuse.");
        if (protectionPage(sellerDocument(html)))
          throw Error("eBay verification required; open the seller page");
        return { html, url: end };
      };
      if (username) {
        const profile = await read(
          new URL(`/fdbk/feedback_profile/${username}`, location.origin).href
        ).catch(() => null);
        if (profile) {
          const info = parseFeedbackCountry(
            profile.html,
            username,
            profile.url.href
          );
          if (info.status !== "UNKNOWN") return info;
        }
      }
      const start = new URL(
        storePath ? `${storePath}?_tab=about` : `/usr/${username}`,
        location.origin
      );
      let page = await read(start.href);
      if (storePath && page.url.pathname.replace(/\/$/, "") !== storePath)
        return unknown("Unexpected store redirect");
      if (page.url.pathname.startsWith("/str/")) {
        if (page.url.searchParams.get("_tab") !== "about") {
          page.url.searchParams.set("_tab", "about");
          page = await read(page.url.href);
        }
        if (page.url.searchParams.get("_tab") !== "about")
          return unknown("Store About not available");
        return parseStoreCountry(page.html, username, page.url.href);
      }
      return parseProfileCountry(page.html, username, page.url.href);
    } catch (e) {
      return unknown(
        controller.signal.aborted ? "Seller lookup cancelled or timed out" : e instanceof Error ? e.message : "Seller page unavailable"
      );
    } finally {
      clearTimeout(timer);
      active.delete(controller);
    }
  }

  // src/ebay/waitForDraft.ts
  async function waitForDraft(doc, url, s, timeout = 6e3) {
    if (pageType(url()) !== "draft")
      throw Error("Open an eBay US listing draft/editor.");
    const identity = draftIdentity(url());
    try {
      return extractDraft(doc, url(), s);
    } catch {
    }
    return new Promise((resolve, reject) => {
      let debounce2;
      let lastError = "Draft editor not available";
      const cleanup = () => {
        observer.disconnect();
        clearTimeout(timer);
        clearTimeout(debounce2);
      };
      const check = () => {
        if (draftIdentity(url()) !== identity) {
          cleanup();
          reject(Error("Navigation while waiting for draft"));
          return;
        }
        try {
          const result = extractDraft(doc, url(), s);
          cleanup();
          resolve(result);
        } catch (e) {
          lastError = e instanceof Error ? e.message : lastError;
        }
      };
      const observer = new MutationObserver(() => {
        clearTimeout(debounce2);
        debounce2 = setTimeout(check, 120);
      });
      const timer = setTimeout(() => {
        cleanup();
        reject(Error(`${lastError} (waited ${timeout / 1e3}s)`));
      }, timeout);
      observer.observe(doc.documentElement, {
        childList: true,
        subtree: true,
        attributes: true,
        attributeFilter: ["hidden", "aria-hidden", "class"]
      });
      check();
    });
  }

  // src/ebay/upc.ts
  var NO_UPC = "Does not apply";
  function resolveUPCs(doc) {
    return resolvePrices(doc).flatMap((r) => {
      const inputs = r.el.closest("tr")?.querySelectorAll('input[cn="upc"]');
      if (inputs?.length !== 1) return [];
      const input = inputs[0];
      if (input.disabled || input.readOnly || input.type === "hidden") return [];
      return [
        {
          el: input,
          field: {
            ...r.field,
            key: r.field.key.replace(/^price:/, "upc:"),
            value: input.value,
            selector: 'input[cn="upc"]'
          }
        }
      ];
    });
  }
  function chooseUPC(input, value) {
    if (value !== NO_UPC && value !== "") throw Error("Valeur UPC non autoris\xE9e");
    const widget = input.closest(".drp");
    const toggle = widget?.querySelector(".pull-down");
    const options = [
      ...widget?.querySelectorAll("a[val]") ?? []
    ].filter((a) => a.getAttribute("val") === value);
    if (!toggle || options.length !== 1)
      throw Error("Menu UPC eBay introuvable : aucune saisie forc\xE9e effectu\xE9e");
    clickMenuLink(toggle);
    clickMenuLink(options[0]);
  }
  function clickMenuLink(control) {
    const win = control.ownerDocument.defaultView;
    const event = new win.MouseEvent("click", {
      bubbles: true,
      cancelable: true,
      composed: true
    });
    event.preventDefault();
    control.dispatchEvent(event);
  }

  // src/core/itemOrigin.ts
  var ITEM_ORIGIN = "China";
  function isItemOriginField(field) {
    return manufactureLabel(field.label);
  }
  function supportsItemOrigin(field) {
    return field.writable && (field.kind !== "select" && !field.options?.length || !!field.options?.some(
      (option) => normalizeCountry(option.label) === ITEM_ORIGIN || normalizeCountry(option.value) === ITEM_ORIGIN
    ));
  }
  function itemOriginChanges(fields) {
    return fields.filter(isItemOriginField).filter(supportsItemOrigin).map((field) => ({
      key: field.key,
      before: field.value,
      after: ITEM_ORIGIN
    }));
  }

  // src/core/nativeImport.ts
  function freshNativeJob(job, now = Date.now()) {
    return job?.schemaVersion === 1 && Number.isFinite(job.createdAt) && job.createdAt <= now + 3e4 && now - job.createdAt < 36e5;
  }

  // src/ebay/nativeGuard.ts
  function normalizedNativeTitle(value) {
    return compact(
      value.normalize("NFKC").replace(/[‘’‚‛]/g, "'").replace(/[“”„‟]/g, '"').replace(/[‐‑‒–—]/g, "-")
    );
  }
  function titleFailure(expected, received, phase, reason) {
    const a = redact(expected).slice(0, 100), b = redact(received).slice(0, 100);
    throw Error(
      `${reason} [Titre ${phase} : attendu ${JSON.stringify(a)} (${expected.length}), re\xE7u ${JSON.stringify(b)} (${received.length}).]`
    );
  }
  function observeNativeTitleEdits(doc, settings) {
    let edited = false;
    const onEdit = (event) => {
      if (!event.isTrusted || !(event.target instanceof Element)) return;
      if (resolveFields(doc, settings).title?.el === event.target) edited = true;
    };
    for (const name of ["beforeinput", "input", "change"])
      doc.addEventListener(name, onEdit, true);
    return {
      edited: () => edited,
      stop: () => {
        for (const name of ["beforeinput", "input", "change"])
          doc.removeEventListener(name, onEdit, true);
      }
    };
  }
  function copiedVariationTitle(doc, fields, job, observed) {
    const input = fields.title.el;
    if (input.tagName !== "INPUT" || !validTitle(observed) || input.defaultValue !== observed || input.getAttribute("value") !== observed)
      return false;
    const expected = normalizedNativeTitle(job.ebaySeed.title), current2 = normalizedNativeTitle(observed);
    const options = job.product.axes.flatMap(
      (axis) => axis.values.flatMap((value) => [
        value,
        `${axis.name}: ${value}`,
        `${axis.name} ${value}`
      ])
    );
    for (const row of job.supplierPlan?.rows ?? []) {
      if (row.values.length > 1)
        options.push(row.values.join(", "), row.values.join(" / "));
    }
    return options.some((value) => {
      const suffix = normalizedNativeTitle(value);
      const candidates = [
        `${expected} (${suffix})`,
        `${expected} - ${suffix}`,
        `${expected}: ${suffix}`
      ];
      return candidates.some(
        (candidate) => candidate === current2 || candidate.length > 80 && candidate.slice(0, 80) === current2
      );
    });
  }
  function emptyDescription(doc, html) {
    const t = doc.createElement("template");
    t.innerHTML = html;
    return !t.content.textContent?.trim() && [...t.content.querySelectorAll("*")].every(
      (el2) => ["P", "BR", "DIV"].includes(el2.tagName) && el2.attributes.length === 0
    );
  }
  function photoCount(doc) {
    const counter = queryAll(doc, SELECTORS.photoCounter)[0];
    const match = counter?.textContent?.trim().match(/^(\d+)\s*\/\s*\d+$/);
    if (match) return Number(match[1]);
    const fixture = doc.querySelector('[data-testid="uploaded-photos"]');
    return fixture ? fixture.querySelectorAll('[data-testid="uploaded-photo"] img').length : null;
  }
  function confirmedPhotoCount(doc) {
    return queryAll(doc, SELECTORS.uploadedPhotos).length;
  }
  function nativeDraftEntryIdentity(url, job) {
    const u = new URL(url);
    const clone = !!job.ebaySeed;
    if (!freshNativeJob(job) || clone && !validEbaySeed(job.ebaySeed) || u.origin !== "https://www.ebay.com" || u.pathname !== "/lstng" || u.searchParams.get("mode") !== (clone ? job.supplierPlan ? "SellLikeItem" : "SellSimilarItem" : "AddItem") || !(u.searchParams.get("draftId") || u.searchParams.get("draft_id")) || ["itemId", "itemid", "item_id", "listingId"].some(
      (key) => u.searchParams.has(key)
    ) || job.identity && draftIdentity(url) !== job.identity)
      throw Error(
        clone ? "Seul le nouveau brouillon cr\xE9\xE9 depuis cette fiche eBay peut \xEAtre rempli." : "Le nouveau brouillon li\xE9 \xE0 cet import est requis."
      );
    return draftIdentity(url);
  }
  function nativeDraftFields(doc, url, s, job) {
    if (job.ebaySeed)
      throw Error("Le nouveau brouillon li\xE9 \xE0 cet import est requis.");
    nativeDraftEntryIdentity(url, job);
    const fields = resolveFields(doc, s);
    if (!fields.title?.field.writable || !fields.description?.field.writable)
      throw Error("Titre ou description indisponible.");
    if (fields.title.field.value.trim() && fields.title.field.value !== job.title)
      throw Error("Titre d\xE9j\xE0 modifi\xE9 : import arr\xEAt\xE9 pour conserver ta saisie.");
    if (!emptyDescription(doc, fields.description.field.value))
      throw Error("Description d\xE9j\xE0 renseign\xE9e : aucune donn\xE9e \xE9cras\xE9e.");
    if (extractVariants(doc).some((v) => v.values.length))
      throw Error("Des variantes sont d\xE9j\xE0 pr\xE9sentes.");
    if (photoCount(doc) !== 0)
      throw Error("Galerie d\xE9j\xE0 renseign\xE9e ou compteur non reconnu.");
    const inputs = queryAll(doc, SELECTORS.photoInput).filter(
      (el2) => !el2.hasAttribute("disabled")
    );
    if (inputs.length !== 1)
      throw Error("Champ d\u2019envoi des photos absent ou ambigu.");
    return { ...fields, photoInput: inputs[0] };
  }
  function clonedDraftFields(doc, url, s, job, titleContext = {}) {
    const u = new URL(url), seed = job.ebaySeed;
    if (!seed)
      throw Error(
        "Seul le nouveau brouillon cr\xE9\xE9 depuis cette fiche eBay peut \xEAtre rempli."
      );
    nativeDraftEntryIdentity(url, job);
    const fields = resolveFields(doc, s);
    if (job.supplierPlan && (photoCount(doc) !== 0 || extractVariants(doc).some((v) => v.values.length)))
      throw Error(
        "Le brouillon contient d\xE9j\xE0 des photos ou variantes. Aucun contenu fournisseur \xE9cras\xE9."
      );
    if (!fields.title?.field.writable || !fields.description?.field.writable)
      throw Error("Titre ou \xE9diteur de description indisponible.");
    if (job.supplierPlan && !emptyDescription(doc, fields.description.field.value))
      throw Error(
        "Description du nouveau brouillon d\xE9j\xE0 renseign\xE9e : aucune donn\xE9e \xE9cras\xE9e."
      );
    const receivedTitle = fields.title.field.value;
    const phase = titleContext.baseline === void 0 ? "initial de la copie" : "avant application";
    if (titleContext.trustedEdit)
      titleFailure(
        titleContext.baseline ?? seed.title,
        receivedTitle,
        phase,
        "Titre du brouillon modifi\xE9 manuellement : import arr\xEAt\xE9 pour conserver ta saisie."
      );
    const expectedTitle = titleContext.baseline ?? seed.title;
    const sameTitle = normalizedNativeTitle(receivedTitle) === normalizedNativeTitle(expectedTitle);
    const initialVariation = !sameTitle && titleContext.baseline === void 0 && titleContext.allowInitialVariation && job.supplierPlan && job.stage === "category" && !job.identity && Date.now() - job.createdAt <= 6e4 && !!receivedTitle.trim() && copiedVariationTitle(doc, fields, job, receivedTitle);
    if ((receivedTitle || titleContext.baseline !== void 0) && !sameTitle && !initialVariation)
      titleFailure(
        expectedTitle,
        receivedTitle,
        phase,
        "Titre du brouillon modifi\xE9 : import arr\xEAt\xE9 pour conserver ta saisie."
      );
    const category = seed.category.split(" > ").at(-1);
    if (!category && seed.categoryFromCopy) {
      const categories = [
        ...doc.querySelectorAll('button[name="categoryId"]')
      ].filter((b) => !b.disabled && !!b.textContent?.trim());
      if (categories.length !== 1 || !sameTitle && !initialVariation || u.searchParams.get("mode") !== "SellLikeItem")
        throw Error(
          "Cat\xE9gorie eBay copi\xE9e non confirm\xE9e. V\xE9rifie le nouveau brouillon."
        );
    } else if (![
      ...doc.querySelectorAll('button[data-testid="draft-category"],button')
    ].some((b) => norm(b.textContent ?? "").includes(norm(category))))
      throw Error(
        "Cat\xE9gorie eBay copi\xE9e non confirm\xE9e. V\xE9rifie le nouveau brouillon."
      );
    for (const specific of fields.specifics) {
      const expected = seed.specifics.find(
        (x) => norm(x.label) === norm(specific.field.label)
      );
      if (expected && specific.field.value && norm(expected.value) !== norm(specific.field.value))
        throw Error(
          `${expected.label} ne correspond plus \xE0 la fiche de d\xE9part. Import arr\xEAt\xE9.`
        );
    }
    if (!job.supplierPlan && seed.hasVariations && !extractVariants(doc).some((v) => v.values.length))
      throw Error(
        "Les variantes eBay n\u2019ont pas \xE9t\xE9 reprises. V\xE9rifie le brouillon avant de continuer."
      );
    return fields;
  }

  // src/ebay/apply.ts
  function findAll(doc, s) {
    const f = resolveFields(doc, s);
    return [
      f.title,
      f.description,
      f.condition,
      ...f.specifics,
      ...resolvePrices(doc),
      resolveSimplePrice(doc),
      resolveSimpleQuantity(doc),
      ...resolveQuantities(doc),
      ...resolveUPCs(doc)
    ].filter((x) => !!x);
  }
  async function setNative(el2, value, key = "", design = false, selection, valid = () => true) {
    if (key === ITEM_CONDITION_KEY)
      return chooseCondition(el2.ownerDocument, value, valid);
    if (key.startsWith("upc:")) {
      chooseUPC(el2, value);
      return;
    }
    if (isNativeMenuControl(el2)) {
      return chooseMenu(el2, value, selection);
    }
    if (key === "title" || key.startsWith("price:") || key.startsWith("quantity:")) {
      writeTextControl(el2, value);
      return;
    }
    const win = el2.ownerDocument.defaultView;
    if (key === "description" && !("value" in el2)) el2.focus();
    if ("value" in el2) {
      const proto = el2.tagName === "SELECT" ? win.HTMLSelectElement.prototype : el2.tagName === "TEXTAREA" ? win.HTMLTextAreaElement.prototype : win.HTMLInputElement.prototype;
      const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
      if (!setter) throw Error("Native value setter unavailable");
      setter.call(el2, value);
    } else if (key === "description" && design) replaceDesign(el2, value);
    else if (key === "description") replaceDescriptionText(el2, value);
    else el2.innerHTML = value;
    el2.dispatchEvent(
      new win.InputEvent("input", {
        bubbles: true,
        composed: true,
        inputType: "insertText"
      })
    );
    if (key === "description" && !("value" in el2))
      el2.dispatchEvent(
        new win.KeyboardEvent("keyup", {
          key: "End",
          code: "End",
          keyCode: 35,
          which: 35,
          bubbles: true,
          composed: true
        })
      );
    el2.dispatchEvent(new win.Event("change", { bubbles: true, composed: true }));
    el2.dispatchEvent(new win.FocusEvent("blur", { bubbles: true }));
    if (key === "description" && !("value" in el2)) el2.blur();
  }
  var FormTransactions = class {
    history = [];
    busy = false;
    get depth() {
      return this.history.length;
    }
    clear() {
      if (!this.busy) this.history = [];
    }
    mergeOriginRepair(identity, baseline = {}) {
      const repair = this.history.at(-1), previous2 = this.history.at(-2);
      if (this.busy || !repair || !previous2 || repair.identity !== identity || previous2.identity !== identity || !repair.fields.every(
        (field) => field.key.startsWith("specific:country") || field.key === ITEM_CONDITION_KEY
      ))
        return;
      for (const field of repair.fields) {
        const original = previous2.fields.find((saved) => saved.key === field.key);
        if (original) original.after = field.after;
        else
          previous2.fields.push({
            ...field,
            before: baseline[field.key] ?? field.before
          });
      }
      this.history.pop();
    }
    commitVariationAxes(identity) {
      for (const tx of this.history)
        if (tx.identity === identity)
          tx.fields = tx.fields.filter((f) => !f.promotedAxis);
      this.history = this.history.filter((tx) => tx.fields.length);
    }
    async apply(doc, url, settings, request, isEnabled = () => settings.enabled, initialDescription) {
      if (!isEnabled()) throw Error("AurOEBay is paused.");
      if (this.busy) throw Error("Another edit is in progress");
      if (pageType(url()) !== "draft" || draftIdentity(url()) !== request.identity)
        throw Error("Draft changed. Analyze again.");
      if (!request.changes.length || request.changes.length > (request.changes.every((c) => c.key.startsWith("upc:")) ? 300 : 600))
        throw Error("No valid changes selected");
      if (new Set(request.changes.map((c) => c.key)).size !== request.changes.length)
        throw Error("Duplicate fields");
      this.busy = true;
      const tx = { identity: request.identity, fields: [] };
      const skipped = [];
      const manualReview = [];
      const listingContent = request.changes.some(
        (c) => /^(title|description|specific:|condition$)/.test(c.key)
      );
      try {
        const preparedCondition = listingContent ? await prepareCondition(
          doc,
          () => isEnabled() && draftIdentity(url()) === request.identity
        ) : null;
        const resolved = findAll(doc, settings);
        if (preparedCondition) {
          const index = resolved.findIndex(
            (r) => r.field.key === ITEM_CONDITION_KEY
          );
          if (index >= 0) resolved[index] = preparedCondition;
          else resolved.push(preparedCondition);
        }
        if (listingContent) {
          const fields = resolved.map((r) => r.field);
          const origins = new Set(
            fields.filter(isItemOriginField).map((f) => f.key)
          );
          request = {
            ...request,
            changes: [
              ...request.changes.filter(
                (c) => !origins.has(c.key) && c.key !== ITEM_CONDITION_KEY
              ),
              ...itemOriginChanges(fields),
              ...itemConditionChanges(preparedCondition?.field)
            ]
          };
          for (const field of fields.filter(isItemOriginField))
            if (!supportsItemOrigin(field))
              manualReview.push(
                `${field.label} : s\xE9lectionne ${ITEM_ORIGIN} dans eBay, ce champ n\u2019est pas modifiable automatiquement.`
              );
        }
        const plan = request.changes.map((c) => {
          const matches = resolved.filter((r2) => r2.field.key === c.key);
          if (matches.length !== 1)
            throw Error(`${c.key}: missing or ambiguous field`);
          const r = matches[0];
          if (!r.field.writable || r.field.value !== c.before)
            throw Error(
              `${r.field.label}: modified since preview or not writable. Analyze again.`
            );
          const promotedAxis = c.after === "" && c.key.startsWith("specific:") && typeof initialDescription === "object" && initialDescription.mode === "SellLikeItem" && initialDescription.identity === request.identity && new URL(url()).searchParams.get("mode") === "SellLikeItem" && request.changes.some(
            (x) => x.key === "description" && x.before === initialDescription.before && x.after === initialDescription.html
          ) && initialDescription.variationAxes?.some(
            (axis) => c.key === `specific:${matchLabel(axis)}`
          );
          if (typeof c.after !== "string" || !c.after.trim() && !promotedAxis || c.after.length > (c.key === "description" ? 5e5 : 3e4))
            throw Error("Invalid value");
          if (c.key === "title" && !validTitle(c.after, settings.maxTitle))
            throw Error("Invalid title (>80 characters, empty or multiline)");
          let after = c.after;
          if (c.key.startsWith("upc:") && (c.before !== "" || after !== NO_UPC))
            throw Error("Seuls les UPC vides peuvent recevoir Does not apply");
          if (c.key.startsWith("quantity:") && after !== "0" && !(c.key === "quantity:simple" && after === "3" && initialDescription !== void 0 && request.changes.some((x) => x.key === "description")))
            throw Error("Seule la quantit\xE9 z\xE9ro est autoris\xE9e pour une rupture");
          if (c.key === "description") {
            if (initialDescription !== void 0) {
              const u = new URL(url());
              if (!u.searchParams.get("draftId") && !u.searchParams.get("draft_id") || u.searchParams.get("mode") !== (typeof initialDescription === "string" ? "AddItem" : initialDescription.mode ?? "SellSimilarItem") || typeof initialDescription !== "string" && initialDescription.mode === "SellLikeItem" && !emptyDescription(doc, c.before) || ["itemId", "itemid", "item_id", "listingId"].some(
                (key) => u.searchParams.has(key)
              ) || (typeof initialDescription === "string" ? !emptyDescription(doc, c.before) || c.after !== initialDescription : initialDescription.identity !== request.identity || initialDescription.before !== c.before || initialDescription.html !== c.after))
                throw Error(
                  "Initialisation r\xE9serv\xE9e au nouveau brouillon li\xE9 \xE0 cet import."
                );
            } else if (c.design) {
              if (typeof c.design.title !== "string" || c.design.title.length > 80 || !Array.isArray(c.design.edits))
                throw Error("Invalid description design");
              const edited = editedDescription(c.before, c.design.edits);
              validateDescriptionChange(c.before, edited);
              if (designDescription(edited, c.design.title).html !== c.after)
                throw Error("Description design mismatch");
            } else validateDescriptionChange(c.before, c.after);
          }
          if (c.key.startsWith("price:") && (!/^\d+(?:\.\d{1,2})?$/.test(after) || Number(after) <= 0 || Number(after) > 1e6))
            throw Error("Prix invalide");
          if (r.field.kind === "select" && promotedAxis) {
            const empty = [...r.el.options].filter(
              (o) => o.value === "" && !o.disabled
            );
            if (empty.length !== 1)
              throw Error(`${r.field.label}: cannot clear fixed variation value`);
          } else if (r.field.kind === "select") {
            const option = r.field.options?.find(
              (o) => norm(o.label) === norm(after) || norm(o.value) === norm(after) || isItemOriginField(r.field) && after === ITEM_ORIGIN && (normalizeCountry(o.label) === ITEM_ORIGIN || normalizeCountry(o.value) === ITEM_ORIGIN)
            );
            if (!option) throw Error(`${r.field.label}: option does not exist`);
            after = option.value;
          }
          if (c.key === ITEM_CONDITION_KEY) {
            const option = preferredItemCondition(r.field);
            if (!option || after !== option.value && norm(after) !== norm(option.label))
              throw Error("Item condition : choix natif New non reconnu.");
          }
          if (r.el.tagName === "INPUT" && r.el.type === "number") {
            const input = r.el;
            const n = Number(after);
            if (!/^-?\d+(?:\.\d+)?$/.test(after) || !Number.isFinite(n) || input.min !== "" && n < Number(input.min) || input.max !== "" && n > Number(input.max))
              throw Error(`${r.field.label}: invalid numeric value`);
            const step = input.step === "any" ? null : Number(input.step || 1);
            const base = Number(input.min || 0);
            if (step && Math.abs((n - base) / step - Math.round((n - base) / step)) > 1e-8)
              throw Error(`${r.field.label}: invalid numeric step`);
          }
          if (r.field.maxLength && after.length > r.field.maxLength)
            throw Error(`${r.field.label}: exceeds field length`);
          return {
            r,
            after,
            before: rawValue(r.el),
            promotedAxis: !!promotedAxis,
            design: !!c.design || c.key === "description" && initialDescription !== void 0
          };
        });
        for (const { r, after, before, design, promotedAxis } of plan) {
          if (!isEnabled()) throw Error("AurOEBay was paused during application");
          if (draftIdentity(url()) !== tx.identity)
            throw Error("Navigation during application");
          const current2 = findAll(doc, settings).find(
            (x) => x.field.key === r.field.key
          );
          if (!current2 || !current2.field.writable || rawValue(current2.el) !== before)
            throw Error(`${r.field.label}: changed during application`);
          if (before === after) {
            skipped.push(r.field.key);
            continue;
          }
          const saved = {
            key: r.field.key,
            before,
            after,
            kind: r.field.kind,
            design,
            promotedAxis
          };
          tx.fields.push(saved);
          const changed = await setNative(
            current2.el,
            after,
            r.field.key,
            design,
            void 0,
            () => isEnabled() && draftIdentity(url()) === request.identity
          );
          if (changed && typeof changed === "object")
            saved.menuSelection = changed.menuSelection;
          if (changed === false) {
            tx.fields.pop();
            skipped.push(r.field.key);
            manualReview.push(
              `${r.field.label} : \xAB ${after} \xBB non s\xE9lectionnable dans eBay. Valeur actuelle conserv\xE9e ; choisis ce champ manuellement.`
            );
            continue;
          }
          await delay(140);
          const fresh = findAll(doc, settings).find(
            (x) => x.field.key === r.field.key
          );
          if (!fresh || rawValue(fresh.el) !== after)
            throw Error(`${r.field.label}: eBay did not retain the value`);
        }
        await delay(200);
        if (!isEnabled()) throw Error("AurOEBay was paused during application");
        for (const f of tx.fields) {
          const r = findAll(doc, settings).find((r2) => r2.field.key === f.key);
          if (!r || rawValue(r.el) !== f.after)
            throw Error(`${f.key}: delayed form update rejected`);
        }
        if (tx.fields.length) this.history.push(tx);
        this.history = this.history.slice(-10);
        return {
          applied: tx.fields.map((f) => f.key),
          skipped,
          undoDepth: this.depth,
          ...manualReview.length ? { manualReview } : {},
          ...listingContent ? {
            conditionStatus: itemConditionStatus(
              findAll(doc, settings).find(
                (r) => r.field.key === ITEM_CONDITION_KEY
              )?.field
            ) + conditionInspectionNote(doc)
          } : {}
        };
      } catch (e) {
        const unresolved = [];
        for (const f of [...tx.fields].reverse()) {
          try {
            if (draftIdentity(url()) !== tx.identity) throw Error("Navigation");
            const r = findAll(doc, settings).find((x) => x.field.key === f.key);
            if (!r) throw Error("Missing");
            if (rawValue(r.el) === f.before) continue;
            if (rawValue(r.el) !== f.after) throw Error("Concurrent edit");
            await setNative(
              r.el,
              f.before,
              f.key,
              f.design,
              f.menuSelection,
              () => draftIdentity(url()) === tx.identity
            );
            await delay(100);
            const fresh = findAll(doc, settings).find(
              (x) => x.field.key === f.key
            );
            if (!fresh || rawValue(fresh.el) !== f.before)
              throw Error("Rollback rejected");
          } catch {
            unresolved.push(f);
          }
        }
        if (unresolved.length) this.history.push({ ...tx, fields: unresolved });
        throw Error(
          `${e instanceof Error ? e.message : "Apply failed"}. ${unresolved.length ? "Some fields could not be restored; use Undo and review manually." : "Changes rolled back."}`
        );
      } finally {
        this.busy = false;
      }
    }
    async undo(doc, url, s) {
      if (this.busy) throw Error("Another edit is in progress");
      const tx = this.history.at(-1);
      if (!tx) throw Error("Nothing to undo in this page session.");
      if (draftIdentity(url()) !== tx.identity)
        throw Error("Undo belongs to another draft.");
      this.busy = true;
      const applied = [];
      const skipped = [];
      try {
        for (const saved of [...tx.fields].reverse()) {
          const r = findAll(doc, s).find((x) => x.field.key === saved.key);
          if (!r || !r.field.writable || r.field.kind !== saved.kind || rawValue(r.el) !== saved.after) {
            skipped.push(`${saved.key}: changed manually or control unavailable`);
            continue;
          }
          try {
            await setNative(
              r.el,
              saved.before,
              saved.key,
              saved.design,
              saved.menuSelection,
              () => draftIdentity(url()) === tx.identity
            );
            await delay(150);
            const fresh = findAll(doc, s).find((x) => x.field.key === saved.key);
            if (fresh && rawValue(fresh.el) === saved.before)
              applied.push(saved.key);
            else skipped.push(`${saved.key}: restoration not retained`);
          } catch (e) {
            skipped.push(
              `${saved.key}: ${e instanceof Error ? e.message : "restoration unavailable"}`
            );
          }
        }
        tx.fields = tx.fields.filter((f) => !applied.includes(f.key));
        if (!tx.fields.length) this.history.pop();
        return { applied, skipped, undoDepth: this.depth };
      } finally {
        this.busy = false;
      }
    }
  };
  function usableMenuControl(node) {
    if (node.hasAttribute("disabled") || node.getAttribute("aria-disabled") === "true" || node.closest('[hidden],[aria-hidden="true"]'))
      return false;
    const win = node.ownerDocument.defaultView;
    for (let current2 = node; current2; current2 = current2.parentElement) {
      const style = win?.getComputedStyle(current2);
      if (style?.display === "none" || style?.visibility === "hidden" || style?.visibility === "collapse")
        return false;
    }
    return true;
  }
  function optionLabel(node) {
    if (node.matches('input[type="checkbox"]')) {
      const input = node;
      return (input.getAttribute("aria-label") || input.labels?.[0]?.textContent || (input.value !== "on" ? input.value : "") || "").trim();
    }
    return (node.textContent || node.getAttribute("aria-label") || "").trim();
  }
  function nativeClearAction(menu) {
    const native = [
      ...menu.querySelectorAll(
        "button.se-filter-menu-button__clear"
      )
    ].filter(usableMenuControl);
    if (native.length === 1) return native[0];
    if (native.length > 1) throw Error("Action d\u2019effacement eBay ambigu\xEB.");
    const actions = [
      ...menu.querySelectorAll('button,[role="button"]')
    ].filter(
      (node) => usableMenuControl(node) && !node.closest(
        '[role="menuitemradio"],[role="menuitemcheckbox"],[role="option"],.se-toggle-group-menu__menu-container,.se-search-box'
      ) && !node.matches(
        '.toggle-button,[role="menuitemradio"],[role="menuitemcheckbox"],[role="option"]'
      ) && /^(clear|clear selection|effacer|effacer la sélection)$/i.test(
        (node.textContent ?? "").trim()
      )
    );
    if (actions.length > 1) throw Error("Action d\u2019effacement eBay ambigu\xEB.");
    return actions[0] ?? null;
  }
  function chipSelectionLabel(node) {
    const name = node.getAttribute("aria-label") ?? node.getAttribute("title") ?? "";
    const named = name.match(
      /^(?:remove|delete|retirer|supprimer)(?: selection)?[:\s]+(.+)$/i
    )?.[1];
    if (named) return named.trim();
    if (!/^(remove|delete|retirer|supprimer)$/i.test(name)) return null;
    const chip = node.closest(
      "[data-selected-value],[data-value],.chip,.filter-chip,.selected-value"
    );
    return chip ? (chip.getAttribute("data-selected-value") ?? chip.getAttribute("data-value") ?? chip.textContent ?? "").trim() || null : null;
  }
  function selectedMenuValues(menu) {
    const groups = /* @__PURE__ */ new Map();
    const selected2 = [
      ...menu.querySelectorAll(
        '[role="menuitemradio"][aria-checked="true"],[role="menuitemcheckbox"][aria-checked="true"],[role="option"][aria-selected="true"],button[aria-pressed="true"],input[type="checkbox"]:checked'
      )
    ].filter(usableMenuControl);
    for (const node of selected2) {
      if (node.matches('input[type="checkbox"]') && selected2.some((parent) => parent !== node && parent.contains(node)))
        continue;
      const label4 = optionLabel(node);
      if (!label4) continue;
      const key = norm(label4), group = groups.get(key) ?? { label: label4, nodes: [] };
      group.nodes.push(node);
      groups.set(key, group);
    }
    for (const node of [
      ...menu.querySelectorAll(
        'button[aria-label],button[title],[role="button"][aria-label]'
      )
    ].filter(usableMenuControl)) {
      const label4 = chipSelectionLabel(node);
      if (label4 && !groups.has(norm(label4)))
        groups.set(norm(label4), { label: label4, nodes: [] });
    }
    return [...groups.values()];
  }
  function removeChipControls(menu, label4) {
    return [
      ...menu.querySelectorAll(
        'button[aria-label],button[title],[role="button"][aria-label]'
      )
    ].filter((node) => {
      if (!usableMenuControl(node)) return false;
      const name = node.getAttribute("aria-label") ?? node.getAttribute("title") ?? "";
      const named = name.match(
        /^(?:remove|delete|clear|retirer|supprimer)(?: selection)?[:\s]+(.+)$/i
      )?.[1];
      if (named && norm(named) === norm(label4)) return true;
      if (!/^(remove|delete|retirer|supprimer)$/i.test(name)) return false;
      const chip = node.closest(
        "[data-selected-value],[data-value],.chip,.filter-chip,.selected-value"
      );
      return !!chip && norm(
        chip.getAttribute("data-selected-value") ?? chip.getAttribute("data-value") ?? chip.textContent ?? ""
      ) === norm(label4);
    });
  }
  function sameSelection(a, b) {
    return JSON.stringify(a.map(norm).sort()) === JSON.stringify(b.map(norm).sort());
  }
  function representsSelection(value, labels) {
    if (!labels.length) return readEmpty(value);
    return [labels.join(", "), labels.join("; "), labels.join(" ")].some(
      (v) => norm(v) === norm(value)
    );
  }
  function readEmpty(value) {
    return !value.trim();
  }
  function exactMenuOptions(menu, value, selector) {
    const candidates = [...menu.querySelectorAll(selector)].filter(
      (node) => usableMenuControl(node) && norm(optionLabel(node)) === norm(value)
    );
    const physical = candidates.filter(
      (node) => !candidates.some((parent) => parent !== node && parent.contains(node))
    );
    const all = physical.filter(
      (node) => !!node.closest('.options,[aria-label="All options"]') || !!node.querySelector('[name^="options-attributes"]')
    );
    return all.length ? all : physical;
  }
  async function restoreMenuValues(el2, menu, labels, value) {
    for (const label4 of labels) {
      const selected2 = selectedMenuValues(menu).map((s) => s.label);
      if (selected2.some((s) => norm(s) === norm(label4)) && representsSelection(readValue(el2), selected2))
        continue;
      const physical = exactMenuOptions(
        menu,
        label4,
        '[role="menuitemradio"],[role="menuitemcheckbox"],[role="option"],input[type="checkbox"],button[aria-pressed],.se-toggle-group-menu__menu-container button.toggle-button'
      );
      if (physical.length !== 1)
        throw Error("Choix eBay introuvable ou ambigu pendant la restauration.");
      physical[0].click();
      await delay(140);
    }
    if (!sameSelection(
      selectedMenuValues(menu).map((s) => s.label),
      labels
    ) || norm(readValue(el2)) !== norm(value))
      throw Error("eBay n\u2019a pas conserv\xE9 la restauration du menu.");
  }
  async function clearNativeSelection(el2, menu) {
    const before = readValue(el2), initial = selectedMenuValues(menu).map((s) => s.label);
    const clear = nativeClearAction(menu);
    if (clear) {
      clear.click();
      return { menuSelection: initial };
    }
    if (!initial.length || !representsSelection(before, initial))
      throw Error(
        "Impossible de vider automatiquement ce menu : efface la valeur dans eBay."
      );
    const removed = [];
    try {
      for (const label4 of initial) {
        const current2 = selectedMenuValues(menu);
        if (!sameSelection(
          current2.map((s) => s.label),
          initial.filter((v) => !removed.includes(v))
        ))
          throw Error("S\xE9lection eBay modifi\xE9e pendant son effacement.");
        const group = current2.find((s) => norm(s.label) === norm(label4));
        const toggles = group.nodes.filter(
          (node) => node.matches(
            '[role="menuitemcheckbox"],input[type="checkbox"],button[aria-pressed="true"]'
          ) || node.matches('[role="option"]') && !!node.closest('[aria-multiselectable="true"]')
        );
        const candidates = [...removeChipControls(menu, label4), ...toggles];
        let cleared = false;
        for (let attempt = 0; attempt < candidates.length; attempt++) {
          const freshGroup = selectedMenuValues(menu).find(
            (s) => norm(s.label) === norm(label4)
          );
          const freshToggles = (freshGroup?.nodes ?? []).filter(
            (node) => node.matches(
              '[role="menuitemcheckbox"],input[type="checkbox"],button[aria-pressed="true"]'
            ) || node.matches('[role="option"]') && !!node.closest('[aria-multiselectable="true"]')
          );
          const candidate = [...removeChipControls(menu, label4), ...freshToggles][attempt];
          if (!candidate) continue;
          if (!candidate.isConnected || !usableMenuControl(candidate)) continue;
          const previous2 = readValue(el2);
          candidate.click();
          await delay(140);
          const next = selectedMenuValues(menu).map((s) => s.label), remaining = initial.filter(
            (v) => !removed.includes(v) && norm(v) !== norm(label4)
          );
          if (sameSelection(next, remaining) && representsSelection(readValue(el2), remaining)) {
            removed.push(label4);
            cleared = true;
            break;
          }
          if (readValue(el2) !== previous2 || !sameSelection(
            next,
            current2.map((s) => s.label)
          ))
            throw Error("eBay n\u2019a pas confirm\xE9 l\u2019effacement de cette valeur.");
        }
        if (!cleared)
          throw Error(
            "Impossible de vider automatiquement ce menu : efface la valeur dans eBay."
          );
      }
      return { menuSelection: initial };
    } catch (error) {
      const current2 = selectedMenuValues(menu).map((s) => s.label);
      if (current2.every((value) => initial.some((v) => norm(v) === norm(value)))) {
        try {
          await restoreMenuValues(el2, menu, initial, before);
        } catch {
        }
      }
      throw error;
    }
  }
  async function chooseMenu(el2, value, selection) {
    const id = el2.getAttribute("aria-controls");
    if (!id) throw Error("Menu eBay non reconnu");
    const wasOpen = el2.getAttribute("aria-expanded") === "true";
    if (!wasOpen) el2.click();
    try {
      await delay(180);
      const menu = el2.ownerDocument.getElementById(id);
      if (!menu) throw Error("Menu eBay indisponible");
      if (!value) {
        return await clearNativeSelection(el2, menu);
      }
      if (selection && selection.length)
        return await restoreMenuValues(el2, menu, selection, value);
      const search = menu.querySelector(
        'input[type="text"],input[type="search"]'
      );
      if (search) {
        await setNative(search, value);
        await delay(300);
      }
      const matches = exactMenuOptions(
        menu,
        value,
        '[role="menuitemradio"],[role="menuitemcheckbox"],[role="option"],.se-toggle-group-menu__menu-container button.toggle-button'
      );
      if (matches.length !== 1) return false;
      if (matches[0].getAttribute("role") === "menuitemcheckbox") {
        const before = readValue(el2);
        const clear = [
          ...menu.querySelectorAll('button,[role="button"]')
        ].filter((o) => norm(o.textContent ?? "") === "clear");
        if (before && norm(before) !== norm(value)) {
          if (clear.length !== 1 || /[,;]/.test(before)) return false;
          clear[0].click();
          await delay(150);
          const fresh = [
            ...menu.querySelectorAll('[role="menuitemcheckbox"]')
          ].filter(
            (o) => norm(o.textContent ?? "") === norm(value) && o.getAttribute("aria-disabled") !== "true" && !o.closest('[hidden],[aria-hidden="true"]')
          );
          if (fresh.length !== 1)
            throw Error("Option eBay disparue apr\xE8s effacement du choix");
          fresh[0].click();
        } else if (norm(before) !== norm(value)) matches[0].click();
      } else matches[0].click();
      await delay(150);
      if (norm(readValue(el2)) !== norm(value))
        throw Error("eBay n\u2019a pas conserv\xE9 ce choix");
    } finally {
      if (!wasOpen && el2.isConnected && el2.getAttribute("aria-expanded") === "true")
        el2.click();
    }
  }

  // src/ebay/supplierVariations.ts
  function visible2(e) {
    if (e.closest("[hidden]")) return false;
    const win = e.ownerDocument.defaultView;
    for (let n = e; n; n = n.parentElement) {
      const style = win?.getComputedStyle(n);
      if (style?.display === "none" || style?.visibility === "hidden")
        return false;
    }
    return e.getBoundingClientRect().width > 0;
  }
  async function waitFor(read, valid, timeout = 15e3, step = "chargement de l\u2019\xE9diteur") {
    const until = Date.now() + timeout;
    while (Date.now() < until) {
      if (!valid()) throw Error("Import fournisseur interrompu.");
      const value = read();
      if (value) return value;
      await delay(150);
    }
    throw Error(
      `Variantes eBay : d\xE9lai d\xE9pass\xE9 pendant ${step}. Le brouillon reste ouvert pour v\xE9rification.`
    );
  }
  async function relay(body, valid) {
    const until = Date.now() + 15e3;
    while (Date.now() < until) {
      if (!valid()) throw Error("Import interrompu.");
      try {
        return await message(body);
      } catch (e) {
        if (!/not loaded/i.test(String(e)) && !(body.type === "NATIVE_VARIANTS" && /could not establish connection.*receiving end does not exist/i.test(
          String(e)
        )))
          throw e;
        await delay(300);
      }
    }
    throw Error("\xC9diteur de variantes non charg\xE9.");
  }
  async function prepareSupplierVariations(doc, job, valid, clearedAxes = []) {
    const buttons = [
      ...doc.querySelectorAll(
        'button[aria-label="Edit Variations"]'
      )
    ].filter(visible2);
    if (buttons.length !== 1)
      throw Error(
        "Cette cat\xE9gorie eBay ne propose pas de formulaire Variations. Choisis une cat\xE9gorie compatible avant l\u2019import."
      );
    const frameClosed = () => !doc.querySelector('iframe[title="Create/Edit variations"]');
    for (let attempt = 0; attempt < 2; attempt++) {
      if (!valid()) throw Error("Import interrompu.");
      const current2 = [
        ...doc.querySelectorAll(
          'button[aria-label="Edit Variations"]'
        )
      ].filter(visible2);
      if (current2.length !== 1)
        throw Error("Contr\xF4le Variations modifi\xE9 pendant la reprise.");
      current2[0].click();
      await waitFor(
        () => doc.querySelector(
          'iframe[title="Create/Edit variations"][src*="bulkedit.ebay.com/msku"]'
        ),
        valid
      );
      const response = await relay(
        {
          type: "NATIVE_VARIANTS",
          id: job.id,
          clearedAxes
        },
        valid
      );
      if (response && typeof response === "object" && "retryAxes" in response && Array.isArray(response.retryAxes) && response.retryAxes.length) {
        if (attempt || response.retryAxes.some((axis) => !clearedAxes.includes(axis)))
          throw Error("Enregistrement des caract\xE9ristiques eBay non confirm\xE9.");
        try {
          await relay(
            { type: "NATIVE_VARIANTS", id: job.id, action: "cancel-for-retry" },
            valid
          );
        } catch (e) {
          if (!frameClosed() && !/port.*closed|message channel.*closed|frame.*removed/i.test(
            String(e)
          ))
            throw e;
        }
        await waitFor(
          frameClosed,
          valid,
          15e3,
          "la fermeture de l\u2019\xE9diteur p\xE9rim\xE9"
        );
        await delay(750);
        continue;
      }
      if (!response || !("rows" in response) || response.rows !== job.supplierPlan?.rows.length)
        throw Error("\xC9diteur de variantes non charg\xE9.");
      await waitFor(frameClosed, valid, 3e4);
      return;
    }
  }

  // src/ebay/nativeImport.ts
  async function setupNativeImport(doc, url, s, tx, enabled2, lock = () => {
  }) {
    const titleEdits = observeNativeTitleEdits(doc, s);
    let job;
    try {
      job = await message({ type: "NATIVE_JOB" });
    } catch (error) {
      titleEdits.stop();
      throw error;
    }
    if (!job || job.transport === "api" || job.stage === "ready" || job.stage === "error" || !enabled2()) {
      titleEdits.stop();
      return () => {
      };
    }
    let active2 = true, busy = false;
    let conditionEntryIdentity;
    let conditionEntryValue;
    const guard = () => {
      if (!active2 || !enabled2())
        throw Error("Import interrompu : page chang\xE9e ou AurOEBay en pause.");
    };
    async function update(patch) {
      guard();
      job = await message({
        type: "NATIVE_UPDATE",
        id: job.id,
        patch
      });
    }
    async function run() {
      if (!active2 || !enabled2() || busy || !job || job.stage === "ready" || job.stage === "error")
        return;
      busy = true;
      try {
        if (!freshNativeJob(job)) {
          titleEdits.stop();
          observer.disconnect();
          clearInterval(poll);
          return;
        }
        const u = new URL(url());
        if (["/sh/lst/active", "/sh/lst/drafts"].includes(u.pathname) && job.stage === "category" && job.supplierPlan) {
          await message({ type: "NATIVE_COPY_RECOVER", id: job.id });
          return;
        }
        if (u.pathname === "/sh/lst/active" && job.stage === "opening") {
          const links = [
            ...doc.querySelectorAll(
              'a[href="https://www.ebay.com/sl/sell"],a[href="/sl/sell"]'
            )
          ].filter(
            (a) => a.textContent?.trim() === "Create listing" && a.getBoundingClientRect().width > 0
          );
          if (links.length === 1) {
            guard();
            links[0].click();
          }
          return;
        }
        const search = queryAll(doc, SELECTORS.nativeSearch).filter(
          (el2) => el2.getBoundingClientRect().width > 0
        );
        if (job.stage === "opening" && search.length === 1) {
          const buttons = [
            ...doc.querySelectorAll("button")
          ].filter(
            (b) => b.textContent?.trim() === "Search" && !b.disabled && b.getBoundingClientRect().width > 0
          );
          if (buttons.length !== 1) return;
          if (search[0].value && search[0].value !== job.title)
            throw Error(
              "Recherche d\xE9j\xE0 saisie : v\xE9rifie manuellement le parcours eBay."
            );
          await update({ stage: "category" });
          guard();
          writeTextControl(search[0], job.title);
          buttons[0].click();
          return;
        }
        if (u.pathname !== "/lstng") return;
        if (job.stage === "opening")
          throw Error(
            "Le parcours cat\xE9gorie doit \xEAtre valid\xE9 depuis la recherche pr\xE9par\xE9e."
          );
        if (job.stage === "filling")
          throw Error(
            "Import pr\xE9c\xE9dent interrompu. V\xE9rifie ce brouillon avant toute reprise manuelle."
          );
        const entryURL = url();
        const entryIdentity = nativeDraftEntryIdentity(entryURL, job);
        if (conditionEntryIdentity && conditionEntryIdentity !== entryIdentity)
          throw Error("Le brouillon a chang\xE9 pendant le choix de l\u2019\xE9tat.");
        conditionEntryIdentity = entryIdentity;
        if (job.stage === "category") {
          lock(true);
          const validEntry = () => {
            if (!active2 || !enabled2() || url() !== entryURL || !job)
              return false;
            try {
              return job.stage === "category" && nativeDraftEntryIdentity(url(), job) === entryIdentity;
            } catch {
              return false;
            }
          };
          const condition = await completeOpenConditionDialog(doc, validEntry);
          if (!validEntry())
            throw Error("Import interrompu pendant le choix de l\u2019\xE9tat.");
          if (condition.handled && !condition.confirmed)
            throw Error(
              condition.note ?? "\xC9tat eBay non confirm\xE9 : choisis New without tags ou New et valide Done."
            );
          if (condition.handled && condition.confirmed)
            conditionEntryValue = condition.value;
        }
        if (!resolveFields(doc, s).description) return;
        const clone = !!job.ebaySeed;
        const initialFields = clone ? clonedDraftFields(doc, url(), s, job, {
          allowInitialVariation: true,
          trustedEdit: titleEdits.edited()
        }) : nativeDraftFields(doc, url(), s, job);
        const initialTitle = initialFields.title.field.value;
        const initialCondition = initialFields.condition ? rawValue(initialFields.condition.el) : void 0;
        const originalDescription = initialFields.description.field.value;
        const inheritedPhotos = clone ? confirmedPhotoCount(doc) : 0;
        const inheritedMarkup = clone ? queryAll(doc, SELECTORS.uploadedPhotos).map((el2) => el2.outerHTML).join("") : "";
        const identity = draftIdentity(url());
        lock(true);
        await update({
          stage: "filling",
          identity,
          ...clone ? { retainedPhotos: inheritedPhotos } : {}
        });
        const files = [];
        let bytes = 0;
        for (const [i, source] of (inheritedPhotos ? [] : job.images).entries()) {
          guard();
          const photo = await message({ type: "NATIVE_IMAGE", id: job.id, url: source });
          guard();
          const binary = atob(photo.data);
          const data = Uint8Array.from(binary, (c) => c.charCodeAt(0));
          bytes += data.length;
          if (bytes > 32 * 1024 * 1024)
            throw Error("S\xE9lection trop volumineuse : maximum 32 Mo au total.");
          const file = new File(
            [data],
            `auro-${i + 1}.${photo.mime === "image/png" ? "png" : photo.mime === "image/webp" ? "webp" : "jpg"}`,
            { type: photo.mime }
          );
          const bitmap = await createImageBitmap(file);
          const small = bitmap.width < 200 || bitmap.height < 200;
          bitmap.close();
          if (small) throw Error("Photo trop petite : choisis une autre image.");
          files.push(file);
        }
        guard();
        const fields = clone ? clonedDraftFields(doc, url(), s, job, {
          baseline: initialTitle,
          trustedEdit: titleEdits.edited()
        }) : nativeDraftFields(doc, url(), s, job);
        if (fields.description.field.value !== originalDescription || clone && queryAll(doc, SELECTORS.uploadedPhotos).map((el2) => el2.outerHTML).join("") !== inheritedMarkup)
          throw Error(
            "Description ou galerie modifi\xE9e pendant la pr\xE9paration. Import arr\xEAt\xE9."
          );
        if (clone && !inheritedPhotos && !files.length)
          throw Error(
            "Aucune photo de galerie disponible : ajoute des photos dans eBay."
          );
        const simplePrice = job.supplierPlan ? job.supplierPlan.axes.length ? null : resolveSimplePrice(doc) : clone && !job.ebaySeed.hasVariations ? resolveSimplePrice(doc) : null;
        if (clone && !job.supplierPlan?.axes.length && (job.supplierPlan || job.ebaySeed.price && job.ebaySeed.currency === "USD") && !simplePrice)
          throw Error(
            "Champ de prix simple non reconnu : aucun remplacement de description effectu\xE9. V\xE9rifie le nouveau brouillon."
          );
        const simpleQuantity = job.supplierPlan?.axes.length || !job.supplierPlan && job.ebaySeed?.hasVariations ? null : resolveSimpleQuantity(doc);
        if (!job.supplierPlan?.axes.length && !(clone && !job.supplierPlan && job.ebaySeed.hasVariations) && !simpleQuantity)
          throw Error(
            "Champ de quantit\xE9 simple non reconnu : import arr\xEAt\xE9 avant modification."
          );
        const axisKeys = new Set(
          job.supplierPlan?.axes.map((a) => `specific:${matchLabel(a.name)}`) ?? []
        );
        const fixedAxes = fields.specifics.filter(
          (r) => axisKeys.has(r.field.key) && r.field.value.trim()
        );
        const contentResult = await tx.apply(
          doc,
          url,
          s,
          {
            identity,
            changes: [
              ...fixedAxes.map((r) => ({
                key: r.field.key,
                before: r.field.value,
                after: ""
              })),
              ...simpleQuantity ? [
                {
                  key: simpleQuantity.field.key,
                  before: simpleQuantity.field.value,
                  after: String(DEFAULT_IMPORT_QUANTITY)
                }
              ] : [],
              ...simplePrice && (job.supplierPlan || job.ebaySeed?.price && job.ebaySeed.currency === "USD") ? [
                {
                  key: simplePrice.field.key,
                  before: simplePrice.field.value,
                  after: job.supplierPlan?.rows[0].price ?? job.ebaySeed.price
                }
              ] : [],
              {
                key: "title",
                before: fields.title.field.value,
                after: job.title
              },
              {
                key: "description",
                before: fields.description.field.value,
                after: job.description
              }
            ]
          },
          () => active2 && enabled2(),
          clone ? {
            identity,
            before: originalDescription,
            html: job.description,
            mode: job.supplierPlan ? "SellLikeItem" : "SellSimilarItem",
            variationAxes: job.supplierPlan?.axes.map((a) => a.name)
          } : job.description
        );
        guard();
        if (draftIdentity(url()) !== identity || !inheritedPhotos && photoCount(doc) !== 0)
          throw Error("Brouillon ou galerie modifi\xE9s pendant l\u2019import.");
        if (!inheritedPhotos) {
          const transfer = new DataTransfer();
          files.forEach((f) => transfer.items.add(f));
          const input = nativeDraftFieldsAfterText(doc, s).photoInput;
          input.files = transfer.files;
          input.dispatchEvent(new Event("change", { bubbles: true }));
          await confirmPhotos(
            doc,
            files.length,
            () => active2 && enabled2() && draftIdentity(url()) === identity
          );
        } else if (queryAll(doc, SELECTORS.uploadedPhotos).map((el2) => el2.outerHTML).join("") !== inheritedMarkup)
          throw Error("Galerie h\xE9rit\xE9e modifi\xE9e. V\xE9rifie le brouillon.");
        guard();
        if (job.supplierPlan?.axes.length) {
          await prepareSupplierVariations(
            doc,
            job,
            () => active2 && enabled2() && draftIdentity(url()) === identity,
            fixedAxes.map((r) => r.field.label)
          );
          tx.commitVariationAxes(identity);
        }
        guard();
        let final = resolveFields(doc, s);
        final.condition = await prepareCondition(
          doc,
          () => active2 && enabled2() && draftIdentity(url()) === identity
        );
        const origins = final.specifics.map((r) => r.field).filter(isItemOriginField);
        const originChanges = itemOriginChanges(origins).filter(
          (change) => normalizeCountry(change.before) !== ITEM_ORIGIN
        );
        const conditionChanges = itemConditionChanges(
          final.condition?.field
        ).filter((change) => change.before !== change.after);
        if (originChanges.length || conditionChanges.length) {
          await tx.apply(
            doc,
            url,
            s,
            { identity, changes: [...originChanges, ...conditionChanges] },
            () => active2 && enabled2()
          );
          tx.mergeOriginRepair(
            identity,
            Object.fromEntries([
              ...initialFields.specifics.filter((r) => isItemOriginField(r.field)).map((r) => [
                r.field.key,
                r.field.kind === "select" ? r.field.options?.find(
                  (option) => option.label === r.field.value
                )?.value ?? r.field.value : r.field.value
              ]),
              ...initialCondition === void 0 ? [] : [[ITEM_CONDITION_KEY, initialCondition]]
            ])
          );
          guard();
          final = resolveFields(doc, s);
          final.condition = await prepareCondition(
            doc,
            () => active2 && enabled2() && draftIdentity(url()) === identity
          );
        }
        if (origins.some(
          (origin) => normalizeCountry(
            final.specifics.find((r) => r.field.key === origin.key)?.field.value ?? ""
          ) !== ITEM_ORIGIN
        ))
          throw Error(
            "Country of Origin : China n\u2019a pas \xE9t\xE9 conserv\xE9. S\xE9lectionne China dans eBay avant de terminer ce brouillon."
          );
        if (final.title?.field.value !== job.title || !final.description || rawValue(final.description.el) !== job.description)
          throw Error(
            "Le contenu n\u2019a pas \xE9t\xE9 conserv\xE9 par eBay. V\xE9rifie le brouillon."
          );
        const expectedCondition = preferredItemCondition(final.condition?.field);
        const expectedConditionLabel = expectedCondition?.label ?? conditionEntryValue;
        if ((contentResult.applied.includes(ITEM_CONDITION_KEY) || expectedConditionLabel) && (!expectedConditionLabel || !final.condition || !exactConditionLabel(
          final.condition.field.value,
          expectedConditionLabel
        )))
          throw Error(itemConditionStatus(final.condition?.field));
        await update({
          stage: "ready",
          identity,
          uploaded: inheritedPhotos || files.length,
          conditionStatus: (expectedConditionLabel ? `Item condition : ${expectedConditionLabel} confirm\xE9 dans eBay.` : itemConditionStatus(final.condition?.field)) + conditionInspectionNote(doc)
        });
        observer.disconnect();
        clearInterval(poll);
        titleEdits.stop();
      } catch (e) {
        if (active2 && enabled2() && job) {
          await update({
            stage: "error",
            error: `${e instanceof Error ? e.message : String(e)} Les photos d\xE9j\xE0 envoy\xE9es se retirent dans eBay ; Annuler les modifications restaure le texte tant que la page reste ouverte.`
          }).catch(() => {
          });
          observer.disconnect();
          clearInterval(poll);
          titleEdits.stop();
        }
      } finally {
        busy = false;
        lock(false);
      }
    }
    const changed = debounce(() => void run(), 400);
    const observer = new MutationObserver(changed);
    observer.observe(doc.body, { childList: true, subtree: true });
    const poll = setInterval(() => void run(), 1e3);
    void run();
    return () => {
      active2 = false;
      observer.disconnect();
      clearInterval(poll);
      titleEdits.stop();
      lock(false);
    };
  }
  function nativeDraftFieldsAfterText(doc, s) {
    const inputs = queryAll(doc, SELECTORS.photoInput).filter(
      (el2) => !el2.hasAttribute("disabled")
    );
    if (inputs.length !== 1) throw Error("Champ photo disparu.");
    return { photoInput: inputs[0] };
  }
  function confirmPhotos(doc, count, valid, timeout = 45e3) {
    return new Promise((resolve, reject) => {
      const finish = (error) => {
        clearTimeout(timer);
        clearInterval(poll);
        observer.disconnect();
        error ? reject(error) : resolve();
      };
      const check = () => {
        if (!valid())
          return finish(Error("Import interrompu pendant l\u2019envoi des photos."));
        if (photoCount(doc) === count && confirmedPhotoCount(doc) === count && !doc.querySelector(
          '.summary__photos [role="progressbar"],.summary__photos .uploader-thumbnail--uploading'
        ))
          finish();
      };
      const observer = new MutationObserver(check);
      observer.observe(doc.body, {
        childList: true,
        subtree: true,
        characterData: true,
        attributes: true
      });
      const timer = setTimeout(
        () => finish(
          Error(
            "Envoi des photos non confirm\xE9 par eBay. V\xE9rifie la galerie ; aucun second envoi automatique."
          )
        ),
        timeout
      );
      const poll = setInterval(check, 500);
      check();
    });
  }

  // src/ebay/content.ts
  quietStaleContext();
  setupClaudeBridge();
  if (window === window.top) void chrome.runtime.sendMessage({ type: "UPDATE_CHECK" }).catch(() => {
  });
  if (window === window.top)
    setTimeout(() => {
      const header = document.getElementById("gh");
      if (!header) return;
      const signedIn = !header.querySelector('a[href*="signin.ebay."]');
      try {
        void Promise.resolve(chrome.runtime.sendMessage({ type: "STATUS_NOTE", signedIn })).catch(() => {
        });
      } catch {
      }
    }, 1500);
  function initializeEbayContent(readOnly2) {
    const transactions = new FormTransactions();
    const checkTransactions = new FormTransactions();
    let identity = draftIdentity(location.href);
    let cleanupResults = () => {
    };
    let enabled2 = false;
    let stopped = false;
    let productBusy = false;
    let productAgain = false;
    let interval;
    async function refreshSeller() {
      if (!enabled2) return;
      if (productBusy) {
        productAgain = true;
        return;
      }
      productBusy = true;
      try {
        const s = await message({ type: "PUBLIC_SETTINGS" });
        if (enabled2 && s.enabled && pageType(location.href) === "product")
          await decorateProduct(s);
      } catch {
      } finally {
        productBusy = false;
        if (productAgain && enabled2) {
          productAgain = false;
          void refreshSeller();
        }
      }
    }
    const changed = debounce(() => {
      if (!enabled2) return;
      const next = draftIdentity(location.href);
      if (next !== identity) {
        identity = next;
        transactions.clear();
        checkTransactions.clear();
        void configure();
      } else if (pageType(location.href) === "product") void refreshSeller();
    }, 700);
    const observer = new MutationObserver((records) => {
      if (records.some(
        (r) => [...r.addedNodes, ...r.removedNodes].some(
          (n) => n.nodeType === 1 && !n.matches(
            "[data-auroebay-seller],[data-auroebay-retry]"
          )
        )
      ))
        changed();
    });
    let configuration = 0;
    let cleanupNative = () => {
    };
    let cleanupPush = () => {
    };
    let cleanupLibraryButton = () => {
    };
    let libraryLinks;
    let cleanupOrders = () => {
    };
    let cleanupPublish = () => {
    };
    let cleanupWinners = () => {
    };
    let nativeBusy = false;
    async function configure() {
      const revision = ++configuration;
      const s = await message({ type: "PUBLIC_SETTINGS" });
      if (stopped || revision !== configuration) return;
      enabled2 = s.enabled;
      setListingStore(s.storeName ?? "");
      setListingTheme(s.descriptionTemplate ?? "classic");
      if (readOnly2) return;
      cleanupNative();
      cleanupPush();
      cleanupLibraryButton();
      libraryLinks?.cleanup();
      cleanupOrders();
      cleanupOrders = () => {
      };
      cleanupPublish();
      cleanupPublish = () => {
      };
      cleanupWinners();
      cleanupWinners = () => {
      };
      nativeBusy = false;
      if (!s.enabled || !s.sellerEnabled) cancelSellerRequests();
      observer.disconnect();
      clearInterval(interval);
      cleanupResults();
      clearSellerUI();
      window.removeEventListener("popstate", changed);
      window.removeEventListener("hashchange", changed);
      if (!enabled2) return;
      cleanupPush = setupEbayPushButton(
        document,
        () => enabled2 && revision === configuration
      );
      cleanupLibraryButton = setupLibraryButton(
        document,
        () => enabled2 && revision === configuration,
        () => captureEbayLibrary(document, location.href, s)
      );
      libraryLinks = setupLibraryLinks(
        document,
        () => enabled2 && revision === configuration
      );
      cleanupOrders = setupOrders(
        document,
        () => enabled2 && revision === configuration
      );
      cleanupPublish = setupPublishLink(
        document,
        () => enabled2 && revision === configuration
      );
      cleanupWinners = setupWinners(
        document,
        () => enabled2 && revision === configuration
      );
      {
        const winners = cleanupWinners;
        const history2 = setupSalesHistory(document, () => enabled2 && revision === configuration);
        const productLink = setupProductLink(document, () => enabled2 && revision === configuration);
        const trackingPage = setupTrackingPage(document, () => enabled2 && revision === configuration);
        const follow = setupFollowSeller(document, () => enabled2 && revision === configuration);
        const returnPage = setupReturnPage(document, () => enabled2 && revision === configuration);
        cleanupWinners = () => {
          winners();
          returnPage();
          history2();
          productLink();
          trackingPage();
          follow();
        };
      }
      const nativeCleanup = await setupNativeImport(
        document,
        () => location.href,
        s,
        transactions,
        () => enabled2 && revision === configuration,
        (value) => {
          nativeBusy = value;
        }
      );
      if (revision !== configuration) {
        nativeCleanup();
        return;
      }
      cleanupNative = nativeCleanup;
      observer.observe(document.body, { childList: true, subtree: true });
      window.addEventListener("popstate", changed);
      window.addEventListener("hashchange", changed);
      interval = setInterval(() => {
        if (!extensionAlive()) return cleanup();
        if (draftIdentity(location.href) !== identity) changed();
      }, 1500);
      if (pageType(location.href) === "results") cleanupResults = setupResults(s);
      void refreshSeller();
    }
    const listener = (msg, sender, reply) => {
      if (msg?.type?.startsWith("PRICES_")) return;
      if (sender.id === chrome.runtime.id && !sender.tab && msg?.type === "SALES_REFRESH_ORDERS") {
        if (!/^\/mesh\/ord\//.test(location.pathname)) return;
        void refreshSavedOrders(Array.isArray(msg.orderIds) ? msg.orderIds : []).then((n) => reply({ ok: true, data: n })).catch((e) => reply({ ok: false, error: e instanceof Error ? e.message : String(e) }));
        return true;
      }
      if (msg?.type === "FIND_SUPPLIERS_PARTIAL") return;
      if (sender.id === chrome.runtime.id && msg?.type === "SELLER_FETCH" && !sender.tab) {
        void message({ type: "PUBLIC_SETTINGS" }).then((s) => {
          if (!s.enabled || !s.sellerEnabled)
            throw Error("Seller detector disabled");
          return fetchSeller(msg.username ?? null, msg.storePath ?? null);
        }).then((data) => reply({ ok: true, data })).catch((e) => reply({ ok: false, error: String(e) }));
        return true;
      }
      if (sender.id === chrome.runtime.id && msg?.type === "SETTINGS_CHANGED") {
        void configure().then(() => reply({ ok: true })).catch(() => reply({ ok: false }));
        return true;
      }
      if (sender.id === chrome.runtime.id && msg?.type === "LIBRARY_LINKS_CHANGED" && !sender.tab) {
        void (libraryLinks?.refresh() ?? Promise.resolve()).then(() => reply({ ok: true })).catch(() => reply({ ok: false }));
        return true;
      }
      if (sender.id !== chrome.runtime.id || !sender.url?.startsWith(chrome.runtime.getURL("")))
        return;
      const run = async () => {
        const settings = await message({
          type: "PUBLIC_SETTINGS"
        });
        if (!settings.enabled)
          throw Error("AurOEBay is paused. Turn it ON to continue.");
        if (nativeBusy && !["PAGE_STATUS", "DRAFT_EXTRACT", "CHECK_EXTRACT"].includes(msg.type))
          throw Error(
            "L\u2019import natif est en cours. Attends la confirmation du brouillon."
          );
        if (![
          "EBAY_SEED_READ",
          "EBAY_COPY_READ",
          "EBAY_LIBRARY_READ",
          "PAGE_STATUS",
          "DRAFT_EXTRACT",
          "CHECK_EXTRACT"
        ].includes(msg.type)) {
          const job = await message(
            {
              type: "NATIVE_JOB"
            }
          );
          if (job && (readOnly2 || job.transport === "api") && !["ready", "error"].includes(job.stage))
            throw Error(
              "L\u2019import natif de ce brouillon est en attente. Termine son import avant d\u2019appliquer d\u2019autres modifications."
            );
        }
        if (msg.type === "EBAY_SEED_READ")
          return extractEbaySeed(document, location.href);
        if (msg.type === "EBAY_COPY_READ") {
          if (typeof msg.description !== "string")
            throw Error("Description eBay absente.");
          return extractListingCopy(document, location.href, msg.description);
        }
        if (msg.type === "EBAY_LIBRARY_READ")
          return captureEbayLibrary(document, location.href, settings);
        if (msg.type === "DRAFT_EXTRACT")
          return {
            draft: await waitForDraft(document, () => location.href, settings),
            undoDepth: transactions.depth
          };
        if (msg.type === "CHECK_APPLY") {
          if (!Array.isArray(msg.request?.changes) || !msg.request.changes.every(
            (c) => c.key === "description"
          ))
            throw Error(
              "Seules les corrections de description sont autoris\xE9es ici."
            );
          return checkTransactions.apply(
            document,
            () => location.href,
            settings,
            msg.request,
            () => enabled2
          );
        }
        if (msg.type === "CHECK_UNDO")
          return checkTransactions.undo(document, () => location.href, settings);
        if (msg.type === "CHECK_EXTRACT") {
          const draft = await waitForDraft(
            document,
            () => location.href,
            settings
          );
          return {
            scriptVersion: version,
            draft,
            promotion: promotionStatus(document),
            hasVariations: draft.variants.length > 0 || !!document.querySelector(
              'button[aria-label="Edit Variations"],iframe[title="Create/Edit variations"]'
            )
          };
        }
        if (msg.type === "VARIANTS_OPEN") {
          if (pageType(location.href) !== "draft")
            throw Error("Ouvre le brouillon eBay.");
          const frames = [
            ...document.querySelectorAll(
              'iframe[title="Create/Edit variations"]'
            )
          ].filter((f) => f.getBoundingClientRect().width > 0);
          if (frames.length === 1) return true;
          const buttons = [
            ...document.querySelectorAll(
              'button[aria-label="Edit Variations"]'
            )
          ].filter((b) => !b.disabled && b.getBoundingClientRect().width > 0);
          if (buttons.length !== 1) throw Error("Bouton Variations introuvable.");
          buttons[0].click();
          return true;
        }
        if (msg.type === "AD_GENERAL")
          return setGeneralPromotion(
            document,
            () => location.href,
            msg.identity,
            () => enabled2
          );
        if (msg.type === "APPLY")
          return transactions.apply(
            document,
            () => location.href,
            settings,
            msg.request,
            () => enabled2
          );
        if (msg.type === "UNDO")
          return transactions.undo(document, () => location.href, settings);
        if (msg.type === "PAGE_STATUS") {
          const r = resolveFields(document, settings);
          return {
            type: pageType(location.href),
            url: location.origin + location.pathname,
            undoDepth: transactions.depth,
            promotion: promotionStatus(document),
            selectors: {
              title: r.title?.field.selector,
              description: r.description?.field.selector,
              specifics: r.specifics.map((x) => ({
                label: x.field.label,
                selector: x.field.selector,
                writable: x.field.writable
              }))
            },
            seller: {
              username: document.querySelector("[data-auroebay-username]")?.getAttribute("data-auroebay-username"),
              element: document.querySelector("[data-auroebay-username]")?.className,
              badge: document.querySelector("[data-auroebay-seller]")?.getAttribute("title")
            }
          };
        }
        throw Error("Unknown operation");
      };
      run().then((data) => reply({ ok: true, data })).catch(
        (e) => reply({
          ok: false,
          error: e instanceof Error ? e.message : "Operation failed"
        })
      );
      return true;
    };
    chrome.runtime.onMessage.addListener(listener);
    const runtimeId = chrome.runtime.id;
    const cleanup = () => {
      if (stopped) return;
      stopped = true;
      enabled2 = false;
      configuration++;
      observer.disconnect();
      clearInterval(interval);
      window.removeEventListener("popstate", changed);
      window.removeEventListener("hashchange", changed);
      cleanupNative();
      cleanupPush();
      cleanupLibraryButton();
      libraryLinks?.cleanup();
      cleanupOrders();
      cleanupPublish();
      cleanupWinners();
      cleanupResults();
      transactions.clear();
      checkTransactions.clear();
      cancelSellerRequests();
      clearSellerUI();
      try {
        chrome.runtime.onMessage.removeListener(listener);
      } catch {
      }
    };
    const controller = {
      version,
      runtimeId,
      readOnly: readOnly2,
      cleanup,
      alive: () => {
        try {
          return !stopped && chrome.runtime.id === runtimeId && chrome.runtime.onMessage.hasListener(listener);
        } catch {
          return false;
        }
      }
    };
    void configure().catch(() => {
    });
    return controller;
  }
  var world = globalThis;
  var readOnly = world.__auroebayReadReconnect === true;
  delete world.__auroebayReadReconnect;
  var previous = world.__auroebayContentController;
  if (!(previous?.version === version && previous.runtimeId === chrome.runtime.id && previous.alive() && (!previous.readOnly || readOnly))) {
    previous?.cleanup();
    world.__auroebayContentController = initializeEbayContent(readOnly);
  }
})();
