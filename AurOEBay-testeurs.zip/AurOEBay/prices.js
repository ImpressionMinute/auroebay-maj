"use strict";
(() => {
  // src/core/text.ts
  var compact = (s) => s.replace(/\s+/g, " ").trim();
  var norm = (s) => compact(s.normalize("NFKC")).toLowerCase().replace(/[\s\W_]+/g, " ").trim();
  var escapeHTML = (s) => s.replace(
    /[&<>"']/g,
    (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]
  );
  function validTitle(s, max = 80) {
    return !!s.trim() && !/[\r\n]/.test(s) && s.length <= Math.min(80, max);
  }
  var delay = (ms) => new Promise((r) => setTimeout(r, ms));

  // src/core/sizes.ts
  function ebaySize(value) {
    const m = value.trim().match(/^(X{2,7})(L|S)$/i);
    return m ? `${m[1].length}X${m[2].toUpperCase()}` : value;
  }
  var STANDARD = /^(XS|S|M|L|XL|X{2,7}[LS]|\d{1,2}X[LS])$/i;
  function standardSize(value) {
    const m = value.trim().match(/^([0-9]{0,2}X{0,7}[A-Z]{1,2})\s*[([（【]\s*(.+?)\s*[)\]）】]$/i);
    const base = (m ? m[1] : value.trim()).toUpperCase();
    if (!STANDARD.test(base)) return null;
    return { size: ebaySize(base), note: m ? m[2] : "" };
  }

  // src/core/variantMatch.ts
  function variantValue(value) {
    return value.normalize("NFKC").toLowerCase().replace(/(\d),(\d)/g, "$1.$2").replace(/[\s\u00a0_-]+/g, "").trim();
  }
  function compact2(value) {
    return variantValue(value).replace(/(mm|cm|inch|in|ml|kg|g|pcs|pc)(?=\b|\d|$)/g, "").replace(/[^\p{L}\p{N}]+/gu, "");
  }
  function distance(a, b) {
    const d = Array.from({ length: b.length + 1 }, (_, i) => i);
    for (let i = 1; i <= a.length; i++) {
      let prev = d[0];
      d[0] = i;
      for (let j = 1; j <= b.length; j++) {
        const tmp = d[j];
        d[j] = Math.min(d[j] + 1, d[j - 1] + 1, prev + (a[i - 1] === b[j - 1] ? 0 : 1));
        prev = tmp;
      }
    }
    return d[b.length];
  }
  function supplierValueFor(value, supplierValues) {
    const exact = supplierValues.filter((v) => variantValue(v) === variantValue(value));
    if (exact.length) return exact[0];
    const wanted = standardSize(value)?.size;
    const sized = wanted ? supplierValues.filter((v) => standardSize(v)?.size === wanted) : [];
    if (sized.length === 1) return sized[0];
    const c = compact2(value);
    const same = [...new Set(supplierValues.filter((v) => c && compact2(v) === c))];
    if (same.length === 1) return same[0];
    if (c.length >= 4) {
      const close = [
        ...new Set(
          supplierValues.filter((v) => {
            const k = compact2(v);
            if (k.length < 4 || /^\d+$/.test(k) || /^\d+$/.test(c)) return false;
            return k.startsWith(c) || c.startsWith(k) || Math.min(k.length, c.length) >= 5 && distance(k, c) <= 2;
          })
        )
      ];
      if (close.length === 1) return close[0];
    }
    return value;
  }
  function supplierKey(values, supplierValues) {
    return JSON.stringify(values.map((v) => variantValue(supplierValueFor(v, supplierValues))).sort());
  }
  function confirmedUnavailable(field, scan) {
    if (!scan || !Array.isArray(scan.unavailable) || !Number.isFinite(scan.at) || scan.at > Date.now() + 3e4 || Date.now() - scan.at > 15 * 60 * 1e3)
      return false;
    const all = [...new Set([...scan.costs, ...scan.unavailable].flatMap((c) => c.values))];
    const target = supplierKey((field.options ?? []).map((o) => o.value), all);
    const matches = (c) => JSON.stringify(c.values.map(variantValue).sort()) === target;
    return !!field.options?.length && scan.unavailable.filter(matches).length === 1 && !scan.costs.some(matches);
  }

  // src/ebay/detection.ts
  function pageType(url) {
    try {
      const u = new URL(url);
      if (!/(^|\.)ebay\.com$/.test(u.hostname)) return "other";
      if (/^\/sl\/(?:sell|list|revise)|^\/lstng|^\/sell\/|^\/sh\/lst\/drafts\//.test(
        u.pathname
      ) || u.pathname === "/sl/sell" || u.hostname === "bulkedit.ebay.com" && u.pathname === "/msku")
        return "draft";
      if (/^\/itm\//.test(u.pathname)) return "product";
      if (/^\/sch\//.test(u.pathname)) return "results";
      return "other";
    } catch {
      return "other";
    }
  }
  function draftIdentity(url) {
    const u = new URL(url);
    const keys = [
      "draftId",
      "draftid",
      "draft_id",
      "itemId",
      "itemid",
      "item_id",
      "listingId",
      "mode"
    ];
    return `${u.origin}${u.pathname}?${keys.filter((k) => u.searchParams.has(k)).map((k) => `${k}=${u.searchParams.get(k)}`).join("&")}${u.hash}`;
  }

  // src/ebay/selectors.ts
  var SELECTORS = {
    title: [
      '[data-testid="title"] input',
      'input[data-testid="title"]',
      '[data-testid="listing-title"] input',
      'input[name="title"]',
      'input[name="listingTitle"]',
      "input#title",
      "input#listingTitle",
      'input[aria-label="Title"]'
    ],
    description: [
      'textarea[data-testid="description"]',
      '[data-testid="description"] textarea',
      'textarea[name="description"]',
      "textarea#description",
      '[contenteditable="true"][aria-label="Description"]',
      '[contenteditable="true"][data-testid="description"]',
      "iframe#description_ifr",
      "iframe#se-rte-frame__summary",
      'iframe[title="Rich Text Area"]'
    ],
    specifics: [
      '[data-testid*="item-specific"]',
      '[data-testid*="itemSpecific"]',
      '[data-testid="specifics"]',
      ".item-specifics",
      "#itemSpecifics",
      ".summary__attributes",
      '[aria-label="Item specifics"]'
    ],
    seller: [
      '[data-testid="seller-info"]',
      ".x-sellercard-atf",
      ".x-sellercard",
      ".x-sellercard-atf__info",
      ".ux-seller-section",
      "#RightSummaryPanel .mbg"
    ],
    sellerLinks: ['a[href*="/usr/"]'],
    results: ["li.s-item", "li.s-card", '[data-testid="item-card"]'],
    variations: [
      '[data-testid*="variation"]',
      ".variation-row",
      ".summary__variations",
      '[aria-label="Variations"]'
    ],
    aliTitle: [
      'h1[data-pl="product-title"]',
      '[data-testid="product-title"]',
      "h1"
    ],
    aliSpecs: [
      '[data-testid="specifications"] li',
      '[class*="specification--prop"]',
      '[class*="specification--line"]',
      ".product-prop",
      '[class*="specification"] tr'
    ],
    aliDescription: [
      '[data-testid="product-description"]',
      "#product-description",
      ".product-description"
    ],
    aliDescriptionFrames: [
      "#nav-description iframe",
      "#product-description iframe",
      '[data-testid="product-description"] iframe'
    ],
    seedTitle: ["h1.x-item-title__mainTitle", 'h1[data-testid="item-title"]'],
    seedSpecifics: [
      ".ux-layout-section-evo__item--description-list",
      '[data-testid="seed-specifics"]'
    ],
    seedCategory: [
      "nav.breadcrumbs a.seo-breadcrumb-text",
      '[data-testid="seed-category"] a'
    ],
    seedPrice: [".x-price-primary", '[data-testid="seed-price"]'],
    simplePrice: [
      'input[name="price"]',
      'input[aria-label="Price"]',
      'input[id$="-price"]'
    ],
    aliVariants: [
      "[data-sku-row]",
      '[data-testid="sku-property"]',
      '[class*="sku-item--property"]'
    ],
    aliStore: [
      '[data-testid="store-name"]',
      'a[class*="store-name"]',
      'a[href*="/store/"]'
    ],
    aliGallery: [
      '[data-testid="product-gallery"]',
      '[class*="slider--img"]',
      '[class*="magnifier--wrap"]'
    ],
    aliShipping: [
      '[data-testid="shipping"]',
      '[class*="delivery--shipping"]',
      '[class*="delivery--content"]',
      '[class*="dynamic-shipping-titleLayout"]'
    ],
    nativeSearch: [
      'input[placeholder="Enter brand, model, description, etc."]',
      'input[aria-label="Enter brand, model, description, etc."]'
    ],
    photoInput: [
      'input#fehelix-uploader[type="file"]',
      'input[data-testid="photo-upload"][type="file"]'
    ],
    photoCounter: [
      '.summary__photos .uploader-thumbnails-ux__header__photo-count span[aria-hidden="true"]'
    ],
    uploadedPhotos: [
      '.summary__variations .uploader-thumbnails__thumbnail button.uploader-thumbnails__image[style*="background-image"]',
      '[data-testid="uploaded-photo"] img',
      '.summary__photos .uploader-thumbnails-ux__image--ready button.uploader-thumbnails-ux__image[style*="background-image"]'
    ]
  };
  var SPECIFIC_LABELS = [
    "Brand",
    "Type",
    "Material",
    "Color",
    "Colour",
    "Size",
    "Features",
    "Compatible Brand",
    "Compatible Model",
    "MPN",
    "Model",
    "Country/Region of Manufacture",
    "Country of Origin",
    "Unit Quantity",
    "Unit Type",
    "Number of Pieces",
    "Dimensions",
    "Length",
    "Width",
    "Height",
    "Capacity",
    "Pattern",
    "Style",
    "Department"
  ];
  function queryAll(root, selectors) {
    const result = /* @__PURE__ */ new Set();
    for (const selector of selectors) {
      try {
        root.querySelectorAll(selector).forEach((e) => result.add(e));
      } catch {
      }
    }
    return [...result];
  }

  // src/core/shippingText.ts
  var PRICE = String.raw`(?:US\s*)?\$\s*(\d+(?:\.\d{1,2})?)`;
  var NAMED = new RegExp(String.raw`(?:standard|shipping|delivery|livraison)[^$·\d]{0,20}?${PRICE}`, "gi");
  var LABEL = new RegExp(String.raw`\b[A-Za-z][A-Za-z' -]{1,30}:\s*${PRICE}`, "g");

  // src/ebay/prices.ts
  function resolvePrices(doc) {
    const rows = [];
    for (const table of doc.querySelectorAll("table")) {
      const header = table.querySelector("thead tr");
      if (!header) continue;
      const headers = [...header.children].map(
        (c) => norm(c.getAttribute("sortby") ?? c.textContent ?? "")
      );
      const priceIndex = headers.findIndex((h) => /^(price|prix)$/.test(h));
      const axes = headers.map((h, i) => ({ h, i, cell: header.children[i] })).filter(
        ({ h, cell }) => h && cell.getAttribute("ignore") !== "1" && !cell.matches(".act,.pic,.sku,.upc,.qty,.prc,.eco-fee,.cell-ph") && !/^(actions|photos|sku|upc|ean|isbn|quantity|quantite|price|prix|eco(?: participation)? fee|eco participation|ecoparticipation)$/.test(
          h
        )
      );
      if (priceIndex < 0 || !axes.length) continue;
      for (const row of table.querySelectorAll("tbody tr")) {
        if (row.hidden || row.classList.contains("hide")) continue;
        const input = row.cells[priceIndex]?.querySelector(
          'input[cn="prc"],input[name*="price" i],input'
        );
        if (!input || input.disabled || input.readOnly || input.type === "hidden")
          continue;
        const values = axes.map(({ h, i }) => ({
          label: h,
          value: compact(row.cells[i]?.textContent ?? "")
        }));
        if (values.some((v) => !v.value)) continue;
        const key = `price:${JSON.stringify(values.map((v) => [v.label, norm(v.value)]).sort())}`;
        rows.push({
          el: input,
          field: {
            key,
            label: values.map((v) => `${v.label}: ${v.value}`).join(" \xB7 "),
            value: input.value,
            kind: "text",
            writable: true,
            selector: 'table tbody input[cn="prc"]',
            options: values.map((v) => ({ label: v.label, value: v.value }))
          }
        });
      }
    }
    const counts = /* @__PURE__ */ new Map();
    rows.forEach(
      (r) => counts.set(r.field.key, (counts.get(r.field.key) ?? 0) + 1)
    );
    return rows.filter((r) => counts.get(r.field.key) === 1).slice(0, 300);
  }
  function resolveQuantities(doc) {
    return resolvePrices(doc).flatMap((r) => {
      const row = r.el.closest("tr");
      const input = row?.querySelector('input[cn="qty"]');
      if (!input || input.disabled || input.readOnly || input.type === "hidden")
        return [];
      return [
        {
          el: input,
          field: {
            ...r.field,
            key: r.field.key.replace(/^price:/, "quantity:"),
            value: input.value,
            selector: 'input[cn="qty"]'
          }
        }
      ];
    });
  }
  function rowSnapshot(el) {
    return JSON.stringify(
      [
        ...el.closest("tr").querySelectorAll("input,textarea,select")
      ].filter((c) => c.type !== "checkbox" && c.type !== "hidden").map((c) => [c.getAttribute("cn") ?? c.name, c.value])
    );
  }
  function resolveSimplePrice(doc) {
    if (doc.querySelector(
      '.summary__variations button[aria-label^="Pricing: Price:"], [data-testid="variation-selector"]'
    ))
      return null;
    const candidates = queryAll(doc, SELECTORS.simplePrice).filter(
      (el2) => el2.tagName === "INPUT" && !el2.hasAttribute("disabled") && !el2.hasAttribute("readonly") && el2.type !== "hidden" && !el2.closest("table")
    );
    if (candidates.length !== 1) return null;
    const el = candidates[0];
    return {
      el,
      field: {
        key: "price:simple",
        label: "Price",
        value: el.value,
        kind: "text",
        writable: true,
        selector: "single price"
      }
    };
  }
  function resolveSimpleQuantity(doc) {
    if (doc.querySelector(
      '.summary__variations button[aria-label^="Pricing: Price:"], [data-testid="variation-selector"]'
    ))
      return null;
    const candidates = queryAll(doc, [
      'input[name="quantity"]',
      'input[aria-label="Quantity"]',
      'input[id$="-quantity"]'
    ]).filter(
      (el2) => el2.tagName === "INPUT" && !el2.hasAttribute("disabled") && !el2.hasAttribute("readonly") && !el2.closest('table,[hidden],[aria-hidden="true"]') && ["text", "number", ""].includes(el2.getAttribute("type") ?? "") && doc.defaultView?.getComputedStyle(el2).display !== "none"
    );
    if (candidates.length !== 1) return null;
    const el = candidates[0];
    return {
      el,
      field: {
        key: "quantity:simple",
        label: "Quantity",
        value: el.value,
        kind: "text",
        writable: true,
        selector: "single inventory quantity"
      }
    };
  }

  // src/ebay/stock.ts
  function prepareStock(doc, url, request, scan, active) {
    const guard = () => {
      if (!active()) throw Error("AurOEBay en pause");
      if (pageType(url()) !== "draft" || draftIdentity(url()) !== request.identity)
        throw Error("Brouillon chang\xE9. Recharge les variantes.");
    };
    const resolve = (a) => {
      guard();
      const r = resolvePrices(doc).find((r2) => r2.field.key === a.key);
      if (!r || rowSnapshot(r.el) !== a.before)
        throw Error("Variante modifi\xE9e ou introuvable. Recharge les variantes.");
      if (!confirmedUnavailable(r.field, scan))
        throw Error("Rupture non confirm\xE9e ou trop ancienne. Relis AliExpress.");
      if (a.action !== "zero" && a.action !== "delete")
        throw Error("Action invalide");
      if (a.action === "zero" && !resolveQuantities(doc).some(
        (q) => q.field.key === a.key.replace(/^price:/, "quantity:")
      ))
        throw Error("Champ quantit\xE9 indisponible");
      if (a.action === "delete") {
        const buttons = r.el.closest("tr").querySelectorAll('[action="delete"]');
        if (buttons.length !== 1 || buttons[0].matches(':disabled,[aria-disabled="true"]') || buttons[0].closest('[hidden],[aria-hidden="true"]'))
          throw Error("Bouton de suppression eBay indisponible");
      }
      return r;
    };
    guard();
    if (!Array.isArray(request.actions) || !request.actions.length || request.actions.length > 300 || new Set(request.actions.map((a) => a.key)).size !== request.actions.length)
      throw Error("Choix de variantes invalide");
    request.actions.forEach(resolve);
    const removals = request.actions.filter((a) => a.action === "delete");
    if (removals.length >= resolvePrices(doc).length)
      throw Error(
        "Garde au moins une variante. Utilise la quantit\xE9 \xE0 z\xE9ro pour la derni\xE8re."
      );
    return { guard, resolve };
  }
  async function applyStock(doc, url, settings, request, scan, quantities2, active) {
    const result = { zeroed: [], deleted: [] };
    try {
      const { guard, resolve } = prepareStock(doc, url, request, scan, active);
      const removals = request.actions.filter((a) => a.action === "delete");
      const zeros = request.actions.filter((a) => a.action === "zero");
      if (zeros.length) {
        const fields = resolveQuantities(doc);
        const applied = await quantities2.apply(
          doc,
          url,
          settings,
          {
            identity: request.identity,
            changes: zeros.map((a) => {
              const f = fields.find(
                (q) => q.field.key === a.key.replace(/^price:/, "quantity:")
              ).field;
              return { key: f.key, before: f.value, after: "0" };
            })
          },
          active
        );
        result.zeroed = applied.applied;
      }
      for (const a of removals) {
        const r = resolve(a);
        if (resolvePrices(doc).length <= 1)
          throw Error("Derni\xE8re variante : utilise la quantit\xE9 z\xE9ro.");
        const row = r.el.closest("tr");
        const removed = () => (!row.isConnected || row.hidden || row.classList.contains("hide")) && !resolvePrices(doc).some((x) => x.field.key === a.key);
        row.querySelector('[action="delete"]').click();
        for (let i = 0; i < 20 && !removed(); i++) await delay(100);
        if (!removed())
          throw Error(
            "Suppression non confirm\xE9e. V\xE9rifie une \xE9ventuelle confirmation dans eBay, puis recharge les variantes."
          );
        result.deleted.push(a.key);
        guard();
      }
    } catch (e) {
      result.error = e instanceof Error ? e.message : String(e);
    }
    return result;
  }

  // src/ebay/variantsApply.ts
  async function applyVariants(doc, url, settings, request, scan, transaction, active) {
    if (!Array.isArray(request.changes) || !Array.isArray(request.actions) || request.changes.length > 300 || request.actions.length > 300 || !request.changes.every(
      (c) => typeof c.key === "string" && c.key.startsWith("price:")
    ) || new Set(request.changes.map((c) => c.key)).size !== request.changes.length || !request.changes.length && !request.actions.length)
      throw Error("S\xE9lection de prix et stock invalide");
    if (request.actions.length) {
      if (!scan || !request.source)
        throw Error("Relis les ruptures AliExpress avant d\u2019appliquer le stock.");
      prepareStock(
        doc,
        url,
        { ...request, source: request.source },
        scan,
        active
      );
    }
    const removals = request.actions.filter((a) => a.action === "delete");
    const removed = new Set(removals.map((a) => a.key));
    const prices = request.changes.filter((c) => !removed.has(c.key));
    const quantities2 = resolveQuantities(doc);
    const zeros = request.actions.filter((a) => a.action === "zero").map((a) => {
      const f = quantities2.find(
        (q) => q.field.key === a.key.replace(/^price:/, "quantity:")
      ).field;
      return { key: f.key, before: f.value, after: "0" };
    });
    const result = {
      prices: [],
      zeroed: [],
      deleted: [],
      skippedPrices: request.changes.filter((c) => removed.has(c.key)).map((c) => c.key),
      undoDepth: transaction.depth
    };
    if (prices.length || zeros.length) {
      const applied = await transaction.apply(
        doc,
        url,
        settings,
        { identity: request.identity, changes: [...prices, ...zeros] },
        active
      );
      result.prices = applied.applied.filter((key) => key.startsWith("price:"));
      result.zeroed = applied.applied.filter(
        (key) => key.startsWith("quantity:")
      );
      result.undoDepth = applied.undoDepth;
    }
    if (removals.length) {
      const deleted = await applyStock(
        doc,
        url,
        settings,
        {
          identity: request.identity,
          source: request.source,
          actions: removals
        },
        scan,
        transaction,
        active
      );
      result.deleted = deleted.deleted;
      result.error = deleted.error;
    }
    return result;
  }

  // src/ebay/upc.ts
  var NO_UPC = "Does not apply";
  function resolveUPCs(doc) {
    return resolvePrices(doc).flatMap((r) => {
      const inputs = r.el.closest("tr")?.querySelectorAll('input[cn="upc"]');
      if (inputs?.length !== 1) return [];
      const input = inputs[0];
      if (input.disabled || input.readOnly || input.type === "hidden") return [];
      return [
        {
          el: input,
          field: {
            ...r.field,
            key: r.field.key.replace(/^price:/, "upc:"),
            value: input.value,
            selector: 'input[cn="upc"]'
          }
        }
      ];
    });
  }
  function chooseUPC(input, value) {
    if (value !== NO_UPC && value !== "") throw Error("Valeur UPC non autoris\xE9e");
    const widget = input.closest(".drp");
    const toggle = widget?.querySelector(".pull-down");
    const options = [
      ...widget?.querySelectorAll("a[val]") ?? []
    ].filter((a) => a.getAttribute("val") === value);
    if (!toggle || options.length !== 1)
      throw Error("Menu UPC eBay introuvable : aucune saisie forc\xE9e effectu\xE9e");
    clickMenuLink(toggle);
    clickMenuLink(options[0]);
  }
  function clickMenuLink(control) {
    const win = control.ownerDocument.defaultView;
    const event = new win.MouseEvent("click", {
      bubbles: true,
      cancelable: true,
      composed: true
    });
    event.preventDefault();
    control.dispatchEvent(event);
  }

  // public/manifest.json
  var version = "0.99.19";

  // src/core/messaging.ts
  var STALE_PAGE = "AurOEBay a \xE9t\xE9 mis \xE0 jour pendant que cette page \xE9tait ouverte : recharge-la (Cmd + R), puis recommence.";
  async function message(body) {
    let reply;
    try {
      reply = await chrome.runtime.sendMessage(body);
    } catch (e) {
      const text = e instanceof Error ? e.message : String(e);
      throw Error(/context invalidated|Receiving end does not exist|message port closed/i.test(text) ? STALE_PAGE : text);
    }
    if (!reply?.ok)
      throw Error(reply?.error ?? "AurOEBay ne r\xE9pond pas. Recharge la page.");
    return reply.data;
  }

  // src/core/descriptionDesign.ts
  var DESCRIPTION_TEMPLATE = '<style>\n.auro-listing{font-family:Arial,Helvetica,sans-serif;color:#213a37;background:#f3f5f3;max-width:960px;margin:0 auto;padding:24px;box-sizing:border-box;line-height:1.65}\n.auro-listing *{box-sizing:border-box}.auro-listing .auro-brand{font-size:12px;letter-spacing:3px;font-weight:bold;margin-bottom:20px;color:#44645b}.auro-listing .auro-header{background:#183e35;color:white;border-radius:14px;padding:30px}.auro-listing h1{font-size:26px;line-height:1.3;margin:10px 0 0}.auro-listing .auro-eyebrow{font-size:11px;letter-spacing:2px;text-transform:uppercase}.auro-listing .auro-body{background:white;border:1px solid #dce5dd;border-radius:14px;margin-top:18px;padding:24px;overflow-wrap:anywhere}.auro-listing .auro-body img{max-width:100%!important;height:auto!important;display:block;margin:18px auto}.auro-listing .auro-body table{max-width:100%;width:auto}.auro-listing .auro-body p{margin:12px 0}.auro-listing .auro-note{font-size:13px;color:#587064;padding:18px 4px}.auro-listing .auro-note strong{color:#213a37}@media(max-width:600px){.auro-listing{padding:12px}.auro-listing .auro-header,.auro-listing .auro-body{padding:18px}.auro-listing h1{font-size:22px}}\n</style>\n<div class="auro-listing">\n{store}\n<div class="auro-header"><div class="auro-eyebrow">Product details</div><h1>{title}</h1></div>\n<div class="auro-body">{description}</div>\n<div class="auro-note"><strong>Choose your option</strong><br>Please check the selected variation, dimensions and item details before ordering.<br>Delivery estimates, shipping charges and return terms are shown in this eBay listing.</div>\n</div>\n';
  function designDescription(html, title) {
    const template = document.createElement("template");
    template.innerHTML = html;
    const root = template.content;
    const removed = [];
    const previous = root.querySelector(".auro-listing .auro-body");
    const legacy = root.querySelector("#wrapper > .box > .content.main_content");
    let body = root;
    if (previous) body = previous;
    else if (legacy) {
      const wrapper = root.querySelector("#wrapper");
      const boxes = [...wrapper.children].filter((e) => e.matches(".box"));
      const disposable = boxes.filter(
        (box) => /^(shipping|returns|payments|feedbacks)$/i.test(
          box.querySelector(":scope > .title")?.textContent?.trim() ?? ""
        )
      );
      if (boxes.every((b) => b.contains(legacy) || disposable.includes(b))) {
        body = legacy;
        removed.push(
          ...disposable.map(
            (b) => b.querySelector(".title").textContent.trim()
          )
        );
      }
    }
    const content = document.createElement("div");
    content.append(...Array.from(body.childNodes).map((n) => n.cloneNode(true)));
    content.querySelectorAll(
      "script,style,iframe,object,embed,form,input,button,link,meta"
    ).forEach((e) => e.remove());
    content.querySelectorAll("*").forEach((el) => {
      for (const attr of [...el.attributes]) {
        if (/^on/i.test(attr.name) || attr.name === "srcdoc" || /^href$/i.test(attr.name) && /^javascript:/i.test(attr.value))
          el.removeAttribute(attr.name);
      }
    });
    const output = listingDescriptionHTML(title, content.innerHTML);
    const normalized = document.createElement("template");
    normalized.innerHTML = output;
    return {
      html: normalized.innerHTML,
      removed,
      images: content.querySelectorAll("img").length
    };
  }
  function replaceDesign(root, html) {
    const t = root.ownerDocument.createElement("template");
    t.innerHTML = html;
    const originals = [...root.querySelectorAll("img")];
    t.content.querySelectorAll("img").forEach((img) => {
      const index = originals.findIndex((o) => o.outerHTML === img.outerHTML);
      if (index >= 0) img.replaceWith(originals.splice(index, 1)[0]);
    });
    root.replaceChildren(t.content);
  }
  var listingStore = "";
  var DESCRIPTION_THEMES = {
    classic: { label: "Vert classique", font: "Arial,Helvetica,sans-serif", ink: "#213a37", page: "#f3f5f3", brand: "#44645b", header: "#183e35", headerInk: "white", card: "white", border: "#dce5dd", radius: "14px", note: "#587064" },
    minimal: { label: "Blanc minimal", font: "Helvetica,Arial,sans-serif", ink: "#1d1d1f", page: "#ffffff", brand: "#86868b", header: "#ffffff;border-bottom:2px solid #1d1d1f", headerInk: "#1d1d1f", card: "white", border: "#e5e5e7", radius: "4px", note: "#6e6e73" },
    ocean: { label: "Bleu oc\xE9an", font: "Arial,Helvetica,sans-serif", ink: "#13293d", page: "#eef4fa", brand: "#2f6690", header: "linear-gradient(135deg,#0b4f9c,#1677d2)", headerInk: "white", card: "white", border: "#d4e3f2", radius: "14px", note: "#4a6582" },
    noir: { label: "Noir & or", font: "Georgia,'Times New Roman',serif", ink: "#1a1a1a", page: "#f5f3ee", brand: "#a8842c", header: "#111111", headerInk: "#f5c451", card: "white", border: "#e6dfcf", radius: "6px", note: "#6b6252" },
    sunset: { label: "Orange \xE9nergie", font: "Arial,Helvetica,sans-serif", ink: "#2b1d16", page: "#fff6ef", brand: "#e8590c", header: "linear-gradient(135deg,#ff5f3a,#ff8a3d 50%,#ffb347)", headerInk: "white", card: "white", border: "#ffe0cc", radius: "18px", note: "#7a5a48" },
    rose: { label: "Rose doux", font: "'Trebuchet MS',Arial,sans-serif", ink: "#3b1f2b", page: "#fff0f5", brand: "#c2255c", header: "linear-gradient(135deg,#f06595,#faa2c1)", headerInk: "white", card: "white", border: "#fcd6e3", radius: "20px", note: "#86566a" },
    tech: { label: "Tech sombre", font: "Verdana,Arial,sans-serif", ink: "#1b2733", page: "#e9eef2", brand: "#0c8599", header: "linear-gradient(135deg,#1b2733,#22394d)", headerInk: "#66d9e8", card: "white", border: "#cfd9e1", radius: "10px", note: "#52667a" }
  };
  var listingTheme = "classic";
  function descriptionTemplate(id = listingTheme) {
    const t = DESCRIPTION_THEMES[id];
    if (!t || id === "classic") return DESCRIPTION_TEMPLATE;
    return DESCRIPTION_TEMPLATE.replace("font-family:Arial,Helvetica,sans-serif", `font-family:${t.font}`).replace("color:#213a37;background:#f3f5f3", `color:${t.ink};background:${t.page}`).replace("color:#44645b", `color:${t.brand}`).replace("background:#183e35;color:white;border-radius:14px", `background:${t.header};color:${t.headerInk};border-radius:${t.radius}`).replace("background:white;border:1px solid #dce5dd;border-radius:14px", `background:${t.card};border:1px solid ${t.border};border-radius:${t.radius}`).replace("color:#587064", `color:${t.note}`).replace(".auro-note strong{color:#213a37}", `.auro-note strong{color:${t.ink}}`);
  }
  function listingDescriptionHTML(title, bodyHTML, store = listingStore, theme = listingTheme) {
    const text = escapeHTML(title).replace(/&#39;/g, "'").replace(/&quot;/g, '"').replace(/\u00a0/g, "&nbsp;");
    const brand = store ? `<div class="auro-brand">${escapeHTML(store.toUpperCase().replace(/\s+/g, ""))}</div>
` : "";
    return descriptionTemplate(theme).replace(
      /\{title\}|\{description\}|\{store\}\n?/g,
      (placeholder) => placeholder === "{title}" ? text : placeholder === "{description}" ? bodyHTML : brand
    );
  }

  // src/core/descriptionHTML.ts
  function isEditorDecoration(node) {
    return node.nodeType === 1 && node.matches("style.darkreader");
  }
  function removeInlineEditorDecoration(el) {
    for (const attr of [...el.attributes])
      if (/^data-darkreader-inline-[a-z-]+$/.test(attr.name))
        el.removeAttribute(attr.name);
    const style = el.style;
    if (style) {
      let removed = false;
      for (const name of Array.from(
        { length: style.length },
        (_, i) => style.item(i)
      ))
        if (/^--darkreader-inline-[a-z-]+$/.test(name)) {
          style.removeProperty(name);
          removed = true;
        }
      if (removed && !el.getAttribute("style")?.trim())
        el.removeAttribute("style");
    }
  }
  function listingAttributes(el) {
    const copy = el.cloneNode(false);
    removeInlineEditorDecoration(copy);
    return [...copy.attributes].map((a) => [a.name, a.value]).sort(([a], [b]) => a.localeCompare(b));
  }
  function listingCopy(el) {
    const copy = el.cloneNode(true);
    copy.querySelectorAll("style.darkreader").forEach((node) => node.remove());
    removeInlineEditorDecoration(copy);
    copy.querySelectorAll("*").forEach(removeInlineEditorDecoration);
    return copy;
  }
  function listingOuterHTML(el) {
    return listingCopy(el).outerHTML;
  }
  function editableHTML(el) {
    if (!el.matches('[contenteditable="true"]') && el.tagName !== "BODY" || ![...el.querySelectorAll("*")].some(
      (node) => isEditorDecoration(node) || [...node.attributes].some(
        (a) => /^data-darkreader-inline-[a-z-]+$/.test(a.name)
      ) || node.getAttribute("style")?.includes("--darkreader-inline-")
    ))
      return el.innerHTML;
    return listingCopy(el).innerHTML;
  }

  // src/core/description.ts
  var discard = /* @__PURE__ */ new Set([
    "SCRIPT",
    "STYLE",
    "IFRAME",
    "OBJECT",
    "EMBED",
    "SVG",
    "MATH",
    "FORM",
    "BUTTON",
    "INPUT",
    "TEXTAREA",
    "SELECT",
    "TEMPLATE",
    "NOSCRIPT",
    "IMG",
    "VIDEO",
    "AUDIO",
    "LINK",
    "META"
  ]);
  function fragment(html) {
    const t = document.createElement("template");
    t.innerHTML = html;
    return t.content;
  }
  function editedDescription(html, edits) {
    const root = fragment(html);
    for (const edit of edits) {
      let node = root;
      for (const i of edit.path) {
        node = node.childNodes[i];
        if (!node) throw Error("Texte d\xE9plac\xE9. Relance l\u2019analyse.");
      }
      if (node.nodeType !== 3 || node.textContent !== edit.before)
        throw Error("Texte modifi\xE9. Relance l\u2019analyse.");
      node.textContent = edit.after;
    }
    const t = document.createElement("template");
    t.content.append(root);
    return t.innerHTML;
  }
  function replaceDescriptionText(root, after, apply = true) {
    const target = fragment(after);
    const writes = [];
    const compareChildren = (a, b) => {
      const children = (node) => [...node.childNodes].filter((n) => !isEditorDecoration(n));
      const fixedA = children(a).filter((n) => n.nodeType !== 3), fixedB = children(b).filter((n) => n.nodeType !== 3);
      if (fixedA.length !== fixedB.length)
        throw Error("Description: modification de structure refus\xE9e");
      const slots = (parent) => {
        const result = [[]];
        for (const c of children(parent)) {
          if (c.nodeType === 3) result.at(-1).push(c);
          else result.push([]);
        }
        return result;
      };
      const aSlots = slots(a), bSlots = slots(b);
      aSlots.forEach((nodes, i) => {
        const text = bSlots[i].map((n) => n.textContent ?? "").join("");
        writes.push(() => {
          if (nodes.length) {
            nodes[0].textContent = text;
            nodes.slice(1).forEach((n) => {
              n.textContent = "";
            });
          } else if (text)
            a.insertBefore(
              a.ownerDocument.createTextNode(text),
              fixedA[i] ?? null
            );
        });
      });
      fixedA.forEach((x, i) => compare(x, fixedB[i]));
    };
    const compare = (a, b) => {
      if (a.nodeType !== b.nodeType || a.nodeName !== b.nodeName)
        throw Error("Description: modification de structure refus\xE9e");
      if (a.nodeType === 1) {
        const x = a, y = b;
        if (JSON.stringify(listingAttributes(x)) !== JSON.stringify(listingAttributes(y)))
          throw Error(
            "Description: modification des images ou attributs refus\xE9e"
          );
        if (discard.has(x.tagName) && listingOuterHTML(x) !== listingOuterHTML(y))
          throw Error("Description: modification de m\xE9dia refus\xE9e");
      }
      if (a.nodeType === 8 && a.textContent !== b.textContent)
        throw Error("Description: commentaire modifi\xE9");
      compareChildren(a, b);
    };
    compareChildren(root, target);
    if (apply) writes.forEach((write) => write());
  }
  function validateDescriptionChange(before, after) {
    replaceDescriptionText(fragment(before), after, false);
  }

  // src/ebay/promotion.ts
  function writeTextControl(el, value) {
    const win = el.ownerDocument.defaultView;
    el.focus();
    const key = value.at(-1) ?? "Backspace";
    const keyboard = {
      key,
      code: !value ? "Backspace" : /^\d$/.test(key) ? `Digit${key}` : "",
      keyCode: !value ? 8 : key.toUpperCase().charCodeAt(0) || 0,
      which: !value ? 8 : key.toUpperCase().charCodeAt(0) || 0,
      bubbles: true,
      composed: true
    };
    el.dispatchEvent(new win.KeyboardEvent("keydown", keyboard));
    el.dispatchEvent(
      new win.KeyboardEvent("keypress", {
        ...keyboard,
        charCode: !value ? 0 : key.charCodeAt(0) || 0
      })
    );
    el.dispatchEvent(
      new win.InputEvent("beforeinput", {
        bubbles: true,
        composed: true,
        inputType: "insertText",
        data: value
      })
    );
    const proto = el.tagName === "TEXTAREA" ? win.HTMLTextAreaElement.prototype : win.HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(proto, "value").set.call(el, value);
    el.dispatchEvent(
      new win.InputEvent("input", {
        bubbles: true,
        composed: true,
        inputType: "insertText",
        data: value
      })
    );
    el.dispatchEvent(new win.KeyboardEvent("keyup", keyboard));
    el.dispatchEvent(new win.Event("change", { bubbles: true }));
    el.blur();
  }

  // src/core/country.ts
  var codes = "AD AE AF AG AI AL AM AO AQ AR AS AT AU AW AX AZ BA BB BD BE BF BG BH BI BJ BL BM BN BO BQ BR BS BT BV BW BY BZ CA CC CD CF CG CH CI CK CL CM CN CO CR CU CV CW CX CY CZ DE DJ DK DM DO DZ EC EE EG EH ER ES ET FI FJ FK FM FO FR GA GB GD GE GF GG GH GI GL GM GN GP GQ GR GS GT GU GW GY HK HM HN HR HT HU ID IE IL IM IN IO IQ IR IS IT JE JM JO JP KE KG KH KI KM KN KP KR KW KY KZ LA LB LC LI LK LR LS LT LU LV LY MA MC MD ME MF MG MH MK ML MM MN MO MP MQ MR MS MT MU MV MW MX MY MZ NA NC NE NF NG NI NL NO NP NR NU NZ OM PA PE PF PG PH PK PL PM PN PR PS PT PW PY QA RE RO RS RU RW SA SB SC SD SE SG SH SI SJ SK SL SM SN SO SR SS ST SV SX SY SZ TC TD TF TG TH TJ TK TL TM TN TO TR TT TV TW TZ UA UG UM US UY UZ VA VC VE VG VI VN VU WF WS YE YT ZA ZM ZW".split(
    " "
  );
  var names = new Intl.DisplayNames(["en"], { type: "region" });
  var map = /* @__PURE__ */ new Map();
  for (const code of codes) {
    const name = names.of(code);
    map.set(norm(code), name);
    map.set(norm(name), name);
  }
  for (const [alias, name] of Object.entries({
    "mainland china": "China",
    "cn origin": "China",
    "china mainland": "China",
    "china origin": "China",
    prc: "China",
    "people s republic of china": "China",
    usa: "United States",
    "u s a": "United States",
    "united states of america": "United States",
    uk: "United Kingdom",
    "great britain": "United Kingdom",
    "south korea": "South Korea",
    "republic of korea": "South Korea",
    taiwan: "Taiwan",
    vietnam: "Vietnam",
    turkey: "T\xFCrkiye"
  }))
    map.set(norm(alias), name);
  function normalizeCountry(value) {
    return map.get(norm(value)) ?? null;
  }
  function manufactureLabel(label2) {
    return [
      "origin",
      "country region of manufacture",
      "country of manufacture",
      "country of origin",
      "manufactured in",
      "made in",
      "origine",
      "pays de fabrication",
      "pays d origine"
    ].includes(norm(label2));
  }

  // src/core/facts.ts
  var aliases = {
    "brand name": "brand",
    marque: "brand",
    matiere: "material",
    mat\u00E9riau: "material",
    couleur: "color",
    colour: "color",
    taille: "size",
    quantity: "unit quantity",
    quantite: "unit quantity",
    "number of pcs": "number of pieces",
    pieces: "number of pieces",
    "model number": "model",
    "country region of manufacture": "country",
    "country of manufacture": "country",
    "country of origin": "country",
    origin: "country",
    origine: "country",
    "made in": "country",
    "pays de fabrication": "country"
  };
  function matchLabel(label2) {
    const n = norm(label2).replace(/\b(?:required|optional)\b/g, "").trim();
    return aliases[n] ?? n;
  }
  var connecting = new Set(
    "a an the and or for of with in on to from by is are this these it its as at your can be use product features specifications specification package includes include included color material size quantity details description".split(
      " "
    )
  );

  // src/core/itemCondition.ts
  var ITEM_CONDITION_KEY = "condition";
  var ITEM_CONDITION_LABEL = "Item condition";
  var ITEM_CONDITION_PREFERENCE = [
    "New without tags",
    "New",
    "New with tags"
  ];
  function exactConditionLabel(a, b) {
    return compact(a.normalize("NFKC")).toLowerCase() === compact(b.normalize("NFKC")).toLowerCase();
  }
  function preferredItemCondition(field) {
    if (!field?.writable) return null;
    for (const preferred of ITEM_CONDITION_PREFERENCE) {
      const matches = field.options?.filter(
        (option) => exactConditionLabel(option.label, preferred)
      );
      if (matches?.length === 1) return matches[0];
    }
    return null;
  }
  function itemConditionChanges(field) {
    const option = preferredItemCondition(field);
    return field && option ? [{ key: ITEM_CONDITION_KEY, before: field.value, after: option.label }] : [];
  }
  function itemConditionStatus(field) {
    if (!field)
      return "Item condition : champ absent ou ambigu ; v\xE9rifie New ou New without tags dans eBay.";
    const option = preferredItemCondition(field);
    if (!option)
      return "Item condition : aucun choix New, New without tags ou New with tags s\xE9lectionnable ; v\xE9rifie ce champ dans eBay.";
    if (exactConditionLabel(field.value, option.label))
      return `Item condition : ${option.label} confirm\xE9 dans eBay.`;
    return `Item condition : ${option.label} non conserv\xE9 ; s\xE9lectionne ce choix dans eBay.`;
  }

  // src/ebay/condition.ts
  var controls = /* @__PURE__ */ new WeakMap();
  var dialogOwners = /* @__PURE__ */ new WeakMap();
  var dialogBaselines = /* @__PURE__ */ new WeakMap();
  var observedOptions = /* @__PURE__ */ new WeakMap();
  var nativeSummaryOwners = /* @__PURE__ */ new WeakMap();
  var observedOverflows = /* @__PURE__ */ new WeakMap();
  var overflowNotes = /* @__PURE__ */ new WeakMap();
  var scopeSelector = 'section,fieldset,.summary__condition,[data-testid="condition"],[data-testid="item-condition"],[data-field="condition"]';
  var choiceSelector = 'input[type="radio"],[role="radio"],[role="menuitemradio"],[role="option"],button,[role="button"]';
  var dialogSelector = '[role="dialog"],[aria-modal="true"],dialog';
  var nativeSummarySelector = '.summary__condition,[data-testid="condition"],[data-testid="item-condition"],[data-field="condition"]';
  var conditionLabel = (label2) => /^(?:item condition|condition|etat de l objet|provide a condition for your item|add the condition of your item)$/.test(
    norm(label2)
  );
  var knownChoice = (label2) => /^(?:new|new without tags|new with tags|new other|new with defects|open box|used|pre owned|preowned|for parts or not working|like new|very good|good|acceptable|excellent|very good condition|good condition)$/.test(
    norm(label2)
  );
  function visible(node) {
    if (node.closest('[hidden],[aria-hidden="true"]')) return false;
    const win = node.ownerDocument.defaultView;
    for (let current = node; current; current = current.parentElement) {
      const style = win?.getComputedStyle(current);
      if (style?.display === "none" || style?.visibility === "hidden" || style?.visibility === "collapse")
        return false;
    }
    return true;
  }
  function visibleInside(node, scope) {
    const win = node.ownerDocument.defaultView;
    for (let current = node; current && current !== scope; current = current.parentElement) {
      if (current.hasAttribute("hidden") || current.getAttribute("aria-hidden") === "true")
        return false;
      const style = win?.getComputedStyle(current);
      if (style?.display === "none" || style?.visibility === "hidden" || style?.visibility === "collapse")
        return false;
    }
    return true;
  }
  function enabled(node) {
    return !node.closest(
      '[disabled],[readonly],[aria-disabled="true"],[aria-readonly="true"]'
    ) && !node.hasAttribute("disabled") && !node.hasAttribute("readonly") && node.getAttribute("aria-disabled") !== "true" && node.getAttribute("aria-readonly") !== "true";
  }
  function label(node) {
    const labelled = node.getAttribute("aria-labelledby")?.split(/\s+/).map((id) => node.ownerDocument.getElementById(id)?.textContent ?? "").join(" ");
    return compact(
      node.getAttribute("aria-label") || labelled || node.labels?.[0]?.textContent || node.closest("label")?.textContent || ""
    );
  }
  function nativeSummaryButton(node) {
    return node.matches('button[name="condition"]') && !!node.closest(nativeSummarySelector);
  }
  function nativeSummaryTrigger(node) {
    if (!nativeSummaryButton(node) || node.getAttribute("type") !== "button" || !node.id || !node.isConnected)
      return false;
    const scope = node.closest(nativeSummarySelector);
    const ids = (node.getAttribute("aria-labelledby") ?? "").trim().split(/\s+/).filter(Boolean);
    if (ids.length !== 2 || new Set(ids).size !== 2 || !ids.includes(node.id))
      return false;
    const references = ids.map((id) => {
      const matches = node.ownerDocument.querySelectorAll(`#${CSS.escape(id)}`);
      return matches.length === 1 ? matches[0] : null;
    });
    const heading = references.find((reference) => reference !== node);
    return references.includes(node) && !!heading && scope.contains(heading) && heading.matches('h2,h3,[role="heading"]') && exactConditionLabel(heading.textContent ?? "", ITEM_CONDITION_LABEL);
  }
  function rememberNativeSummary(current) {
    if (!nativeSummaryTrigger(current.el) || !visible(current.el)) return;
    nativeSummaryOwners.set(current.el.ownerDocument, {
      el: current.el,
      scope: current.el.closest(nativeSummarySelector),
      value: current.field.value,
      labelledBy: current.el.getAttribute("aria-labelledby")
    });
  }
  function maskedNativeSummary(doc, dialog) {
    const saved = nativeSummaryOwners.get(doc);
    if (!saved) return null;
    if (saved.el.ownerDocument !== doc || !nativeSummaryTrigger(saved.el) || saved.el.closest(nativeSummarySelector) !== saved.scope || saved.el.getAttribute("aria-labelledby") !== saved.labelledBy || triggerText(saved.el) !== saved.value || !enabled(saved.el) || !saved.el.closest('[aria-hidden="true"]') || saved.dialog && saved.dialog !== dialog) {
      nativeSummaryOwners.delete(doc);
      return null;
    }
    saved.dialog = dialog;
    return saved;
  }
  function dialogName(node) {
    return label(node) || compact(
      [...node.querySelectorAll('h1,h2,h3,[role="heading"]')].filter(
        (heading) => heading.closest(dialogSelector) === node && visibleInside(heading, node)
      ).map((heading) => heading.textContent ?? "").find((text) => exactConditionLabel(text, ITEM_CONDITION_LABEL)) ?? ""
    );
  }
  function isConditionDialog(node) {
    return node.matches(dialogSelector) && exactConditionLabel(dialogName(node), ITEM_CONDITION_LABEL);
  }
  function openDialogs(doc) {
    return [...doc.querySelectorAll(dialogSelector)].filter(
      (node) => visible(node) && !(node.tagName === "DIALOG" && !node.hasAttribute("open")) && !node.parentElement?.closest(dialogSelector)
    );
  }
  function openConditionDialogs(doc) {
    return openDialogs(doc).filter(isConditionDialog);
  }
  function soleConditionDialog(doc) {
    const dialogs = openDialogs(doc);
    return dialogs.length === 1 && isConditionDialog(dialogs[0]) ? dialogs[0] : null;
  }
  function radioTitle(node) {
    const direct = node.getAttribute("aria-label");
    if (direct) return compact(direct);
    const described = new Set(
      (node.getAttribute("aria-describedby") ?? "").split(/\s+/).filter(Boolean)
    );
    const refs = (node.getAttribute("aria-labelledby") ?? "").split(/\s+/).filter(Boolean).map((id) => node.ownerDocument.getElementById(id)).filter((el) => !!el);
    const explanatory = (el) => typeof el === "string" ? compact(el).length > 40 : described.has(el.id) || el.matches(
      "p,[data-condition-description],.radio__description,.radio__help-text"
    ) || compact(el.textContent ?? "").length > 40;
    if (refs.length > 1) {
      const text = compact(refs.map((el) => el.textContent ?? "").join(" "));
      if (knownChoice(text)) return text;
      return refs.slice(1).every(explanatory) ? compact(refs[0].textContent ?? "") : text;
    }
    const labels = [...node.labels ?? []];
    const source = refs.length === 1 ? refs[0] : labels.length === 1 ? labels[0] : node.closest("label");
    if (!source || !refs.length && labels.length > 1) return label(node);
    const full = compact(source.textContent ?? "");
    if (knownChoice(full)) return full;
    let container = source;
    for (let depth = 0; depth < 4; depth++) {
      const parts = [...container.childNodes].flatMap(
        (part) => {
          if (part.nodeType === 3)
            return compact(part.textContent ?? "") ? [part.textContent ?? ""] : [];
          if (part.nodeType !== 1) return [];
          const el = part;
          return el === node || el.matches('input,svg,[aria-hidden="true"]') || !visibleInside(el, node.closest(dialogSelector) ?? source) ? [] : [el];
        }
      );
      if (parts.length === 1 && typeof parts[0] !== "string") {
        container = parts[0];
        continue;
      }
      if (parts.length > 1 && parts.slice(1).every(explanatory))
        return compact(
          typeof parts[0] === "string" ? parts[0] : parts[0].textContent ?? ""
        );
      break;
    }
    return full;
  }
  function choiceLabel(node) {
    if (node.matches('input[type="radio"]')) {
      const dialog = node.closest(dialogSelector);
      return dialog && isConditionDialog(dialog) ? radioTitle(node) : label(node);
    }
    return compact(
      node.getAttribute("aria-label") || node.querySelector(
        ".btn__text,.toggle-button__text,[data-condition-label]"
      )?.textContent || node.textContent || ""
    );
  }
  function dialogChoices(dialog) {
    return [
      ...dialog.querySelectorAll('input[type="radio"]')
    ].filter(
      (node) => node.closest(dialogSelector) === dialog && visible(node) && enabled(node) && !!choiceLabel(node)
    );
  }
  function dialogDone(dialog, requireEnabled = true) {
    const done = [
      ...dialog.querySelectorAll('button,[role="button"]')
    ].filter(
      (node) => node.closest(dialogSelector) === dialog && visible(node) && exactConditionLabel(label(node) || node.textContent || "", "Done") && (!compact(node.textContent ?? "") || exactConditionLabel(node.textContent ?? "", "Done"))
    );
    return done.length === 1 && (!requireEnabled || enabled(done[0])) ? done[0] : null;
  }
  function staticConditionValue(scope) {
    if (!scope.matches(nativeSummarySelector)) return null;
    const staticNode = (node) => visible(node) && !node.closest(dialogSelector) && !node.closest(
      'button,[role="button"],label,[role="radio"],[role="option"]'
    ) && !node.querySelector('input,select,button,[role="radio"],[role="button"]');
    let values = [
      ...scope.querySelectorAll("[data-condition-value],.summary__value")
    ].filter(
      (node) => staticNode(node) && !!compact(node.textContent ?? "") && !conditionLabel(node.textContent ?? "")
    );
    if (!values.length)
      values = [...scope.querySelectorAll("p,span")].filter(
        (node) => staticNode(node) && knownChoice(node.textContent ?? "")
      );
    values.push(
      ...[...scope.querySelectorAll('button[name="condition"]')].filter(
        (node) => visible(node) && nativeSummaryTrigger(node)
      )
    );
    values = values.filter(
      (node) => !values.some((other) => other !== node && other.contains(node))
    );
    return values.length === 1 ? nativeSummaryButton(values[0]) ? triggerText(values[0]) : compact(values[0].textContent ?? "") : null;
  }
  function selected(node) {
    return node.matches('input[type="radio"]') && node.checked || node.getAttribute("aria-checked") === "true" || node.getAttribute("aria-selected") === "true" || node.getAttribute("aria-pressed") === "true" || node.getAttribute("data-selected") === "true" || node.matches(
      ".selected,.is-selected,.toggle-button--selected,.btn--selected"
    );
  }
  function choices(scope, includeHidden = false) {
    return [...scope.querySelectorAll(choiceSelector)].filter(
      (node) => enabled(node) && !nativeSummaryButton(node) && (includeHidden ? visibleInside(node, scope) : visible(node)) && (node.matches(
        'input[type="radio"],[role="radio"],[role="menuitemradio"],[role="option"]'
      ) || knownChoice(choiceLabel(node))) && !!choiceLabel(node) && !node.querySelector('input[type="radio"],[role="radio"]')
    );
  }
  function overflowCandidates(scope) {
    return [
      ...scope.querySelectorAll('button,[role="button"]')
    ].filter(
      (node) => visible(node) && enabled(node) && [label(node), node.textContent ?? ""].some(
        (text) => /^(?:\.{3}|…|more options)$/i.test(compact(text))
      )
    );
  }
  function overflowTrigger(scope, controlsId) {
    const candidates = overflowCandidates(scope);
    if (candidates.length !== 1) return null;
    const trigger = candidates[0];
    const ids = trigger.getAttribute("aria-controls")?.trim().split(/\s+/);
    if (ids?.length !== 1 || !ids[0] || controlsId && ids[0] !== controlsId)
      return null;
    const attached = [
      ...scope.ownerDocument.querySelectorAll(`#${CSS.escape(ids[0])}`)
    ];
    if (attached.length > 1 || attached.some(
      (popup) => popup === scope.ownerDocument.body || popup === scope.ownerDocument.documentElement || popup.contains(scope)
    ))
      return null;
    return trigger;
  }
  function controlledOverflow(scope, controlsId) {
    const trigger = overflowTrigger(scope, controlsId);
    if (!trigger) return null;
    const popup = scope.ownerDocument.getElementById(
      trigger.getAttribute("aria-controls").trim()
    );
    return popup && popup !== scope.ownerDocument.body && popup !== scope.ownerDocument.documentElement && !popup.contains(scope) ? popup : null;
  }
  function primaryChoices(scope) {
    const popup = controlledOverflow(scope);
    return choices(scope).filter((node) => !popup?.contains(node));
  }
  function actualOverflowChoices(scope) {
    const observed = observedOverflows.get(scope);
    const popup = controlledOverflow(scope, observed?.controlsId);
    return popup ? choices(popup, true) : [];
  }
  function distinctOptions(options) {
    return options.filter(
      (option, i) => !options.slice(0, i).some((before) => exactConditionLabel(before.label, option.label))
    );
  }
  function mergeConditionOptions(primary, additional) {
    return [
      ...primary,
      ...additional.filter(
        (option) => !primary.some(
          (known) => exactConditionLabel(known.label, option.label)
        )
      )
    ];
  }
  function conditionScopes(doc) {
    const scopes = /* @__PURE__ */ new Set();
    for (const node of doc.querySelectorAll(
      '.summary__condition,[data-testid="condition"],[data-testid="item-condition"],[data-field="condition"]'
    ))
      if (visible(node)) scopes.add(node);
    for (const heading of doc.querySelectorAll(
      'h1,h2,h3,legend,[role="heading"]'
    )) {
      if (!visible(heading) || !conditionLabel(heading.textContent ?? ""))
        continue;
      const scope = heading.closest(scopeSelector) ?? heading.parentElement;
      if (scope && scope !== doc.body && scope !== doc.documentElement)
        scopes.add(scope);
    }
    return [...scopes];
  }
  function triggerText(node) {
    const value = compact(
      node.querySelector(".btn__text,[data-condition-value]")?.textContent ?? node.textContent ?? ""
    );
    const clean = value.replace(/^item condition\s*[:—–-]?\s*/i, "").trim();
    return conditionLabel(clean) || /^(?:select|select one|choose|—|–|-)$/i.test(clean) ? "" : clean;
  }
  function menuFor(node) {
    const id = node.getAttribute("aria-controls");
    if (id) return node.ownerDocument.getElementById(id);
    const dialogs = [
      ...node.ownerDocument.querySelectorAll('[role="dialog"]')
    ].filter(
      (dialog) => visible(dialog) && [...dialog.querySelectorAll('h2,h3,[role="heading"]')].some(
        (heading) => conditionLabel(heading.textContent ?? "")
      )
    );
    return dialogs.length === 1 ? dialogs[0] : null;
  }
  function conditionValue(node) {
    const mode = controls.get(node);
    if (!mode) return void 0;
    if (mode === "select") {
      const select = node;
      return select.value ? compact(select.selectedOptions[0]?.textContent ?? "") : "";
    }
    if (mode === "menu") {
      const summary = node.closest(nativeSummarySelector);
      return (summary && staticConditionValue(summary)) ?? triggerText(node);
    }
    if (mode === "dialog") return dialogBaselines.get(node) ?? "";
    if (mode === "unsupported") {
      const value = staticConditionValue(node);
      if (value !== null) return value;
    }
    const picked = [
      ...primaryChoices(node),
      ...actualOverflowChoices(node)
    ].filter(selected);
    const labels = distinctOptions(
      picked.map((option) => ({
        label: choiceLabel(option),
        value: choiceLabel(option)
      }))
    );
    return labels.length === 1 ? labels[0].label : "";
  }
  function resolveConditionControl(doc, excludedDialog, ambiguity) {
    const scopes = conditionScopes(doc).filter(
      (scope) => !excludedDialog?.contains(scope)
    ), candidates = /* @__PURE__ */ new Map();
    for (const node of doc.querySelectorAll(
      'select,button,[role="combobox"][aria-controls]'
    )) {
      if (!visible(node) || excludedDialog?.contains(node)) continue;
      if (nativeSummaryButton(node) && !nativeSummaryTrigger(node)) continue;
      if (conditionLabel(label(node)) || nativeSummaryTrigger(node) || controls.get(node) === "menu" && scopes.some((scope) => scope.contains(node)) || node.tagName === "SELECT" && scopes.some((scope) => scope.contains(node)))
        candidates.set(node, node.tagName === "SELECT" ? "select" : "menu");
    }
    for (const scope of scopes) {
      if (scopes.some(
        (other) => other !== scope && controlledOverflow(other)?.contains(scope)
      ))
        continue;
      if ([...candidates].some(
        ([node, mode2]) => mode2 === "menu" && menuFor(node)?.contains(scope)
      ))
        continue;
      if ([...candidates.keys()].some((node) => scope.contains(node))) continue;
      const options2 = primaryChoices(scope).filter(
        (node) => !excludedDialog?.contains(node)
      );
      if (options2.length) candidates.set(scope, "choices");
      else {
        const triggers = [
          ...scope.querySelectorAll('button,[role="button"]')
        ].filter(
          (node) => !excludedDialog?.contains(node) && visible(node) && (!nativeSummaryButton(node) || nativeSummaryTrigger(node)) && (conditionLabel(label(node)) || conditionLabel(node.textContent ?? "") || /^item condition\s*[:—–-]/i.test(compact(node.textContent ?? "")))
        );
        if (triggers.length === 1) candidates.set(triggers[0], "menu");
        else if (!triggers.length) {
          const edits = staticConditionValue(scope) !== null ? [
            ...scope.querySelectorAll(
              'button,[role="button"]'
            )
          ].filter(
            (node) => !excludedDialog?.contains(node) && visible(node) && /^(?:edit|edit condition|edit item condition)$/i.test(
              label(node) || compact(node.textContent ?? "")
            )
          ) : [];
          if (edits.length === 1) candidates.set(edits[0], "menu");
          else if (edits.length > 1) {
            if (ambiguity) ambiguity.value = true;
            return null;
          } else candidates.set(scope, "unsupported");
        }
      }
    }
    const unique = [...candidates].filter(
      ([node]) => ![...candidates.keys()].some(
        (other) => other !== node && node.contains(other)
      )
    );
    if (unique.length !== 1) {
      if (unique.length > 1 && ambiguity) ambiguity.value = true;
      return null;
    }
    const [el, mode] = unique[0];
    controls.set(el, mode);
    const nativeOptions = mode === "select" ? [...el.options].filter((option) => option.value && !option.disabled).map((option) => ({
      value: option.value,
      label: compact(option.textContent ?? "")
    })) : mode === "choices" ? primaryChoices(el).filter((node) => !excludedDialog?.contains(node)).map((node) => ({
      value: choiceLabel(node),
      label: choiceLabel(node)
    })) : mode === "menu" && menuFor(el) ? choices(menuFor(el), true).map((node) => ({
      value: choiceLabel(node),
      label: choiceLabel(node)
    })) : [];
    if (mode === "menu" && nativeOptions.length)
      observedOptions.set(el, nativeOptions);
    let options = mode === "menu" && !menuFor(el) ? observedOptions.get(el) ?? nativeOptions : nativeOptions;
    const overflow = mode === "choices" && observedOverflows.get(el);
    if (overflow && overflowTrigger(el, overflow.controlsId)) {
      const popup = controlledOverflow(el, overflow.controlsId);
      const additional = popup ? actualOverflowChoices(el).map((node) => ({
        value: choiceLabel(node),
        label: choiceLabel(node)
      })) : overflow.options;
      options = mergeConditionOptions(options, additional);
    }
    return {
      el,
      field: {
        key: ITEM_CONDITION_KEY,
        label: ITEM_CONDITION_LABEL,
        value: mode === "choices" && excludedDialog ? (() => {
          const picked = primaryChoices(el).filter(
            (node) => !excludedDialog.contains(node) && selected(node)
          );
          const labels = distinctOptions(
            picked.map((node) => ({
              value: choiceLabel(node),
              label: choiceLabel(node)
            }))
          );
          return labels.length === 1 ? labels[0].label : "";
        })() : conditionValue(el) ?? "",
        kind: mode === "select" ? "select" : mode === "unsupported" ? "unsupported" : "menu",
        writable: mode !== "unsupported" && enabled(el) && visible(el) && (mode !== "select" || !el.multiple),
        selector: el.id ? `#${CSS.escape(el.id)}` : `${el.tagName.toLowerCase()} (label: Item condition)`,
        options: options.length ? options : void 0
      }
    };
  }
  function resolveCondition(doc) {
    const nativeDialogs = openConditionDialogs(doc).filter(
      (dialog2) => !!dialog2.querySelector('input[type="radio"]')
    );
    if (!nativeDialogs.length) {
      nativeSummaryOwners.delete(doc);
      return resolveConditionControl(doc);
    }
    const dialog = soleConditionDialog(doc);
    if (!dialog || nativeDialogs.length !== 1) {
      nativeSummaryOwners.delete(doc);
      return null;
    }
    const ambiguity = { value: false };
    let underlying = resolveConditionControl(doc, dialog, ambiguity);
    if (ambiguity.value || underlying?.el.tagName === "SELECT") {
      nativeSummaryOwners.delete(doc);
      return null;
    }
    const remembered = nativeSummaryOwners.get(doc);
    if (remembered && (remembered.el.ownerDocument !== doc || !remembered.el.isConnected || !visible(remembered.el))) {
      const saved = maskedNativeSummary(doc, dialog);
      if (!saved || underlying && underlying.el !== saved.el) {
        nativeSummaryOwners.delete(doc);
        return null;
      }
      underlying = {
        el: saved.el,
        field: {
          key: ITEM_CONDITION_KEY,
          label: ITEM_CONDITION_LABEL,
          value: saved.value,
          kind: "menu",
          writable: false,
          selector: `#${CSS.escape(saved.el.id)}`
        }
      };
    }
    const el = underlying?.el ?? dialog;
    const options = dialogChoices(dialog).map((node) => ({
      value: choiceLabel(node),
      label: choiceLabel(node)
    }));
    if (underlying) observedOptions.set(underlying.el, options);
    controls.set(el, "dialog");
    dialogOwners.set(el, dialog);
    dialogBaselines.set(el, underlying?.field.value ?? "");
    return {
      el,
      field: {
        key: ITEM_CONDITION_KEY,
        label: ITEM_CONDITION_LABEL,
        value: underlying?.field.value ?? "",
        kind: "menu",
        writable: enabled(dialog) && !!dialogDone(dialog, false) && !!options.length,
        selector: el.id ? `#${CSS.escape(el.id)}` : `${el.tagName.toLowerCase()} (label: Item condition)`,
        options: options.length ? options : void 0
      }
    };
  }
  async function restoreOverflowPopup(doc, controlsId, wasOpen, originalScope) {
    if (wasOpen) return;
    const fresh = resolveCondition(doc);
    const scope = fresh && controls.get(fresh.el) === "choices" ? fresh.el : originalScope?.isConnected ? originalScope : null;
    if (!scope) return;
    const trigger = overflowTrigger(scope, controlsId);
    const popup = trigger && controlledOverflow(scope, controlsId);
    if (trigger && (trigger.getAttribute("aria-expanded") === "true" || popup && visible(popup))) {
      trigger.click();
      await delay(80);
    }
  }
  async function prepareOverflow(doc, current, valid) {
    const candidates = overflowCandidates(current.el);
    if (!candidates.length) {
      overflowNotes.delete(current.el);
      return current;
    }
    const trigger = overflowTrigger(current.el);
    if (!trigger) {
      observedOverflows.delete(current.el);
      overflowNotes.set(
        current.el,
        "Autres choix de condition non inspect\xE9s : bouton d\u2019options ambigu ou sans lien natif explicite. Pr\xE9f\xE9rence limit\xE9e aux choix visibles."
      );
      return current;
    }
    const controlsId = trigger.getAttribute("aria-controls").trim();
    const popup = controlledOverflow(current.el, controlsId);
    const wasOpen = trigger.getAttribute("aria-expanded") === "true" || !!(popup && visible(popup));
    if (!valid())
      throw Error("Condition : brouillon chang\xE9 ou AurOEBay en pause.");
    if (!wasOpen) trigger.click();
    try {
      await delay(180);
      if (!valid())
        throw Error("Condition : brouillon chang\xE9 ou AurOEBay en pause.");
      const fresh = resolveCondition(doc);
      if (!fresh || controls.get(fresh.el) !== "choices" || !overflowTrigger(fresh.el, controlsId))
        return current;
      const opened = controlledOverflow(fresh.el, controlsId);
      if (!opened || !visible(opened)) {
        observedOverflows.delete(fresh.el);
        overflowNotes.set(
          fresh.el,
          "Autres choix de condition non inspect\xE9s : le menu natif d\u2019options n\u2019est pas disponible. Pr\xE9f\xE9rence limit\xE9e aux choix visibles."
        );
        return resolveCondition(doc);
      }
      const options = choices(opened).map((node) => ({
        value: choiceLabel(node),
        label: choiceLabel(node)
      }));
      observedOverflows.set(fresh.el, { controlsId, options });
      const primary = primaryChoices(fresh.el).map(choiceLabel);
      const ambiguous = options.some(
        (option) => !primary.some((known) => exactConditionLabel(known, option.label)) && options.filter(
          (other) => exactConditionLabel(other.label, option.label)
        ).length > 1
      );
      if (ambiguous)
        overflowNotes.set(
          fresh.el,
          "Autres choix de condition ambigus : plusieurs options portent le m\xEAme libell\xE9. Pr\xE9f\xE9rence limit\xE9e aux choix non ambigus."
        );
      else if (options.length) overflowNotes.delete(fresh.el);
      else
        overflowNotes.set(
          fresh.el,
          "Autres choix de condition non inspect\xE9s : aucun choix natif lisible dans ce menu. Pr\xE9f\xE9rence limit\xE9e aux choix visibles."
        );
      return resolveCondition(doc);
    } finally {
      await restoreOverflowPopup(doc, controlsId, wasOpen, current.el);
    }
  }
  function conditionInspectionNote(doc) {
    const current = resolveCondition(doc);
    const note = current && overflowNotes.get(current.el);
    return note ? ` ${note}` : "";
  }
  async function finishConditionInspection(doc, current, valid) {
    if (!current || controls.get(current.el) !== "dialog") return current;
    if (current.field.value && await commitConditionDialog(doc, current.field.value, valid))
      return resolveCondition(doc);
    const dialog = dialogOwners.get(current.el);
    const exits = dialog && soleConditionDialog(doc) === dialog ? [
      ...dialog.querySelectorAll('button,[role="button"]')
    ].filter(
      (node) => node.closest(dialogSelector) === dialog && visible(node) && enabled(node) && /^(?:cancel|close)$/i.test(
        label(node) || compact(node.textContent ?? "")
      )
    ) : [];
    if (exits.length === 1) {
      assertConditionContext(valid);
      exits[0].click();
      for (let attempt = 0; attempt < 40; attempt++) {
        await delay(100);
        assertConditionContext(valid);
        if (openDialogs(doc).length) continue;
        const retained = resolveCondition(doc);
        if (retained && exactConditionLabel(retained.field.value, current.field.value))
          return retained;
      }
    }
    throw Error(
      "Item condition : dialogue natif non refermable sans modifier ce choix ; ferme-le dans eBay puis recommence."
    );
  }
  async function prepareCondition(doc, valid) {
    let current = resolveCondition(doc);
    if (current && controls.get(current.el) === "dialog")
      return finishConditionInspection(doc, current, valid);
    const summary = current?.el.closest(nativeSummarySelector);
    const savedSummary = summary && staticConditionValue(summary);
    if (current && controls.get(current.el) === "menu" && savedSummary && exactConditionLabel(savedSummary, "New without tags") && !current.el.getAttribute("aria-controls")?.trim() && !menuFor(current.el)) {
      observedOptions.set(current.el, [
        { value: savedSummary, label: savedSummary }
      ]);
      overflowNotes.delete(current.el);
      return resolveCondition(doc);
    }
    if (current?.field.writable && controls.get(current.el) === "choices")
      return prepareOverflow(doc, current, valid);
    if (!current || controls.get(current.el) !== "menu" || menuFor(current.el) && choices(menuFor(current.el), true).length || !current.field.writable)
      return current;
    if (!valid())
      throw Error("Condition : brouillon chang\xE9 ou AurOEBay en pause.");
    const trigger = current.el, wasOpen = trigger.getAttribute("aria-expanded") === "true" || !!(menuFor(trigger) && visible(menuFor(trigger)));
    if (!wasOpen) {
      rememberNativeSummary(current);
      trigger.click();
    }
    let inspectedDialog = false;
    try {
      await delay(180);
      if (!valid())
        throw Error("Condition : brouillon chang\xE9 ou AurOEBay en pause.");
      current = resolveCondition(doc);
      inspectedDialog = !!current && controls.get(current.el) === "dialog";
      return finishConditionInspection(doc, current, valid);
    } finally {
      const fresh = resolveCondition(doc);
      if (!inspectedDialog && !wasOpen && fresh && controls.get(fresh.el) === "menu" && fresh.el.getAttribute("aria-expanded") === "true")
        fresh.el.click();
    }
  }
  function assertConditionContext(valid) {
    if (!valid())
      throw Error("Condition : brouillon chang\xE9 ou AurOEBay en pause.");
  }
  async function commitConditionDialog(doc, value, valid) {
    assertConditionContext(valid);
    let current = resolveCondition(doc);
    let dialog = current && dialogOwners.get(current.el);
    if (!value || !current?.field.writable || controls.get(current.el) !== "dialog" || !dialog || soleConditionDialog(doc) !== dialog || !dialogDone(dialog, false))
      return false;
    let matches = dialogChoices(dialog).filter(
      (node) => exactConditionLabel(choiceLabel(node), value)
    );
    const groupNames = new Set(dialogChoices(dialog).map((node) => node.name));
    if (matches.length !== 1 || groupNames.size !== 1) return false;
    assertConditionContext(valid);
    if (!selected(matches[0])) matches[0].click();
    await delay(100);
    assertConditionContext(valid);
    current = resolveCondition(doc);
    dialog = current && dialogOwners.get(current.el);
    if (!current?.field.writable || controls.get(current.el) !== "dialog" || !dialog || soleConditionDialog(doc) !== dialog)
      return false;
    matches = dialogChoices(dialog).filter(
      (node) => exactConditionLabel(choiceLabel(node), value)
    );
    const picked = dialogChoices(dialog).filter(selected);
    const done = dialogDone(dialog);
    if (matches.length !== 1 || new Set(dialogChoices(dialog).map((node) => node.name)).size !== 1 || picked.length !== 1 || picked[0] !== matches[0] || !done)
      return false;
    assertConditionContext(valid);
    done.click();
    for (let attempt = 0; attempt < 40; attempt++) {
      await delay(100);
      assertConditionContext(valid);
      if (openDialogs(doc).length) continue;
      const retained = resolveCondition(doc);
      if (retained && controls.get(retained.el) !== "dialog" && exactConditionLabel(retained.field.value, value))
        return true;
    }
    throw Error("Item condition : eBay did not retain the value after Done.");
  }
  async function chooseCondition(doc, value, valid = () => true) {
    assertConditionContext(valid);
    let current = resolveCondition(doc);
    if (!current?.field.writable) return false;
    const mode = controls.get(current.el);
    if (mode === "dialog") return commitConditionDialog(doc, value, valid);
    if (mode === "select") {
      const select = current.el;
      const options = [...select.options].filter(
        (option) => !option.disabled && option.value === value
      );
      if (options.length !== 1) return false;
      const win = doc.defaultView;
      Object.getOwnPropertyDescriptor(
        win.HTMLSelectElement.prototype,
        "value"
      ).set.call(select, value);
      select.dispatchEvent(
        new win.Event("input", { bubbles: true, composed: true })
      );
      select.dispatchEvent(
        new win.Event("change", { bubbles: true, composed: true })
      );
      return;
    }
    const trigger = mode === "menu" ? current.el : null;
    const wasOpen = trigger?.getAttribute("aria-expanded") === "true" || !!(trigger && menuFor(trigger) && visible(menuFor(trigger)));
    if (trigger && !wasOpen) {
      rememberNativeSummary(current);
      trigger.click();
    }
    let overflowControlsId;
    let overflowWasOpen = false;
    let usedDialog = false;
    if (mode === "choices") {
      const visibleMatches = primaryChoices(current.el).filter(
        (node) => exactConditionLabel(choiceLabel(node), value)
      );
      const needsOverflow = value ? visibleMatches.length === 0 : !primaryChoices(current.el).some(selected) && actualOverflowChoices(current.el).some(selected);
      const observed = observedOverflows.get(current.el);
      if (needsOverflow && observed && (!value || observed.options.some(
        (option) => exactConditionLabel(option.label, value)
      ))) {
        const overflow = overflowTrigger(current.el, observed.controlsId);
        if (!overflow) return false;
        overflowControlsId = observed.controlsId;
        const popup = controlledOverflow(current.el, overflowControlsId);
        overflowWasOpen = overflow.getAttribute("aria-expanded") === "true" || !!(popup && visible(popup));
        if (!overflowWasOpen) overflow.click();
      } else if (needsOverflow) return false;
    }
    try {
      if (trigger || overflowControlsId) await delay(180);
      assertConditionContext(valid);
      current = resolveCondition(doc);
      if (!current?.field.writable) return false;
      if (controls.get(current.el) === "dialog") {
        usedDialog = true;
        return commitConditionDialog(doc, value, valid);
      }
      const scope = overflowControlsId ? controlledOverflow(current.el, overflowControlsId) : controls.get(current.el) === "menu" ? menuFor(current.el) : current.el;
      if (!scope || !visible(scope)) return false;
      if (!value) {
        const clear = [
          ...scope.querySelectorAll('button,[role="button"]')
        ].filter(
          (node) => visible(node) && enabled(node) && /^(?:clear|clear selection|select|select one)$/i.test(
            choiceLabel(node)
          )
        );
        if (clear.length === 1) clear[0].click();
        else {
          const picked = choices(scope).filter(selected);
          if (picked.every((node) => node.matches('input[type="radio"]'))) {
            const win = doc.defaultView;
            for (const node of picked) {
              Object.getOwnPropertyDescriptor(
                win.HTMLInputElement.prototype,
                "checked"
              ).set.call(node, false);
              node.dispatchEvent(
                new win.Event("input", { bubbles: true, composed: true })
              );
              node.dispatchEvent(
                new win.Event("change", { bubbles: true, composed: true })
              );
            }
          } else if (picked.length === 1 && picked[0].hasAttribute("aria-pressed"))
            picked[0].click();
          else
            throw Error(
              "Item condition : s\xE9lection initiale vide non restaurable automatiquement."
            );
        }
        return;
      }
      const matches = choices(scope).filter(
        (node) => exactConditionLabel(choiceLabel(node), value)
      );
      if (matches.length !== 1) return false;
      if (!matches[0].isConnected || !visible(matches[0]) || !enabled(matches[0]))
        return false;
      matches[0].click();
      await delay(140);
    } finally {
      if (overflowControlsId)
        await restoreOverflowPopup(doc, overflowControlsId, overflowWasOpen);
      const fresh = resolveCondition(doc);
      if (!usedDialog && trigger && !wasOpen && fresh && controls.get(fresh.el) === "menu" && fresh.el.getAttribute("aria-expanded") === "true")
        fresh.el.click();
    }
  }

  // src/ebay/fieldResolver.ts
  var controlSelector = 'input:not([type="hidden"]):not([type="checkbox"]):not([type="radio"]):not([type="submit"]):not([type="button"]),textarea,select,[contenteditable="true"],[role="combobox"],button[name^="attributes."],button[aria-controls]';
  function labelOf(el) {
    if (el.matches('button[name^="attributes."]'))
      return compact(el.getAttribute("name").slice("attributes.".length));
    const direct = el.getAttribute("aria-label");
    if (direct) return compact(direct);
    const by = el.getAttribute("aria-labelledby")?.split(/\s+/).map((id) => el.ownerDocument.getElementById(id)?.textContent ?? "").join(" ");
    if (by) return compact(by);
    const labels = el.labels;
    if (labels?.length) return compact(labels[0].textContent ?? "");
    const wrap = el.closest("label");
    if (wrap) return compact(wrap.textContent ?? "");
    const near = el.closest("[data-field],.field,.form-field,.ux-labels-values,fieldset")?.querySelector("label,legend,[data-label]");
    if (near) return compact(near.textContent ?? "");
    return el.getAttribute("name") ?? el.id;
  }
  function isNativeMenuControl(el) {
    return el.matches("button[aria-controls]") && (el.matches('button[name^="attributes."]') || manufactureLabel(labelOf(el)));
  }
  function readValue(el) {
    const condition = conditionValue(el);
    if (condition !== void 0) return condition;
    if (el.matches('button[name^="attributes."]') || isNativeMenuControl(el)) {
      const value = compact(
        el.querySelector(".btn__text")?.textContent ?? el.textContent ?? ""
      );
      return norm(value) === norm(labelOf(el)) || /^(select|select one|choose|selectionner)$/.test(norm(value)) ? "" : value;
    }
    if (el.tagName === "SELECT") {
      const s = el;
      return s.value ? s.selectedOptions[0]?.textContent?.trim() ?? s.value : "";
    }
    if ("value" in el) return String(el.value);
    return editableHTML(el);
  }
  function rawValue(el) {
    const condition = conditionValue(el);
    if (condition !== void 0 && el.tagName !== "SELECT") return condition;
    if (el.matches('button[name^="attributes."]') || isNativeMenuControl(el))
      return readValue(el);
    return "value" in el ? String(el.value) : editableHTML(el);
  }
  function usable(el) {
    if (el.closest('[hidden],[aria-hidden="true"]') || el.getAttribute("type") === "hidden")
      return false;
    const win = el.ownerDocument.defaultView;
    if (win)
      for (let node = el; node; node = node.parentElement) {
        const style = win.getComputedStyle(node);
        if (style.display === "none" || style.visibility === "hidden" || style.visibility === "collapse")
          return false;
      }
    return true;
  }
  function selectorFor(el) {
    if (el.id) return `#${CSS.escape(el.id)}`;
    for (const attr of ["data-testid", "name", "aria-label"]) {
      const val = el.getAttribute(attr);
      if (val) return `${el.tagName.toLowerCase()}[${attr}="${CSS.escape(val)}"]`;
    }
    return `${el.tagName.toLowerCase()} (label: ${labelOf(el)})`;
  }
  function resolveElement(el, key, label2) {
    if (el.tagName === "IFRAME") {
      try {
        if (!usable(el)) return null;
        const body = el.contentDocument?.body;
        const editors = body ? [...body.querySelectorAll('[contenteditable="true"]')].filter(usable) : [];
        if (editors.length === 1) el = editors[0];
        else if (editors.length > 1) return null;
        else if (body && (body.isContentEditable || body.contentEditable === "true" || body.ownerDocument.designMode === "on"))
          el = body;
        else return null;
      } catch {
        return null;
      }
    }
    if (!el.matches(controlSelector) && el.tagName !== "BODY") return null;
    if (el.matches("button[aria-controls]") && !el.matches('button[name^="attributes."]') && !isNativeMenuControl(el))
      return null;
    const select = el.tagName === "SELECT";
    const text = ["INPUT", "TEXTAREA"].includes(el.tagName);
    const html = !text && !select && (el.getAttribute("contenteditable") === "true" || el.tagName === "BODY");
    const menu = isNativeMenuControl(el);
    const kind = menu ? "menu" : select ? "select" : el.tagName === "TEXTAREA" ? "textarea" : text ? "text" : html ? "html" : "unsupported";
    const unsupported = el.getAttribute("role") === "combobox" || select && el.multiple || ["INPUT"].includes(el.tagName) && !["text", "search", "number", ""].includes(
      el.getAttribute("type") ?? ""
    );
    const writable = kind !== "unsupported" && !unsupported && !el.hasAttribute("disabled") && !el.hasAttribute("readonly") && el.getAttribute("aria-readonly") !== "true" && el.getAttribute("aria-disabled") !== "true" && usable(el);
    const menuOptions = menu ? [
      ...el.ownerDocument.getElementById(el.getAttribute("aria-controls"))?.querySelectorAll(
        '[role="menuitemradio"],[role="menuitemcheckbox"],[role="option"],.se-toggle-group-menu__menu-container button.toggle-button'
      ) ?? []
    ].filter((o) => o.getAttribute("aria-disabled") !== "true").map((o) => ({
      value: compact(o.textContent ?? ""),
      label: compact(o.textContent ?? "")
    })).filter(
      (o, i, all) => o.value && all.findIndex((x) => norm(x.value) === norm(o.value)) === i
    ) : [];
    return {
      el,
      field: {
        key,
        label: label2,
        value: readValue(el),
        kind: unsupported ? "unsupported" : kind,
        writable,
        selector: selectorFor(el),
        options: select ? Array.from(el.options).filter((o) => !o.disabled && o.value).map((o) => ({
          value: o.value,
          label: compact(o.textContent ?? "")
        })) : menuOptions.length ? menuOptions : void 0,
        maxLength: text && el.maxLength > 0 ? el.maxLength : void 0
      }
    };
  }
  function resolveNamed(root, label2, selectors, aliases2) {
    const candidates = queryAll(root, selectors).filter(usable);
    for (const el of root.querySelectorAll(controlSelector)) {
      if (usable(el) && aliases2.includes(norm(labelOf(el)))) candidates.push(el);
    }
    const unique = [...new Set(candidates)];
    const resolved = unique.map(
      (el) => resolveElement(el, label2, label2 === "title" ? "Title" : "Description")
    ).filter((x) => !!x);
    const writable = resolved.filter((x) => x.field.writable);
    if (writable.length > 1) return null;
    return writable[0] ?? (resolved.length === 1 ? resolved[0] : null);
  }
  function resolveFields(doc, settings) {
    const title = resolveNamed(
      doc,
      "title",
      [
        ...SELECTORS.title,
        ...settings.fallbackSelectors.title ? [settings.fallbackSelectors.title] : []
      ],
      ["title", "listing title", "item title", "titre"]
    );
    const description = resolveNamed(
      doc,
      "description",
      [
        ...SELECTORS.description,
        ...settings.fallbackSelectors.description ? [settings.fallbackSelectors.description] : []
      ],
      [
        "description",
        "item description",
        "listing description",
        "description de l objet"
      ]
    );
    const scopes = queryAll(doc, [
      ...SELECTORS.specifics,
      ...settings.fallbackSelectors.specifics ? [settings.fallbackSelectors.specifics] : []
    ]);
    const condition = resolveCondition(doc);
    for (const heading of doc.querySelectorAll("h2,h3,legend"))
      if (["item specifics", "caracteristiques de l objet"].includes(
        norm(heading.textContent ?? "")
      )) {
        const scope = heading.closest("section,fieldset");
        if (scope) scopes.push(scope);
      }
    const controls2 = /* @__PURE__ */ new Set();
    for (const scope of scopes)
      scope.querySelectorAll(controlSelector).forEach((el) => controls2.add(el));
    for (const el of doc.querySelectorAll(controlSelector))
      if (manufactureLabel(labelOf(el)) || SPECIFIC_LABELS.some((l) => matchLabel(l) === matchLabel(labelOf(el))))
        controls2.add(el);
    const resolved = [];
    for (const el of controls2) {
      if (el === title?.el || el === description?.el || el === condition?.el || condition?.el.contains(el) || !usable(el) || el.closest('[role="menu"],.fake-menu-button__menu') || el.getAttribute("name")?.startsWith("search-box-"))
        continue;
      const label2 = labelOf(el).replace(/\s*\*\s*$/, "");
      if (!label2 || /(?:price|payment|shipping|location|return|policy|quantity available|stock|sku)/i.test(
        label2
      ))
        continue;
      const key = manufactureLabel(label2) ? "specific:country" : `specific:${matchLabel(label2)}`;
      const r = resolveElement(el, key, label2);
      if (r) resolved.push(r);
    }
    const origins = resolved.filter((r) => manufactureLabel(r.field.label));
    if (new Set(origins.map((r) => norm(r.field.label))).size > 1)
      origins.forEach((r) => {
        r.field.key = `specific:country:${norm(r.field.label)}`;
      });
    const counts = /* @__PURE__ */ new Map();
    resolved.forEach(
      (r) => counts.set(r.field.key, (counts.get(r.field.key) ?? 0) + 1)
    );
    resolved.forEach((r) => {
      if (counts.get(r.field.key) !== 1) {
        r.field.writable = false;
        r.field.kind = "unsupported";
      }
    });
    return { title, description, condition, specifics: resolved };
  }

  // src/core/itemOrigin.ts
  var ITEM_ORIGIN = "China";
  function isItemOriginField(field) {
    return manufactureLabel(field.label);
  }
  function supportsItemOrigin(field) {
    return field.writable && (field.kind !== "select" && !field.options?.length || !!field.options?.some(
      (option) => normalizeCountry(option.label) === ITEM_ORIGIN || normalizeCountry(option.value) === ITEM_ORIGIN
    ));
  }
  function itemOriginChanges(fields) {
    return fields.filter(isItemOriginField).filter(supportsItemOrigin).map((field) => ({
      key: field.key,
      before: field.value,
      after: ITEM_ORIGIN
    }));
  }

  // src/ebay/nativeGuard.ts
  function emptyDescription(doc, html) {
    const t = doc.createElement("template");
    t.innerHTML = html;
    return !t.content.textContent?.trim() && [...t.content.querySelectorAll("*")].every(
      (el) => ["P", "BR", "DIV"].includes(el.tagName) && el.attributes.length === 0
    );
  }

  // src/ebay/apply.ts
  function findAll(doc, s) {
    const f = resolveFields(doc, s);
    return [
      f.title,
      f.description,
      f.condition,
      ...f.specifics,
      ...resolvePrices(doc),
      resolveSimplePrice(doc),
      resolveSimpleQuantity(doc),
      ...resolveQuantities(doc),
      ...resolveUPCs(doc)
    ].filter((x) => !!x);
  }
  async function setNative(el, value, key = "", design = false, selection, valid = () => true) {
    if (key === ITEM_CONDITION_KEY)
      return chooseCondition(el.ownerDocument, value, valid);
    if (key.startsWith("upc:")) {
      chooseUPC(el, value);
      return;
    }
    if (isNativeMenuControl(el)) {
      return chooseMenu(el, value, selection);
    }
    if (key === "title" || key.startsWith("price:") || key.startsWith("quantity:")) {
      writeTextControl(el, value);
      return;
    }
    const win = el.ownerDocument.defaultView;
    if (key === "description" && !("value" in el)) el.focus();
    if ("value" in el) {
      const proto = el.tagName === "SELECT" ? win.HTMLSelectElement.prototype : el.tagName === "TEXTAREA" ? win.HTMLTextAreaElement.prototype : win.HTMLInputElement.prototype;
      const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
      if (!setter) throw Error("Native value setter unavailable");
      setter.call(el, value);
    } else if (key === "description" && design) replaceDesign(el, value);
    else if (key === "description") replaceDescriptionText(el, value);
    else el.innerHTML = value;
    el.dispatchEvent(
      new win.InputEvent("input", {
        bubbles: true,
        composed: true,
        inputType: "insertText"
      })
    );
    if (key === "description" && !("value" in el))
      el.dispatchEvent(
        new win.KeyboardEvent("keyup", {
          key: "End",
          code: "End",
          keyCode: 35,
          which: 35,
          bubbles: true,
          composed: true
        })
      );
    el.dispatchEvent(new win.Event("change", { bubbles: true, composed: true }));
    el.dispatchEvent(new win.FocusEvent("blur", { bubbles: true }));
    if (key === "description" && !("value" in el)) el.blur();
  }
  var FormTransactions = class {
    history = [];
    busy = false;
    get depth() {
      return this.history.length;
    }
    clear() {
      if (!this.busy) this.history = [];
    }
    mergeOriginRepair(identity, baseline = {}) {
      const repair = this.history.at(-1), previous = this.history.at(-2);
      if (this.busy || !repair || !previous || repair.identity !== identity || previous.identity !== identity || !repair.fields.every(
        (field) => field.key.startsWith("specific:country") || field.key === ITEM_CONDITION_KEY
      ))
        return;
      for (const field of repair.fields) {
        const original = previous.fields.find((saved) => saved.key === field.key);
        if (original) original.after = field.after;
        else
          previous.fields.push({
            ...field,
            before: baseline[field.key] ?? field.before
          });
      }
      this.history.pop();
    }
    commitVariationAxes(identity) {
      for (const tx of this.history)
        if (tx.identity === identity)
          tx.fields = tx.fields.filter((f) => !f.promotedAxis);
      this.history = this.history.filter((tx) => tx.fields.length);
    }
    async apply(doc, url, settings, request, isEnabled = () => settings.enabled, initialDescription) {
      if (!isEnabled()) throw Error("AurOEBay is paused.");
      if (this.busy) throw Error("Another edit is in progress");
      if (pageType(url()) !== "draft" || draftIdentity(url()) !== request.identity)
        throw Error("Draft changed. Analyze again.");
      if (!request.changes.length || request.changes.length > (request.changes.every((c) => c.key.startsWith("upc:")) ? 300 : 600))
        throw Error("No valid changes selected");
      if (new Set(request.changes.map((c) => c.key)).size !== request.changes.length)
        throw Error("Duplicate fields");
      this.busy = true;
      const tx = { identity: request.identity, fields: [] };
      const skipped = [];
      const manualReview = [];
      const listingContent = request.changes.some(
        (c) => /^(title|description|specific:|condition$)/.test(c.key)
      );
      try {
        const preparedCondition = listingContent ? await prepareCondition(
          doc,
          () => isEnabled() && draftIdentity(url()) === request.identity
        ) : null;
        const resolved = findAll(doc, settings);
        if (preparedCondition) {
          const index = resolved.findIndex(
            (r) => r.field.key === ITEM_CONDITION_KEY
          );
          if (index >= 0) resolved[index] = preparedCondition;
          else resolved.push(preparedCondition);
        }
        if (listingContent) {
          const fields = resolved.map((r) => r.field);
          const origins = new Set(
            fields.filter(isItemOriginField).map((f) => f.key)
          );
          request = {
            ...request,
            changes: [
              ...request.changes.filter(
                (c) => !origins.has(c.key) && c.key !== ITEM_CONDITION_KEY
              ),
              ...itemOriginChanges(fields),
              ...itemConditionChanges(preparedCondition?.field)
            ]
          };
          for (const field of fields.filter(isItemOriginField))
            if (!supportsItemOrigin(field))
              manualReview.push(
                `${field.label} : s\xE9lectionne ${ITEM_ORIGIN} dans eBay, ce champ n\u2019est pas modifiable automatiquement.`
              );
        }
        const plan = request.changes.map((c) => {
          const matches = resolved.filter((r2) => r2.field.key === c.key);
          if (matches.length !== 1)
            throw Error(`${c.key}: missing or ambiguous field`);
          const r = matches[0];
          if (!r.field.writable || r.field.value !== c.before)
            throw Error(
              `${r.field.label}: modified since preview or not writable. Analyze again.`
            );
          const promotedAxis = c.after === "" && c.key.startsWith("specific:") && typeof initialDescription === "object" && initialDescription.mode === "SellLikeItem" && initialDescription.identity === request.identity && new URL(url()).searchParams.get("mode") === "SellLikeItem" && request.changes.some(
            (x) => x.key === "description" && x.before === initialDescription.before && x.after === initialDescription.html
          ) && initialDescription.variationAxes?.some(
            (axis) => c.key === `specific:${matchLabel(axis)}`
          );
          if (typeof c.after !== "string" || !c.after.trim() && !promotedAxis || c.after.length > (c.key === "description" ? 5e5 : 3e4))
            throw Error("Invalid value");
          if (c.key === "title" && !validTitle(c.after, settings.maxTitle))
            throw Error("Invalid title (>80 characters, empty or multiline)");
          let after = c.after;
          if (c.key.startsWith("upc:") && (c.before !== "" || after !== NO_UPC))
            throw Error("Seuls les UPC vides peuvent recevoir Does not apply");
          if (c.key.startsWith("quantity:") && after !== "0" && !(c.key === "quantity:simple" && after === "3" && initialDescription !== void 0 && request.changes.some((x) => x.key === "description")))
            throw Error("Seule la quantit\xE9 z\xE9ro est autoris\xE9e pour une rupture");
          if (c.key === "description") {
            if (initialDescription !== void 0) {
              const u = new URL(url());
              if (!u.searchParams.get("draftId") && !u.searchParams.get("draft_id") || u.searchParams.get("mode") !== (typeof initialDescription === "string" ? "AddItem" : initialDescription.mode ?? "SellSimilarItem") || typeof initialDescription !== "string" && initialDescription.mode === "SellLikeItem" && !emptyDescription(doc, c.before) || ["itemId", "itemid", "item_id", "listingId"].some(
                (key) => u.searchParams.has(key)
              ) || (typeof initialDescription === "string" ? !emptyDescription(doc, c.before) || c.after !== initialDescription : initialDescription.identity !== request.identity || initialDescription.before !== c.before || initialDescription.html !== c.after))
                throw Error(
                  "Initialisation r\xE9serv\xE9e au nouveau brouillon li\xE9 \xE0 cet import."
                );
            } else if (c.design) {
              if (typeof c.design.title !== "string" || c.design.title.length > 80 || !Array.isArray(c.design.edits))
                throw Error("Invalid description design");
              const edited = editedDescription(c.before, c.design.edits);
              validateDescriptionChange(c.before, edited);
              if (designDescription(edited, c.design.title).html !== c.after)
                throw Error("Description design mismatch");
            } else validateDescriptionChange(c.before, c.after);
          }
          if (c.key.startsWith("price:") && (!/^\d+(?:\.\d{1,2})?$/.test(after) || Number(after) <= 0 || Number(after) > 1e6))
            throw Error("Prix invalide");
          if (r.field.kind === "select" && promotedAxis) {
            const empty = [...r.el.options].filter(
              (o) => o.value === "" && !o.disabled
            );
            if (empty.length !== 1)
              throw Error(`${r.field.label}: cannot clear fixed variation value`);
          } else if (r.field.kind === "select") {
            const option = r.field.options?.find(
              (o) => norm(o.label) === norm(after) || norm(o.value) === norm(after) || isItemOriginField(r.field) && after === ITEM_ORIGIN && (normalizeCountry(o.label) === ITEM_ORIGIN || normalizeCountry(o.value) === ITEM_ORIGIN)
            );
            if (!option) throw Error(`${r.field.label}: option does not exist`);
            after = option.value;
          }
          if (c.key === ITEM_CONDITION_KEY) {
            const option = preferredItemCondition(r.field);
            if (!option || after !== option.value && norm(after) !== norm(option.label))
              throw Error("Item condition : choix natif New non reconnu.");
          }
          if (r.el.tagName === "INPUT" && r.el.type === "number") {
            const input = r.el;
            const n = Number(after);
            if (!/^-?\d+(?:\.\d+)?$/.test(after) || !Number.isFinite(n) || input.min !== "" && n < Number(input.min) || input.max !== "" && n > Number(input.max))
              throw Error(`${r.field.label}: invalid numeric value`);
            const step = input.step === "any" ? null : Number(input.step || 1);
            const base = Number(input.min || 0);
            if (step && Math.abs((n - base) / step - Math.round((n - base) / step)) > 1e-8)
              throw Error(`${r.field.label}: invalid numeric step`);
          }
          if (r.field.maxLength && after.length > r.field.maxLength)
            throw Error(`${r.field.label}: exceeds field length`);
          return {
            r,
            after,
            before: rawValue(r.el),
            promotedAxis: !!promotedAxis,
            design: !!c.design || c.key === "description" && initialDescription !== void 0
          };
        });
        for (const { r, after, before, design, promotedAxis } of plan) {
          if (!isEnabled()) throw Error("AurOEBay was paused during application");
          if (draftIdentity(url()) !== tx.identity)
            throw Error("Navigation during application");
          const current = findAll(doc, settings).find(
            (x) => x.field.key === r.field.key
          );
          if (!current || !current.field.writable || rawValue(current.el) !== before)
            throw Error(`${r.field.label}: changed during application`);
          if (before === after) {
            skipped.push(r.field.key);
            continue;
          }
          const saved = {
            key: r.field.key,
            before,
            after,
            kind: r.field.kind,
            design,
            promotedAxis
          };
          tx.fields.push(saved);
          const changed = await setNative(
            current.el,
            after,
            r.field.key,
            design,
            void 0,
            () => isEnabled() && draftIdentity(url()) === request.identity
          );
          if (changed && typeof changed === "object")
            saved.menuSelection = changed.menuSelection;
          if (changed === false) {
            tx.fields.pop();
            skipped.push(r.field.key);
            manualReview.push(
              `${r.field.label} : \xAB ${after} \xBB non s\xE9lectionnable dans eBay. Valeur actuelle conserv\xE9e ; choisis ce champ manuellement.`
            );
            continue;
          }
          await delay(140);
          const fresh = findAll(doc, settings).find(
            (x) => x.field.key === r.field.key
          );
          if (!fresh || rawValue(fresh.el) !== after)
            throw Error(`${r.field.label}: eBay did not retain the value`);
        }
        await delay(200);
        if (!isEnabled()) throw Error("AurOEBay was paused during application");
        for (const f of tx.fields) {
          const r = findAll(doc, settings).find((r2) => r2.field.key === f.key);
          if (!r || rawValue(r.el) !== f.after)
            throw Error(`${f.key}: delayed form update rejected`);
        }
        if (tx.fields.length) this.history.push(tx);
        this.history = this.history.slice(-10);
        return {
          applied: tx.fields.map((f) => f.key),
          skipped,
          undoDepth: this.depth,
          ...manualReview.length ? { manualReview } : {},
          ...listingContent ? {
            conditionStatus: itemConditionStatus(
              findAll(doc, settings).find(
                (r) => r.field.key === ITEM_CONDITION_KEY
              )?.field
            ) + conditionInspectionNote(doc)
          } : {}
        };
      } catch (e) {
        const unresolved = [];
        for (const f of [...tx.fields].reverse()) {
          try {
            if (draftIdentity(url()) !== tx.identity) throw Error("Navigation");
            const r = findAll(doc, settings).find((x) => x.field.key === f.key);
            if (!r) throw Error("Missing");
            if (rawValue(r.el) === f.before) continue;
            if (rawValue(r.el) !== f.after) throw Error("Concurrent edit");
            await setNative(
              r.el,
              f.before,
              f.key,
              f.design,
              f.menuSelection,
              () => draftIdentity(url()) === tx.identity
            );
            await delay(100);
            const fresh = findAll(doc, settings).find(
              (x) => x.field.key === f.key
            );
            if (!fresh || rawValue(fresh.el) !== f.before)
              throw Error("Rollback rejected");
          } catch {
            unresolved.push(f);
          }
        }
        if (unresolved.length) this.history.push({ ...tx, fields: unresolved });
        throw Error(
          `${e instanceof Error ? e.message : "Apply failed"}. ${unresolved.length ? "Some fields could not be restored; use Undo and review manually." : "Changes rolled back."}`
        );
      } finally {
        this.busy = false;
      }
    }
    async undo(doc, url, s) {
      if (this.busy) throw Error("Another edit is in progress");
      const tx = this.history.at(-1);
      if (!tx) throw Error("Nothing to undo in this page session.");
      if (draftIdentity(url()) !== tx.identity)
        throw Error("Undo belongs to another draft.");
      this.busy = true;
      const applied = [];
      const skipped = [];
      try {
        for (const saved of [...tx.fields].reverse()) {
          const r = findAll(doc, s).find((x) => x.field.key === saved.key);
          if (!r || !r.field.writable || r.field.kind !== saved.kind || rawValue(r.el) !== saved.after) {
            skipped.push(`${saved.key}: changed manually or control unavailable`);
            continue;
          }
          try {
            await setNative(
              r.el,
              saved.before,
              saved.key,
              saved.design,
              saved.menuSelection,
              () => draftIdentity(url()) === tx.identity
            );
            await delay(150);
            const fresh = findAll(doc, s).find((x) => x.field.key === saved.key);
            if (fresh && rawValue(fresh.el) === saved.before)
              applied.push(saved.key);
            else skipped.push(`${saved.key}: restoration not retained`);
          } catch (e) {
            skipped.push(
              `${saved.key}: ${e instanceof Error ? e.message : "restoration unavailable"}`
            );
          }
        }
        tx.fields = tx.fields.filter((f) => !applied.includes(f.key));
        if (!tx.fields.length) this.history.pop();
        return { applied, skipped, undoDepth: this.depth };
      } finally {
        this.busy = false;
      }
    }
  };
  function usableMenuControl(node) {
    if (node.hasAttribute("disabled") || node.getAttribute("aria-disabled") === "true" || node.closest('[hidden],[aria-hidden="true"]'))
      return false;
    const win = node.ownerDocument.defaultView;
    for (let current = node; current; current = current.parentElement) {
      const style = win?.getComputedStyle(current);
      if (style?.display === "none" || style?.visibility === "hidden" || style?.visibility === "collapse")
        return false;
    }
    return true;
  }
  function optionLabel(node) {
    if (node.matches('input[type="checkbox"]')) {
      const input = node;
      return (input.getAttribute("aria-label") || input.labels?.[0]?.textContent || (input.value !== "on" ? input.value : "") || "").trim();
    }
    return (node.textContent || node.getAttribute("aria-label") || "").trim();
  }
  function nativeClearAction(menu) {
    const native = [
      ...menu.querySelectorAll(
        "button.se-filter-menu-button__clear"
      )
    ].filter(usableMenuControl);
    if (native.length === 1) return native[0];
    if (native.length > 1) throw Error("Action d\u2019effacement eBay ambigu\xEB.");
    const actions = [
      ...menu.querySelectorAll('button,[role="button"]')
    ].filter(
      (node) => usableMenuControl(node) && !node.closest(
        '[role="menuitemradio"],[role="menuitemcheckbox"],[role="option"],.se-toggle-group-menu__menu-container,.se-search-box'
      ) && !node.matches(
        '.toggle-button,[role="menuitemradio"],[role="menuitemcheckbox"],[role="option"]'
      ) && /^(clear|clear selection|effacer|effacer la sélection)$/i.test(
        (node.textContent ?? "").trim()
      )
    );
    if (actions.length > 1) throw Error("Action d\u2019effacement eBay ambigu\xEB.");
    return actions[0] ?? null;
  }
  function chipSelectionLabel(node) {
    const name = node.getAttribute("aria-label") ?? node.getAttribute("title") ?? "";
    const named = name.match(
      /^(?:remove|delete|retirer|supprimer)(?: selection)?[:\s]+(.+)$/i
    )?.[1];
    if (named) return named.trim();
    if (!/^(remove|delete|retirer|supprimer)$/i.test(name)) return null;
    const chip = node.closest(
      "[data-selected-value],[data-value],.chip,.filter-chip,.selected-value"
    );
    return chip ? (chip.getAttribute("data-selected-value") ?? chip.getAttribute("data-value") ?? chip.textContent ?? "").trim() || null : null;
  }
  function selectedMenuValues(menu) {
    const groups = /* @__PURE__ */ new Map();
    const selected2 = [
      ...menu.querySelectorAll(
        '[role="menuitemradio"][aria-checked="true"],[role="menuitemcheckbox"][aria-checked="true"],[role="option"][aria-selected="true"],button[aria-pressed="true"],input[type="checkbox"]:checked'
      )
    ].filter(usableMenuControl);
    for (const node of selected2) {
      if (node.matches('input[type="checkbox"]') && selected2.some((parent) => parent !== node && parent.contains(node)))
        continue;
      const label2 = optionLabel(node);
      if (!label2) continue;
      const key = norm(label2), group = groups.get(key) ?? { label: label2, nodes: [] };
      group.nodes.push(node);
      groups.set(key, group);
    }
    for (const node of [
      ...menu.querySelectorAll(
        'button[aria-label],button[title],[role="button"][aria-label]'
      )
    ].filter(usableMenuControl)) {
      const label2 = chipSelectionLabel(node);
      if (label2 && !groups.has(norm(label2)))
        groups.set(norm(label2), { label: label2, nodes: [] });
    }
    return [...groups.values()];
  }
  function removeChipControls(menu, label2) {
    return [
      ...menu.querySelectorAll(
        'button[aria-label],button[title],[role="button"][aria-label]'
      )
    ].filter((node) => {
      if (!usableMenuControl(node)) return false;
      const name = node.getAttribute("aria-label") ?? node.getAttribute("title") ?? "";
      const named = name.match(
        /^(?:remove|delete|clear|retirer|supprimer)(?: selection)?[:\s]+(.+)$/i
      )?.[1];
      if (named && norm(named) === norm(label2)) return true;
      if (!/^(remove|delete|retirer|supprimer)$/i.test(name)) return false;
      const chip = node.closest(
        "[data-selected-value],[data-value],.chip,.filter-chip,.selected-value"
      );
      return !!chip && norm(
        chip.getAttribute("data-selected-value") ?? chip.getAttribute("data-value") ?? chip.textContent ?? ""
      ) === norm(label2);
    });
  }
  function sameSelection(a, b) {
    return JSON.stringify(a.map(norm).sort()) === JSON.stringify(b.map(norm).sort());
  }
  function representsSelection(value, labels) {
    if (!labels.length) return readEmpty(value);
    return [labels.join(", "), labels.join("; "), labels.join(" ")].some(
      (v) => norm(v) === norm(value)
    );
  }
  function readEmpty(value) {
    return !value.trim();
  }
  function exactMenuOptions(menu, value, selector) {
    const candidates = [...menu.querySelectorAll(selector)].filter(
      (node) => usableMenuControl(node) && norm(optionLabel(node)) === norm(value)
    );
    const physical = candidates.filter(
      (node) => !candidates.some((parent) => parent !== node && parent.contains(node))
    );
    const all = physical.filter(
      (node) => !!node.closest('.options,[aria-label="All options"]') || !!node.querySelector('[name^="options-attributes"]')
    );
    return all.length ? all : physical;
  }
  async function restoreMenuValues(el, menu, labels, value) {
    for (const label2 of labels) {
      const selected2 = selectedMenuValues(menu).map((s) => s.label);
      if (selected2.some((s) => norm(s) === norm(label2)) && representsSelection(readValue(el), selected2))
        continue;
      const physical = exactMenuOptions(
        menu,
        label2,
        '[role="menuitemradio"],[role="menuitemcheckbox"],[role="option"],input[type="checkbox"],button[aria-pressed],.se-toggle-group-menu__menu-container button.toggle-button'
      );
      if (physical.length !== 1)
        throw Error("Choix eBay introuvable ou ambigu pendant la restauration.");
      physical[0].click();
      await delay(140);
    }
    if (!sameSelection(
      selectedMenuValues(menu).map((s) => s.label),
      labels
    ) || norm(readValue(el)) !== norm(value))
      throw Error("eBay n\u2019a pas conserv\xE9 la restauration du menu.");
  }
  async function clearNativeSelection(el, menu) {
    const before = readValue(el), initial = selectedMenuValues(menu).map((s) => s.label);
    const clear = nativeClearAction(menu);
    if (clear) {
      clear.click();
      return { menuSelection: initial };
    }
    if (!initial.length || !representsSelection(before, initial))
      throw Error(
        "Impossible de vider automatiquement ce menu : efface la valeur dans eBay."
      );
    const removed = [];
    try {
      for (const label2 of initial) {
        const current = selectedMenuValues(menu);
        if (!sameSelection(
          current.map((s) => s.label),
          initial.filter((v) => !removed.includes(v))
        ))
          throw Error("S\xE9lection eBay modifi\xE9e pendant son effacement.");
        const group = current.find((s) => norm(s.label) === norm(label2));
        const toggles = group.nodes.filter(
          (node) => node.matches(
            '[role="menuitemcheckbox"],input[type="checkbox"],button[aria-pressed="true"]'
          ) || node.matches('[role="option"]') && !!node.closest('[aria-multiselectable="true"]')
        );
        const candidates = [...removeChipControls(menu, label2), ...toggles];
        let cleared = false;
        for (let attempt = 0; attempt < candidates.length; attempt++) {
          const freshGroup = selectedMenuValues(menu).find(
            (s) => norm(s.label) === norm(label2)
          );
          const freshToggles = (freshGroup?.nodes ?? []).filter(
            (node) => node.matches(
              '[role="menuitemcheckbox"],input[type="checkbox"],button[aria-pressed="true"]'
            ) || node.matches('[role="option"]') && !!node.closest('[aria-multiselectable="true"]')
          );
          const candidate = [...removeChipControls(menu, label2), ...freshToggles][attempt];
          if (!candidate) continue;
          if (!candidate.isConnected || !usableMenuControl(candidate)) continue;
          const previous = readValue(el);
          candidate.click();
          await delay(140);
          const next = selectedMenuValues(menu).map((s) => s.label), remaining = initial.filter(
            (v) => !removed.includes(v) && norm(v) !== norm(label2)
          );
          if (sameSelection(next, remaining) && representsSelection(readValue(el), remaining)) {
            removed.push(label2);
            cleared = true;
            break;
          }
          if (readValue(el) !== previous || !sameSelection(
            next,
            current.map((s) => s.label)
          ))
            throw Error("eBay n\u2019a pas confirm\xE9 l\u2019effacement de cette valeur.");
        }
        if (!cleared)
          throw Error(
            "Impossible de vider automatiquement ce menu : efface la valeur dans eBay."
          );
      }
      return { menuSelection: initial };
    } catch (error) {
      const current = selectedMenuValues(menu).map((s) => s.label);
      if (current.every((value) => initial.some((v) => norm(v) === norm(value)))) {
        try {
          await restoreMenuValues(el, menu, initial, before);
        } catch {
        }
      }
      throw error;
    }
  }
  async function chooseMenu(el, value, selection) {
    const id = el.getAttribute("aria-controls");
    if (!id) throw Error("Menu eBay non reconnu");
    const wasOpen = el.getAttribute("aria-expanded") === "true";
    if (!wasOpen) el.click();
    try {
      await delay(180);
      const menu = el.ownerDocument.getElementById(id);
      if (!menu) throw Error("Menu eBay indisponible");
      if (!value) {
        return await clearNativeSelection(el, menu);
      }
      if (selection && selection.length)
        return await restoreMenuValues(el, menu, selection, value);
      const search = menu.querySelector(
        'input[type="text"],input[type="search"]'
      );
      if (search) {
        await setNative(search, value);
        await delay(300);
      }
      const matches = exactMenuOptions(
        menu,
        value,
        '[role="menuitemradio"],[role="menuitemcheckbox"],[role="option"],.se-toggle-group-menu__menu-container button.toggle-button'
      );
      if (matches.length !== 1) return false;
      if (matches[0].getAttribute("role") === "menuitemcheckbox") {
        const before = readValue(el);
        const clear = [
          ...menu.querySelectorAll('button,[role="button"]')
        ].filter((o) => norm(o.textContent ?? "") === "clear");
        if (before && norm(before) !== norm(value)) {
          if (clear.length !== 1 || /[,;]/.test(before)) return false;
          clear[0].click();
          await delay(150);
          const fresh = [
            ...menu.querySelectorAll('[role="menuitemcheckbox"]')
          ].filter(
            (o) => norm(o.textContent ?? "") === norm(value) && o.getAttribute("aria-disabled") !== "true" && !o.closest('[hidden],[aria-hidden="true"]')
          );
          if (fresh.length !== 1)
            throw Error("Option eBay disparue apr\xE8s effacement du choix");
          fresh[0].click();
        } else if (norm(before) !== norm(value)) matches[0].click();
      } else matches[0].click();
      await delay(150);
      if (norm(readValue(el)) !== norm(value))
        throw Error("eBay n\u2019a pas conserv\xE9 ce choix");
    } finally {
      if (!wasOpen && el.isConnected && el.getAttribute("aria-expanded") === "true")
        el.click();
    }
  }

  // src/ebay/supplierVariations.ts
  function visible2(e) {
    if (e.closest("[hidden]")) return false;
    const win = e.ownerDocument.defaultView;
    for (let n = e; n; n = n.parentElement) {
      const style = win?.getComputedStyle(n);
      if (style?.display === "none" || style?.visibility === "hidden")
        return false;
    }
    return e.getBoundingClientRect().width > 0;
  }
  async function waitFor(read, valid, timeout = 15e3, step = "chargement de l\u2019\xE9diteur") {
    const until = Date.now() + timeout;
    while (Date.now() < until) {
      if (!valid()) throw Error("Import fournisseur interrompu.");
      const value = read();
      if (value) return value;
      await delay(150);
    }
    throw Error(
      `Variantes eBay : d\xE9lai d\xE9pass\xE9 pendant ${step}. Le brouillon reste ouvert pour v\xE9rification.`
    );
  }
  function click(doc, selector) {
    const e = doc.querySelector(selector);
    if (!e || !visible2(e) || e.hasAttribute("disabled"))
      throw Error(`Contr\xF4le de variantes indisponible : ${selector}`);
    e.click();
  }
  async function relay(body, valid) {
    const until = Date.now() + 15e3;
    while (Date.now() < until) {
      if (!valid()) throw Error("Import interrompu.");
      try {
        return await message(body);
      } catch (e) {
        if (!/not loaded/i.test(String(e)) && !(body.type === "NATIVE_VARIANTS" && /could not establish connection.*receiving end does not exist/i.test(
          String(e)
        )))
          throw e;
        await delay(300);
      }
    }
    throw Error("\xC9diteur de variantes non charg\xE9.");
  }
  async function cancelUncreatedVariations(doc, valid) {
    if (!valid() || resolvePrices(doc).length || doc.querySelector("#msku-edit-variation-button") && visible2(doc.querySelector("#msku-edit-variation-button")))
      throw Error("Un tableau de variantes d\xE9j\xE0 cr\xE9\xE9 ne peut pas \xEAtre repris.");
    const popupCancel = doc.querySelector("#msku-cancel-parent-tag-btn");
    if (popupCancel && visible2(popupCancel))
      click(doc, "#msku-cancel-parent-tag-btn");
    click(doc, "#msku-cancel-create-variations-button");
    const exit = await waitFor(
      () => {
        const button = doc.querySelector("#msku-exit-button");
        const dialog = button?.closest('[role="dialog"]');
        return button && visible2(button) && !button.disabled && dialog && /are you sure you want to cancel the variations you[’']re creating\?/i.test(
          dialog.textContent ?? ""
        ) && button;
      },
      valid,
      1e4,
      "la confirmation de fermeture des variantes non cr\xE9\xE9es"
    );
    if (!valid()) throw Error("Import interrompu.");
    exit.click();
    return true;
  }
  async function fillSupplierVariations(doc, job, valid, clearedAxes = []) {
    const plan = job.supplierPlan;
    const frameURL = new URL(doc.location.href);
    if (!plan || job.stage !== "filling" || frameURL.hostname !== "bulkedit.ebay.com" || frameURL.pathname !== "/msku" || frameURL.searchParams.get("draftId") !== new URL(job.identity).searchParams.get("draftId"))
      throw Error("Variantes non autoris\xE9es pour ce brouillon.");
    await waitFor(() => doc.querySelector("#msku-attribute-add"), valid);
    if (doc.querySelector("#msku-edit-variation-button") && visible2(doc.querySelector("#msku-edit-variation-button")))
      throw Error(
        "Des variantes existent d\xE9j\xE0 dans ce nouveau brouillon. Import arr\xEAt\xE9."
      );
    if (clearedAxes.length) {
      if (clearedAxes.some((name) => !plan.axes.some((axis) => axis.name === name)))
        throw Error("Axe effac\xE9 non autoris\xE9 pour ce produit fournisseur.");
      click(doc, "#msku-attribute-add");
      await waitFor(() => {
        const save = doc.querySelector("#msku-add-parent-tag-btn");
        return save && visible2(save);
      }, valid);
      const names2 = [
        ...doc.querySelectorAll("#msku-variation-checkbox-list label")
      ].map((label2) => norm(label2.textContent ?? ""));
      const retryAxes = clearedAxes.filter((axis) => !names2.includes(norm(axis)));
      if (retryAxes.length) return { retryAxes };
      click(doc, "#msku-cancel-parent-tag-btn");
    }
    const tags = () => [
      ...doc.querySelectorAll(
        '#msku-variations-header [role="tab"]'
      )
    ].filter(visible2);
    while (tags().length) {
      const count = tags().length;
      tags()[0].parentElement?.querySelector("button")?.click();
      await waitFor(() => tags().length < count, valid);
    }
    for (const axis of plan.axes) {
      click(doc, "#msku-attribute-add");
      await waitFor(
        // The native overlay wrapper has a 0 × 0 rect; its absolutely
        // positioned dialog and controls are visible. Observe the actual control.
        () => {
          const save = doc.querySelector(
            "#msku-variation-add-list #msku-add-parent-tag-btn"
          );
          return save && visible2(save);
        },
        valid,
        15e3,
        `l\u2019ouverture du menu d\u2019attribut ${axis.name}`
      );
      const labels = [
        ...doc.querySelectorAll(
          "#msku-variation-checkbox-list label"
        )
      ];
      const native = labels.find(
        (l) => norm(l.textContent ?? "") === norm(axis.name)
      );
      if (native) {
        const box = native.querySelector(
          'input[type="checkbox"]'
        );
        if (!box || !visible2(box) || box.disabled)
          throw Error(`Attribut eBay indisponible : ${axis.name}`);
        if (!box.checked) box.click();
      } else {
        const own = doc.querySelector(
          "#msku-own-parent-tag-checkbox"
        );
        if (!own || !visible2(own) || own.disabled)
          throw Error("Option d\u2019attribut personnalis\xE9 eBay indisponible.");
        if (!own.checked) own.click();
        const input = await waitFor(
          () => {
            const e = doc.querySelector(
              "#msku-custom-parent-attribute-input"
            );
            return e && visible2(e) && !e.disabled && e;
          },
          valid,
          15e3,
          `la saisie de l\u2019attribut ${axis.name}`
        );
        writeTextControl(input, axis.name);
      }
      click(doc, "#msku-add-parent-tag-btn");
      const tab = await waitFor(
        () => {
          const input = doc.querySelector(
            "#msku-custom-parent-attribute-input"
          );
          const conflict = [
            ...doc.querySelectorAll("#msku-variation-add-list h2")
          ].find(
            (e) => visible2(e) && /remove the value added for it in item specifics/i.test(
              e.textContent ?? ""
            )
          );
          if (conflict || input && visible2(input) && input.getAttribute("aria-invalid") === "true")
            throw Error(
              `eBay refuse l\u2019attribut ${axis.name} : v\xE9rifie que sa valeur fixe a \xE9t\xE9 retir\xE9e des caract\xE9ristiques de l\u2019objet.`
            );
          return tags().find(
            (t) => norm(t.textContent ?? "") === norm(axis.name)
          );
        },
        valid,
        15e3,
        `l\u2019ajout de l\u2019attribut ${axis.name}`
      );
      tab.click();
      for (const value of axis.values) {
        if (!valid()) throw Error("Import interrompu.");
        const panel = doc.getElementById(tab.getAttribute("aria-controls"));
        const existing = [
          ...panel?.querySelectorAll('[role="button"]') ?? []
        ].find((e) => e.textContent?.trim() === value);
        if (existing) {
          if (existing.getAttribute("aria-pressed") !== "true") existing.click();
        } else {
          click(doc, "#msku-custom-option-link");
          const input = await waitFor(
            () => {
              const e = doc.querySelector(
                "#msku-custom-option-input"
              );
              return e && visible2(e) && !e.disabled && e;
            },
            valid,
            15e3,
            `la saisie de l\u2019option ${axis.name} : ${value}`
          );
          writeTextControl(input, value);
          click(doc, "#msku-custom-option-add");
        }
        await waitFor(
          () => [
            ...doc.querySelectorAll(
              "#msku-variation-details-container .msku-parent-attribute-container"
            )
          ].some(
            (e) => norm(e.querySelector("b")?.textContent ?? "") === norm(axis.name) && [...e.querySelectorAll("li span")].some(
              (s) => s.textContent === value
            )
          ),
          valid,
          15e3,
          `l\u2019ajout de l\u2019option ${axis.name} : ${value}`
        );
      }
    }
    click(doc, "#msku-create-variations-button");
    await waitFor(
      () => resolvePrices(doc).length,
      valid,
      15e3,
      "la cr\xE9ation du tableau des prix"
    );
    const signature = (options) => JSON.stringify(
      plan.axes.map(
        (a) => options.find((o) => norm(o.label) === norm(a.name))?.value
      )
    );
    const expected = new Map(plan.rows.map((r) => [JSON.stringify(r.values), r]));
    while (true) {
      const row = resolvePrices(doc).find(
        (r) => !expected.has(signature(r.field.options))
      );
      if (!row) break;
      const unwanted = signature(row.field.options);
      const del = row.el.closest("tr")?.querySelector('a[action="delete"]');
      if (!del || !visible2(del))
        throw Error(
          "Impossible de retirer une combinaison non propos\xE9e par AliExpress."
        );
      if (!valid()) throw Error("Import interrompu.");
      del.click();
      const removed = () => !resolvePrices(doc).some((r) => signature(r.field.options) === unwanted);
      const result = await waitFor(
        () => {
          if (removed()) return { removed: true };
          const dialogs = [
            ...doc.querySelectorAll('[role="dialog"]')
          ].filter(
            (e) => visible2(e) && /are you sure you want to delete this variation\?/i.test(
              e.textContent ?? ""
            )
          );
          if (dialogs.length !== 1) return null;
          const buttons = [
            ...dialogs[0].querySelectorAll("button")
          ].filter(
            (b) => visible2(b) && !b.disabled && norm(b.textContent ?? "") === "ok"
          );
          return buttons.length === 1 ? { confirm: buttons[0] } : null;
        },
        valid,
        15e3,
        "le retrait d\u2019une combinaison indisponible"
      );
      if ("confirm" in result && result.confirm) {
        if (!valid()) throw Error("Import interrompu.");
        result.confirm.click();
        await waitFor(
          removed,
          valid,
          15e3,
          "la confirmation du retrait de la variante"
        );
      }
    }
    const rows = resolvePrices(doc);
    if (rows.length !== expected.size)
      throw Error(
        "Les combinaisons AliExpress ne correspondent pas au nouveau tableau eBay."
      );
    const quantities2 = resolveQuantities(doc), upcs2 = resolveUPCs(doc);
    for (const row of rows) {
      if (!valid()) throw Error("Import interrompu.");
      const values = expected.get(signature(row.field.options));
      const qty = quantities2.find(
        (q) => q.field.key === row.field.key.replace("price:", "quantity:")
      );
      if (!values || !qty)
        throw Error("Prix ou quantit\xE9 fournisseur non reconnu.");
      writeTextControl(row.el, values.price);
      writeTextControl(qty.el, String(values.quantity));
      const upc = upcs2.find(
        (u) => u.field.key === row.field.key.replace("price:", "upc:")
      );
      if (upc) chooseUPC(upc.el, NO_UPC);
    }
    const photoAxis = plan.axes.find(
      (a) => a.values.every(
        (v) => job.product.variantImages.some(
          (i) => norm(i.axis) === norm(a.name) && i.value === v
        )
      )
    );
    if (photoAxis) {
      const select = doc.querySelector("#msku-photos_options");
      if (!select || ![...select.options].some((o) => o.value === photoAxis.name))
        throw Error("Photos par variante non disponibles.");
      select.value = photoAxis.name;
      select.dispatchEvent(new Event("change", { bubbles: true }));
      for (const value of photoAxis.values) {
        const option = await waitFor(
          () => [
            ...doc.querySelectorAll("#msku-photos_variations li")
          ].find((li) => li.querySelector("a")?.textContent === value),
          valid
        );
        option.querySelector("a").click();
        await waitFor(
          () => doc.querySelector(
            '#msku-photos_photos_wrapper iframe[src*="picupload"]'
          ),
          valid
        );
        const image = job.product.variantImages.find(
          (i) => norm(i.axis) === norm(photoAxis.name) && i.value === value
        );
        await relay(
          { type: "NATIVE_VARIANT_PHOTO", id: job.id, url: image.url, value },
          valid
        );
        await waitFor(
          () => Number(option.querySelector(".pics-count")?.textContent) === 1,
          valid,
          3e4
        );
      }
    }
    if (resolvePrices(doc).length !== expected.size)
      throw Error("Le tableau a chang\xE9 pendant l\u2019import des photos.");
    for (const row of resolvePrices(doc)) {
      const values = expected.get(signature(row.field.options));
      if (!values || row.field.value !== values.price || row.el.closest("tr")?.querySelector('input[cn="qty"]')?.value !== String(values.quantity))
        throw Error("eBay n\u2019a pas conserv\xE9 les prix et quantit\xE9s AliExpress.");
    }
    if (!valid()) throw Error("Import interrompu.");
    click(doc, "#msku-saveAndCloseBtn");
    return { rows: rows.length };
  }

  // src/core/errorLog.ts
  function logToJournal(kind, what, text) {
    try {
      void chrome.runtime.sendMessage({ type: "LOG", kind, what, text: text.slice(0, 600) }).catch(() => {
      });
    } catch {
    }
  }
  var ownError = (stack) => {
    try {
      return stack.includes(`chrome-extension://${chrome.runtime.id}`);
    } catch {
      return false;
    }
  };
  var describe = (reason) => reason instanceof Error ? `${reason.message} ${reason.stack?.split("\n").slice(1, 3).map((l) => l.trim()).join(" ") ?? ""}` : String(reason);
  function watchErrors(extensionPage, win = window) {
    win.addEventListener("error", (e) => {
      const where = `${e.filename ?? ""} ${e.error instanceof Error ? e.error.stack ?? "" : ""}`;
      if (!extensionPage && !ownError(where)) return;
      if (/Extension context invalidated|ResizeObserver loop/i.test(e.message)) return;
      logToJournal("error", "page", `${e.message} (${String(e.filename ?? "").split("/").pop()}:${e.lineno})`);
    });
    win.addEventListener("unhandledrejection", (e) => {
      const text = describe(e.reason);
      if (!extensionPage && !ownError(e.reason instanceof Error ? e.reason.stack ?? "" : "")) return;
      if (/Extension context invalidated/i.test(text)) return;
      logToJournal("error", "page", text);
    });
  }

  // src/core/staleContext.ts
  var stale = (reason) => /Extension context invalidated/i.test(reason instanceof Error ? reason.message : String(reason));
  function quietStaleContext(win = window) {
    watchErrors(false, win);
    win.addEventListener("error", (e) => {
      if (stale(e.error ?? e.message)) e.preventDefault();
    });
    win.addEventListener("unhandledrejection", (e) => {
      if (stale(e.reason)) e.preventDefault();
    });
  }

  // src/ebay/priceContent.ts
  quietStaleContext();
  var transactions = new FormTransactions();
  var quantities = new FormTransactions();
  var upcs = new FormTransactions();
  var variants = new FormTransactions();
  var busy = false;
  var enabled2 = true;
  void message({ type: "NATIVE_FRAME_REGISTER", kind: "variants" }).catch(
    () => {
    }
  );
  chrome.runtime.onMessage.addListener((msg, sender, reply) => {
    if (sender.id !== chrome.runtime.id) return;
    if (msg?.type === "NATIVE_VARIANTS_RUN" && sender.url?.startsWith(chrome.runtime.getURL(""))) {
      if (busy) {
        reply({ ok: false, error: "Une modification est en cours." });
        return;
      }
      busy = true;
      void (async () => {
        enabled2 = (await message({ type: "PUBLIC_SETTINGS" })).enabled;
        const job = await message({ type: "NATIVE_JOB" });
        if (!enabled2 || !job || job.id !== msg.id)
          throw Error("Import de variantes non autoris\xE9.");
        if (msg.action === "cancel-for-retry")
          return cancelUncreatedVariations(
            document,
            () => enabled2 && job.stage === "filling" && new URL(job.identity).searchParams.get("draftId") === new URL(location.href).searchParams.get("draftId")
          );
        return fillSupplierVariations(
          document,
          job,
          () => enabled2,
          msg.clearedAxes ?? []
        );
      })().then((data) => reply({ ok: true, data })).catch((e) => reply({ ok: false, error: e.message })).finally(() => {
        busy = false;
      });
      return true;
    }
    if (msg?.type === "SETTINGS_CHANGED") {
      void message({ type: "PUBLIC_SETTINGS" }).then((s) => {
        enabled2 = s.enabled;
      });
      return;
    }
    if (!sender.url?.startsWith(chrome.runtime.getURL("")) || ![
      "PRICES_EXTRACT",
      "PRICES_VARIANTS_APPLY",
      "PRICES_VARIANTS_UNDO",
      "PRICES_APPLY",
      "PRICES_UNDO",
      "PRICES_STOCK_APPLY",
      "PRICES_STOCK_UNDO",
      "PRICES_UPC_APPLY",
      "PRICES_UPC_UNDO"
    ].includes(msg?.type))
      return;
    if (busy) {
      reply({ ok: false, error: "Une modification est en cours." });
      return;
    }
    busy = true;
    void (async () => {
      const settings = await message({
        type: "PUBLIC_SETTINGS"
      });
      enabled2 = settings.enabled;
      if (!enabled2) throw Error("AurOEBay en pause");
      if (msg.type === "PRICES_EXTRACT")
        return {
          scriptVersion: version,
          identity: draftIdentity(location.href),
          fields: resolvePrices(document).map((r) => r.field),
          diagnostics: [...document.querySelectorAll("table")].slice(0, 10).map((table) => ({
            headers: [...table.querySelector("thead tr")?.children ?? []].map(
              (c) => (c.getAttribute("sortby") ?? c.textContent ?? "").trim().slice(0, 80)
            ),
            rows: table.querySelectorAll("tbody tr:not(.hide)").length,
            priceInputs: table.querySelectorAll('input[cn="prc"]').length
          })),
          upcs: resolveUPCs(document).map((r) => r.field),
          quantities: resolveQuantities(document).map((r) => r.field),
          snapshots: Object.fromEntries(
            resolvePrices(document).map((r) => [r.field.key, rowSnapshot(r.el)])
          )
        };
      if (msg.type === "PRICES_VARIANTS_UNDO")
        return variants.undo(document, () => location.href, settings);
      if (msg.type === "PRICES_VARIANTS_APPLY") {
        const scan = msg.request?.actions?.length ? await message({
          type: "VARIANT_STOCK_PROOF",
          url: msg.request.source
        }) : null;
        return applyVariants(
          document,
          () => location.href,
          settings,
          msg.request,
          scan,
          variants,
          () => enabled2
        );
      }
      if (msg.type === "PRICES_UPC_UNDO")
        return upcs.undo(document, () => location.href, settings);
      if (msg.type === "PRICES_UPC_APPLY") {
        if (!Array.isArray(msg.request?.changes) || !msg.request.changes.every(
          (c) => c.key?.startsWith("upc:")
        ))
          throw Error("Seuls les UPC des variantes sont autoris\xE9s");
        return upcs.apply(
          document,
          () => location.href,
          settings,
          msg.request,
          () => enabled2
        );
      }
      if (msg.type === "PRICES_STOCK_UNDO")
        return quantities.undo(document, () => location.href, settings);
      if (msg.type === "PRICES_STOCK_APPLY") {
        const scan = await message({
          type: "VARIANT_STOCK_PROOF",
          url: msg.request?.source
        });
        return applyStock(
          document,
          () => location.href,
          settings,
          msg.request,
          scan,
          quantities,
          () => enabled2
        );
      }
      if (msg.type === "PRICES_UNDO")
        return transactions.undo(document, () => location.href, settings);
      if (!msg.request?.changes?.every(
        (c) => c.key.startsWith("price:")
      ))
        throw Error("Seuls les prix des variantes sont autoris\xE9s");
      return transactions.apply(
        document,
        () => location.href,
        settings,
        msg.request,
        () => enabled2
      );
    })().then((data) => {
      busy = false;
      reply({ ok: true, data });
    }).catch((e) => {
      busy = false;
      reply({ ok: false, error: e.message });
    });
    return true;
  });
})();
