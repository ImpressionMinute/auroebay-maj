"use strict";
(() => {
  // src/core/messaging.ts
  async function message(body2) {
    const reply = await chrome.runtime.sendMessage(body2);
    if (!reply?.ok)
      throw Error(reply?.error ?? "AurOEBay ne r\xE9pond pas. Recharge la page.");
    return reply.data;
  }

  // src/core/license.ts
  var LICENSE_KEY = "license:v1";
  var CHECKOUT_URL = "https://auroebay.lemonsqueezy.com/checkout/buy/1b765c13-2f39-4847-82fa-e7950d112d63";
  var TRIAL_DAYS = 15;
  var CODE_MAX_DAYS = 93;
  var MANAGE_URL = "https://app.lemonsqueezy.com/my-orders";
  var AFFILIATE_URL = "https://auroebay.lemonsqueezy.com/affiliates";
  var GRACE_DAYS = 3;
  var DAY = 864e5;
  var OWNER_EXTENSION_ID = "bbedjpfnnkjadfjpbbmppikmgocoglfh";
  var SKEW = 10 * 6e4;
  var extensionId = () => globalThis.chrome?.runtime?.id ?? "";
  var ownerInstall = () => extensionId() === OWNER_EXTENSION_ID;
  function licenseActive(s, now = Date.now()) {
    if (!s) return false;
    if (s.owner) return ownerInstall();
    if (s.status === "trial") return trialActive(s, now);
    if (!s.key || s.status !== "active" || !s.checkedAt) return false;
    if (s.checkedAt > now + SKEW || (s.triedAt ?? 0) > now + SKEW) return false;
    if (typeof s.expiresAt === "string" && Date.parse(s.expiresAt) < now - DAY) return false;
    return now - s.checkedAt < GRACE_DAYS * DAY;
  }
  var PEPPER = "AurOEBay\xB7licence\xB7v1\xB74f1c9e27b8d36a05";
  var SEALED = ["owner", "key", "instanceId", "status", "checkedAt", "triedAt", "email", "expiresAt", "error", "trialUntil", "trialId"];
  async function hmac(text) {
    const enc = new TextEncoder();
    const raw = await crypto.subtle.digest("SHA-256", enc.encode(PEPPER + "|" + extensionId()));
    const key = await crypto.subtle.importKey("raw", raw, { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
    const sig = await crypto.subtle.sign("HMAC", key, enc.encode(text));
    return [...new Uint8Array(sig)].map((b) => b.toString(16).padStart(2, "0")).join("");
  }
  var body = (s) => JSON.stringify(SEALED.map((k) => s[k] ?? null));
  async function sealValid(s) {
    if (!s || typeof s.seal !== "string") return false;
    try {
      return s.seal === await hmac(body(s));
    } catch {
      return false;
    }
  }
  async function trustedLicense(raw) {
    const s = raw && typeof raw === "object" ? raw : {};
    if (await sealValid(s)) return { state: s, sealed: true };
    if (s.owner === true && ownerInstall()) return { state: { owner: true }, sealed: false };
    if (typeof s.key === "string" && typeof s.instanceId === "string")
      return { state: { key: s.key, instanceId: s.instanceId, status: "unverified" }, sealed: false };
    return { state: {}, sealed: false };
  }
  async function readLicense() {
    const raw = (await chrome.storage.local.get(LICENSE_KEY))[LICENSE_KEY];
    return (await trustedLicense(raw)).state;
  }
  var isTrialCode = (text) => /^ESSAI-/i.test(text.trim());
  function trialActive(s, now = Date.now()) {
    if (typeof s.trialUntil !== "number" || now >= s.trialUntil) return false;
    if ((s.checkedAt ?? 0) > now + SKEW) return false;
    return s.trialUntil - now <= (CODE_MAX_DAYS + 1) * DAY;
  }
  var trialDaysLeft = (s, now = Date.now()) => s?.status === "trial" && trialActive(s, now) ? Math.ceil((s.trialUntil - now) / DAY) : 0;
  function licenseLabel(s, now = Date.now()) {
    if (s?.owner) return "Version propri\xE9taire : aucune licence n\xE9cessaire.";
    if (s?.status === "trial" && trialActive(s, now)) {
      const left = trialDaysLeft(s, now);
      const end = new Date(s.trialUntil).toLocaleDateString("fr-FR", { day: "numeric", month: "long" });
      return `Essai gratuit : encore ${left} jour${left > 1 ? "s" : ""} (jusqu\u2019au ${end}). Abonne-toi avant pour continuer sans coupure.`;
    }
    if (s?.status === "trial" || s?.status === "trial-ended") return "Ton essai gratuit est termin\xE9 : abonne-toi pour continuer. Tes donn\xE9es sont gard\xE9es.";
    if (!s?.key) return `Aucune cl\xE9 de licence : commence ton essai gratuit de ${TRIAL_DAYS} jours, puis colle la cl\xE9 re\xE7ue par e-mail.`;
    if (licenseActive(s, now)) return `Abonnement actif${s.email ? ` (${s.email})` : ""}.`;
    if (s.status === "unverified") return s.error ? `${s.error} Ta licence sera v\xE9rifi\xE9e d\xE8s le retour de la connexion.` : "V\xE9rification de ta licence aupr\xE8s de Lemon Squeezy\u2026";
    if (s.status === "active") return "Impossible de v\xE9rifier ta licence depuis plus de 3 jours : v\xE9rifie ta connexion internet.";
    if (s.status === "expired") return "Abonnement termin\xE9 : renouvelle-le pour r\xE9activer AurOEBay.";
    if (s.status === "disabled") return "Licence d\xE9sactiv\xE9e : contacte bonjour@impression-minute.fr.";
    return s.error ?? "Licence inactive.";
  }
  function versionBelow(version, than) {
    if (!version) return false;
    const a = version.split(".").map(Number);
    const b = than.split(".").map(Number);
    for (let i = 0; i < 3; i++) if ((a[i] ?? 0) !== (b[i] ?? 0)) return (a[i] ?? 0) < (b[i] ?? 0);
    return false;
  }

  // src/core/text.ts
  var escapeHTML = (s) => s.replace(
    /[&<>"']/g,
    (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]
  );
  function redact(s) {
    return s.replace(/\bsk-[A-Za-z0-9_-]+/g, "[REDACTED_KEY]").replace(/Bearer\s+\S+/gi, "Bearer [REDACTED]").replace(/[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}/g, "[EMAIL]").replace(/https?:\/\/[^\s<>"']+/g, "[URL]");
  }

  // src/ui/license.ts
  var read = readLicense;
  function licenseBox(root) {
    const draw = async (note = "", error = false) => {
      const s = await read();
      const on = licenseActive(s);
      root.innerHTML = `
      <p class="lic-status ${on ? "ok" : "off"}">${on ? "\u2705" : "\u{1F512}"} ${escapeHTML(licenseLabel(s))}</p>
      ${s.owner ? "" : `
      <div class="lic-row">
        <input id="lic-key" placeholder="Colle ta cl\xE9 de licence ou ton code d\u2019essai" autocomplete="off" spellcheck="false" value="" />
        <button type="button" class="btn primary" id="lic-go">${s.key ? "Changer de cl\xE9" : "Activer"}</button>
      </div>
      <p class="lic-links">
        ${on && s.status !== "trial" ? "" : `<a class="btn small secondary" href="${CHECKOUT_URL}" target="_blank" rel="noopener">${s.key || s.status?.startsWith("trial") ? "S\u2019abonner \xB7 9,99 \u20AC/mois" : `Essai gratuit ${TRIAL_DAYS} jours`}</a>`}
        ${s.key ? `<a class="btn small secondary" href="${MANAGE_URL}" target="_blank" rel="noopener">G\xE9rer mon abonnement \u2197</a>
        <button type="button" class="btn small secondary" id="lic-check">V\xE9rifier maintenant</button>
        <button type="button" class="btn small secondary" id="lic-release" title="Pour utiliser ta cl\xE9 sur un autre ordinateur (2 au plus)">Lib\xE9rer cette cl\xE9</button>` : ""}
      </p>`}
      ${note ? `<p class="lic-note${error ? " err" : ""}">${escapeHTML(note)}</p>` : ""}`;
    };
    root.addEventListener("keydown", (e) => {
      if (e.key === "Enter" && e.target.id === "lic-key") {
        e.preventDefault();
        root.querySelector("#lic-go")?.click();
      }
    });
    root.addEventListener("click", async (e) => {
      const t = e.target;
      const run = async (button, job, done) => {
        button.disabled = true;
        try {
          await job();
          await draw(done);
        } catch (err) {
          await draw(err instanceof Error ? err.message : String(err), true);
        }
      };
      if (t.id === "lic-go") {
        const key = root.querySelector("#lic-key").value;
        await run(t, () => message({ type: "LICENSE_ACTIVATE", key }), isTrialCode(key) ? "Essai activ\xE9 : AurOEBay est pr\xEAt \u2713" : "Licence activ\xE9e : AurOEBay est pr\xEAt \u2713");
      } else if (t.id === "lic-check") await run(t, () => message({ type: "LICENSE_REFRESH" }), "V\xE9rifi\xE9 aupr\xE8s de Lemon Squeezy.");
      else if (t.id === "lic-release" && confirm("Lib\xE9rer la cl\xE9 sur ce navigateur ? AurOEBay se mettra en pause ici jusqu\u2019\xE0 ce que tu la remettes."))
        await run(t, () => message({ type: "LICENSE_RELEASE" }), "Cl\xE9 lib\xE9r\xE9e : tu peux l\u2019activer sur un autre ordinateur.");
    });
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "local" && changes[LICENSE_KEY] && !root.contains(document.activeElement)) void draw();
    });
    void draw();
  }
  function licenseBanner(doc = document) {
    if (/\/(welcome|options)\.html$/.test(location.pathname)) return;
    const show = async () => {
      doc.getElementById("lic-banner")?.remove();
      const s = await read();
      const left = trialDaysLeft(s);
      if (left > 0 && left <= 3) {
        const note = doc.createElement("div");
        note.id = "lic-banner";
        note.className = "lic-banner";
        note.innerHTML = `<span>\u23F3 ${escapeHTML(licenseLabel(s))}</span>
        <span><a class="btn small primary" href="${CHECKOUT_URL}" target="_blank" rel="noopener">S\u2019abonner</a> <a class="btn small secondary" href="welcome.html">Entrer ma cl\xE9</a></span>`;
        doc.body.prepend(note);
        return;
      }
      if (licenseActive(s)) return;
      const bar = doc.createElement("div");
      bar.id = "lic-banner";
      bar.className = "lic-banner";
      bar.innerHTML = `<span>\u{1F512} ${escapeHTML(licenseLabel(s))} AurOEBay est en pause ; tes donn\xE9es restent ici.</span>
      <span><a class="btn small primary" href="welcome.html">Entrer ma cl\xE9</a> <a class="btn small secondary" href="${CHECKOUT_URL}" target="_blank" rel="noopener">${s.key || s.status?.startsWith("trial") ? "S\u2019abonner" : `Essai gratuit ${TRIAL_DAYS} jours`}</a></span>`;
      doc.body.prepend(bar);
    };
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "local" && changes[LICENSE_KEY]) void show();
    });
    void show().catch(() => {
    });
  }

  // src/core/claudeBridge.ts
  var BRIDGE_KEY = "claudeBridgeOn:v1";
  var bridgeOpen = (value2) => value2 === true;

  // src/core/goal.ts
  var GOAL_KEY = "monthGoal:v1";
  function cleanGoal(x) {
    const v = x ?? {};
    const num = (n, max) => {
      const value2 = typeof n === "string" ? Number(n.replace(",", ".").trim() || NaN) : typeof n === "number" ? n : NaN;
      return Number.isFinite(value2) && value2 >= 1 ? Math.min(max, Math.round(value2)) : null;
    };
    return { sales: num(v.sales, 1e5), profit: num(v.profit, 1e7) };
  }
  var hasGoal = (g) => !!g && (g.sales !== null || g.profit !== null);

  // src/core/update.ts
  var UPDATE_KEY = "update:v1";
  var VERSION_URL = "https://auroebay.netlify.app/version.json";
  var MIRROR = "https://raw.githubusercontent.com/ImpressionMinute/auroebay-maj/main/";
  var VERSION_URLS = [VERSION_URL, MIRROR + "version.json"];
  var UPDATE_GUIDE_URL = "https://auroebay.netlify.app/mise-a-jour.html";
  var UPDATE_EVERY_MS = 24 * 36e5;
  var UPDATE_RECHECK_MS = 2 * 6e4;
  var WHATS_NEW_KEY = "whatsNew:v1";
  var NEWS_URL = "https://auroebay.netlify.app/nouveautes.html";
  var MAC_COMMAND = `curl -fsSL ${MIRROR}maj-mac.sh | bash`;
  var WINDOWS_COMMAND = `powershell -ExecutionPolicy Bypass -c "[Net.ServicePointManager]::SecurityProtocol=3072;irm ${MIRROR}maj-windows.ps1|iex"`;
  var DISK_WAIT_KEY = "updateOnDisk:v1";
  var SITE = "https://auroebay.netlify.app/";
  function cleanNotes(value2) {
    if (!Array.isArray(value2)) return [];
    return value2.filter((n) => typeof n === "string").map((n) => n.replace(/\s+/g, " ").trim().slice(0, 240)).filter(Boolean).slice(0, 8);
  }
  function parseReleaseNotes(value2) {
    if (!Array.isArray(value2)) return [];
    return value2.flatMap((r) => {
      const v = r;
      if (typeof v?.version !== "string" || !/^\d{1,4}\.\d{1,5}\.\d{1,6}$/.test(v.version)) return [];
      const notes = cleanNotes(v.notes);
      return notes.length ? [{ version: v.version, date: typeof v.date === "string" ? v.date.slice(0, 10) : "", notes }] : [];
    });
  }
  function parseVersionFile(value2) {
    const v = value2;
    if (typeof v?.version !== "string" || !/^\d{1,4}\.\d{1,5}\.\d{1,6}$/.test(v.version)) return null;
    if (typeof v.url !== "string" || !(v.url.startsWith(SITE) || v.url.startsWith(MIRROR)) || /["'<>\s]/.test(v.url)) return null;
    return { latest: v.version, url: v.url, notes: cleanNotes(v.notes) };
  }
  function updateAvailable(info, current) {
    return !!info?.latest && !!info.url && versionBelow(current, info.latest);
  }

  // src/ui/update.ts
  var DISMISSED = "updateDismissed:v1";
  var isWindows = () => /Windows/i.test(navigator.userAgent);
  function steps() {
    return isWindows() ? `<ol class="upd-steps"><li>Clique <b>Copier</b>.</li><li>Appuie sur les touches <kbd>\u229E Windows</kbd> + <kbd>R</kbd>.</li><li>Appuie sur <kbd>Ctrl</kbd> + <kbd>V</kbd>, puis <kbd>Entr\xE9e</kbd>.</li><li>Quand \xAB C\u2019est fait \xBB s\u2019affiche : <b>ferme compl\xE8tement Chrome et rouvre-le</b> (obligatoire).</li></ol>` : `<ol class="upd-steps"><li>Clique <b>Copier</b>.</li><li>Appuie sur <kbd>\u2318 Cmd</kbd> + <kbd>Espace</kbd>, tape <b>Terminal</b>, puis <kbd>Entr\xE9e</kbd>.</li><li>Appuie sur <kbd>\u2318 Cmd</kbd> + <kbd>V</kbd>, puis <kbd>Entr\xE9e</kbd>.</li><li>Quand \xAB C\u2019est fait \xBB s\u2019affiche : <b>quitte Chrome</b> (<kbd>\u2318 Cmd</kbd> + <kbd>Q</kbd>) <b>et rouvre-le</b> (obligatoire).</li></ol>`;
  }
  var list = (notes) => notes.length ? `<ul class="upd-notes">${notes.map((n) => `<li>${escapeHTML(n)}</li>`).join("")}</ul>` : "";
  function updateBanner(doc = document) {
    const current = chrome.runtime.getManifest().version;
    const show = async () => {
      doc.getElementById("upd-banner")?.remove();
      const got = await chrome.storage.local.get([UPDATE_KEY, DISMISSED]);
      const saved = got[UPDATE_KEY];
      const ok = parseVersionFile({ version: saved?.latest, url: saved?.url, notes: saved?.notes });
      const info = ok ? { ...ok, checkedAt: saved?.checkedAt } : void 0;
      if (!updateAvailable(info, current) || got[DISMISSED] === info.latest) return;
      const bar = doc.createElement("div");
      bar.id = "upd-banner";
      bar.className = "lic-banner upd-banner";
      const waiting = (await chrome.storage.local.get(DISK_WAIT_KEY))[DISK_WAIT_KEY];
      bar.innerHTML = waiting?.version ? `<div><b>\u2705 AurOEBay ${escapeHTML(waiting.version)} est pr\xEAt.</b> Il se recharge tout seul d\xE8s que ${escapeHTML(waiting.reason ?? "le travail en cours")} sera fini.</div>
      <span><button type="button" class="btn small primary" id="upd-now">Recharger maintenant</button></span>` : `<div><b>\u{1F195} AurOEBay ${escapeHTML(info.latest)} est disponible</b> (tu as ${escapeHTML(current)}).${ok.notes.length ? ` Ce que \xE7a apporte :${list(ok.notes)}` : ""}<p class="upd-how">Mise \xE0 jour en 1 minute, tes donn\xE9es sont gard\xE9es :</p>${steps()}<p class="upd-how small">Sans red\xE9marrer Chrome, les boutons AurOEBay ne marchent pas sur les pages eBay et AliExpress.</p></div>
      <span><button type="button" class="btn small primary" id="upd-copy">\u{1F4CB} Copier</button>
      <a class="btn small secondary" href="${UPDATE_GUIDE_URL}" target="_blank" rel="noopener">Aide en images</a>
      <button type="button" class="btn small secondary" id="upd-later">Plus tard</button></span>`;
      bar.querySelector("#upd-later")?.addEventListener("click", () => {
        void chrome.storage.local.set({ [DISMISSED]: info.latest });
      });
      bar.querySelector("#upd-now")?.addEventListener("click", () => {
        if (confirm("Recharger AurOEBay maintenant ? Le travail en cours sera interrompu (tes donn\xE9es sont gard\xE9es)."))
          void chrome.runtime.sendMessage({ type: "UPDATE_RELOAD_NOW" }).catch(() => {
          });
      });
      const copy = bar.querySelector("#upd-copy");
      copy?.addEventListener("click", () => {
        void navigator.clipboard.writeText(isWindows() ? WINDOWS_COMMAND : MAC_COMMAND).then(() => copy.textContent = "\u2713 Copi\xE9 ! \xC9tape 2 \u2192").catch(() => copy.textContent = "\u26A0 Copie impossible : utilise l\u2019aide en images");
      });
      doc.body.prepend(bar);
      poll();
    };
    let polling;
    const poll = () => {
      if (polling) return;
      polling = setInterval(() => {
        if (!doc.getElementById("upd-banner")) return void (clearInterval(polling), polling = void 0);
        void chrome.runtime.sendMessage({ type: "UPDATE_DISK" }).catch(() => {
        });
      }, 4e3);
    };
    const news = async () => {
      doc.getElementById("upd-news")?.remove();
      if ((await chrome.storage.local.get(WHATS_NEW_KEY))[WHATS_NEW_KEY] !== current) return;
      const notes = await fetch(chrome.runtime.getURL("release-notes.json")).then((r) => r.json()).then((v) => parseReleaseNotes(v).find((r) => r.version === current)?.notes ?? []).catch(() => []);
      if (!notes.length) return;
      const bar = doc.createElement("div");
      bar.id = "upd-news";
      bar.className = "lic-banner upd-banner upd-news";
      bar.innerHTML = `<div><b>\u{1F389} AurOEBay est \xE0 jour (${escapeHTML(current)}). Les nouveaut\xE9s :</b>${list(notes)}<p class="upd-how small">Si ce n\u2019est pas d\xE9j\xE0 fait : ferme compl\xE8tement Chrome et rouvre-le, sinon les boutons AurOEBay ne marchent pas sur les pages eBay et AliExpress d\xE9j\xE0 ouvertes.</p></div>
      <span><a class="btn small secondary" href="${NEWS_URL}" target="_blank" rel="noopener">Toutes les nouveaut\xE9s</a>
      <button type="button" class="btn small primary" id="upd-news-ok">J\u2019ai compris</button></span>`;
      bar.querySelector("#upd-news-ok")?.addEventListener("click", () => void chrome.storage.local.remove(WHATS_NEW_KEY));
      doc.body.prepend(bar);
    };
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "local") return;
      if (changes[UPDATE_KEY] || changes[DISMISSED] || changes[DISK_WAIT_KEY]) void show().catch(() => {
      });
      if (changes[WHATS_NEW_KEY]) void news().catch(() => {
      });
    });
    void show().catch(() => {
    });
    void news().catch(() => {
    });
    void chrome.runtime.sendMessage({ type: "UPDATE_CHECK" }).catch(() => {
    });
  }

  // src/core/debug.ts
  function safeDiagnostic(value2) {
    if (typeof value2 === "string") return redact(value2).slice(0, 3e4);
    if (Array.isArray(value2)) return value2.slice(0, 200).map(safeDiagnostic);
    if (value2 && typeof value2 === "object")
      return Object.fromEntries(
        Object.entries(value2).filter(
          ([k]) => !/(api.?key|authorization|cookie|token|secret|password)/i.test(k) || /^(input_tokens|output_tokens|reasoning_tokens|maxOutputTokens)$/.test(
            k
          )
        ).map(([k, v]) => [k, safeDiagnostic(v)])
      );
    return value2;
  }

  // src/core/links.ts
  var DISCORD_URL = "https://discord.gg/sr2g2ZZZQ9";

  // src/ui/report.ts
  var REPORT_URL = "https://auroebay.netlify.app/";
  var SUPPORT_EMAIL = "bonjour@impression-minute.fr";
  var MAX_IMAGE = 5 * 1024 * 1024;
  async function technicalReport(extra) {
    const health = await message({ type: "HEALTH_CHECK" }).catch(() => []);
    let session = {};
    try {
      session = await chrome.storage.session.get(["apiTrace:v1", "lastPanelError:v1"]);
    } catch {
    }
    const trace = session["apiTrace:v1"];
    const report = {
      version: chrome.runtime.getManifest().version,
      navigateur: navigator.userAgent,
      page: location.pathname,
      "tout-va-bien": health.map((x) => `${x.ok ? "OK" : x.unknown ? "?" : "!!"} ${x.title} : ${x.text}`),
      "derniere-erreur": session["lastPanelError:v1"] ?? null,
      "trace-import": trace?.slice(-40) ?? []
    };
    const text = JSON.stringify(safeDiagnostic(report), null, 2);
    return (extra ? `${text}

--- Panneau ---
${extra}` : text).slice(0, 6e4);
  }
  var CSS = `
.rp{border:0;border-radius:18px;padding:0;max-width:520px;width:calc(100vw - 32px);background:var(--surface,#fff);color:var(--text,#1d1a24);box-shadow:0 24px 60px rgba(0,0,0,.4);font:14px system-ui,-apple-system,sans-serif}
.rp::backdrop{background:rgba(10,8,14,.55)}
.rp form{display:grid;gap:12px;padding:20px 22px}
.rp h2{margin:0;font-size:19px}
.rp p{margin:0;color:var(--muted,#a49bb0);line-height:1.45}
.rp .rp-community a{color:#ff8a3d;font-weight:600}
.rp label{display:grid;gap:6px;font-weight:600}
.rp textarea,.rp input[type=email]{font:inherit;padding:10px 12px;border-radius:10px;border:1px solid var(--line,#3a3346);background:var(--bg,var(--field,#faf7f3));color:inherit}
.rp textarea{min-height:110px;resize:vertical}
.rp .rp-check{display:flex;align-items:center;gap:8px;font-weight:500;color:var(--muted,#75697d)}.rp .rp-check input{width:auto;flex:none;margin:0}.rp h2{color:inherit}
.rp .rp-actions{display:flex;flex-wrap:wrap;gap:8px;justify-content:flex-end}.rp .rp-copy{margin-right:auto;font-weight:500}
.rp button{font:600 14px system-ui;border-radius:10px;padding:9px 16px;border:1px solid var(--line,#ddd);background:transparent;color:var(--text,#1d1a24);cursor:pointer}
.rp button.primary{background:linear-gradient(135deg,#ff5f3a,#ff8a3d 50%,#ffb347);border-color:transparent;color:#fff}
.rp button:disabled{opacity:.6;cursor:default}
.rp .rp-msg{font-weight:600}
.rp .rp-msg.ok{color:#3fd09a}.rp .rp-msg.err{color:#ff6b78}
`;
  function openReport(extra) {
    document.getElementById("auroebay-report")?.remove();
    if (!document.getElementById("auroebay-report-css")) {
      const style = document.createElement("style");
      style.id = "auroebay-report-css";
      style.textContent = CSS;
      document.head.append(style);
    }
    const dialog = document.createElement("dialog");
    dialog.id = "auroebay-report";
    dialog.className = "rp";
    dialog.innerHTML = `<form method="dialog">
      <h2>\u{1F198} Un souci avec AurOEBay ?</h2>
      <p>Explique simplement ce qui ne marche pas. Le message part directement, pas besoin de bo\xEEte e-mail.</p>
      <p class="rp-community">\u{1F4AC} Plut\xF4t une question ? <a href="${DISCORD_URL}" target="_blank" rel="noopener">Demande \xE0 la communaut\xE9 AurOEBay sur Discord \u2197</a></p>
      <label>Qu\u2019est-ce qui ne marche pas ?<textarea name="message" required maxlength="4000" placeholder="Ex. : quand je clique \xAB Cr\xE9er le brouillon \xBB, rien ne se passe."></textarea></label>
      <label>Une capture d\u2019\xE9cran (si tu veux)<input name="capture" type="file" accept="image/*"></label>
      <label>Ton e-mail, pour te r\xE9pondre (si tu veux)<input name="email" type="email" maxlength="200" placeholder="toi@exemple.fr"></label>
      <label class="rp-check"><input name="tech" type="checkbox" checked> Joindre le rapport technique (aucun mot de passe ni cl\xE9)</label>
      <p class="rp-msg" hidden></p>
      <div class="rp-actions"><button type="button" class="rp-copy" title="Pour le coller dans un message">\u{1F4CB} Copier le rapport</button><button type="button" value="cancel" class="rp-cancel">Annuler</button><button type="submit" class="primary">Envoyer</button></div>
    </form>`;
    document.body.append(dialog);
    const form2 = dialog.querySelector("form");
    const msg = dialog.querySelector(".rp-msg");
    const send = dialog.querySelector("button[type=submit]");
    const say = (text, kind = "") => {
      msg.hidden = false;
      msg.className = `rp-msg ${kind}`;
      msg.textContent = text;
    };
    dialog.querySelector(".rp-cancel").addEventListener("click", () => dialog.close());
    dialog.querySelector(".rp-copy").addEventListener("click", async () => {
      try {
        await navigator.clipboard.writeText(await technicalReport(extra ? await extra().catch(() => "") : void 0));
        say("\u{1F4CB} Rapport copi\xE9 (aucun mot de passe ni cl\xE9).", "ok");
      } catch {
        say("Copie impossible.", "err");
      }
    });
    dialog.addEventListener("close", () => dialog.remove());
    form2.addEventListener("submit", async (event) => {
      event.preventDefault();
      const text = form2.elements.namedItem("message").value.trim();
      if (!text) return say("\xC9cris d\u2019abord ce qui ne marche pas.", "err");
      const file = form2.elements.namedItem("capture").files?.[0];
      if (file && file.size > MAX_IMAGE) return say("Capture trop lourde (5 Mo au plus).", "err");
      send.disabled = true;
      say("Envoi\u2026");
      const version = chrome.runtime.getManifest().version;
      const tech = form2.elements.namedItem("tech").checked ? await technicalReport(extra ? await extra().catch(() => "") : void 0).catch(() => "") : "";
      const body2 = new FormData();
      body2.set("form-name", "probleme");
      body2.set("bot-field", "");
      body2.set("message", text);
      body2.set("email", form2.elements.namedItem("email").value.trim());
      body2.set("version", version);
      body2.set("rapport", tech);
      if (file) body2.set("capture", file, file.name);
      try {
        const r = await fetch(REPORT_URL, { method: "POST", body: body2, signal: AbortSignal.timeout(3e4) });
        if (!r.ok) throw Error(String(r.status));
        say("\u2705 Envoy\xE9, merci ! Tu auras une r\xE9ponse par e-mail si tu as laiss\xE9 ton adresse.", "ok");
        send.textContent = "Fermer";
        send.disabled = false;
        send.type = "button";
        send.addEventListener("click", () => dialog.close(), { once: true });
      } catch {
        try {
          await navigator.clipboard.writeText(`${text}

${tech}`);
        } catch {
        }
        window.open(
          `mailto:${SUPPORT_EMAIL}?subject=${encodeURIComponent(`AurOEBay ${version} : un probl\xE8me`)}&body=${encodeURIComponent(`${text}

(Le rapport est copi\xE9 : colle-le ici avec Cmd+V ou Ctrl+V.)`)}`,
          "_blank"
        );
        say("L\u2019envoi direct n\u2019a pas march\xE9 : un e-mail s\u2019ouvre, ton message y est d\xE9j\xE0 (colle le rapport avec Cmd+V ou Ctrl+V).", "err");
        send.disabled = false;
      }
    });
    dialog.showModal();
    form2.elements.namedItem("message").focus();
  }

  // src/ui/theme.ts
  function setupTheme() {
    licenseBanner();
    updateBanner();
    simpleTopbar();
    const system = matchMedia("(prefers-color-scheme: dark)");
    const button = document.getElementById("theme-toggle");
    const choice = document.getElementById(
      "theme-choice"
    );
    let theme = "system";
    let revision = 0;
    const valid = (value2) => value2 === "light" || value2 === "dark" ? value2 : "system";
    const render = () => {
      const dark = theme === "dark" || theme === "system" && system.matches;
      document.documentElement.dataset.theme = dark ? "dark" : "light";
      if (button) {
        button.textContent = dark ? "\u2600" : "\u263E";
        button.setAttribute("aria-pressed", String(dark));
        button.setAttribute(
          "aria-label",
          dark ? "Activer le mode clair" : "Activer le mode sombre"
        );
        button.title = button.getAttribute("aria-label");
      }
      if (choice) choice.value = theme;
    };
    const save = async (value2) => {
      revision++;
      theme = value2;
      render();
      try {
        await chrome.storage.local.set({ uiTheme: value2 });
      } catch {
      }
    };
    button?.addEventListener(
      "click",
      () => void save(
        document.documentElement.dataset.theme === "dark" ? "light" : "dark"
      )
    );
    choice?.addEventListener("change", () => void save(valid(choice.value)));
    system.addEventListener("change", render);
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "local" && changes.uiTheme) {
        revision++;
        theme = valid(changes.uiTheme.newValue);
        render();
      }
    });
    const initial = revision;
    void chrome.storage.local.get("uiTheme").then(({ uiTheme }) => {
      if (revision === initial) theme = valid(uiTheme);
      render();
    }).catch(() => render());
    render();
  }
  var PAGES = [
    ["routine.html", "\u2600\uFE0F Ma journ\xE9e"],
    ["dashboard.html", "\u{1F4E6} Mes produits"],
    ["scout.html", "\u{1F50D} Trouver"],
    ["sales.html", "\u{1F4D2} Ventes"]
  ];
  function simpleTopbar() {
    const bar = document.querySelector("header.topbar");
    const actions = bar?.querySelector(".top-actions");
    if (!bar || !actions || bar.querySelector(".ao-nav")) return;
    const here = location.pathname.split("/").pop() || "";
    if (here === "welcome.html") return;
    actions.querySelectorAll("a[href]").forEach((a) => {
      if (PAGES.some(([href]) => a.getAttribute("href") === href)) a.remove();
    });
    const nav = document.createElement("nav");
    nav.className = "ao-nav";
    nav.setAttribute("aria-label", "Pages d\u2019AurOEBay");
    for (const [href, label] of PAGES) {
      const a = document.createElement("a");
      a.href = href;
      a.textContent = label;
      if (href === here) {
        a.className = "on";
        a.setAttribute("aria-current", "page");
      }
      nav.append(a);
    }
    bar.querySelector(".brand")?.after(nav);
    bar.querySelector(".brand .crumb")?.remove();
    if (here !== "options.html") {
      const settings2 = document.createElement("a");
      settings2.className = "btn ghost";
      settings2.href = "options.html";
      settings2.textContent = "\u2699\uFE0F Param\xE8tres";
      actions.append(settings2);
    }
    const help = document.createElement("button");
    help.id = "help-report";
    help.type = "button";
    help.className = "btn ghost";
    help.textContent = "\u{1F198} Aide";
    help.title = "Un souci ? \xC9cris-nous, c\u2019est envoy\xE9 tout de suite";
    help.addEventListener("click", () => openReport());
    actions.append(help);
  }

  // src/core/descriptionDesign.ts
  var DESCRIPTION_TEMPLATE = '<style>\n.auro-listing{font-family:Arial,Helvetica,sans-serif;color:#213a37;background:#f3f5f3;max-width:960px;margin:0 auto;padding:24px;box-sizing:border-box;line-height:1.65}\n.auro-listing *{box-sizing:border-box}.auro-listing .auro-brand{font-size:12px;letter-spacing:3px;font-weight:bold;margin-bottom:20px;color:#44645b}.auro-listing .auro-header{background:#183e35;color:white;border-radius:14px;padding:30px}.auro-listing h1{font-size:26px;line-height:1.3;margin:10px 0 0}.auro-listing .auro-eyebrow{font-size:11px;letter-spacing:2px;text-transform:uppercase}.auro-listing .auro-body{background:white;border:1px solid #dce5dd;border-radius:14px;margin-top:18px;padding:24px;overflow-wrap:anywhere}.auro-listing .auro-body img{max-width:100%!important;height:auto!important;display:block;margin:18px auto}.auro-listing .auro-body table{max-width:100%;width:auto}.auro-listing .auro-body p{margin:12px 0}.auro-listing .auro-note{font-size:13px;color:#587064;padding:18px 4px}.auro-listing .auro-note strong{color:#213a37}@media(max-width:600px){.auro-listing{padding:12px}.auro-listing .auro-header,.auro-listing .auro-body{padding:18px}.auro-listing h1{font-size:22px}}\n</style>\n<div class="auro-listing">\n{store}\n<div class="auro-header"><div class="auro-eyebrow">Product details</div><h1>{title}</h1></div>\n<div class="auro-body">{description}</div>\n<div class="auro-note"><strong>Choose your option</strong><br>Please check the selected variation, dimensions and item details before ordering.<br>Delivery estimates, shipping charges and return terms are shown in this eBay listing.</div>\n</div>\n';
  var listingStore = "";
  var DESCRIPTION_THEMES = {
    classic: { label: "Vert classique", font: "Arial,Helvetica,sans-serif", ink: "#213a37", page: "#f3f5f3", brand: "#44645b", header: "#183e35", headerInk: "white", card: "white", border: "#dce5dd", radius: "14px", note: "#587064" },
    minimal: { label: "Blanc minimal", font: "Helvetica,Arial,sans-serif", ink: "#1d1d1f", page: "#ffffff", brand: "#86868b", header: "#ffffff;border-bottom:2px solid #1d1d1f", headerInk: "#1d1d1f", card: "white", border: "#e5e5e7", radius: "4px", note: "#6e6e73" },
    ocean: { label: "Bleu oc\xE9an", font: "Arial,Helvetica,sans-serif", ink: "#13293d", page: "#eef4fa", brand: "#2f6690", header: "linear-gradient(135deg,#0b4f9c,#1677d2)", headerInk: "white", card: "white", border: "#d4e3f2", radius: "14px", note: "#4a6582" },
    noir: { label: "Noir & or", font: "Georgia,'Times New Roman',serif", ink: "#1a1a1a", page: "#f5f3ee", brand: "#a8842c", header: "#111111", headerInk: "#f5c451", card: "white", border: "#e6dfcf", radius: "6px", note: "#6b6252" },
    sunset: { label: "Orange \xE9nergie", font: "Arial,Helvetica,sans-serif", ink: "#2b1d16", page: "#fff6ef", brand: "#e8590c", header: "linear-gradient(135deg,#ff5f3a,#ff8a3d 50%,#ffb347)", headerInk: "white", card: "white", border: "#ffe0cc", radius: "18px", note: "#7a5a48" },
    rose: { label: "Rose doux", font: "'Trebuchet MS',Arial,sans-serif", ink: "#3b1f2b", page: "#fff0f5", brand: "#c2255c", header: "linear-gradient(135deg,#f06595,#faa2c1)", headerInk: "white", card: "white", border: "#fcd6e3", radius: "20px", note: "#86566a" },
    tech: { label: "Tech sombre", font: "Verdana,Arial,sans-serif", ink: "#1b2733", page: "#e9eef2", brand: "#0c8599", header: "linear-gradient(135deg,#1b2733,#22394d)", headerInk: "#66d9e8", card: "white", border: "#cfd9e1", radius: "10px", note: "#52667a" }
  };
  var listingTheme = "classic";
  function setListingTheme(id) {
    listingTheme = typeof id === "string" && id in DESCRIPTION_THEMES ? id : "classic";
  }
  function descriptionTemplate(id = listingTheme) {
    const t = DESCRIPTION_THEMES[id];
    if (!t || id === "classic") return DESCRIPTION_TEMPLATE;
    return DESCRIPTION_TEMPLATE.replace("font-family:Arial,Helvetica,sans-serif", `font-family:${t.font}`).replace("color:#213a37;background:#f3f5f3", `color:${t.ink};background:${t.page}`).replace("color:#44645b", `color:${t.brand}`).replace("background:#183e35;color:white;border-radius:14px", `background:${t.header};color:${t.headerInk};border-radius:${t.radius}`).replace("background:white;border:1px solid #dce5dd;border-radius:14px", `background:${t.card};border:1px solid ${t.border};border-radius:${t.radius}`).replace("color:#587064", `color:${t.note}`).replace(".auro-note strong{color:#213a37}", `.auro-note strong{color:${t.ink}}`);
  }
  function setListingStore(name) {
    listingStore = typeof name === "string" ? name.trim().slice(0, 40) : "";
  }
  function listingDescriptionHTML(title, bodyHTML, store = listingStore, theme = listingTheme) {
    const text = escapeHTML(title).replace(/&#39;/g, "'").replace(/&quot;/g, '"').replace(/\u00a0/g, "&nbsp;");
    const brand = store ? `<div class="auro-brand">${escapeHTML(store.toUpperCase().replace(/\s+/g, ""))}</div>
` : "";
    return descriptionTemplate(theme).replace(
      /\{title\}|\{description\}|\{store\}\n?/g,
      (placeholder) => placeholder === "{title}" ? text : placeholder === "{description}" ? bodyHTML : brand
    );
  }

  // src/core/bannerStyle.ts
  var BANNER_PRESETS = {
    aurore: { label: "Orange Aurore", stops: ["#ff5f3a", "#ff8a3d", "#ffb347"], ink: "#ffffff", shadow: "rgba(150,30,10,.25)" },
    rouge: { label: "Rouge promo", stops: ["#c8102e", "#e3262f", "#ff4d4d"], ink: "#ffffff", shadow: "rgba(80,0,0,.3)" },
    noir: { label: "Noir & or", stops: ["#0d0d0d", "#1c1c1c", "#2b2b2b"], ink: "#f5c451", shadow: "rgba(0,0,0,.5)" },
    bleu: { label: "Bleu oc\xE9an", stops: ["#0b4f9c", "#1677d2", "#36a3f5"], ink: "#ffffff", shadow: "rgba(0,30,80,.3)" },
    vert: { label: "Vert frais", stops: ["#0f7a4a", "#16a05e", "#3cc77c"], ink: "#ffffff", shadow: "rgba(0,60,30,.3)" },
    rose: { label: "Rose", stops: ["#d6336c", "#f06595", "#faa2c1"], ink: "#ffffff", shadow: "rgba(110,0,40,.25)" },
    violet: { label: "Violet n\xE9on", stops: ["#5f3dc4", "#7950f2", "#b197fc"], ink: "#ffffff", shadow: "rgba(40,0,90,.3)" },
    jaune: { label: "Jaune flash", stops: ["#ffd43b", "#ffe066", "#fff3bf"], ink: "#1a1a1a", shadow: "rgba(120,90,0,.2)" },
    blanc: { label: "Blanc sobre", stops: ["#ffffff", "#f6f6f6", "#ececec"], ink: "#1a1a1a", shadow: "rgba(0,0,0,.08)" }
  };
  var BANNER_TEXT = /^[\p{L}\p{N} !%&'+.,:/#$€£-]*$/u;
  function bannerStyle(s) {
    const preset = BANNER_PRESETS[s.bannerPreset ?? "aurore"] ?? BANNER_PRESETS.aurore;
    return {
      stops: preset.stops,
      ink: preset.ink,
      shadow: preset.shadow,
      main: (s.bannerMain ?? "SALE").trim(),
      title: (s.bannerTitle ?? "HOT DEALS").trim(),
      sub: (s.bannerSub ?? "SHOP NOW").trim(),
      position: s.bannerPosition === "bottom" ? "bottom" : "top"
    };
  }

  // src/core/settings.ts
  var DEFAULTS = {
    enabled: true,
    model: "gpt-5-nano",
    reasoningEffort: "minimal",
    temperature: null,
    timeoutMs: 9e4,
    maxTitle: 80,
    minTitle: 65,
    autoConfidence: 0.9,
    probableConfidence: 0.75,
    strictFactual: true,
    rewriteDescription: true,
    aiSpecifics: true,
    captureEnabled: true,
    sourceExpiryMinutes: 120,
    sellerEnabled: true,
    haloEnabled: true,
    sellerTtlDays: 7,
    resultsEnabled: false,
    saleBanner: true,
    bannerPreset: "aurore",
    bannerMain: "SALE",
    bannerTitle: "HOT DEALS",
    bannerSub: "SHOP NOW",
    bannerPosition: "top",
    descriptionTemplate: "classic",
    storeName: "",
    debug: false,
    showSelectors: false,
    fallbackSelectors: { title: "", description: "", specifics: "" }
  };
  function validateSettings(input) {
    const s = {
      ...DEFAULTS,
      ...input,
      fallbackSelectors: {
        ...DEFAULTS.fallbackSelectors,
        ...input.fallbackSelectors
      }
    };
    const range = (key, min, max) => {
      const n = s[key];
      if (typeof n !== "number" || !Number.isFinite(n) || n < min || n > max)
        throw Error(`Invalid setting: ${key} (${min}\u2013${max})`);
    };
    range("timeoutMs", 5e3, 18e4);
    range("maxTitle", 20, 80);
    range("minTitle", 0, s.maxTitle);
    range("autoConfidence", 0.9, 1);
    range("probableConfidence", 0.75, s.autoConfidence);
    range("sourceExpiryMinutes", 1, 1440);
    if (![1, 3, 7, 14, 30].includes(s.sellerTtlDays))
      throw Error("Invalid seller TTL");
    if (!/^[a-zA-Z0-9._:-]{1,100}$/.test(s.model))
      throw Error("Invalid model name");
    if (!["", "none", "minimal", "low", "medium", "high"].includes(
      s.reasoningEffort
    ))
      throw Error("Invalid reasoning effort");
    if (s.temperature !== null && (typeof s.temperature !== "number" || !Number.isFinite(s.temperature) || s.temperature < 0 || s.temperature > 2))
      throw Error("Invalid temperature");
    for (const k of [
      "enabled",
      "strictFactual",
      "rewriteDescription",
      "aiSpecifics",
      "captureEnabled",
      "sellerEnabled",
      "haloEnabled",
      "resultsEnabled",
      "saleBanner",
      "debug",
      "showSelectors"
    ])
      if (typeof s[k] !== "boolean") throw Error(`Invalid ${k}`);
    if (typeof s.storeName !== "string" || s.storeName.length > 40 || /[<>{}]/.test(s.storeName))
      throw Error("Nom de boutique invalide (40 caract\xE8res, sans < > { }).");
    s.storeName = s.storeName.trim();
    if (!(s.bannerPreset in BANNER_PRESETS)) throw Error("Couleurs du bandeau inconnues.");
    if (!["top", "bottom"].includes(s.bannerPosition)) throw Error("Position du bandeau invalide.");
    for (const [k, max] of [["bannerMain", 12], ["bannerTitle", 20], ["bannerSub", 24]]) {
      if (typeof s[k] !== "string" || s[k].length > max || !BANNER_TEXT.test(s[k]))
        throw Error(`Texte du bandeau trop long ou avec des signes non permis (${max} caract\xE8res au plus).`);
      s[k] = s[k].trim();
    }
    if (!s.bannerMain && !s.bannerTitle && !s.bannerSub) throw Error("Le bandeau a besoin d\u2019au moins un texte.");
    if (!(s.descriptionTemplate in DESCRIPTION_THEMES)) throw Error("Mod\xE8le de description inconnu.");
    for (const v of Object.values(s.fallbackSelectors))
      if (typeof v !== "string" || v.length > 500)
        throw Error("Invalid selector");
    return s;
  }
  async function getSettings() {
    const { settings: settings2, extensionEnabled = true, [LICENSE_KEY]: license } = await chrome.storage.local.get([
      "settings",
      "extensionEnabled",
      LICENSE_KEY
    ]);
    const on = extensionEnabled !== false && licenseActive((await trustedLicense(license)).state);
    try {
      const s = validateSettings({
        ...settings2,
        enabled: on
      });
      setListingStore(s.storeName);
      setListingTheme(s.descriptionTemplate);
      return s;
    } catch {
      return {
        ...structuredClone(DEFAULTS),
        enabled: on
      };
    }
  }

  // src/ui/power.ts
  function setupPower(onChange) {
    const button = document.querySelector("#power-toggle");
    let enabled = true;
    const render = async () => {
      enabled = (await getSettings()).enabled;
      button.setAttribute("aria-checked", String(enabled));
      button.textContent = enabled ? "ON" : "OFF";
      button.disabled = false;
      document.querySelector("#power-state").textContent = enabled ? "AurOEBay activ\xE9e" : "AurOEBay en pause";
      document.querySelector("#power-help").textContent = enabled ? "Clique pour mettre en pause." : "Cl\xE9 et r\xE9glages conserv\xE9s. Clique pour reprendre.";
      onChange?.(enabled);
    };
    button.addEventListener("click", async () => {
      button.disabled = true;
      try {
        await chrome.storage.local.set({ extensionEnabled: !enabled });
      } catch {
        document.querySelector("#power-help").textContent = "Impossible de changer l\u2019\xE9tat. R\xE9essaie.";
      } finally {
        await render();
      }
    });
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "local" && (changes.extensionEnabled || changes.settings))
        void render();
    });
    void render();
  }

  // src/seller/cache.ts
  async function clearSellerCache() {
    const all = await chrome.storage.local.get(null);
    await chrome.storage.local.remove(
      Object.keys(all).filter((k) => k.startsWith("seller:"))
    );
  }

  // src/ebay/saleBanner.ts
  async function saleBannerFromPage(image, style) {
    try {
      const look = {
        stops: ["#ff5f3a", "#ff8a3d", "#ffb347"],
        ink: "#ffffff",
        shadow: "rgba(150,30,10,.25)",
        main: "SALE",
        title: "HOT DEALS",
        sub: "SHOP NOW",
        position: "top",
        ...style ?? {}
      };
      if (!image || typeof image.data !== "string" || !/^image\//.test(image.mime))
        return { ok: false, error: "Photo invalide." };
      const binary = atob(image.data);
      const bytes = Uint8Array.from(binary, (c) => c.charCodeAt(0));
      const bitmap = await createImageBitmap(new Blob([bytes], { type: image.mime }));
      try {
        if (!bitmap.width || !bitmap.height || bitmap.width * bitmap.height > 4e7)
          return { ok: false, error: "Dimensions de la photo inexploitables." };
        const S = 1600;
        const k = S / 1200;
        const band = Math.round(150 * k);
        const canvas = document.createElement("canvas");
        canvas.width = S;
        canvas.height = S;
        const g = canvas.getContext("2d");
        if (!g) return { ok: false, error: "Dessin indisponible." };
        g.fillStyle = "#ffffff";
        g.fillRect(0, 0, S, S);
        const room = S - band;
        const top = look.position === "bottom" ? 0 : band;
        const bandY = look.position === "bottom" ? S - band : 0;
        const cover = Math.max(S / bitmap.width, room / bitmap.height);
        const cw = bitmap.width * cover;
        const ch = bitmap.height * cover;
        const kept = Math.min(S / cw, room / ch);
        g.imageSmoothingQuality = "high";
        g.save();
        g.beginPath();
        g.rect(0, top, S, room);
        g.clip();
        if (kept >= 0.85) g.drawImage(bitmap, (S - cw) / 2, top + (room - ch) / 2, cw, ch);
        else {
          g.save();
          g.filter = `blur(${Math.round(30 * k)}px) brightness(0.9)`;
          g.drawImage(bitmap, (S - cw * 1.1) / 2, top + (room - ch * 1.1) / 2, cw * 1.1, ch * 1.1);
          g.restore();
          const fit = Math.min(S / bitmap.width, room / bitmap.height);
          const w = bitmap.width * fit;
          const h = bitmap.height * fit;
          g.drawImage(bitmap, (S - w) / 2, top + (room - h) / 2, w, h);
        }
        g.restore();
        const gradient = g.createLinearGradient(0, bandY, S, bandY + band * 2);
        look.stops.forEach((c, i) => gradient.addColorStop(i / Math.max(1, look.stops.length - 1), c));
        g.fillStyle = gradient;
        g.fillRect(0, bandY, S, band);
        g.save();
        g.translate(0, bandY);
        const family = 'system-ui, -apple-system, "Helvetica Neue", Arial, sans-serif';
        const font = (weight, size) => `${weight} ${Math.round(size * k)}px ${family}`;
        const spaced = (px) => {
          g.letterSpacing = `${px * k}px`;
        };
        g.textBaseline = "alphabetic";
        let z = 1;
        const sizes = () => {
          spaced(-2 * z);
          g.font = font(900, 108 * z);
          const a = look.main ? g.measureText(look.main).width : 0;
          spaced(-1 * z);
          g.font = font(800, 52 * z);
          const b = look.title ? g.measureText(look.title).width : 0;
          spaced(2 * z);
          g.font = font(600, 24 * z);
          const c = look.sub ? g.measureText(look.sub).width : 0;
          return { a, b, c };
        };
        let m = sizes();
        const gap = 28 * k;
        const bar = 4 * k;
        const width = () => m.a + (m.a && (m.b || m.c) ? gap + bar + gap : 0) + Math.max(m.b, m.c);
        while (width() > S - 80 * k && z > 0.4) {
          z -= 0.05;
          m = sizes();
        }
        const sale = m.a;
        const total = width();
        let x = (S - total) / 2;
        const middle = band / 2;
        if (look.main) {
          spaced(-2 * z);
          g.font = font(900, 108 * z);
          g.fillStyle = look.shadow;
          g.fillText(look.main, x, middle + 38 * k * z + 4 * k);
          g.fillStyle = look.ink;
          g.fillText(look.main, x, middle + 38 * k * z);
          x += sale;
          if (m.b || m.c) {
            x += gap;
            g.fillStyle = look.ink;
            g.globalAlpha = 0.7;
            const barHeight = 86 * k * z;
            g.beginPath();
            g.roundRect(x, middle - barHeight / 2, bar, barHeight, bar / 2);
            g.fill();
            g.globalAlpha = 1;
            x += bar + gap;
          }
        }
        g.fillStyle = look.ink;
        const both = !!(m.b && m.c);
        if (m.b) {
          spaced(-1 * z);
          g.font = font(800, 52 * z);
          g.fillText(look.title, x, both ? middle + 4 * k * z : middle + 18 * k * z);
        }
        if (m.c) {
          spaced(2 * z);
          g.font = font(600, 24 * z);
          g.globalAlpha = 0.95;
          g.fillText(look.sub, x, both ? middle + 40 * k * z : middle + 9 * k * z);
          g.globalAlpha = 1;
        }
        spaced(0);
        g.restore();
        const blob = await new Promise((resolve) => canvas.toBlob(resolve, "image/jpeg", 0.92));
        if (!blob || !blob.size || blob.size > 8 * 1024 * 1024)
          return { ok: false, error: "Photo avec bandeau trop volumineuse." };
        const out = new Uint8Array(await blob.arrayBuffer());
        let text = "";
        for (let i = 0; i < out.length; i += 32768)
          text += String.fromCharCode(...out.subarray(i, i + 32768));
        return { ok: true, data: btoa(text), mime: "image/jpeg", size: out.length };
      } finally {
        bitmap.close();
      }
    } catch (error) {
      return { ok: false, error: error instanceof Error ? error.message : String(error) };
    }
  }

  // src/ui/options.ts
  setupTheme();
  setupGoal();
  document.querySelector("#referral-join").href = AFFILIATE_URL;
  var form = document.querySelector("#settings-form");
  document.getElementById("options-version").textContent = chrome.runtime.getManifest().version;
  var field = (name) => form.elements.namedItem(name);
  var status = (s) => {
    document.querySelector("#settings-status").textContent = s;
  };
  var settings;
  async function load() {
    settings = await getSettings();
    for (const [key, value2] of Object.entries(settings)) {
      const el = field(key);
      if (!el) continue;
      if (el instanceof HTMLInputElement && el.type === "checkbox")
        el.checked = Boolean(value2);
      else el.value = value2 === null ? "" : String(value2);
    }
    field("timeoutSeconds").value = String(settings.timeoutMs / 1e3);
    for (const key of ["title", "description", "specifics"])
      field(`fallback${key[0].toUpperCase() + key.slice(1)}`).value = settings.fallbackSelectors[key];
    const { apiKey } = await chrome.storage.local.get("apiKey");
    document.querySelector("#key-status").textContent = apiKey ? "Une cl\xE9 est enregistr\xE9e et masqu\xE9e. Laisse le champ vide pour la conserver." : "Aucune cl\xE9 enregistr\xE9e. L\u2019analyse sans IA reste disponible.";
  }
  form.addEventListener(
    "invalid",
    (e) => {
      let disclosure = e.target.closest("details");
      while (disclosure) {
        disclosure.open = true;
        disclosure = disclosure.parentElement?.closest("details") ?? null;
      }
    },
    true
  );
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    try {
      const next = { ...settings };
      for (const key2 of Object.keys(settings)) {
        const el = field(key2);
        if (!el) continue;
        let value2 = el.value;
        if (el instanceof HTMLInputElement && el.type === "checkbox")
          value2 = el.checked;
        else if (typeof settings[key2] === "number" || key2 === "temperature")
          value2 = el.value === "" ? null : Number(el.value);
        next[key2] = value2;
      }
      next.timeoutMs = Number(field("timeoutSeconds").value) * 1e3;
      next.fallbackSelectors = {
        title: field("fallbackTitle").value,
        description: field("fallbackDescription").value,
        specifics: field("fallbackSpecifics").value
      };
      for (const selector of Object.values(next.fallbackSelectors))
        if (selector) document.querySelector(selector);
      const validated = validateSettings(next);
      const keyInput = document.querySelector("#api-key");
      const key = keyInput.value.trim();
      if (key && (!key.startsWith("sk-") || key.length < 15))
        throw Error("La cl\xE9 API doit commencer par sk- et \xEAtre compl\xE8te.");
      await chrome.storage.local.set({
        settings: validated,
        ...key ? { apiKey: key } : {}
      });
      keyInput.value = "";
      settings = validated;
      status(
        "Param\xE8tres enregistr\xE9s. Recharge les pages eBay si tu as modifi\xE9 les fonctions de d\xE9tection."
      );
      await load();
    } catch (e2) {
      status(
        e2 instanceof Error ? e2.message : "Impossible d\u2019enregistrer les param\xE8tres."
      );
    }
  });
  document.querySelector("#remove-key").addEventListener("click", async () => {
    await chrome.storage.local.remove("apiKey");
    document.querySelector("#api-key").value = "";
    await load();
    status("Cl\xE9 supprim\xE9e. Les fonctions sans IA restent disponibles.");
  });
  document.querySelector("#clear-sellers").addEventListener("click", async () => {
    await clearSellerCache();
    status(
      "V\xE9rifications des vendeurs effac\xE9es. Elles seront relues lors de leur prochaine ouverture."
    );
  });
  document.querySelector("#clear-sources").addEventListener("click", async () => {
    await chrome.storage.session.remove(["sources", "aiCache"]);
    status(
      "Captures et analyses temporaires effac\xE9es. Ta biblioth\xE8que est conserv\xE9e."
    );
  });
  document.querySelector("#export-settings").addEventListener("click", () => {
    const blob = new Blob(
      [JSON.stringify(safeDiagnostic({ version: "0.11.0", settings }), null, 2)],
      { type: "application/json" }
    );
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "auroebay-settings-diagnostic.json";
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1e3);
    status("R\xE9glages export\xE9s, sans la cl\xE9 API.");
  });
  void load().catch(
    () => status("Impossible de lire les param\xE8tres de l\u2019extension.")
  );
  setupPower();
  licenseBox(document.getElementById("license-box"));
  if (ownerInstall()) {
    const card = document.querySelector("#bridge-card");
    card.hidden = false;
    const draw = async () => {
      const open = bridgeOpen((await chrome.storage.local.get(BRIDGE_KEY))[BRIDGE_KEY]);
      document.querySelector("#bridge-status").textContent = open ? "\u2705 Activ\xE9e : elle reste active jusqu\u2019\xE0 ce que tu la d\xE9sactives." : "D\xE9sactiv\xE9e.";
      document.querySelector("#bridge-on").hidden = open;
      document.querySelector("#bridge-off").hidden = !open;
    };
    document.querySelector("#bridge-on").addEventListener(
      "click",
      () => void chrome.storage.local.set({ [BRIDGE_KEY]: true }).then(draw)
    );
    document.querySelector("#bridge-off").addEventListener("click", () => void chrome.storage.local.remove(BRIDGE_KEY).then(draw));
    void draw();
  }
  var option = (value2, label) => Object.assign(document.createElement("option"), { value: value2, textContent: label });
  document.querySelector("#banner-preset").append(...Object.entries(BANNER_PRESETS).map(([k, p]) => option(k, p.label)));
  document.querySelector("#description-template").append(...Object.entries(DESCRIPTION_THEMES).map(([k, t]) => option(k, t.label)));
  var sample = (async () => {
    const c = document.createElement("canvas");
    c.width = c.height = 600;
    const g = c.getContext("2d");
    const bg = g.createLinearGradient(0, 0, 0, 600);
    bg.addColorStop(0, "#f4f1ec");
    bg.addColorStop(1, "#e2ddd4");
    g.fillStyle = bg;
    g.fillRect(0, 0, 600, 600);
    g.fillStyle = "rgba(0,0,0,.12)";
    g.beginPath();
    g.ellipse(300, 470, 170, 28, 0, 0, Math.PI * 2);
    g.fill();
    const body2 = g.createLinearGradient(170, 0, 430, 0);
    body2.addColorStop(0, "#3d5a80");
    body2.addColorStop(1, "#98c1d9");
    g.fillStyle = body2;
    g.beginPath();
    g.roundRect(170, 170, 260, 290, 36);
    g.fill();
    g.fillStyle = "#293241";
    g.beginPath();
    g.roundRect(230, 120, 140, 70, 18);
    g.fill();
    const blob = await new Promise((r) => c.toBlob(r, "image/png"));
    const bytes = new Uint8Array(await blob.arrayBuffer());
    let text = "";
    for (let i = 0; i < bytes.length; i += 32768) text += String.fromCharCode(...bytes.subarray(i, i + 32768));
    return { data: btoa(text), mime: "image/png" };
  })();
  var value = (name) => (field(name)?.value ?? "").trim();
  var drawn = 0;
  async function previewBanner() {
    const turn = ++drawn;
    const img = document.querySelector("#banner-preview");
    const look = bannerStyle({ bannerPreset: value("bannerPreset"), bannerMain: value("bannerMain"), bannerTitle: value("bannerTitle"), bannerSub: value("bannerSub"), bannerPosition: value("bannerPosition") });
    const result = await saleBannerFromPage(await sample, look);
    if (turn === drawn && result.ok) img.src = `data:image/jpeg;base64,${result.data}`;
  }
  function previewDescription() {
    const frame = document.querySelector("#description-preview");
    frame.srcdoc = listingDescriptionHTML(
      "Stainless Steel Insulated Water Bottle 32oz, Leak Proof",
      "<p><b>Features</b></p><ul><li>Keeps drinks cold 24 h, hot 12 h</li><li>Leak-proof lid, easy to carry</li></ul><p><b>Package</b>: 1 \xD7 bottle</p>",
      value("storeName"),
      value("descriptionTemplate") || "classic"
    );
  }
  var timer;
  form.addEventListener("input", (e) => {
    const name = e.target.name ?? "";
    clearTimeout(timer);
    timer = setTimeout(() => {
      if (name.startsWith("banner")) void previewBanner();
      if (name === "descriptionTemplate" || name === "storeName") previewDescription();
    }, 150);
  });
  void load().then(() => {
    void previewBanner();
    previewDescription();
  }).catch(() => {
  });
  function setupGoal() {
    const sales = document.querySelector("#goal-sales");
    const profit = document.querySelector("#goal-profit");
    const say = (text) => document.querySelector("#goal-status").textContent = text;
    const show = async () => {
      const goal = cleanGoal((await chrome.storage.local.get(GOAL_KEY))[GOAL_KEY]);
      sales.value = goal.sales === null ? "" : String(goal.sales);
      profit.value = goal.profit === null ? "" : String(goal.profit);
    };
    const save = async () => {
      const goal = cleanGoal({ sales: sales.value, profit: profit.value });
      if (hasGoal(goal)) await chrome.storage.local.set({ [GOAL_KEY]: goal });
      else await chrome.storage.local.remove(GOAL_KEY);
      await show();
      say(hasGoal(goal) ? "Objectif enregistr\xE9 : il s\u2019affiche dans \xAB \u2600\uFE0F Ma journ\xE9e \xBB." : "Pas d\u2019objectif : rien ne s\u2019affiche dans \xAB Ma journ\xE9e \xBB.");
    };
    document.querySelector("#goal-save").addEventListener("click", () => void save());
    document.querySelector("#goal-clear").addEventListener("click", () => {
      sales.value = profit.value = "";
      void save();
    });
    for (const input of [sales, profit])
      input.addEventListener("keydown", (e) => {
        if (e.key === "Enter") {
          e.preventDefault();
          void save();
        }
      });
    void show();
  }
})();
