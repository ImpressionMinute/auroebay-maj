"use strict";
(() => {
  // src/core/text.ts
  var compact = (s) => s.replace(/\s+/g, " ").trim();
  var norm = (s) => compact(s.normalize("NFKC")).toLowerCase().replace(/[\s\W_]+/g, " ").trim();
  var escapeHTML = (s) => s.replace(
    /[&<>"']/g,
    (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]
  );
  function redact(s) {
    return s.replace(/\bsk-[A-Za-z0-9_-]+/g, "[REDACTED_KEY]").replace(/Bearer\s+\S+/gi, "Bearer [REDACTED]").replace(/[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}/g, "[EMAIL]").replace(/https?:\/\/[^\s<>"']+/g, "[URL]");
  }

  // src/core/messaging.ts
  async function message(body2) {
    const reply = await chrome.runtime.sendMessage(body2);
    if (!reply?.ok)
      throw Error(reply?.error ?? "AurOEBay ne r\xE9pond pas. Recharge la page.");
    return reply.data;
  }

  // src/core/shippingText.ts
  var PRICE = String.raw`(?:US\s*)?\$\s*(\d+(?:\.\d{1,2})?)`;
  var NAMED = new RegExp(String.raw`(?:standard|shipping|delivery|livraison)[^$·\d]{0,20}?${PRICE}`, "gi");
  var LABEL = new RegExp(String.raw`\b[A-Za-z][A-Za-z' -]{1,30}:\s*${PRICE}`, "g");
  var NOT_A_FEE = /over|orders|min|save|off\b|coupon|discount|code|price|extra/i;
  function paidShipping(text) {
    if (!text) return null;
    const hit = [...text.matchAll(NAMED), ...text.matchAll(LABEL)].find((m) => !NOT_A_FEE.test(m[0]));
    const cost = hit ? Number(hit[1]) : 0;
    return cost > 0 && cost < 200 ? cost : null;
  }

  // src/ebay/prices.ts
  var USUAL_SHIPPING = { cost: 1.99, freeOver: 10, usual: true };
  function shippingCharge(d) {
    const threshold = d?.freeShippingThreshold && d.freeShippingThreshold > 0 ? d.freeShippingThreshold : null;
    if (d && d.cost !== null && d.cost > 0 && (d.currency === null || d.currency === "USD"))
      return { cost: d.cost, freeOver: threshold };
    const written = d && d.cost === null ? paidShipping(d.evidence) : null;
    if (written !== null) return { cost: written, freeOver: threshold };
    return threshold ? { ...USUAL_SHIPPING, freeOver: threshold } : USUAL_SHIPPING;
  }
  var shippingFor = (cost, s) => s && !(s.freeOver !== null && cost >= s.freeOver) ? s.cost : 0;

  // src/core/country.ts
  var codes = "AD AE AF AG AI AL AM AO AQ AR AS AT AU AW AX AZ BA BB BD BE BF BG BH BI BJ BL BM BN BO BQ BR BS BT BV BW BY BZ CA CC CD CF CG CH CI CK CL CM CN CO CR CU CV CW CX CY CZ DE DJ DK DM DO DZ EC EE EG EH ER ES ET FI FJ FK FM FO FR GA GB GD GE GF GG GH GI GL GM GN GP GQ GR GS GT GU GW GY HK HM HN HR HT HU ID IE IL IM IN IO IQ IR IS IT JE JM JO JP KE KG KH KI KM KN KP KR KW KY KZ LA LB LC LI LK LR LS LT LU LV LY MA MC MD ME MF MG MH MK ML MM MN MO MP MQ MR MS MT MU MV MW MX MY MZ NA NC NE NF NG NI NL NO NP NR NU NZ OM PA PE PF PG PH PK PL PM PN PR PS PT PW PY QA RE RO RS RU RW SA SB SC SD SE SG SH SI SJ SK SL SM SN SO SR SS ST SV SX SY SZ TC TD TF TG TH TJ TK TL TM TN TO TR TT TV TW TZ UA UG UM US UY UZ VA VC VE VG VI VN VU WF WS YE YT ZA ZM ZW".split(
    " "
  );
  var names = new Intl.DisplayNames(["en"], { type: "region" });
  var map = /* @__PURE__ */ new Map();
  for (const code of codes) {
    const name = names.of(code);
    map.set(norm(code), name);
    map.set(norm(name), name);
  }
  for (const [alias, name] of Object.entries({
    "mainland china": "China",
    "cn origin": "China",
    "china mainland": "China",
    "china origin": "China",
    prc: "China",
    "people s republic of china": "China",
    usa: "United States",
    "u s a": "United States",
    "united states of america": "United States",
    uk: "United Kingdom",
    "great britain": "United Kingdom",
    "south korea": "South Korea",
    "republic of korea": "South Korea",
    taiwan: "Taiwan",
    vietnam: "Vietnam",
    turkey: "T\xFCrkiye"
  }))
    map.set(norm(alias), name);

  // src/ebay/savedDraft.ts
  var SCAN_LIMIT = 3 * 1024 * 1024;

  // src/ebay/draftApi.ts
  var HTML_LIMIT = 8 * 1024 * 1024;

  // src/core/sales.ts
  var localDay = (ms) => {
    const d = new Date(ms);
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  };
  var round = (n) => Math.round(n * 100) / 100;
  function purchases(sale) {
    return [...sale.supplier ? [sale.supplier] : [], ...sale.extraSuppliers ?? []];
  }
  function trackingCovered(sale) {
    const onEbay = new Set((sale.tracking ?? "").split(/\s*,\s*/).filter(Boolean));
    if (!onEbay.size) return false;
    if (sale.items.length > 1 && sale.trackedItems !== void 0 && sale.trackedItems >= sale.items.length) return true;
    return onEbay.size >= purchases(sale).filter((p) => p.tracking).length && (sale.items.length <= 1 || sale.trackedItems === void 0 || sale.trackedItems >= sale.items.length);
  }
  function trackingsToSend(sale) {
    if (sale.status === "cancelled" || trackingCovered(sale)) return [];
    return purchases(sale).filter((p) => p.tracking && !(sale.tracking ?? "").includes(p.tracking));
  }
  function saleRate(sale, fallback = null) {
    return sale.adjust?.rate ?? sale.rate ?? fallback;
  }
  function latestRate(sales2) {
    return [...sales2].filter((s) => s.rate).sort((a, b) => (b.soldAt ?? 0) - (a.soldAt ?? 0))[0]?.rate ?? null;
  }
  function toPayout(sale, money4, fallbackRate2 = null) {
    if (!money4) return null;
    const payout = sale.earnings?.currency ?? "USD";
    const rate = saleRate(sale, fallbackRate2);
    if (money4.currency === payout) return money4.amount;
    if (money4.currency === "USD" && rate) return round(money4.amount * rate);
    if (payout === "USD" && rate && money4.currency === "EUR")
      return round(money4.amount / rate);
    return null;
  }
  function saleNumbers(sale, fallbackRate2 = null) {
    const currency = sale.earnings?.currency ?? "USD";
    const a = sale.adjust ?? {};
    let usedEstimate = false;
    const convert = (m) => {
      if (!m) return null;
      const direct = toPayout(sale, m);
      if (direct !== null) return direct;
      const estimated = toPayout(sale, m, fallbackRate2);
      if (estimated !== null) usedEstimate = true;
      return estimated;
    };
    const total = sale.orderTotal ? convert(sale.orderTotal) : sale.subtotal ? (() => {
      const sub = convert(sale.subtotal);
      const ship = sale.shipping ? convert(sale.shipping) : 0;
      return sub === null || ship === null ? null : round(sub + ship);
    })() : null;
    const taxed = sale.orderTotal && sale.tax ? convert({ ...sale.tax, amount: Math.abs(sale.tax.amount) }) : 0;
    let gross = a.revenue ?? (total === null || taxed === null ? null : round(total - taxed));
    if (sale.refund && a.revenue === void 0 && gross !== null && gross < 0) gross = 0;
    const fees = a.fees ?? round(sale.fees.reduce((sum, f) => sum + (convert(f.amount) ?? 0), 0) * -1);
    const earnings = a.earnings ?? (a.revenue !== void 0 || a.fees !== void 0 ? gross === null ? null : round(gross - fees) : sale.earnings?.amount ?? (gross !== null ? round(gross - fees) : null));
    const linked = purchases(sale);
    let supplier;
    if (a.supplierCost) supplier = convert(a.supplierCost);
    else if (linked.length) {
      const parts = linked.map((p) => convert(p.cost));
      supplier = parts.some((x) => x === null) ? null : round(parts.reduce((t, x) => t + x, 0));
    } else supplier = sale.manualCost ? convert(sale.manualCost) : null;
    let supplierRefund = 0;
    if (!a.supplierCost && supplier !== null && sale.supplierRefunds?.length) {
      for (const r of sale.supplierRefunds) supplierRefund += convert(r.amount) ?? 0;
      supplierRefund = round(Math.min(supplierRefund, supplier));
      supplier = round(supplier - supplierRefund);
    }
    const cost = supplier === null ? null : round(supplier + (sale.otherCost || 0));
    const cancelled = sale.status === "cancelled";
    const profit = cancelled ? 0 : earnings === null || cost === null ? null : round(earnings - cost);
    return {
      currency,
      revenue: cancelled ? 0 : gross,
      fees: cancelled ? 0 : fees,
      earnings: cancelled ? 0 : earnings,
      supplier: cancelled ? 0 : supplier,
      cost: cancelled ? 0 : cost,
      profit,
      complete: cancelled || profit !== null,
      estimatedRate: usedEstimate,
      rate: saleRate(sale, usedEstimate ? fallbackRate2 : null),
      buyerRefund: sale.refund ? convert(sale.refund) : null,
      supplierRefund
    };
  }
  function salesCSV(sales2, rates2) {
    const fallback = latestRate(sales2);
    const head = [
      "Commande eBay",
      "Date",
      "Pays",
      "Articles",
      "Quantit\xE9",
      "Pay\xE9 par l'acheteur",
      "Devise pay\xE9e",
      "Taxe collect\xE9e par eBay",
      "Frais eBay",
      "Gains eBay",
      "Co\xFBt fournisseur",
      "Autres co\xFBts",
      "B\xE9n\xE9fice",
      ...rates2 ? ["URSSAF + imp\xF4t", "B\xE9n\xE9fice apr\xE8s charges"] : [],
      "Devise",
      "Commande AliExpress",
      "Statut",
      "Suivi"
    ];
    const cell2 = (v) => {
      const s = v === null || v === void 0 ? "" : String(v);
      return /[;"\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
    };
    const num2 = (n) => n === null || n === void 0 ? "" : n.toFixed(2).replace(".", ",");
    const rows = sales2.map((s) => {
      const n = saleNumbers(s, fallback);
      return [
        s.orderId,
        s.soldAt ? localDay(s.soldAt) : "",
        s.country,
        s.items.map((i) => i.title + (i.variation ? ` (${i.variation})` : "")).join(" + "),
        s.items.reduce((q, i) => q + i.quantity, 0),
        num2(s.orderTotal?.amount),
        s.orderTotal?.currency ?? "",
        num2(s.tax ? Math.abs(s.tax.amount) : null),
        num2(n.fees),
        num2(n.earnings),
        num2(n.supplier),
        num2(s.otherCost || 0),
        num2(n.profit),
        ...rates2 ? (() => {
          const charges = n.revenue === null ? null : Math.round(n.revenue * (rates2.urssaf + rates2.impot)) / 100;
          return [num2(charges), num2(n.profit === null || charges === null ? null : n.profit - charges)];
        })() : [],
        n.currency,
        purchases(s).map((p) => p.orderId).join(" + "),
        { to_ship: "\xC0 exp\xE9dier", shipped: "Exp\xE9di\xE9e", cancelled: "Annul\xE9e" }[s.status],
        s.tracking
      ].map(cell2).join(";");
    });
    return "\uFEFF" + [head.join(";"), ...rows].join("\n");
  }

  // src/core/license.ts
  var LICENSE_KEY = "license:v1";
  var CHECKOUT_URL = "https://auroebay.lemonsqueezy.com/checkout/buy/1b765c13-2f39-4847-82fa-e7950d112d63";
  var TRIAL_DAYS = 15;
  var CODE_MAX_DAYS = 93;
  var GRACE_DAYS = 3;
  var DAY = 864e5;
  var OWNER_EXTENSION_ID = "bbedjpfnnkjadfjpbbmppikmgocoglfh";
  var SKEW = 10 * 6e4;
  var extensionId = () => globalThis.chrome?.runtime?.id ?? "";
  var ownerInstall = () => extensionId() === OWNER_EXTENSION_ID;
  function licenseActive(s, now = Date.now()) {
    if (!s) return false;
    if (s.owner) return ownerInstall();
    if (s.status === "trial") return trialActive(s, now);
    if (!s.key || s.status !== "active" || !s.checkedAt) return false;
    if (s.checkedAt > now + SKEW || (s.triedAt ?? 0) > now + SKEW) return false;
    if (typeof s.expiresAt === "string" && Date.parse(s.expiresAt) < now - DAY) return false;
    return now - s.checkedAt < GRACE_DAYS * DAY;
  }
  var PEPPER = "AurOEBay\xB7licence\xB7v1\xB74f1c9e27b8d36a05";
  var SEALED = ["owner", "key", "instanceId", "status", "checkedAt", "triedAt", "email", "expiresAt", "error", "trialUntil", "trialId"];
  async function hmac(text) {
    const enc = new TextEncoder();
    const raw = await crypto.subtle.digest("SHA-256", enc.encode(PEPPER + "|" + extensionId()));
    const key = await crypto.subtle.importKey("raw", raw, { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
    const sig = await crypto.subtle.sign("HMAC", key, enc.encode(text));
    return [...new Uint8Array(sig)].map((b) => b.toString(16).padStart(2, "0")).join("");
  }
  var body = (s) => JSON.stringify(SEALED.map((k) => s[k] ?? null));
  async function sealValid(s) {
    if (!s || typeof s.seal !== "string") return false;
    try {
      return s.seal === await hmac(body(s));
    } catch {
      return false;
    }
  }
  async function trustedLicense(raw) {
    const s = raw && typeof raw === "object" ? raw : {};
    if (await sealValid(s)) return { state: s, sealed: true };
    if (s.owner === true && ownerInstall()) return { state: { owner: true }, sealed: false };
    if (typeof s.key === "string" && typeof s.instanceId === "string")
      return { state: { key: s.key, instanceId: s.instanceId, status: "unverified" }, sealed: false };
    return { state: {}, sealed: false };
  }
  async function readLicense() {
    const raw = (await chrome.storage.local.get(LICENSE_KEY))[LICENSE_KEY];
    return (await trustedLicense(raw)).state;
  }
  var GIFT_CODES = [
    // An owner's friend, 2 months (11/11/2026 → 10/01/2027).
    { hash: "17d203ba3126fbb6d37dd5140799c68f5b838f94e15027b54a99ce12b10724bc", until: Date.UTC(2027, 0, 10, 22, 59) }
  ];
  function trialActive(s, now = Date.now()) {
    if (typeof s.trialUntil !== "number" || now >= s.trialUntil) return false;
    if ((s.checkedAt ?? 0) > now + SKEW) return false;
    return s.trialUntil - now <= (CODE_MAX_DAYS + 1) * DAY;
  }
  var trialDaysLeft = (s, now = Date.now()) => s?.status === "trial" && trialActive(s, now) ? Math.ceil((s.trialUntil - now) / DAY) : 0;
  function licenseLabel(s, now = Date.now()) {
    if (s?.owner) return "Version propri\xE9taire : aucune licence n\xE9cessaire.";
    if (s?.status === "trial" && trialActive(s, now)) {
      const left = trialDaysLeft(s, now);
      const end = new Date(s.trialUntil).toLocaleDateString("fr-FR", { day: "numeric", month: "long" });
      return `Essai gratuit : encore ${left} jour${left > 1 ? "s" : ""} (jusqu\u2019au ${end}). Abonne-toi avant pour continuer sans coupure.`;
    }
    if (s?.status === "trial" || s?.status === "trial-ended") return "Ton essai gratuit est termin\xE9 : abonne-toi pour continuer. Tes donn\xE9es sont gard\xE9es.";
    if (!s?.key) return `Aucune cl\xE9 de licence : commence ton essai gratuit de ${TRIAL_DAYS} jours, puis colle la cl\xE9 re\xE7ue par e-mail.`;
    if (licenseActive(s, now)) return `Abonnement actif${s.email ? ` (${s.email})` : ""}.`;
    if (s.status === "unverified") return s.error ? `${s.error} Ta licence sera v\xE9rifi\xE9e d\xE8s le retour de la connexion.` : "V\xE9rification de ta licence aupr\xE8s de Lemon Squeezy\u2026";
    if (s.status === "active") return "Impossible de v\xE9rifier ta licence depuis plus de 3 jours : v\xE9rifie ta connexion internet.";
    if (s.status === "expired") return "Abonnement termin\xE9 : renouvelle-le pour r\xE9activer AurOEBay.";
    if (s.status === "disabled") return "Licence d\xE9sactiv\xE9e : contacte bonjour@impression-minute.fr.";
    return s.error ?? "Licence inactive.";
  }
  function versionBelow(version, than) {
    if (!version) return false;
    const a = version.split(".").map(Number);
    const b = than.split(".").map(Number);
    for (let i = 0; i < 3; i++) if ((a[i] ?? 0) !== (b[i] ?? 0)) return (a[i] ?? 0) < (b[i] ?? 0);
    return false;
  }

  // src/ui/license.ts
  var read = readLicense;
  function licenseBanner(doc = document) {
    if (/\/(welcome|options)\.html$/.test(location.pathname)) return;
    const show = async () => {
      doc.getElementById("lic-banner")?.remove();
      const s = await read();
      const left = trialDaysLeft(s);
      if (left > 0 && left <= 3) {
        const note = doc.createElement("div");
        note.id = "lic-banner";
        note.className = "lic-banner";
        note.innerHTML = `<span>\u23F3 ${escapeHTML(licenseLabel(s))}</span>
        <span><a class="btn small primary" href="${CHECKOUT_URL}" target="_blank" rel="noopener">S\u2019abonner</a> <a class="btn small secondary" href="welcome.html">Entrer ma cl\xE9</a></span>`;
        doc.body.prepend(note);
        return;
      }
      if (licenseActive(s)) return;
      const bar = doc.createElement("div");
      bar.id = "lic-banner";
      bar.className = "lic-banner";
      bar.innerHTML = `<span>\u{1F512} ${escapeHTML(licenseLabel(s))} AurOEBay est en pause ; tes donn\xE9es restent ici.</span>
      <span><a class="btn small primary" href="welcome.html">Entrer ma cl\xE9</a> <a class="btn small secondary" href="${CHECKOUT_URL}" target="_blank" rel="noopener">${s.key || s.status?.startsWith("trial") ? "S\u2019abonner" : `Essai gratuit ${TRIAL_DAYS} jours`}</a></span>`;
      doc.body.prepend(bar);
    };
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "local" && changes[LICENSE_KEY]) void show();
    });
    void show().catch(() => {
    });
  }

  // src/core/update.ts
  var UPDATE_KEY = "update:v1";
  var VERSION_URL = "https://auroebay.netlify.app/version.json";
  var MIRROR = "https://raw.githubusercontent.com/ImpressionMinute/auroebay-maj/main/";
  var VERSION_URLS = [VERSION_URL, MIRROR + "version.json"];
  var UPDATE_GUIDE_URL = "https://auroebay.netlify.app/mise-a-jour.html";
  var UPDATE_EVERY_MS = 24 * 36e5;
  var UPDATE_RECHECK_MS = 2 * 6e4;
  var WHATS_NEW_KEY = "whatsNew:v1";
  var NEWS_URL = "https://auroebay.netlify.app/nouveautes.html";
  var MAC_COMMAND = `curl -fsSL ${MIRROR}maj-mac.sh | bash`;
  var WINDOWS_COMMAND = `powershell -ExecutionPolicy Bypass -c "[Net.ServicePointManager]::SecurityProtocol=3072;irm ${MIRROR}maj-windows.ps1|iex"`;
  var DISK_WAIT_KEY = "updateOnDisk:v1";
  var SITE = "https://auroebay.netlify.app/";
  function cleanNotes(value) {
    if (!Array.isArray(value)) return [];
    return value.filter((n) => typeof n === "string").map((n) => n.replace(/\s+/g, " ").trim().slice(0, 240)).filter(Boolean).slice(0, 8);
  }
  function parseReleaseNotes(value) {
    if (!Array.isArray(value)) return [];
    return value.flatMap((r) => {
      const v = r;
      if (typeof v?.version !== "string" || !/^\d{1,4}\.\d{1,5}\.\d{1,6}$/.test(v.version)) return [];
      const notes = cleanNotes(v.notes);
      return notes.length ? [{ version: v.version, date: typeof v.date === "string" ? v.date.slice(0, 10) : "", notes }] : [];
    });
  }
  function parseVersionFile(value) {
    const v = value;
    if (typeof v?.version !== "string" || !/^\d{1,4}\.\d{1,5}\.\d{1,6}$/.test(v.version)) return null;
    if (typeof v.url !== "string" || !(v.url.startsWith(SITE) || v.url.startsWith(MIRROR)) || /["'<>\s]/.test(v.url)) return null;
    return { latest: v.version, url: v.url, notes: cleanNotes(v.notes) };
  }
  function updateAvailable(info, current) {
    return !!info?.latest && !!info.url && versionBelow(current, info.latest);
  }

  // src/ui/update.ts
  var DISMISSED = "updateDismissed:v1";
  var isWindows = () => /Windows/i.test(navigator.userAgent);
  function steps() {
    return isWindows() ? `<ol class="upd-steps"><li>Clique <b>Copier</b>.</li><li>Appuie sur les touches <kbd>\u229E Windows</kbd> + <kbd>R</kbd>.</li><li>Appuie sur <kbd>Ctrl</kbd> + <kbd>V</kbd>, puis <kbd>Entr\xE9e</kbd>.</li><li>Quand \xAB C\u2019est fait \xBB s\u2019affiche : <b>ferme compl\xE8tement Chrome et rouvre-le</b> (obligatoire).</li></ol>` : `<ol class="upd-steps"><li>Clique <b>Copier</b>.</li><li>Appuie sur <kbd>\u2318 Cmd</kbd> + <kbd>Espace</kbd>, tape <b>Terminal</b>, puis <kbd>Entr\xE9e</kbd>.</li><li>Appuie sur <kbd>\u2318 Cmd</kbd> + <kbd>V</kbd>, puis <kbd>Entr\xE9e</kbd>.</li><li>Quand \xAB C\u2019est fait \xBB s\u2019affiche : <b>quitte Chrome</b> (<kbd>\u2318 Cmd</kbd> + <kbd>Q</kbd>) <b>et rouvre-le</b> (obligatoire).</li></ol>`;
  }
  var list = (notes) => notes.length ? `<ul class="upd-notes">${notes.map((n) => `<li>${escapeHTML(n)}</li>`).join("")}</ul>` : "";
  function updateBanner(doc = document) {
    const current = chrome.runtime.getManifest().version;
    const show = async () => {
      doc.getElementById("upd-banner")?.remove();
      const got = await chrome.storage.local.get([UPDATE_KEY, DISMISSED]);
      const saved = got[UPDATE_KEY];
      const ok = parseVersionFile({ version: saved?.latest, url: saved?.url, notes: saved?.notes });
      const info = ok ? { ...ok, checkedAt: saved?.checkedAt } : void 0;
      if (!updateAvailable(info, current) || got[DISMISSED] === info.latest) return;
      const bar = doc.createElement("div");
      bar.id = "upd-banner";
      bar.className = "lic-banner upd-banner";
      const waiting = (await chrome.storage.local.get(DISK_WAIT_KEY))[DISK_WAIT_KEY];
      bar.innerHTML = waiting?.version ? `<div><b>\u2705 AurOEBay ${escapeHTML(waiting.version)} est pr\xEAt.</b> Il se recharge tout seul d\xE8s que ${escapeHTML(waiting.reason ?? "le travail en cours")} sera fini.</div>
      <span><button type="button" class="btn small primary" id="upd-now">Recharger maintenant</button></span>` : `<div><b>\u{1F195} AurOEBay ${escapeHTML(info.latest)} est disponible</b> (tu as ${escapeHTML(current)}).${ok.notes.length ? ` Ce que \xE7a apporte :${list(ok.notes)}` : ""}<p class="upd-how">Mise \xE0 jour en 1 minute, tes donn\xE9es sont gard\xE9es :</p>${steps()}<p class="upd-how small">Sans red\xE9marrer Chrome, les boutons AurOEBay ne marchent pas sur les pages eBay et AliExpress.</p></div>
      <span><button type="button" class="btn small primary" id="upd-copy">\u{1F4CB} Copier</button>
      <a class="btn small secondary" href="${UPDATE_GUIDE_URL}" target="_blank" rel="noopener">Aide en images</a>
      <button type="button" class="btn small secondary" id="upd-later">Plus tard</button></span>`;
      bar.querySelector("#upd-later")?.addEventListener("click", () => {
        void chrome.storage.local.set({ [DISMISSED]: info.latest });
      });
      bar.querySelector("#upd-now")?.addEventListener("click", () => {
        if (confirm("Recharger AurOEBay maintenant ? Le travail en cours sera interrompu (tes donn\xE9es sont gard\xE9es)."))
          void chrome.runtime.sendMessage({ type: "UPDATE_RELOAD_NOW" }).catch(() => {
          });
      });
      const copy = bar.querySelector("#upd-copy");
      copy?.addEventListener("click", () => {
        void navigator.clipboard.writeText(isWindows() ? WINDOWS_COMMAND : MAC_COMMAND).then(() => copy.textContent = "\u2713 Copi\xE9 ! \xC9tape 2 \u2192").catch(() => copy.textContent = "\u26A0 Copie impossible : utilise l\u2019aide en images");
      });
      doc.body.prepend(bar);
      poll();
    };
    let polling;
    const poll = () => {
      if (polling) return;
      polling = setInterval(() => {
        if (!doc.getElementById("upd-banner")) return void (clearInterval(polling), polling = void 0);
        void chrome.runtime.sendMessage({ type: "UPDATE_DISK" }).catch(() => {
        });
      }, 4e3);
    };
    const news = async () => {
      doc.getElementById("upd-news")?.remove();
      if ((await chrome.storage.local.get(WHATS_NEW_KEY))[WHATS_NEW_KEY] !== current) return;
      const notes = await fetch(chrome.runtime.getURL("release-notes.json")).then((r) => r.json()).then((v) => parseReleaseNotes(v).find((r) => r.version === current)?.notes ?? []).catch(() => []);
      if (!notes.length) return;
      const bar = doc.createElement("div");
      bar.id = "upd-news";
      bar.className = "lic-banner upd-banner upd-news";
      bar.innerHTML = `<div><b>\u{1F389} AurOEBay est \xE0 jour (${escapeHTML(current)}). Les nouveaut\xE9s :</b>${list(notes)}<p class="upd-how small">Si ce n\u2019est pas d\xE9j\xE0 fait : ferme compl\xE8tement Chrome et rouvre-le, sinon les boutons AurOEBay ne marchent pas sur les pages eBay et AliExpress d\xE9j\xE0 ouvertes.</p></div>
      <span><a class="btn small secondary" href="${NEWS_URL}" target="_blank" rel="noopener">Toutes les nouveaut\xE9s</a>
      <button type="button" class="btn small primary" id="upd-news-ok">J\u2019ai compris</button></span>`;
      bar.querySelector("#upd-news-ok")?.addEventListener("click", () => void chrome.storage.local.remove(WHATS_NEW_KEY));
      doc.body.prepend(bar);
    };
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "local") return;
      if (changes[UPDATE_KEY] || changes[DISMISSED] || changes[DISK_WAIT_KEY]) void show().catch(() => {
      });
      if (changes[WHATS_NEW_KEY]) void news().catch(() => {
      });
    });
    void show().catch(() => {
    });
    void news().catch(() => {
    });
    void chrome.runtime.sendMessage({ type: "UPDATE_CHECK" }).catch(() => {
    });
  }

  // src/core/debug.ts
  function safeDiagnostic(value) {
    if (typeof value === "string") return redact(value).slice(0, 3e4);
    if (Array.isArray(value)) return value.slice(0, 200).map(safeDiagnostic);
    if (value && typeof value === "object")
      return Object.fromEntries(
        Object.entries(value).filter(
          ([k]) => !/(api.?key|authorization|cookie|token|secret|password)/i.test(k) || /^(input_tokens|output_tokens|reasoning_tokens|maxOutputTokens)$/.test(
            k
          )
        ).map(([k, v]) => [k, safeDiagnostic(v)])
      );
    return value;
  }

  // src/core/links.ts
  var DISCORD_URL = "https://discord.gg/sr2g2ZZZQ9";

  // src/ui/report.ts
  var REPORT_URL = "https://auroebay.netlify.app/";
  var SUPPORT_EMAIL = "bonjour@impression-minute.fr";
  var MAX_IMAGE = 5 * 1024 * 1024;
  async function technicalReport(extra) {
    const health = await message({ type: "HEALTH_CHECK" }).catch(() => []);
    let session = {};
    try {
      session = await chrome.storage.session.get(["apiTrace:v1", "lastPanelError:v1"]);
    } catch {
    }
    const trace = session["apiTrace:v1"];
    const report = {
      version: chrome.runtime.getManifest().version,
      navigateur: navigator.userAgent,
      page: location.pathname,
      "tout-va-bien": health.map((x) => `${x.ok ? "OK" : x.unknown ? "?" : "!!"} ${x.title} : ${x.text}`),
      "derniere-erreur": session["lastPanelError:v1"] ?? null,
      "trace-import": trace?.slice(-40) ?? []
    };
    const text = JSON.stringify(safeDiagnostic(report), null, 2);
    return (extra ? `${text}

--- Panneau ---
${extra}` : text).slice(0, 6e4);
  }
  var CSS = `
.rp{border:0;border-radius:18px;padding:0;max-width:520px;width:calc(100vw - 32px);background:var(--surface,#fff);color:var(--text,#1d1a24);box-shadow:0 24px 60px rgba(0,0,0,.4);font:14px system-ui,-apple-system,sans-serif}
.rp::backdrop{background:rgba(10,8,14,.55)}
.rp form{display:grid;gap:12px;padding:20px 22px}
.rp h2{margin:0;font-size:19px}
.rp p{margin:0;color:var(--muted,#a49bb0);line-height:1.45}
.rp .rp-community a{color:#ff8a3d;font-weight:600}
.rp label{display:grid;gap:6px;font-weight:600}
.rp textarea,.rp input[type=email]{font:inherit;padding:10px 12px;border-radius:10px;border:1px solid var(--line,#3a3346);background:var(--bg,var(--field,#faf7f3));color:inherit}
.rp textarea{min-height:110px;resize:vertical}
.rp .rp-check{display:flex;align-items:center;gap:8px;font-weight:500;color:var(--muted,#75697d)}.rp .rp-check input{width:auto;flex:none;margin:0}.rp h2{color:inherit}
.rp .rp-actions{display:flex;flex-wrap:wrap;gap:8px;justify-content:flex-end}.rp .rp-copy{margin-right:auto;font-weight:500}
.rp button{font:600 14px system-ui;border-radius:10px;padding:9px 16px;border:1px solid var(--line,#ddd);background:transparent;color:var(--text,#1d1a24);cursor:pointer}
.rp button.primary{background:linear-gradient(135deg,#ff5f3a,#ff8a3d 50%,#ffb347);border-color:transparent;color:#fff}
.rp button:disabled{opacity:.6;cursor:default}
.rp .rp-msg{font-weight:600}
.rp .rp-msg.ok{color:#3fd09a}.rp .rp-msg.err{color:#ff6b78}
`;
  function openReport(extra) {
    document.getElementById("auroebay-report")?.remove();
    if (!document.getElementById("auroebay-report-css")) {
      const style = document.createElement("style");
      style.id = "auroebay-report-css";
      style.textContent = CSS;
      document.head.append(style);
    }
    const dialog = document.createElement("dialog");
    dialog.id = "auroebay-report";
    dialog.className = "rp";
    dialog.innerHTML = `<form method="dialog">
      <h2>\u{1F198} Un souci avec AurOEBay ?</h2>
      <p>Explique simplement ce qui ne marche pas. Le message part directement, pas besoin de bo\xEEte e-mail.</p>
      <p class="rp-community">\u{1F4AC} Plut\xF4t une question ? <a href="${DISCORD_URL}" target="_blank" rel="noopener">Demande \xE0 la communaut\xE9 AurOEBay sur Discord \u2197</a></p>
      <label>Qu\u2019est-ce qui ne marche pas ?<textarea name="message" required maxlength="4000" placeholder="Ex. : quand je clique \xAB Cr\xE9er le brouillon \xBB, rien ne se passe."></textarea></label>
      <label>Une capture d\u2019\xE9cran (si tu veux)<input name="capture" type="file" accept="image/*"></label>
      <label>Ton e-mail, pour te r\xE9pondre (si tu veux)<input name="email" type="email" maxlength="200" placeholder="toi@exemple.fr"></label>
      <label class="rp-check"><input name="tech" type="checkbox" checked> Joindre le rapport technique (aucun mot de passe ni cl\xE9)</label>
      <p class="rp-msg" hidden></p>
      <div class="rp-actions"><button type="button" class="rp-copy" title="Pour le coller dans un message">\u{1F4CB} Copier le rapport</button><button type="button" value="cancel" class="rp-cancel">Annuler</button><button type="submit" class="primary">Envoyer</button></div>
    </form>`;
    document.body.append(dialog);
    const form = dialog.querySelector("form");
    const msg = dialog.querySelector(".rp-msg");
    const send = dialog.querySelector("button[type=submit]");
    const say = (text, kind = "") => {
      msg.hidden = false;
      msg.className = `rp-msg ${kind}`;
      msg.textContent = text;
    };
    dialog.querySelector(".rp-cancel").addEventListener("click", () => dialog.close());
    dialog.querySelector(".rp-copy").addEventListener("click", async () => {
      try {
        await navigator.clipboard.writeText(await technicalReport(extra ? await extra().catch(() => "") : void 0));
        say("\u{1F4CB} Rapport copi\xE9 (aucun mot de passe ni cl\xE9).", "ok");
      } catch {
        say("Copie impossible.", "err");
      }
    });
    dialog.addEventListener("close", () => dialog.remove());
    form.addEventListener("submit", async (event) => {
      event.preventDefault();
      const text = form.elements.namedItem("message").value.trim();
      if (!text) return say("\xC9cris d\u2019abord ce qui ne marche pas.", "err");
      const file = form.elements.namedItem("capture").files?.[0];
      if (file && file.size > MAX_IMAGE) return say("Capture trop lourde (5 Mo au plus).", "err");
      send.disabled = true;
      say("Envoi\u2026");
      const version = chrome.runtime.getManifest().version;
      const tech = form.elements.namedItem("tech").checked ? await technicalReport(extra ? await extra().catch(() => "") : void 0).catch(() => "") : "";
      const body2 = new FormData();
      body2.set("form-name", "probleme");
      body2.set("bot-field", "");
      body2.set("message", text);
      body2.set("email", form.elements.namedItem("email").value.trim());
      body2.set("version", version);
      body2.set("rapport", tech);
      if (file) body2.set("capture", file, file.name);
      try {
        const r = await fetch(REPORT_URL, { method: "POST", body: body2, signal: AbortSignal.timeout(3e4) });
        if (!r.ok) throw Error(String(r.status));
        say("\u2705 Envoy\xE9, merci ! Tu auras une r\xE9ponse par e-mail si tu as laiss\xE9 ton adresse.", "ok");
        send.textContent = "Fermer";
        send.disabled = false;
        send.type = "button";
        send.addEventListener("click", () => dialog.close(), { once: true });
      } catch {
        try {
          await navigator.clipboard.writeText(`${text}

${tech}`);
        } catch {
        }
        window.open(
          `mailto:${SUPPORT_EMAIL}?subject=${encodeURIComponent(`AurOEBay ${version} : un probl\xE8me`)}&body=${encodeURIComponent(`${text}

(Le rapport est copi\xE9 : colle-le ici avec Cmd+V ou Ctrl+V.)`)}`,
          "_blank"
        );
        say("L\u2019envoi direct n\u2019a pas march\xE9 : un e-mail s\u2019ouvre, ton message y est d\xE9j\xE0 (colle le rapport avec Cmd+V ou Ctrl+V).", "err");
        send.disabled = false;
      }
    });
    dialog.showModal();
    form.elements.namedItem("message").focus();
  }

  // src/ui/theme.ts
  function setupTheme() {
    licenseBanner();
    updateBanner();
    simpleTopbar();
    const system = matchMedia("(prefers-color-scheme: dark)");
    const button = document.getElementById("theme-toggle");
    const choice = document.getElementById(
      "theme-choice"
    );
    let theme = "system";
    let revision = 0;
    const valid = (value) => value === "light" || value === "dark" ? value : "system";
    const render = () => {
      const dark = theme === "dark" || theme === "system" && system.matches;
      document.documentElement.dataset.theme = dark ? "dark" : "light";
      if (button) {
        button.textContent = dark ? "\u2600" : "\u263E";
        button.setAttribute("aria-pressed", String(dark));
        button.setAttribute(
          "aria-label",
          dark ? "Activer le mode clair" : "Activer le mode sombre"
        );
        button.title = button.getAttribute("aria-label");
      }
      if (choice) choice.value = theme;
    };
    const save = async (value) => {
      revision++;
      theme = value;
      render();
      try {
        await chrome.storage.local.set({ uiTheme: value });
      } catch {
      }
    };
    button?.addEventListener(
      "click",
      () => void save(
        document.documentElement.dataset.theme === "dark" ? "light" : "dark"
      )
    );
    choice?.addEventListener("change", () => void save(valid(choice.value)));
    system.addEventListener("change", render);
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "local" && changes.uiTheme) {
        revision++;
        theme = valid(changes.uiTheme.newValue);
        render();
      }
    });
    const initial = revision;
    void chrome.storage.local.get("uiTheme").then(({ uiTheme }) => {
      if (revision === initial) theme = valid(uiTheme);
      render();
    }).catch(() => render());
    render();
  }
  var PAGES = [
    ["routine.html", "\u2600\uFE0F Ma journ\xE9e"],
    ["dashboard.html", "\u{1F4E6} Mes produits"],
    ["scout.html", "\u{1F50D} Trouver"],
    ["sales.html", "\u{1F4D2} Ventes"]
  ];
  function simpleTopbar() {
    const bar = document.querySelector("header.topbar");
    const actions = bar?.querySelector(".top-actions");
    if (!bar || !actions || bar.querySelector(".ao-nav")) return;
    const here = location.pathname.split("/").pop() || "";
    if (here === "welcome.html") return;
    actions.querySelectorAll("a[href]").forEach((a) => {
      if (PAGES.some(([href]) => a.getAttribute("href") === href)) a.remove();
    });
    const nav = document.createElement("nav");
    nav.className = "ao-nav";
    nav.setAttribute("aria-label", "Pages d\u2019AurOEBay");
    for (const [href, label] of PAGES) {
      const a = document.createElement("a");
      a.href = href;
      a.textContent = label;
      if (href === here) {
        a.className = "on";
        a.setAttribute("aria-current", "page");
      }
      nav.append(a);
    }
    bar.querySelector(".brand")?.after(nav);
    bar.querySelector(".brand .crumb")?.remove();
    if (here !== "options.html") {
      const settings = document.createElement("a");
      settings.className = "btn ghost";
      settings.href = "options.html";
      settings.textContent = "\u2699\uFE0F Param\xE8tres";
      actions.append(settings);
    }
    const help = document.createElement("button");
    help.id = "help-report";
    help.type = "button";
    help.className = "btn ghost";
    help.textContent = "\u{1F198} Aide";
    help.title = "Un souci ? \xC9cris-nous, c\u2019est envoy\xE9 tout de suite";
    help.addEventListener("click", () => openReport());
    actions.append(help);
  }

  // src/core/profit.ts
  var PROFIT_SETTINGS_KEY = "profitSettings:v1";
  var DEFAULT_PROFIT_SETTINGS = { aliExtra: 10, feeRate: null, adRate: 5 };
  var EBAY_PERCENT = (0.136 + 0.0165) * 1.07;
  var round2 = (n) => Math.round(n * 100) / 100;
  function estimateProfit(priceUSD, costUSD, m, shipping = USUAL_SHIPPING) {
    const revenue = priceUSD * m.rate;
    const fees = revenue * m.feeRate + (m.feeFixed ?? 0) * m.rate;
    const supplier = (costUSD + shippingFor(costUSD, shipping)) * (1 + m.aliExtra) * m.rate;
    const charges = revenue * m.charges;
    return {
      revenue: round2(revenue),
      fees: round2(fees),
      supplier: round2(supplier),
      charges: round2(charges),
      net: round2(revenue - fees - supplier - charges)
    };
  }

  // src/core/variantMatch.ts
  function variantValue(value) {
    return value.normalize("NFKC").toLowerCase().replace(/(\d),(\d)/g, "$1.$2").replace(/[\s\u00a0_-]+/g, "").trim();
  }

  // src/core/profitReview.ts
  var round3 = (n) => Math.round(n * 100) / 100;
  function soldVariantCost(variation, costs) {
    const usd = costs.filter((c) => c.currency === "USD" && Number.isFinite(c.cost) && c.cost > 0);
    if (!usd.length) return null;
    if (usd.length === 1) return usd[0].cost;
    const sold = variation.split(/\s*[·•|]\s*/).map((part) => part.split(":").slice(1).join(":")).map(variantValue).filter(Boolean);
    if (!sold.length) return null;
    const hits = usd.filter((c) => c.values.length && c.values.every((v) => sold.includes(variantValue(v))));
    return hits.length === 1 ? hits[0].cost : null;
  }
  function reviewSale(sale, n, product, model) {
    if (sale.status === "cancelled" || sale.refund || sale.items.length !== 1 || !product) return null;
    if (!n.complete || n.profit === null || n.revenue === null || n.currency !== model.currency) return null;
    const item2 = sale.items[0];
    if (!item2.price || item2.price.currency !== "USD" || !(item2.price.amount > 0)) return null;
    const unit = soldVariantCost(item2.variation, product.costs);
    if (unit === null) return null;
    const qty = Math.max(1, item2.quantity);
    const planned = estimateProfit(item2.price.amount * qty, unit * qty, model, product.shipping).net;
    const real = round3(n.profit - n.revenue * model.charges);
    const paid = purchases(sale);
    const base = unit * qty + shippingFor(unit * qty, product.shipping);
    const usd = paid.length && paid.every((p) => p.cost.currency === "USD") ? paid.reduce((t, p) => t + p.cost.amount, 0) : null;
    const ratio = usd !== null && base > 0 ? usd / base - 1 : null;
    return {
      orderId: sale.orderId,
      planned,
      real,
      diff: round3(real - planned),
      // Beyond these, another variant or a price change: not a tax.
      tax: ratio !== null && ratio > -0.05 && ratio < 0.4 ? Math.round(ratio * 1e3) / 1e3 : null
    };
  }
  var median = (v) => {
    const s = [...v].sort((a, b) => a - b);
    const m = Math.floor(s.length / 2);
    return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2;
  };
  function reviewSummary(reviews2) {
    const taxes = reviews2.map((r) => r.tax).filter((t) => t !== null);
    return {
      count: reviews2.length,
      diff: reviews2.length ? round3(median(reviews2.map((r) => r.diff))) : null,
      tax: taxes.length >= 3 ? Math.max(0, Math.round(median(taxes) * 1e3) / 10) : null,
      taxSamples: taxes.length
    };
  }

  // src/core/disputes.ts
  var DISPUTES_KEY = "disputes:v1";
  var deliveredMissing = (d) => d.source === "aliexpress" && d.open && /delivered but not received/i.test(d.reason ?? "");
  var RETURN_AUTO = /buyer started a return|approved automatically/i;
  var returnToHold = (d) => d.source === "ebay" && d.kind === "return" && d.open && !d.held && !d.photos && RETURN_AUTO.test(`${d.status} ${d.detail ?? ""}`);
  var returnMessageUrl = (orderId2) => `https://www.ebay.com/mesh/ord/details?mode=SH&orderid=${encodeURIComponent(orderId2)}#auroebay-return-hold`;
  function disputeAdvice(list2, hasAliOrder) {
    const ebay = list2.filter((d) => d.source === "ebay");
    const ali = list2.filter((d) => d.source === "aliexpress");
    const ebayOpen = ebay.filter((d) => d.open);
    const aliOpen = ali.filter((d) => d.open);
    if (!ebay.length && !ali.length) return null;
    if (!ali.length && ebay.some(returnToHold))
      return { level: "urgent", text: "eBay a accept\xE9 ce retour tout seul : dis tout de suite au client de ne rien renvoyer, et demande-lui ses photos." };
    const proof = aliOpen.find((d) => d.awaitingProof);
    if (proof)
      return {
        level: "urgent",
        text: `AliExpress attend ta r\xE9ponse${proof.deadline ? ` avant le ${proof.deadline}` : ""} : ajoute une preuve et un message, sinon le litige peut se fermer sans remboursement.`
      };
    const photos = ebayOpen.find((d) => d.photos);
    const due = ebayOpen.find((d) => d.deadline);
    if (due) return { level: "urgent", text: `R\xE9ponds sur eBay avant le ${due.deadline} : \xAB ${due.status} \xBB.` };
    if (ebayOpen.some((d) => d.kind === "case"))
      return { level: "urgent", text: "eBay examine un litige (case) : envoie tes preuves (suivi, photos) depuis la page eBay." };
    if (photos && hasAliOrder && !ali.length)
      return { level: "todo", text: `Le client a envoy\xE9 ${photos.photos} photo(s) : ouvre le litige AliExpress avec elles pour obtenir un remboursement ou une \xE9tiquette de retour.` };
    if (ebayOpen.length && hasAliOrder && !ali.length)
      return {
        level: "todo",
        text: ebayOpen.some((d) => d.held) ? "D\xE8s que le client a envoy\xE9 ses photos, ouvre le litige AliExpress avec elles pour obtenir un remboursement ou une \xE9tiquette de retour." : ebayOpen[0].kind === "inr" ? "Le client dit ne pas avoir re\xE7u le colis : v\xE9rifie le suivi, et ouvre un litige \xAB colis non re\xE7u \xBB sur la commande AliExpress si besoin." : "Le client a un souci avec l\u2019article : ouvre un litige sur la commande AliExpress pour te faire rembourser par le fournisseur."
      };
    const missing = ali.find(deliveredMissing);
    if (missing)
      return {
        level: "info",
        text: `Litige \xAB livr\xE9 mais pas re\xE7u \xBB en cours${missing.deadline ? `, r\xE9ponse du vendeur attendue avant le ${missing.deadline}` : ""}. Si le client retrouve le colis, annule le litige. Si le vendeur envoie une preuve, transmets-la au client. Si rien ne se d\xE9bloque, envisage de le rembourser.`
      };
    const back = aliOpen.find((d) => d.awaitingReturn);
    if (back)
      return {
        level: "todo",
        text: `AliExpress attend le retour de l\u2019article${back.deadline ? ` avant le ${back.deadline}` : ""} : regarde sur la page AliExpress comment le renvoyer (adresse ou \xE9tiquette) et transmets-le au client.`
      };
    if (ebayOpen.length && aliOpen.length) return { level: "info", text: "Litiges en cours des deux c\xF4t\xE9s : suis-les jusqu\u2019au remboursement." };
    if (ebayOpen.length) return { level: "todo", text: `Litige eBay en cours : \xAB ${ebayOpen[0].status} \xBB.` };
    if (aliOpen.length) return { level: "info", text: "Litige eBay termin\xE9 : attends la d\xE9cision AliExpress pour r\xE9cup\xE9rer ton co\xFBt." };
    if (ebay.some((d) => d.refunded) && hasAliOrder && !ali.length)
      return { level: "todo", text: "Le client a \xE9t\xE9 rembours\xE9 sur eBay : demande aussi un remboursement au fournisseur AliExpress si l\u2019article posait probl\xE8me." };
    return { level: "done", text: "Litige termin\xE9 des deux c\xF4t\xE9s." };
  }

  // src/core/protection.ts
  var PARCELS_KEY = "aliParcels:v1";
  var DRAFT_HASH = "auroebay-dispute=";
  function disputeStartUrl(draft, info) {
    const link = info?.disputeLinks?.[draft.received ? "received" : "notReceived"];
    const base = link || `https://www.aliexpress.com/p/order/detail.html?orderId=${encodeURIComponent(draft.aliOrderId)}`;
    return `${base.split("#")[0]}#${DRAFT_HASH}${encodeURIComponent(JSON.stringify(draft))}`;
  }
  var enDay = (t) => new Date(t).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
  var units = (sale) => sale.items.reduce((n, i) => n + i.quantity, 0) || 1;
  function notReceivedDraft(sale, p, info, now = Date.now()) {
    const facts = [
      info?.placedAt ? `I placed this order on ${enDay(info.placedAt)}` : "I placed this order",
      "and the package has still not been delivered."
    ].join(" ");
    const track = p.tracking ? `Tracking number ${p.tracking}${info?.lastEventAt ? `: no update since ${enDay(info.lastEventAt)}${info.lastEvent ? ` (last status: "${info.lastEvent}")` : ""}` : ""}.` : "";
    const late = info?.etaEnd && info.etaEnd < now ? `The estimated delivery date (${enDay(info.etaEnd)}) has passed.` : "";
    return {
      saleId: sale.orderId,
      aliOrderId: p.orderId,
      received: false,
      reason: "Colis non re\xE7u (\xAB Package not received \xBB / \xAB Didn\u2019t receive the package \xBB)",
      quantity: units(sale),
      message: ["Hello,", [facts, track, late].filter(Boolean).join(" "), "Please refund me for this order. Thank you."].join("\n\n"),
      tips: ["Choisis \xAB No \xBB quand AliExpress demande si tu as re\xE7u le colis.", "Joins une capture du suivi si AliExpress la demande."]
    };
  }
  var priceText = (m) => m.amount.toLocaleString("fr-FR", { style: "currency", currency: m.currency });
  function deliveredMissingDraft(sale, p, info) {
    const when = info?.lastEventAt ? ` on ${enDay(info.lastEventAt)}` : "";
    const total = p.share?.total ?? p.cost;
    return {
      saleId: sale.orderId,
      aliOrderId: p.orderId,
      received: false,
      reason: "Tracking shows delivered but not received",
      quantity: units(sale),
      message: [
        "Hello,",
        `${p.tracking ? `Tracking number ${p.tracking}` : "The tracking"} shows this package as delivered${when}, but the recipient did not receive it or sign for it.`,
        "Please provide the carrier's proof of delivery (signature, photo or drop-off location). If no proof can be provided, please refund this order. Thank you."
      ].join("\n\n"),
      choices: [
        "Delivery status : \xAB Package not received \xBB",
        "Select a reason : \xAB Tracking shows delivered but not received \xBB",
        `Refund amount : le total de la commande, livraison comprise${total?.amount > 0 ? ` (${priceText(total)} selon AurOEBay, v\xE9rifie)` : ""}`,
        "Refund method : \xAB Original payment method \xBB, pas le solde bonus propos\xE9 par d\xE9faut"
      ],
      tips: [
        "\xAB Submit \xBB reste bloqu\xE9 tant qu\u2019aucune preuve n\u2019est jointe : une capture recadr\xE9e du message du client peut suffire.",
        "Sur la capture, garde seulement le message : pas d\u2019adresse ni de t\xE9l\xE9phone."
      ]
    };
  }
  function aliProofDraft(sale, p, ali, ebay, info) {
    const delivered = /delivered but not received/i.test(ali.reason ?? "");
    const changed = /no longer needed|changed my mind|no longer want|ordered by mistake/i.test(`${ali.reason ?? ""} ${ebay?.reason ?? ""}`);
    const track = p.tracking ? ` (tracking ${p.tracking})` : "";
    const when = info?.delivered && info.lastEventAt ? ` was delivered on ${enDay(info.lastEventAt)}` : "";
    const message2 = delivered ? deliveredMissingDraft(sale, p, info).message : changed ? ["Hello,", `My customer changed their mind and opened a return, as shown in the attached screenshot.${when ? ` The package${track}${when}.` : ""}`, "Please provide the return address or a return label, so the item can be sent back and this order refunded once it is returned. Thank you."].join("\n\n") : ["Hello,", `Please find the attached proof for this request${ebay?.reason ? ` (reason given by my customer: "${ebay.reason}")` : ""}.`, "Please tell me how to return the item, or refund this order. Thank you."].join("\n\n");
    return {
      saleId: sale.orderId,
      aliOrderId: p.orderId,
      received: true,
      reason: ali.reason ?? "",
      quantity: units(sale),
      message: message2,
      choices: [
        `Clique \xAB Provide additional information(s) \xBB${ali.deadline ? ` avant le ${ali.deadline}` : ""}`,
        "Photo : une capture recadr\xE9e de ta page de retour ou du message du client",
        "Colle le message dans \xAB Tell Us More About The Issue \xBB",
        "Clique toi-m\xEAme \xAB Submit \xBB"
      ],
      tips: ["Sur la capture : ni nom, ni adresse, ni t\xE9l\xE9phone, ni prix de vente.", "\xC9cris seulement ce qui est vrai : n\u2019invente pas de d\xE9faut sur l\u2019article."]
    };
  }
  var disputeDetailUrl = (url, draft) => `${url.split("#")[0]}#${DRAFT_HASH}${encodeURIComponent(JSON.stringify(draft))}`;
  function deliveredMissingFacts(sale, p, info, earnings) {
    const date2 = (t) => new Date(t).toLocaleString("fr-FR", { day: "numeric", month: "long", hour: "2-digit", minute: "2-digit" });
    const place = [sale.zip, sale.city, sale.country].filter(Boolean).join(" ");
    return [
      { label: "Suivi", value: p.tracking || "pas de num\xE9ro connu" },
      { label: "Livr\xE9 le", value: info.lastEventAt ? date2(info.lastEventAt) : "date inconnue" },
      ...info.lastEvent ? [{ label: "Dernier statut", value: info.lastEvent }] : [],
      ...place ? [{ label: "Adresse", value: place }] : [],
      { label: "Co\xFBt AliExpress", value: priceText(p.cost) },
      ...earnings ? [{ label: "Gain eBay", value: earnings }] : [],
      ...info.autoConfirmAt ? [{ label: "Confirmation auto AliExpress", value: date2(info.autoConfirmAt) }] : []
    ];
  }
  var REASONS = [
    { test: /wrong|different|not as described|doesn.?t match|not match|incorrect/i, fr: "Article diff\xE9rent de la description (\xAB Item not as described \xBB / \xAB Wrong item \xBB)", en: "the item received is not the one ordered / not as described" },
    { test: /damag|broken|defect|doesn.?t work|not work|faulty/i, fr: "Article endommag\xE9 ou d\xE9fectueux (\xAB Damaged \xBB / \xAB Defective \xBB)", en: "the item arrived damaged or does not work" },
    { test: /missing|parts|incomplete|quantity/i, fr: "Article ou pi\xE8ces manquants (\xAB Missing items \xBB)", en: "items or parts are missing from the package" },
    { test: /fit|size|small|large|big/i, fr: "Mauvaise taille (\xAB Size doesn\u2019t match \xBB / \xAB Not as described \xBB)", en: "the size received does not match the size ordered" },
    { test: /quality|fake|counterfeit/i, fr: "Qualit\xE9 / article diff\xE9rent de la description (\xAB Not as described \xBB)", en: "the quality is not as described" }
  ];
  function ebayDisputeDraft(sale, p, d, info) {
    if (d.kind === "inr") return info?.delivered ? deliveredMissingDraft(sale, p, info) : notReceivedDraft(sale, p, info);
    const r = REASONS.find((x) => x.test.test(d.reason ?? ""));
    const price = sale.items.find((i) => i.price)?.price?.amount ?? 0;
    const asked = d.amount?.amount ?? 0;
    const quantity = price > 0 && asked > 0 ? Math.max(1, Math.min(units(sale), Math.round(asked / price))) : units(sale);
    const variation = sale.items.map((i) => i.variation).filter(Boolean).join("; ");
    return {
      saleId: sale.orderId,
      aliOrderId: p.orderId,
      received: true,
      reason: r ? r.fr : "La raison la plus proche de celle du client eBay",
      quantity,
      message: [
        "Hello,",
        `I received this order and ${r ? r.en : "there is a problem with it"}${d.reason ? ` (reason: "${d.reason}")` : ""}.${variation ? ` I ordered: ${variation}.` : ""}`,
        `Please refund me for ${quantity > 1 ? `these ${quantity} items` : "this item"}. I can send photos if needed. Thank you.`
      ].join("\n\n"),
      tips: ["Ajoute les photos envoy\xE9es par le client si tu en as.", "Si AliExpress fournit une \xE9tiquette retour, envoie-la au client depuis eBay."]
    };
  }

  // src/ui/disputesView.ts
  async function loadDisputes() {
    const saved = (await chrome.storage.local.get(DISPUTES_KEY).catch(() => ({})))[DISPUTES_KEY];
    return saved?.items ? saved : { items: {}, at: 0 };
  }
  function disputesByOrder(store) {
    const map2 = /* @__PURE__ */ new Map();
    for (const d of Object.values(store.items)) {
      if (!d.orderId) continue;
      map2.set(d.orderId, [...map2.get(d.orderId) ?? [], d]);
    }
    for (const list2 of map2.values()) list2.sort((a, b) => Number(b.open) - Number(a.open) || Number(a.source !== "ebay") - Number(b.source !== "ebay") || b.updatedAt - a.updatedAt);
    return map2;
  }
  var KIND = {
    return: "Retour",
    inr: "Colis non re\xE7u",
    case: "Litige eBay (case)",
    refund: "Remboursement"
  };
  var money = (m) => m ? m.amount.toLocaleString("fr-FR", { style: "currency", currency: m.currency }) : "";
  function el(tag, cls = "", text = "") {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text) e.textContent = text;
    return e;
  }
  function saleDisputesBlock(sale, list2, parcels2 = {}) {
    if (!list2.length) return null;
    const box = el("div", "disputes");
    for (const d of list2) {
      const line = el("div", "dispute " + (d.open ? "open" : "closed"));
      const side = el("span", "side " + d.source, d.source === "ebay" ? "eBay" : "AliExpress");
      const what = el("b", "", KIND[d.kind]);
      const link = el("a", "", d.status || (d.open ? "En cours" : "Termin\xE9"));
      link.href = d.url;
      link.target = "_blank";
      link.rel = "noopener";
      link.title = [d.detail, d.reason && `Motif : ${d.reason}`, d.history?.length && d.history.map((h) => `${h.date} \xB7 ${h.text}`).join("\n")].filter(Boolean).join("\n\n");
      line.append(side, what, el("span", "state", d.open ? "en cours" : "termin\xE9"), link);
      if (d.reason) line.append(el("span", "muted", d.reason));
      if (d.amount && d.open) line.append(el("span", "muted", `demand\xE9 ${money(d.amount)}`));
      if (d.refunded) line.append(el("span", "refund", `rembours\xE9 ${money(d.refunded)}`));
      if (d.photos && d.open) line.append(el("span", "refund", `\u{1F4F7} ${d.photos} photo(s) du client`));
      if (d.deadline && d.open) line.append(el("span", "due", `\u23F0 avant le ${d.deadline}`));
      if (d.outcome) line.append(el("span", "muted", d.outcome));
      box.append(line);
    }
    const advice = disputeAdvice(list2, purchases(sale).length > 0);
    if (advice) {
      const a = el("div", "advice " + advice.level, "\u{1F449} " + advice.text);
      const hold = list2.find(returnToHold);
      if (hold) {
        const write = el("a", "", "\u2709\uFE0F \xC9crire au client \u2197");
        write.href = returnMessageUrl(sale.orderId);
        write.target = "_blank";
        write.rel = "noopener";
        const sent = el("button", "link-button", "\u2713 C\u2019est envoy\xE9");
        sent.type = "button";
        sent.addEventListener("click", () => void message({ type: "DISPUTE_HELD", key: hold.key }).then(() => location.reload()));
        a.append(" ", write, " ", sent);
      }
      const proof = list2.find((d) => d.source === "aliexpress" && d.open && d.awaitingProof);
      const proofOrder = proof && purchases(sale).find((p) => p.orderId === proof.aliOrderId);
      if (proof && proofOrder) {
        const answer = el("a", "", "\u{1F9FE} Pr\xE9parer ma r\xE9ponse \u2197");
        answer.href = disputeDetailUrl(proof.url, aliProofDraft(sale, proofOrder, proof, list2.find((d) => d.source === "ebay"), parcels2[proofOrder.orderId]));
        answer.target = "_blank";
        answer.rel = "noopener";
        a.append(" ", answer);
      }
      const ali = purchases(sale)[0];
      const ebay = list2.find((d) => d.source === "ebay" && d.open && (d.kind === "return" || d.kind === "inr"));
      if (ali && (advice.level === "todo" || ebay) && !list2.some((d) => d.source === "aliexpress")) {
        const go = el("a", "", ebay ? "\u{1F6E1}\uFE0F Pr\xE9parer le litige AliExpress \u2197" : "Ouvrir la commande AliExpress \u2197");
        go.href = ebay ? disputeStartUrl(ebayDisputeDraft(sale, ali, ebay, parcels2[ali.orderId]), parcels2[ali.orderId]) : `https://www.aliexpress.us/p/order/detail.html?orderId=${encodeURIComponent(ali.orderId)}`;
        go.title = ebay ? "Ouvre la page AliExpress \xAB Returns/refunds \xBB de la commande, avec la raison, la quantit\xE9 et le message en anglais pr\xEAts \xE0 copier. Tu remplis et tu valides toi-m\xEAme." : "";
        go.target = "_blank";
        go.rel = "noopener";
        a.append(" ", go);
      }
      box.append(a);
    }
    return box;
  }
  function disputeStatus(store, saleIds) {
    const all = Object.values(store.items);
    const outside = all.filter((d) => d.source === "ebay" && d.open && (!d.orderId || !saleIds.has(d.orderId)));
    if (!store.at) return { text: "Lit tes retours, demandes et litiges eBay, et les remboursements AliExpress des commandes li\xE9es. Rien n\u2019est envoy\xE9 ni accept\xE9 \xE0 ta place.", outside };
    const open = all.filter((d) => d.open).length;
    const when = new Date(store.at).toLocaleString("fr-FR", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });
    return {
      text: `Derni\xE8re synchro ${when} \xB7 ${open} litige(s) en cours${store.errors?.length ? " \xB7 \u26A0 " + store.errors.join(" ") : ""}`,
      outside
    };
  }

  // src/core/buyerMessages.ts
  var first = (name) => {
    const word = name.trim().split(/\s+/)[0] ?? "";
    return /^[\p{L}'-]{2,}$/u.test(word) ? word.charAt(0).toUpperCase() + word.slice(1).toLowerCase() : "";
  };
  var hello = (i) => first(i.buyer) ? `Hello ${first(i.buyer)},` : "Hello,";
  var item = (i) => {
    const t = i.item.trim().replace(/\s+/g, " ");
    return t.length > 60 ? `${t.slice(0, 60).replace(/\s+\S*$/, "")}\u2026` : t || "item";
  };
  var bye = "Kind regards";
  var BUYER_MESSAGES = [
    {
      id: "thanks",
      label: "Merci pour la commande",
      text: (i) => `${hello(i)}

Thank you for your order of the ${item(i)}! It is being prepared and I will send you the tracking number as soon as it ships.

If you have any question, just message me.

${bye}`
    },
    {
      id: "tracking",
      label: "Colis exp\xE9di\xE9 (num\xE9ro de suivi)",
      text: (i) => `${hello(i)}

Good news: your ${item(i)} has shipped.${i.tracking ? ` Tracking number: ${i.tracking}.` : ""} The tracking can take a few days to show the first updates, this is normal.

${bye}`
    },
    {
      id: "delay",
      label: "Retard de livraison",
      text: (i) => `${hello(i)}

I am sorry, your ${item(i)} is taking longer than expected. It is on its way${i.tracking ? ` (tracking: ${i.tracking})` : ""} and I am following it closely. Thank you for your patience, I will keep you updated.

${bye}`
    },
    {
      id: "phone",
      label: "Demander un num\xE9ro de portable",
      text: (i) => `${hello(i)}

Thank you for your order! The carrier needs a mobile phone number to deliver your ${item(i)} (the one on the order looks like a landline). Could you please send me a mobile number?

Thank you!
${bye}`
    },
    {
      id: "address",
      label: "Demander de confirmer l\u2019adresse",
      text: (i) => `${hello(i)}

Thank you for your order! The carrier cannot validate the delivery address as written. Could you please confirm your full address, including the postcode?

Thank you!
${bye}`
    },
    {
      id: "military",
      label: "Adresse militaire (APO/FPO) : demander une adresse civile",
      text: (i) => `${hello(i)}

Thank you for your order! Unfortunately my carrier cannot deliver to APO/FPO/DPO military addresses. Could you send me a civilian address in the United States? If that is not possible, I will cancel the order and you will receive a full refund.

${bye}`
    },
    {
      id: "country",
      label: "Pays non livrable : j\u2019annule et je rembourse",
      text: (i) => `${hello(i)}

Thank you for your order of the ${item(i)}. I am very sorry, but I am not able to ship this item to your region. I am cancelling the order now and you will receive a full refund.

Sorry for the inconvenience.
${bye}`
    },
    {
      id: "return-hold",
      label: "Retour : ne renvoie pas encore, envoie tes photos",
      text: (i) => `${hello(i)}

Thank you for your message. Please do not return the item yet.

Could you please send me a photo of the item you received, of the package, and of the shipping label if you still have it? This will allow me to contact the warehouse and provide you with the correct return label.

I will get back to you shortly with the next steps. Thank you for your cooperation.

${bye}`
    },
    {
      id: "return-photos",
      label: "Retour : photos bien re\xE7ues, garde l\u2019article",
      text: (i) => `${hello(i)}

Thank you very much for the photos, I have received them all.

I am now contacting the warehouse to arrange your return. Please keep the item and do not send it back yet.

I will get back to you within 2 to 3 business days with the next steps and the correct return label.

Thank you for your patience.

${bye}`
    },
    {
      id: "delivered-missing",
      label: "Indiqu\xE9 livr\xE9, mais pas re\xE7u : v\xE9rifier voisins et poste",
      text: (i) => `${hello(i)}

I am sorry to hear this. The tracking${i.tracking ? ` (${i.tracking})` : ""} shows the package as delivered${i.deliveredOn ? ` on ${i.deliveredOn}` : ""}, but this does not prove who received it.

Could you please check with your neighbors, in your mailbox, around the usual parcel area, and with your local post office?

In the meantime, I am asking the supplier for proof of delivery. I will get back to you as soon as I have an answer.

${bye}`
    },
    {
      id: "stock",
      label: "Rupture : j\u2019annule et je rembourse",
      text: (i) => `${hello(i)}

Thank you for your order. I am very sorry, the ${item(i)} is no longer available. I am cancelling the order now and you will receive a full refund.

Sorry for the inconvenience.
${bye}`
    }
  ];
  function buyerMessage(id, input) {
    const m = BUYER_MESSAGES.find((x) => x.id === id);
    return m ? m.text(input).slice(0, 2e3) : null;
  }

  // src/core/backupExtras.ts
  var BACKUP_EXTRA_KEYS = [
    "taxRates:v1",
    "disputes:v1",
    "aliParcels:v1",
    "hiddenProducts:v1",
    "monthGoal:v1",
    "firstSale:v1",
    "watch:v1",
    "competitorSuppliers:v1",
    "productShipping:v1",
    "listingPrices:v1"
  ];
  function backupExtras(local) {
    return Object.fromEntries(BACKUP_EXTRA_KEYS.flatMap((k) => local[k] === void 0 ? [] : [[k, local[k]]]));
  }

  // src/ui/backup.ts
  var STATUS = "backupStatus:v1";
  var MAIN_FILE = "auroebay-sauvegarde.json";
  var KEEP_DAYS = 14;
  var EVERY_MS = 6 * 36e5;
  async function fullBackup() {
    const local = await chrome.storage.local.get([
      "sales:v1",
      "listingSuppliers:v1",
      "variantPricing",
      "competitors:v1",
      "profitSettings:v1",
      "urssafDeclarations:v1",
      ...BACKUP_EXTRA_KEYS
    ]);
    return {
      format: "auroebay-full",
      version: 1,
      exportedAt: Date.now(),
      library: await message({ type: "LIBRARY", command: { action: "export" } }),
      sales: local["sales:v1"] ?? {},
      listingSuppliers: local["listingSuppliers:v1"] ?? {},
      variantPricing: local.variantPricing ?? null,
      competitors: local["competitors:v1"] ?? {},
      profitSettings: local["profitSettings:v1"] ?? null,
      urssafDeclarations: local["urssafDeclarations:v1"] ?? null,
      extras: backupExtras(local)
    };
  }
  function db() {
    return new Promise((resolve, reject) => {
      const open = indexedDB.open("auroebay-backup", 1);
      open.onupgradeneeded = () => open.result.createObjectStore("kv");
      open.onsuccess = () => resolve(open.result);
      open.onerror = () => reject(open.error);
    });
  }
  async function kv(mode, value) {
    const d = await db();
    return new Promise((resolve, reject) => {
      const store = d.transaction("kv", mode === "get" ? "readonly" : "readwrite").objectStore("kv");
      const req = mode === "get" ? store.get("folder") : mode === "put" ? store.put(value, "folder") : store.delete("folder");
      req.onsuccess = () => resolve(mode === "get" ? req.result : void 0);
      req.onerror = () => reject(req.error);
    });
  }
  var backupFolder = () => kv("get").catch(() => void 0);
  async function backupStatus() {
    const status = (await chrome.storage.local.get(STATUS))[STATUS] ?? { at: null, folder: null };
    const handle = await backupFolder();
    return {
      ...status,
      folder: handle?.name ?? null,
      permission: handle ? await handle.queryPermission({ mode: "readwrite" }).catch(() => "denied") : "none"
    };
  }
  var writing = null;
  async function writeBackup(force = false) {
    if (writing) return writing;
    writing = (async () => {
      const handle = await backupFolder();
      if (!handle || await handle.queryPermission({ mode: "readwrite" }) !== "granted") return;
      const status = (await chrome.storage.local.get(STATUS))[STATUS] ?? {};
      if (!force && status.at && Date.now() - status.at < 6e4) return;
      try {
        const text = JSON.stringify(await fullBackup());
        const day3 = `auroebay-${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.json`;
        for (const name of [MAIN_FILE, day3]) {
          const file = await handle.getFileHandle(name, { create: true });
          const w = await file.createWritable();
          await w.write(text);
          await w.close();
        }
        const dated = [];
        for await (const name of handle.keys()) if (/^auroebay-\d{4}-\d{2}-\d{2}\.json$/.test(name)) dated.push(name);
        for (const old of dated.sort().slice(0, Math.max(0, dated.length - KEEP_DAYS)))
          await handle.removeEntry(old).catch(() => {
          });
        await chrome.storage.local.set({ [STATUS]: { at: Date.now(), folder: handle.name } });
      } catch (e) {
        await chrome.storage.local.set({
          [STATUS]: { ...status, folder: handle.name, error: e instanceof Error ? e.message : String(e) }
        });
      }
    })().finally(() => writing = null);
    return writing;
  }
  function setupAutoBackup(bar) {
    let timer;
    const refresh = async () => {
      const s = await backupStatus();
      bar.hidden = true;
      bar.replaceChildren();
      if (s.permission === "none") return;
      if (s.permission !== "granted") {
        const button = document.createElement("button");
        button.className = "btn small";
        button.type = "button";
        button.textContent = "R\xE9activer";
        button.addEventListener("click", async () => {
          const handle = await backupFolder();
          if (handle && await handle.requestPermission({ mode: "readwrite" }) === "granted") {
            await writeBackup(true);
            await refresh();
          }
        });
        bar.append(`Sauvegarde automatique en pause : Chrome demande d\u2019autoriser \xE0 nouveau le dossier \xAB ${s.folder} \xBB. `, button);
        bar.hidden = false;
        return;
      }
      if (!s.at || Date.now() - s.at > EVERY_MS) {
        await writeBackup(true);
      }
    };
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "local" || !(changes.libraryRevision || changes["sales:v1"] || changes["listingSuppliers:v1"] || changes["competitors:v1"] || changes["urssafDeclarations:v1"]))
        return;
      clearTimeout(timer);
      timer = setTimeout(() => void writeBackup(true), 2e4);
    });
    void refresh().catch(() => {
    });
    return { refresh };
  }

  // src/ui/profits.ts
  var round4 = (n) => Math.round(n * 100) / 100;
  function saleNet(n, charges) {
    if (!n.complete || n.profit === null) return null;
    return round4(n.profit - charges(n.revenue ?? 0));
  }
  function productProfits(sales2, numbers, charges, currency) {
    const rows = /* @__PURE__ */ new Map();
    for (const s of sales2) {
      if (s.status === "cancelled" || !s.items.length) continue;
      const n = numbers(s);
      const net = n.currency === currency ? saleNet(n, charges) : null;
      if (net === null) continue;
      const item2 = s.items[0];
      const key = item2.itemId ?? item2.title.toLowerCase().trim();
      const row = rows.get(key) ?? { key, title: item2.title, itemId: item2.itemId, sales: 0, net: 0, revenue: 0, fees: 0, cost: 0, charges: 0 };
      row.sales++;
      row.net = round4(row.net + net);
      row.revenue = round4(row.revenue + (n.revenue ?? 0));
      row.fees = round4(row.fees + n.fees);
      row.cost = round4(row.cost + (n.cost ?? 0));
      row.charges = round4(row.charges + charges(n.revenue ?? 0));
      rows.set(key, row);
    }
    return [...rows.values()];
  }
  function monthlyNet(sales2, numbers, charges, currency, months = 12, now = /* @__PURE__ */ new Date()) {
    const out = [];
    for (let i = months - 1; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      out.push({ key: `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`, net: 0, orders: 0, complete: 0 });
    }
    const byKey = new Map(out.map((m) => [m.key, m]));
    for (const s of sales2) {
      if (!s.soldAt || s.status === "cancelled") continue;
      const d = new Date(s.soldAt);
      const m = byKey.get(`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`);
      if (!m) continue;
      m.orders++;
      const n = numbers(s);
      const net = n.currency === currency ? saleNet(n, charges) : null;
      if (net === null) continue;
      m.complete++;
      m.net = round4(m.net + net);
    }
    return out;
  }
  var fmt = (n, cur) => n.toLocaleString("fr-FR", { style: "currency", currency: cur });
  var monthLabel = (key, style) => (/* @__PURE__ */ new Date(key + "-01T12:00:00")).toLocaleDateString("fr-FR", style === "short" ? { month: "short" } : { month: "long", year: "numeric" });
  function barPath(x, w, zero, y) {
    const h = Math.abs(zero - y);
    if (h < 0.5) return "";
    const r = Math.min(4, h, w / 2);
    if (y < zero)
      return `M${x},${zero}V${y + r}Q${x},${y} ${x + r},${y}H${x + w - r}Q${x + w},${y} ${x + w},${y + r}V${zero}Z`;
    return `M${x},${zero}V${y - r}Q${x},${y} ${x + r},${y}H${x + w - r}Q${x + w},${y} ${x + w},${y - r}V${zero}Z`;
  }
  function renderProfits(root, data) {
    const { months, products, currency } = data;
    const W = 720, H2 = 220, top = 18, bottom = 30, left = 8, right = 8;
    const values = months.map((m) => m.net);
    const max = Math.max(0, ...values);
    const min = Math.min(0, ...values);
    const span = max - min || 1;
    const plot = H2 - top - bottom;
    const y = (v) => top + (max - v) / span * plot;
    const zero = y(0);
    const slot = (W - left - right) / months.length;
    const barW = Math.min(34, slot - 6);
    const hasData = months.some((m) => m.complete);
    const best = values.indexOf(Math.max(...values));
    const last = months.length - 1;
    const bars = months.map((m, i) => {
      const x = left + i * slot + (slot - barW) / 2;
      const path = barPath(x, barW, zero, y(m.net));
      const label = (i === best || i === last) && m.complete ? `<text class="pv" x="${x + barW / 2}" y="${m.net >= 0 ? y(m.net) - 6 : y(m.net) + 14}" text-anchor="middle">${escapeHTML(fmt(m.net, currency).replace(/\s/g, " "))}</text>` : "";
      return `<g class="bar" data-i="${i}" style="--d:${i * 0.04}s">
        <rect class="hit" x="${left + i * slot}" y="${top}" width="${slot}" height="${plot}" fill="transparent"/>
        ${path ? `<path class="${m.net >= 0 ? "pos" : "neg"}" d="${path}" style="transform-origin:0 ${zero}px"/>` : ""}
        ${label}
        <text class="mx" x="${x + barW / 2}" y="${H2 - 10}" text-anchor="middle">${escapeHTML(monthLabel(m.key, "short"))}</text>
      </g>`;
    }).join("");
    const grid = [max / 2, min / 2].filter((v, i, a) => v !== 0 && a.indexOf(v) === i).map((v) => `<line class="gl" x1="${left}" x2="${W - right}" y1="${y(v)}" y2="${y(v)}"/><text class="gt" x="${left}" y="${y(v) - 4}" text-anchor="start">${escapeHTML(fmt(v, currency).replace(/\s/g, " "))}</text>`).join("");
    const winners = products.filter((p) => p.net > 0).sort((a, b) => b.net - a.net).slice(0, 5);
    const losers = products.filter((p) => p.net < 0).sort((a, b) => a.net - b.net).slice(0, 5);
    const list2 = (rows, empty) => rows.length ? `<ol>${rows.map(
      (p) => `<li><div class="pt">${p.itemId ? `<a href="https://www.ebay.com/itm/${escapeHTML(p.itemId)}" target="_blank" rel="noopener">${escapeHTML(p.title)}</a>` : escapeHTML(p.title)}</div>
            <div class="pm"><b><i class="k ${p.net >= 0 ? "pos" : "neg"}"></i>${p.net >= 0 ? "+" : ""}${escapeHTML(fmt(p.net, currency))}</b><span>${p.sales} vente(s) \xB7 ${p.net / p.sales >= 0 ? "+" : ""}${escapeHTML(fmt(p.net / p.sales, currency))} / vente</span></div>
            <div class="pd">Vendu ${escapeHTML(fmt(p.revenue, currency))} \u2212 frais eBay ${escapeHTML(fmt(p.fees, currency))} \u2212 AliExpress ${escapeHTML(fmt(p.cost, currency))} \u2212 URSSAF + imp\xF4t ${escapeHTML(fmt(p.charges, currency))}</div></li>`
    ).join("")}</ol>` : `<p class="muted">${empty}</p>`;
    root.innerHTML = `
    <div class="pf-chart">
      <div class="pf-head"><div><h3>B\xE9n\xE9fice apr\xE8s URSSAF et imp\xF4t</h3><p class="muted">12 derniers mois \xB7 ventes compl\xE8tes seulement</p></div>
        <div class="pf-key"><span class="k pos"></span>b\xE9n\xE9fice <span class="k neg"></span>perte</div></div>
      ${hasData ? `<svg viewBox="0 0 ${W} ${H2}" role="img" aria-label="B\xE9n\xE9fice net par mois">${grid}<line class="zl" x1="${left}" x2="${W - right}" y1="${zero}" y2="${zero}"/>${bars}</svg><div class="pf-tip" hidden></div>` : `<p class="muted pf-empty">Pas encore de vente compl\xE8te (avec co\xFBt fournisseur) sur les 12 derniers mois.</p>`}
    </div>
    <div class="pf-lists">
      <div class="pf-list"><h3>\u{1F4B0} Ce qui rapporte</h3><p class="muted">${escapeHTML(data.periodLabel)} \xB7 b\xE9n\xE9fice apr\xE8s URSSAF et imp\xF4t</p>${list2(winners, "Aucun produit rentable sur cette p\xE9riode.")}</div>
      <div class="pf-list"><h3>\u26A0\uFE0F Ce qui fait perdre</h3><p class="muted">N\xE9gatif une fois l\u2019URSSAF et l\u2019imp\xF4t pay\xE9s : monte le prix ou retire l\u2019annonce.</p>${list2(losers, "Aucune vente \xE0 perte sur cette p\xE9riode. \u{1F44C}")}</div>
    </div>`;
    const svg = root.querySelector("svg");
    const tip = root.querySelector(".pf-tip");
    if (!svg || !tip) return;
    svg.querySelectorAll("g.bar").forEach((g) => {
      const m = months[Number(g.dataset.i)];
      g.addEventListener("mouseenter", () => {
        svg.classList.add("hovering");
        g.classList.add("on");
        tip.innerHTML = `<b>${escapeHTML(monthLabel(m.key, "long"))}</b><span>${m.complete ? `${m.net >= 0 ? "+" : ""}${escapeHTML(fmt(m.net, currency))} apr\xE8s charges` : "aucune vente compl\xE8te"}</span><small>${m.orders} commande(s)${m.orders - m.complete ? ` \xB7 ${m.orders - m.complete} sans co\xFBt` : ""}</small>`;
        tip.hidden = false;
        const card = root.querySelector(".pf-chart").getBoundingClientRect();
        const r = g.querySelector("rect.hit").getBoundingClientRect();
        const bar = (g.querySelector("path") ?? g.querySelector("rect.hit")).getBoundingClientRect();
        const tipWidth = tip.offsetWidth || 170;
        const rightSide = r.right - card.left + 6;
        tip.style.left = `${rightSide + tipWidth < card.width - 8 ? rightSide : r.left - card.left - tipWidth - 6}px`;
        tip.style.top = `${Math.max(48, bar.top - card.top - 4)}px`;
      });
      g.addEventListener("mouseleave", () => {
        svg.classList.remove("hovering");
        g.classList.remove("on");
        tip.hidden = true;
      });
    });
  }

  // src/ui/urssaf.ts
  var URSSAF_KEY = "urssafDeclarations:v1";
  var round5 = (n) => Math.round(n * 100) / 100;
  function periodOf(t, frequency) {
    const d = new Date(t);
    const y = d.getFullYear();
    if (frequency === "month") {
      const m = d.getMonth();
      return { key: `${y}-${String(m + 1).padStart(2, "0")}`, start: new Date(y, m, 1), end: new Date(y, m + 1, 1) };
    }
    const q = Math.floor(d.getMonth() / 3);
    return { key: `${y}-T${q + 1}`, start: new Date(y, q * 3, 1), end: new Date(y, q * 3 + 3, 1) };
  }
  var dueDate = (end) => new Date(end.getFullYear(), end.getMonth() + 1, 0);
  function declarationPeriods(sales2, numbers, frequency, currency) {
    const map2 = /* @__PURE__ */ new Map();
    for (const s of sales2) {
      if (!s.soldAt || s.status === "cancelled") continue;
      const p = periodOf(s.soldAt, frequency);
      const row = map2.get(p.key) ?? {
        key: p.key,
        label: frequency === "month" ? p.start.toLocaleDateString("fr-FR", { month: "long", year: "numeric" }) : `${p.key.slice(5).replace("T", "")}${p.key.endsWith("1") ? "er" : "e"} trimestre ${p.start.getFullYear()}`,
        start: p.start,
        end: p.end,
        due: dueDate(p.end),
        revenue: 0,
        orders: 0,
        estimated: 0,
        missing: 0
      };
      const n = numbers(s);
      if (n.currency !== currency || n.revenue === null) row.missing++;
      else {
        row.revenue = round5(row.revenue + n.revenue);
        row.orders++;
        if (n.estimatedRate) row.estimated++;
      }
      map2.set(p.key, row);
    }
    return [...map2.values()].sort((a, b) => b.start.getTime() - a.start.getTime());
  }
  function declarationCSV(sales2, numbers, period, frequency) {
    const cell2 = (v) => `"${String(v).replace(/"/g, '""')}"`;
    const num2 = (n) => n.toFixed(2).replace(".", ",");
    const lines = [["Date d'encaissement", "Commande eBay", "Produit", "Chiffre d'affaires", "Devise", "Taux estim\xE9"].map(cell2).join(";")];
    let total = 0;
    for (const s of [...sales2].sort((a, b) => (a.soldAt ?? 0) - (b.soldAt ?? 0))) {
      if (!s.soldAt || s.status === "cancelled" || periodOf(s.soldAt, frequency).key !== period.key) continue;
      const n = numbers(s);
      if (n.revenue === null) continue;
      total += n.revenue;
      lines.push(
        [new Date(s.soldAt).toLocaleDateString("fr-FR"), s.orderId, s.items[0]?.title ?? "", num2(n.revenue), n.currency, n.estimatedRate ? "oui" : ""].map(cell2).join(";")
      );
    }
    lines.push(["", "", "TOTAL \xC0 D\xC9CLARER", num2(round5(total)), "", ""].map(cell2).join(";"));
    return "\uFEFF" + lines.join("\n");
  }
  var fmt2 = (n, cur) => n.toLocaleString("fr-FR", { style: "currency", currency: cur });
  var day = (d) => d.toLocaleDateString("fr-FR", { day: "numeric", month: "long", year: "numeric" });
  function renderDeclarations(root, data) {
    const now = data.now ?? /* @__PURE__ */ new Date();
    const { periods, store, currency } = data;
    const open = periods.filter((p) => p.end <= now && !store.declared[p.key]).sort((a, b) => a.due.getTime() - b.due.getTime());
    const next = open[0];
    const daysLeft = next ? Math.ceil((next.due.getTime() - now.getTime()) / 864e5) : null;
    const banner = next ? `<div class="ur-next ${daysLeft !== null && daysLeft <= 7 ? "hot" : ""}"><b>${daysLeft !== null && daysLeft < 0 ? "\u26A0 En retard" : "\xC0 d\xE9clarer"} : ${escapeHTML(next.label)}</b> \u2014 <strong>${escapeHTML(fmt2(next.revenue, currency))}</strong> de chiffre d\u2019affaires, avant le ${escapeHTML(day(next.due))}${daysLeft !== null && daysLeft >= 0 ? ` (dans ${daysLeft} jour${daysLeft > 1 ? "s" : ""})` : ""}.${open.length > 1 ? ` <span class="muted">${open.length - 1} autre(s) p\xE9riode(s) non coch\xE9e(s).</span>` : ""}</div>` : `<div class="ur-next ok">\u2713 Rien en attente : toutes les p\xE9riodes termin\xE9es sont coch\xE9es \xAB D\xE9clar\xE9 \xBB.</div>`;
    root.innerHTML = `
    <div class="ur-head">
      <div><h3>\u{1F9FE} D\xE9claration URSSAF</h3><p class="muted">Chiffre d\u2019affaires encaiss\xE9 \xE0 d\xE9clarer (prix + livraison pay\xE9s par l\u2019acheteur, taxe US collect\xE9e par eBay exclue, frais eBay non d\xE9duits). Date d\u2019encaissement = paiement de l\u2019acheteur sur eBay.</p></div>
      <label class="ur-freq">Je d\xE9clare <select id="ur-frequency"><option value="month">chaque mois</option><option value="quarter">chaque trimestre</option></select></label>
    </div>
    ${banner}
    <table class="mini ur-table"><thead><tr><th>P\xE9riode</th><th class="n">Ventes</th><th class="n">CA \xE0 d\xE9clarer</th><th class="n">URSSAF + imp\xF4t estim\xE9</th><th>\xC0 d\xE9clarer avant</th><th>Statut</th><th></th></tr></thead><tbody>
    ${periods.slice(0, 12).map((p) => {
      const done = !!store.declared[p.key];
      const running = p.end > now;
      const notes = [
        p.estimated ? `${p.estimated} au taux estim\xE9` : "",
        p.missing ? `${p.missing} sans montant lu` : ""
      ].filter(Boolean);
      return `<tr class="${done ? "done" : running ? "running" : ""}">
          <td>${escapeHTML(p.label)}${notes.length ? `<br><small class="muted">${escapeHTML(notes.join(" \xB7 "))}</small>` : ""}</td>
          <td class="n">${p.orders}</td>
          <td class="n"><b>${escapeHTML(fmt2(p.revenue, currency))}</b></td>
          <td class="n">${escapeHTML(fmt2(data.charges(p.revenue), currency))}</td>
          <td>${escapeHTML(day(p.due))}</td>
          <td>${running ? '<span class="muted">en cours</span>' : `<label class="ur-done"><input type="checkbox" data-declared="${escapeHTML(p.key)}" ${done ? "checked" : ""}> D\xE9clar\xE9</label>`}</td>
          <td><button class="btn small" type="button" data-export="${escapeHTML(p.key)}">Exporter</button></td>
        </tr>`;
    }).join("")}
    </tbody></table>
    <p class="muted ur-foot">Montants en ${escapeHTML(currency)} au taux eBay de chaque commande. Un remboursement est d\xE9duit une fois la commande relue (\xAB \u2696\uFE0F Synchroniser les litiges \xBB ou en ouvrant la commande eBay) ; v\xE9rifie avec ton relev\xE9 eBay (\xAB Payments \xBB).</p>`;
    const select = root.querySelector("#ur-frequency");
    select.value = store.frequency;
    select.addEventListener("change", () => data.onFrequency(select.value));
    root.querySelectorAll("[data-declared]").forEach(
      (box) => box.addEventListener("change", () => data.onDeclared(box.dataset.declared, box.checked))
    );
    root.querySelectorAll("[data-export]").forEach(
      (b) => b.addEventListener("click", () => {
        const p = periods.find((x) => x.key === b.dataset.export);
        if (p) data.onExport(p);
      })
    );
  }

  // src/core/demo.ts
  var DAY2 = 864e5;
  var H = 36e5;
  var isDemo = (search) => new URLSearchParams(search).get("demo") === "1";
  var EXAMPLES = [
    { id: 1, title: "Silicone Solo Loop Watch Band for Apple Watch", variation: "Color: Black \xB7 Size: S", buyer: "mike_t2024", country: "United States", ago: 30 * H, price: 9.99 },
    { id: 2, title: "Mini LED Desk Lamp USB Rechargeable", variation: "Color: White", buyer: "sarah.home", country: "United States", ago: 3 * DAY2, price: 14.99, cost: 4.2, status: "shipped", aliTracking: "1ST06015360001", boughtAgo: 3 * DAY2 },
    { id: 3, title: "Car Dashboard Crack Repair Gel 60ml", buyer: "garage_joe", country: "United States", ago: 7 * DAY2, price: 12.49, cost: 3.1, aliTracking: "SPXDEM039711300003", aliStatus: "Processing", boughtAgo: 6.5 * DAY2 },
    { id: 4, title: "Fiber Optic Side Glow Cable 2m", buyer: "lightfan_88", country: "United States", ago: 52 * DAY2, price: 18.99, cost: 5.4, status: "shipped", aliTracking: "GFUS01081060000004", ebayTracking: "AP00100060000004", boughtAgo: 52 * DAY2 },
    { id: 5, title: "Silicone Solo Loop Watch Band for Apple Watch", variation: "Color: Pink \xB7 Size: M", buyer: "joli_shop", country: "Mexico", ago: 15 * DAY2, price: 9.99, quantity: 2, cost: 4.8, status: "shipped", aliTracking: "1ST06015350005", ebayTracking: "1ST06015350005", boughtAgo: 15 * DAY2 },
    { id: 6, title: "RC Plane Balance Stand CG Tool", buyer: "flyhigh_rc", country: "United States", ago: 4 * DAY2, price: 6.99, cost: 7.9, status: "shipped", aliTracking: "1ST06015360006", ebayTracking: "1ST06015360006", boughtAgo: 4 * DAY2 },
    { id: 7, title: "UV Resin Curing Lamp 9 LED", buyer: "crafty_ann", country: "United States", ago: 9 * DAY2, price: 11.99, cost: 3.6, status: "shipped", aliTracking: "9C1821J621007", ebayTracking: "9C1821J621007", boughtAgo: 9 * DAY2 },
    { id: 8, title: "Mini LED Desk Lamp USB Rechargeable", variation: "Color: Black", buyer: "desk_dan", country: "United States", ago: 11 * DAY2, price: 14.99, cost: 4.2, status: "shipped", aliTracking: "1ST06015340008", ebayTracking: "1ST06015340008", boughtAgo: 11 * DAY2 }
  ];
  var orderId = (n) => `00-00000-${String(n).padStart(5, "0")}`;
  var aliId = (n) => `30000000000000${String(n).padStart(2, "0")}`;
  var RATE = 0.86;
  var r2 = (n) => Math.round(n * 100) / 100;
  function demoSales(now = Date.now()) {
    return EXAMPLES.map((e) => {
      const quantity = e.quantity ?? 1;
      const total = r2(e.price * quantity);
      const fees = r2(total * RATE * 0.153 + 0.4 * RATE);
      const soldAt = now - e.ago;
      return {
        orderId: orderId(e.id),
        soldAt,
        buyer: e.buyer,
        country: e.country,
        items: [{ title: e.title, itemId: `99000000000${e.id}`, variation: e.variation ?? "", quantity, price: { amount: e.price, currency: "USD" }, sku: null, supplierId: null }],
        subtotal: { amount: total, currency: "USD" },
        shipping: { amount: 0, currency: "USD" },
        tax: null,
        orderTotal: { amount: total, currency: "USD" },
        fees: [{ label: "Fees", amount: { amount: -fees, currency: "EUR" } }],
        earnings: { amount: r2(total * RATE - fees), currency: "EUR" },
        rate: RATE,
        status: e.status ?? "to_ship",
        tracking: e.ebayTracking ?? "",
        supplier: e.cost !== void 0 ? {
          orderId: aliId(e.id),
          cost: { amount: e.cost, currency: "USD" },
          status: e.aliStatus ?? "Awaiting delivery",
          ...e.aliTracking && e.aliStatus !== "Processing" ? { tracking: e.aliTracking } : {},
          how: "auto",
          linkedAt: now - (e.boughtAgo ?? e.ago)
        } : null,
        manualCost: null,
        otherCost: 0,
        notes: "Exemple (d\xE9mo)",
        savedAt: soldAt,
        updatedAt: soldAt
      };
    });
  }
  function demoDisputes(now = Date.now()) {
    const respond = new Date(now + 2 * DAY2).toLocaleDateString("en-US", { month: "short", day: "numeric" });
    return [
      {
        key: "ebay:demo-return-5",
        source: "ebay",
        kind: "return",
        id: "5300000005",
        url: "https://www.ebay.com/sh/ord/return",
        orderId: orderId(5),
        open: true,
        status: "Provide a return shipping label",
        reason: "Doesn't fit",
        amount: { amount: 9.99, currency: "USD" },
        deadline: respond,
        updatedAt: now - 3 * H
      }
    ];
  }

  // src/core/ledger.ts
  var round6 = (n) => Math.round(n * 100) / 100;
  var inYear = (t, year) => !!t && new Date(t).getFullYear() === year;
  function ledgerYears(sales2) {
    return [...new Set(sales2.filter((s) => s.soldAt).map((s) => new Date(s.soldAt).getFullYear()))].sort((a, b) => b - a);
  }
  function receiptRows(sales2, numbers, year) {
    const rows = [];
    for (const s of sales2) {
      if (s.status === "cancelled" || !inYear(s.soldAt, year)) continue;
      const n = numbers(s);
      if (n.revenue === null) continue;
      const units2 = s.items.reduce((t, i) => t + i.quantity, 0);
      rows.push({
        date: s.soldAt,
        ref: s.orderId,
        client: s.buyer ? `Acheteur eBay ${s.buyer}${s.country ? ` (${s.country})` : ""}` : "Acheteur eBay",
        nature: `Vente de marchandises : ${s.items[0]?.title ?? ""}${s.items.length > 1 ? ` + ${s.items.length - 1} autre(s)` : ""}${units2 > 1 ? ` (${units2} articles)` : ""}`,
        amount: round6(n.revenue),
        currency: n.currency,
        payment: "eBay (paiement en ligne, vers\xE9 sur le compte bancaire)",
        note: [n.buyerRefund ? "apr\xE8s remboursement" : "", n.estimatedRate ? "taux de change estim\xE9" : ""].filter(Boolean).join(", ")
      });
    }
    return rows.sort((a, b) => a.date - b.date || a.ref.localeCompare(b.ref));
  }
  function purchaseRows(sales2, fallbackRate2, year) {
    const rows = [];
    for (const s of sales2) {
      if (s.status === "cancelled") continue;
      const currency = s.earnings?.currency ?? "USD";
      for (const p of purchases(s)) {
        const date2 = p.linkedAt || s.soldAt;
        if (!inYear(date2, year)) continue;
        const direct = toPayout(s, p.cost);
        const amount = direct ?? toPayout(s, p.cost, fallbackRate2);
        if (amount === null) continue;
        const refund = (s.supplierRefunds ?? []).filter((r) => r.aliOrderId === p.orderId).reduce((t, r) => t + (toPayout(s, r.amount, fallbackRate2) ?? 0), 0);
        rows.push({
          date: date2,
          ref: p.orderId,
          supplier: "AliExpress",
          nature: `Achat de marchandises : ${s.items[0]?.title ?? ""}`,
          amount: round6(amount - Math.min(refund, amount)),
          currency,
          sale: s.orderId,
          note: [
            p.share ? `commande partag\xE9e entre ${p.share.sales.length} ventes (part de cette vente)` : "",
            refund ? "apr\xE8s remboursement AliExpress" : "",
            direct === null ? "taux de change estim\xE9" : ""
          ].filter(Boolean).join(", ")
        });
      }
    }
    return rows.sort((a, b) => a.date - b.date || a.ref.localeCompare(b.ref));
  }
  var cell = (v) => `"${String(v).replace(/"/g, '""')}"`;
  var num = (n) => n.toFixed(2).replace(".", ",");
  var day2 = (t) => new Date(t).toLocaleDateString("fr-FR");
  function receiptsCSV(rows) {
    const lines = [["Date", "R\xE9f\xE9rence (commande eBay)", "Client", "Nature", "Montant", "Devise", "Mode de r\xE8glement", "Remarque"].map(cell).join(";")];
    for (const r of rows) lines.push([day2(r.date), r.ref, r.client, r.nature, num(r.amount), r.currency, r.payment, r.note].map(cell).join(";"));
    lines.push(["", "", "", "TOTAL", num(round6(rows.reduce((t, r) => t + r.amount, 0))), rows[0]?.currency ?? "", "", ""].map(cell).join(";"));
    return "\uFEFF" + lines.join("\n");
  }
  function purchasesCSV(rows) {
    const lines = [["Date", "R\xE9f\xE9rence (commande AliExpress)", "Fournisseur", "Nature", "Montant", "Devise", "Vente eBay", "Remarque"].map(cell).join(";")];
    for (const r of rows) lines.push([day2(r.date), r.ref, r.supplier, r.nature, num(r.amount), r.currency, r.sale, r.note].map(cell).join(";"));
    lines.push(["", "", "", "TOTAL", num(round6(rows.reduce((t, r) => t + r.amount, 0))), rows[0]?.currency ?? "", "", ""].map(cell).join(";"));
    return "\uFEFF" + lines.join("\n");
  }
  var esc = (s) => s.replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]);
  var money2 = (n, cur) => n.toLocaleString("fr-FR", { style: "currency", currency: cur });
  function ledgerPrintHTML(year, receipts, buys, owner = "") {
    const total = (rows) => round6(rows.reduce((t, r) => t + r.amount, 0));
    const cur = receipts[0]?.currency ?? buys[0]?.currency ?? "EUR";
    const table = (head, body2, sum) => `<table><thead><tr>${head.map((h) => `<th>${esc(h)}</th>`).join("")}</tr></thead><tbody>${body2.map((r) => `<tr>${r.map((c, i) => `<td${i === 4 ? ' class="n"' : ""}>${esc(c)}</td>`).join("")}</tr>`).join("")}</tbody><tfoot><tr><td colspan="4">Total ${year}</td><td class="n">${esc(money2(sum, cur))}</td><td colspan="${head.length - 5}"></td></tr></tfoot></table>`;
    return `<!doctype html><html lang="fr"><head><meta charset="utf-8"><title>Livre des recettes ${year}</title>
<style>body{font:11px/1.35 system-ui,sans-serif;color:#111;margin:24px}h1{font-size:18px;margin:0 0 4px}h2{font-size:14px;margin:22px 0 6px}p{margin:2px 0;color:#555}
table{width:100%;border-collapse:collapse;margin-top:6px}th,td{border:1px solid #bbb;padding:3px 5px;text-align:left;vertical-align:top}th{background:#eee}.n{text-align:right;white-space:nowrap}tfoot td{font-weight:700;background:#f6f6f6}
@media print{body{margin:0}h2{break-before:page}h2.first{break-before:auto}}</style></head><body>
<h1>Livre des recettes ${year}${owner ? ` \u2014 ${esc(owner)}` : ""}</h1>
<p>Recettes encaiss\xE9es dans l\u2019ordre des dates : prix + livraison pay\xE9s par l\u2019acheteur, taxe am\xE9ricaine collect\xE9e par eBay exclue, remboursements d\xE9duits. Montants en ${esc(cur)} au taux eBay de chaque commande.</p>
<h2 class="first">Recettes (${receipts.length})</h2>
${table(["Date", "R\xE9f\xE9rence", "Client", "Nature", "Montant", "Mode de r\xE8glement", "Remarque"], receipts.map((r) => [day2(r.date), r.ref, r.client, r.nature, money2(r.amount, r.currency), r.payment, r.note]), total(receipts))}
<h2>Registre des achats ${year} (${buys.length})</h2>
<p>Achats de marchandises revendues, dans l\u2019ordre des dates.</p>
${table(["Date", "R\xE9f\xE9rence", "Fournisseur", "Nature", "Montant", "Vente eBay", "Remarque"], buys.map((r) => [day2(r.date), r.ref, r.supplier, r.nature, money2(r.amount, r.currency), r.sale, r.note]), total(buys))}
<p style="margin-top:16px">Document pr\xE9par\xE9 par AurOEBay \xE0 partir de tes ventes enregistr\xE9es. V\xE9rifie-le avec tes relev\xE9s eBay (\xAB Payments \xBB) et AliExpress avant de le transmettre.</p>
</body></html>`;
  }

  // src/ui/sales.ts
  var $ = (id) => document.getElementById(id);
  var DEMO = isDemo(location.search);
  var sales = [];
  var fallbackRate = null;
  var saleNumbers2 = (s) => saleNumbers(s, fallbackRate);
  var tab = "all";
  var disputeStore = { items: {}, at: 0 };
  var parcels = {};
  var disputes = /* @__PURE__ */ new Map();
  var productByItem = /* @__PURE__ */ new Map();
  var productBySupplier = /* @__PURE__ */ new Map();
  var reviewProducts = /* @__PURE__ */ new Map();
  var reviewModel = null;
  var reviews = /* @__PURE__ */ new Map();
  function computeReviews() {
    reviews.clear();
    if (!reviewModel) return;
    for (const s of sales) {
      const id = productOf(s);
      const r = reviewSale(s, saleNumbers2(s), id ? reviewProducts.get(id) ?? null : null, reviewModel);
      if (r) reviews.set(s.orderId, r);
    }
  }
  async function loadProductIndex() {
    const products = await message({ type: "LIBRARY", command: { action: "list" } }).catch(() => []);
    productByItem.clear();
    productBySupplier.clear();
    reviewProducts.clear();
    for (const p of products) {
      const main = p.suppliers?.find((x) => x.id === p.primarySupplierId) ?? p.suppliers?.[0];
      if (main?.source)
        reviewProducts.set(p.id, { costs: main.source.variantCosts ?? [], shipping: shippingCharge(main.source.shippingDetails) });
      for (const l of p.ownListings ?? []) {
        const item2 = l.url.match(/\/itm\/(?:[^/]+\/)?(\d{9,15})/)?.[1];
        if (item2) productByItem.set(item2, p.id);
      }
      for (const sup of p.suppliers ?? []) if (sup.id) productBySupplier.set(sup.id, p.id);
    }
  }
  function productOf(s) {
    for (const i of s.items) if (i.itemId && productByItem.has(i.itemId)) return productByItem.get(i.itemId);
    for (const i of s.items) if (i.supplierId && productBySupplier.has(i.supplierId)) return productBySupplier.get(i.supplierId);
    return null;
  }
  var query = "";
  var focus = new URLSearchParams(location.search).get("order");
  var money3 = (n, cur = "EUR") => n === null || n === void 0 ? "\u2014" : n.toLocaleString("fr-FR", { style: "currency", currency: cur });
  var date = (t) => t ? new Date(t).toLocaleDateString("fr-FR") : "\u2014";
  var el2 = (tag, cls = "", text = "") => {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text) e.textContent = text;
    return e;
  };
  var toastTimer;
  function toast(text, error = false) {
    const t = $("toast");
    t.textContent = text;
    t.className = "toast" + (error ? " error" : "");
    t.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => t.hidden = true, 3500);
  }
  function inPeriod(s, period) {
    if (period === "all" || !s.soldAt) return period === "all";
    const d = new Date(s.soldAt);
    const now = /* @__PURE__ */ new Date();
    if (period === "month") return d.getFullYear() === now.getFullYear() && d.getMonth() === now.getMonth();
    if (period === "last-month") {
      const m = new Date(now.getFullYear(), now.getMonth() - 1, 1);
      return d.getFullYear() === m.getFullYear() && d.getMonth() === m.getMonth();
    }
    if (period === "year") return d.getFullYear() === now.getFullYear();
    return Date.now() - s.soldAt <= Number(period) * 864e5;
  }
  var LATE_DAYS = 5;
  var DAY3 = 864e5;
  var untracked = (s) => s.status === "to_ship" ? purchases(s).filter((p) => !p.tracking && Date.now() - (p.linkedAt || s.soldAt || 0) > LATE_DAYS * DAY3) : [];
  var trackingToSend = trackingsToSend;
  var matches = (s, t) => t === "all" || t === "disputes" && (disputes.get(s.orderId)?.length ?? 0) > 0 || (t === "no_supplier" ? !s.supplier && !s.manualCost && s.status !== "cancelled" : t === "late" ? untracked(s).length > 0 : t === "to_track" ? trackingToSend(s).length > 0 : s.status === t);
  var RATES_KEY = "taxRates:v1";
  var rates = { urssaf: 12.3, impot: 1 };
  var chargesOf = (revenue) => Math.round(revenue * (rates.urssaf + rates.impot)) / 100;
  function totals(list2) {
    const counts = /* @__PURE__ */ new Map();
    for (const s of list2) {
      const c = saleNumbers2(s).currency;
      counts.set(c, (counts.get(c) ?? 0) + 1);
    }
    const currency = [...counts].sort((a, b) => b[1] - a[1])[0]?.[0] ?? "EUR";
    const t = { currency, orders: 0, revenue: 0, fees: 0, cost: 0, profit: 0, complete: 0, incomplete: 0, other: 0, losses: 0 };
    for (const s of list2) {
      const n = saleNumbers2(s);
      if (n.currency !== currency) {
        t.other++;
        continue;
      }
      if (s.status !== "cancelled") t.orders++;
      if (!n.complete) {
        t.incomplete++;
        continue;
      }
      t.complete++;
      t.revenue += n.revenue ?? 0;
      t.fees += n.fees;
      t.cost += n.cost ?? 0;
      t.profit += n.profit ?? 0;
      if ((n.profit ?? 0) < 0) t.losses++;
    }
    const charges = chargesOf(t.revenue);
    return { ...t, charges, net: Math.round((t.profit - charges) * 100) / 100 };
  }
  function renderPriorities() {
    const toShip = sales.filter((s) => s.status === "to_ship");
    const late = toShip.filter((s) => s.soldAt && Date.now() - s.soldAt > 3 * 864e5);
    const noSupplier = sales.filter((s) => matches(s, "no_supplier"));
    const box = $("priorities");
    box.replaceChildren();
    const add = (n, title, hint, go, hot = false) => {
      const b = el2("button", "priority" + (hot && n ? " hot" : ""));
      b.type = "button";
      b.append(el2("b", "", String(n)), Object.assign(el2("div"), { innerHTML: "" }));
      const text = b.lastElementChild;
      text.append(el2("strong", "", title), el2("div", "muted", hint));
      b.addEventListener("click", () => setTab(go));
      box.append(b);
    };
    add(noSupplier.length, "Sans achat AliExpress", "Ventes pas encore li\xE9es \xE0 une commande fournisseur.", "no_supplier", true);
    add(toShip.length, "\xC0 exp\xE9dier", late.length ? `${late.length} en attente depuis plus de 3 jours.` : "Aucune en retard.", "to_ship", late.length > 0);
    const noTracking = sales.filter((s) => untracked(s).length);
    add(noTracking.length, "Colis sans suivi", `Commande AliExpress sans num\xE9ro de suivi depuis plus de ${LATE_DAYS} jours : contacte le vendeur.`, "late", true);
    const send = sales.filter((s) => trackingToSend(s).length);
    add(send.length, "Suivi \xE0 mettre sur eBay", "Num\xE9ro AliExpress connu mais pas encore sur la commande eBay (se met \xE0 jour en ouvrant tes commandes eBay).", "to_track", true);
    const disputed = sales.filter((s) => disputes.get(s.orderId)?.some((d) => d.open));
    if (disputed.length || Object.keys(disputeStore.items).length)
      add(disputed.length, "Litiges en cours", "Retours, colis non re\xE7us et litiges eBay, avec leur c\xF4t\xE9 AliExpress.", "disputes", true);
  }
  function renderStats() {
    const period = $("period").value;
    const list2 = sales.filter((s) => inPeriod(s, period));
    const t = totals(list2);
    const k = $("kpis");
    k.replaceChildren();
    const card = (label, value, hint = "", cls = "", detail = false) => {
      const c = el2("div", detail ? "kpi detail" : "kpi");
      c.append(el2("span", "", label), el2("strong", cls, value));
      if (hint) c.append(el2("small", "", hint));
      k.append(c);
    };
    const margin = t.revenue ? t.profit / t.revenue * 100 : null;
    card("Commandes", String(t.orders));
    card("Chiffre d\u2019affaires", money3(t.revenue, t.currency), "hors taxe collect\xE9e par eBay");
    const netMargin = t.revenue ? t.net / t.revenue * 100 : null;
    card(
      "B\xE9n\xE9fice net",
      money3(t.net, t.currency),
      netMargin === null ? "apr\xE8s frais, fournisseur, URSSAF et imp\xF4t" : `marge ${netMargin.toFixed(1).replace(".", ",")} % \xB7 apr\xE8s frais, fournisseur, URSSAF et imp\xF4t`,
      t.net >= 0 ? "pos" : "neg"
    );
    card("Frais eBay", money3(t.fees, t.currency), "", "", true);
    card("Co\xFBt fournisseur", money3(t.cost, t.currency), "", "", true);
    card("B\xE9n\xE9fice avant charges", money3(t.profit, t.currency), `${t.losses ? `${t.losses} vente(s) \xE0 perte \xB7 ` : ""}marge ${margin === null ? "\u2013" : margin.toFixed(1).replace(".", ",")} %`, t.profit >= 0 ? "pos" : "neg", true);
    card(
      `URSSAF + imp\xF4t (${String(rates.urssaf + rates.impot).replace(".", ",")} %)`,
      money3(t.charges, t.currency),
      `${String(rates.urssaf).replace(".", ",")} % URSSAF + ${String(rates.impot).replace(".", ",")} % lib\xE9ratoire du CA`,
      "",
      true
    );
    let open = false;
    try {
      open = localStorage.getItem("salesKpiOpen") === "1";
    } catch {
    }
    k.classList.toggle("open", open);
    const more = el2("button", "kpi-more link-button", open ? "Masquer le d\xE9tail" : "Voir le d\xE9tail \u25BE");
    more.type = "button";
    more.addEventListener("click", () => {
      const now = !k.classList.contains("open");
      k.classList.toggle("open", now);
      more.textContent = now ? "Masquer le d\xE9tail" : "Voir le d\xE9tail \u25BE";
      try {
        localStorage.setItem("salesKpiOpen", now ? "1" : "");
      } catch {
      }
    });
    k.append(more);
    $("complete").textContent = t.incomplete ? `\u26A0 ${t.incomplete} vente(s) sans co\xFBt fournisseur ne sont pas compt\xE9es (jamais compt\xE9es \xE0 z\xE9ro).` : list2.length ? "\u2713 Toutes les ventes de la p\xE9riode ont un co\xFBt fournisseur." : "";
    if (t.other) $("complete").textContent += ` ${t.other} vente(s) dans une autre devise non incluses.`;
    renderProfits($("profits"), {
      months: monthlyNet(sales, saleNumbers2, chargesOf, t.currency),
      products: productProfits(list2, saleNumbers2, chargesOf, t.currency),
      currency: t.currency,
      periodLabel: $("period").selectedOptions[0]?.textContent ?? ""
    });
    const months = /* @__PURE__ */ new Map();
    for (const s of sales) {
      if (!s.soldAt) continue;
      const d = new Date(s.soldAt);
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
      months.set(key, [...months.get(key) ?? [], s]);
    }
    const table = $("months");
    table.innerHTML = '<tr><th>Mois</th><th class="n">Commandes</th><th class="n">Chiffre d\u2019affaires</th><th class="n">Frais</th><th class="n">Co\xFBt fournisseur</th><th class="n">B\xE9n\xE9fice</th><th class="n">URSSAF + imp\xF4t</th><th class="n">Apr\xE8s charges</th><th class="n">\xC0 compl\xE9ter</th></tr>';
    for (const [key, list3] of [...months].sort((a, b) => b[0].localeCompare(a[0]))) {
      const m = totals(list3);
      const tr = el2("tr");
      const label = (/* @__PURE__ */ new Date(key + "-01T12:00:00")).toLocaleDateString("fr-FR", { month: "long", year: "numeric" });
      for (const [v, cls] of [
        [label, ""],
        [String(m.orders), "n"],
        [money3(m.revenue, m.currency), "n"],
        [money3(m.fees, m.currency), "n"],
        [money3(m.cost, m.currency), "n"],
        [money3(m.profit, m.currency), "n " + (m.profit >= 0 ? "pos" : "neg")],
        [money3(m.charges, m.currency), "n"],
        [money3(m.net, m.currency), "n " + (m.net >= 0 ? "pos" : "neg")],
        [m.incomplete ? String(m.incomplete) : "", "n warn"]
      ])
        tr.append(el2("td", cls, v));
      table.append(tr);
    }
  }
  function renderList() {
    for (const t of ["all", "to_ship", "no_supplier", "late", "to_track", "disputes", "shipped", "cancelled"])
      $(`n-${t}`).textContent = String(sales.filter((s) => matches(s, t)).length);
    const q = query.toLowerCase();
    const list2 = sales.filter(
      (s) => matches(s, tab) && (!q || [s.orderId, s.buyer, s.country, ...purchases(s).map((p) => p.orderId), ...s.items.map((i) => i.title + " " + i.variation)].join(" ").toLowerCase().includes(q))
    );
    $("count").textContent = `${list2.length} vente(s)`;
    $("empty").hidden = list2.length > 0;
    const box = $("list");
    box.replaceChildren();
    for (const s of list2) {
      const n = saleNumbers2(s);
      const row = el2("div", "sale" + (s.orderId === focus ? " focus" : ""));
      row.id = "sale-" + s.orderId;
      row.append(el2("div", "date", date(s.soldAt)));
      const main = el2("div");
      const name = el2("div", "name");
      name.textContent = s.items.map((i) => (i.quantity > 1 ? `${i.quantity}\xD7 ` : "") + i.title).join(" + ");
      name.title = name.textContent;
      const links = el2("div", "links");
      const ebay = el2("a", "", "eBay #" + s.orderId);
      ebay.href = `https://www.ebay.com/mesh/ord/details?mode=SH&orderid=${s.orderId}`;
      ebay.target = "_blank";
      links.append(ebay);
      if (s.supplier) {
        for (const p of purchases(s)) {
          const ali = el2("a", "", "AliExpress #" + p.orderId);
          ali.href = `https://www.aliexpress.us/p/order/detail.html?orderId=${p.orderId}`;
          ali.target = "_blank";
          links.append(ali);
          if (p.share)
            links.append(
              el2(
                "span",
                "",
                `\u{1F517} partag\xE9e avec #${p.share.sales.filter((id) => id !== s.orderId).join(", #")} \xB7 ta part ${money3(p.cost.amount, p.cost.currency)} sur ${money3(p.share.total.amount, p.share.total.currency)}`
              )
            );
          if (p.tracking) {
            const onEbay = !!s.tracking && s.tracking.includes(p.tracking) || trackingCovered(s);
            links.append(el2("span", onEbay ? "" : "warn", `\u{1F4E6} ${p.tracking}${onEbay ? " \xB7 sur eBay" : " \xB7 pas encore sur eBay"}`));
          }
        }
        if (s.supplier.how === "auto") links.append(el2("span", "", "li\xE9e auto (nom + code postal)"));
        for (const p of untracked(s))
          links.append(
            el2("span", "warn", `\u23F3 #${p.orderId.slice(-6)} sans suivi depuis ${Math.floor((Date.now() - (p.linkedAt || s.soldAt || 0)) / DAY3)} j`)
          );
        if (trackingToSend(s).length) {
          const go = el2("a", "", "\u{1F4E6} Mettre le suivi sur eBay");
          go.href = `https://www.ebay.com/mesh/ord/details?mode=SH&orderid=${s.orderId}#auroebay-track`;
          go.target = "_blank";
          links.append(go);
        }
      } else if (s.status !== "cancelled") links.append(el2("span", "warn", s.manualCost ? "Co\xFBt saisi \xE0 la main" : "AliExpress non li\xE9"));
      const variation = s.items.map((i) => i.variation).filter(Boolean).join(" \xB7 ");
      if (variation) links.append(el2("span", "", variation));
      links.append(el2("span", "", [s.buyer.split(" ")[0], s.country].filter(Boolean).join(" \xB7 ")));
      main.append(name, links);
      const block = saleDisputesBlock(s, disputes.get(s.orderId) ?? [], parcels);
      if (block) main.append(block);
      row.append(main);
      const num2 = (label, value, cls = "num") => {
        const d = el2("div", cls);
        d.append(el2("span", "", label), el2("b", "", value));
        return d;
      };
      const approx = n.estimatedRate ? "\u2248 " : "";
      const paid = num2(
        "Pay\xE9 par l\u2019acheteur",
        money3(s.orderTotal?.amount, s.orderTotal?.currency ?? "USD")
      );
      if (s.orderTotal && s.orderTotal.currency !== n.currency && n.revenue !== null)
        paid.append(el2("small", "muted", `${approx}${money3(n.revenue, n.currency)} hors taxe`));
      if (n.buyerRefund) paid.append(el2("small", "neg", `rembours\xE9 au client \u2212${money3(n.buyerRefund, n.currency)}`));
      const costCell = num2("Co\xFBt", n.cost === null ? "\u2014" : approx + money3(n.cost, n.currency));
      if (n.supplierRefund) costCell.append(el2("small", "pos", `rembours\xE9 par AliExpress \u2212${money3(n.supplierRefund, n.currency)}`));
      row.append(paid, num2("Frais eBay", approx + money3(n.fees, n.currency)), costCell);
      if (n.estimatedRate)
        row.title = `Pas de taux eBay sur cette commande : conversion estim\xE9e avec le dernier taux eBay (1 $ = ${fallbackRate} ${n.currency}).`;
      const profit = num2("B\xE9n\xE9fice", money3(n.profit, n.currency), "num profit");
      profit.querySelector("b").className = n.profit === null ? "warn" : n.profit >= 0 ? "pos" : "neg";
      if (n.profit !== null && s.status !== "cancelled") {
        const net = Math.round((n.profit - chargesOf(n.revenue ?? 0)) * 100) / 100;
        const line = el2("small", net < 0 ? "neg" : "muted", `net apr\xE8s charges ${approx}${money3(net, n.currency)}`);
        line.title = `B\xE9n\xE9fice \u2212 URSSAF et imp\xF4t (${String(rates.urssaf + rates.impot).replace(".", ",")} % du chiffre d\u2019affaires hors taxe)`;
        profit.append(line);
        const r = reviews.get(s.orderId);
        if (r) {
          const sign = r.diff >= 0 ? "+" : "\u2212";
          const plan = el2("small", r.diff < -0.5 ? "neg" : "muted", `pr\xE9vu ${money3(r.planned, n.currency)} \xB7 \xE9cart ${sign}${money3(Math.abs(r.diff), n.currency)}`);
          plan.title = "B\xE9n\xE9fice que AurOEBay avait pr\xE9vu (prix eBay, co\xFBt AliExpress de la variante, port, frais, URSSAF), compar\xE9 au r\xE9el. Le port pay\xE9 par le client compte dans le r\xE9el.";
          profit.append(plan);
        }
      }
      row.append(profit);
      const actions = el2("div", "actions");
      const pillClass = { to_ship: "todo", shipped: "live", cancelled: "archived" }[s.status];
      actions.append(el2("span", "pill " + pillClass, { to_ship: "\xC0 exp\xE9dier", shipped: "Exp\xE9di\xE9e", cancelled: "Annul\xE9e" }[s.status]));
      const costs = el2("button", "btn small", "Co\xFBts");
      costs.type = "button";
      costs.title = "R\xE9capitulatif eBay + AliExpress, modifiable";
      costs.addEventListener("click", () => editCosts(s));
      const edit = el2("button", "btn small", "Modifier");
      edit.type = "button";
      edit.addEventListener("click", () => editSale(s));
      const remove = el2("button", "link-button sale-remove", "Supprimer");
      remove.type = "button";
      remove.addEventListener("click", () => void removeSale(s));
      const productId = productOf(s);
      const sheet = el2("button", "btn small", "\u{1F4D2} Fiche");
      sheet.type = "button";
      sheet.disabled = !productId;
      sheet.title = productId ? "Ouvrir la fiche AurOEBay de ce produit (prix, fournisseurs, stock)" : "Aucune fiche AurOEBay reli\xE9e \xE0 cette annonce : relie-la dans Mes produits (\xAB Relier mon annonce eBay \xBB).";
      sheet.addEventListener("click", () => {
        if (productId)
          void chrome.tabs.create({ url: chrome.runtime.getURL(`dashboard.html?product=${encodeURIComponent(productId)}`) });
      });
      const delivered = purchases(s).find((p) => parcels[p.orderId]?.delivered);
      if (delivered && s.status !== "cancelled" && !(disputes.get(s.orderId) ?? []).some((d) => d.source === "aliexpress")) {
        const missing = el2("button", "btn small", "\u{1F4ED} Pas re\xE7u ?");
        missing.type = "button";
        missing.title = "Le suivi indique livr\xE9, mais le client dit ne pas avoir re\xE7u le colis";
        missing.addEventListener("click", () => deliveredMissingDialog(s, delivered.orderId));
        actions.append(missing);
      }
      actions.append(sheet, costs, edit, remove);
      row.append(actions);
      box.append(row);
    }
    if (focus) document.getElementById("sale-" + focus)?.scrollIntoView({ block: "center" });
  }
  function deliveredMissingDialog(s, aliOrderId) {
    const p = purchases(s).find((x) => x.orderId === aliOrderId);
    const info = parcels[aliOrderId];
    if (!p || !info) return;
    const n = saleNumbers2(s);
    const earnings = n.earnings !== null ? money3(n.earnings, n.currency) : null;
    const facts = deliveredMissingFacts(s, p, info, earnings);
    const reply = buyerMessage("delivered-missing", {
      buyer: s.buyer,
      item: s.items[0]?.title ?? "",
      tracking: p.tracking ?? null,
      deliveredOn: info.lastEventAt ? new Date(info.lastEventAt).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }) : null
    });
    const box = $("missing");
    $("missing-title").textContent = `Livr\xE9 mais pas re\xE7u \xB7 vente eBay #${s.orderId}`;
    $("missing-body").innerHTML = `
    <table class="mini">${facts.map((f) => `<tr><th>${escapeHTML(f.label)}</th><td>${escapeHTML(f.value)}</td></tr>`).join("")}</table>
    <h3>1. R\xE9ponds au client</h3>
    <textarea id="missing-reply" rows="9" style="width:100%;box-sizing:border-box"></textarea>
    <p><button class="btn small" id="missing-copy" type="button">\u{1F4CB} Copier le message</button>
    <a class="btn small" target="_blank" rel="noopener" href="https://www.ebay.com/mesh/ord/details?mode=SH&orderid=${encodeURIComponent(s.orderId)}">Ouvrir la commande eBay \u2197</a></p>
    <h3>2. S\u2019il ne retrouve pas le colis</h3>
    <p><a class="btn primary small" target="_blank" rel="noopener" href="${escapeHTML(disputeStartUrl(deliveredMissingDraft(s, p, info), info))}">\u{1F6E1}\uFE0F Pr\xE9parer le litige AliExpress \u2197</a></p>
    <p class="muted">Les choix et le message en anglais s\u2019affichent sur la page AliExpress. Tu remplis, tu joins la preuve et tu valides toi-m\xEAme.</p>
    <h3>3. Ensuite</h3>
    <ul class="muted">
      <li>Synchronise les litiges pour suivre la date limite du vendeur.</li>
      <li>Le client retrouve le colis : annule le litige.</li>
      <li>Le vendeur envoie une preuve : transmets-la au client.</li>
      <li>Rien ne se d\xE9bloque : envisage de rembourser le client.</li>
    </ul>`;
    const text = $("missing-reply");
    text.value = reply;
    const copy = $("missing-copy");
    copy.addEventListener("click", () => {
      void navigator.clipboard.writeText(text.value).then(
        () => copy.textContent = "\u2713 Copi\xE9",
        () => text.select()
      );
    });
    box.showModal();
  }
  function editSale(s) {
    const dialog = $("dialog");
    $("dialog-title").textContent = `Vente eBay #${s.orderId}`;
    const n = saleNumbers2(s);
    $("dialog-body").innerHTML = `
    <p class="muted">${escapeHTML(s.items.map((i) => i.title).join(" + "))}</p>
    <p class="muted">Gains eBay : <b>${money3(s.earnings?.amount, n.currency)}</b>${s.rate ? ` \xB7 taux eBay 1 $ = ${s.rate} ${escapeHTML(n.currency)}` : ""}</p>
    ${purchases(s).length ? `<p class="muted">Commandes AliExpress li\xE9es (d\xE9coche pour d\xE9lier) :</p>${purchases(s).map((p) => `<label class="inline"><input type="checkbox" class="f-purchase" value="${escapeHTML(p.orderId)}" checked> #${escapeHTML(p.orderId)} \xB7 ${money3(p.cost.amount, p.cost.currency)}${p.share ? ` (part de ${money3(p.share.total.amount, p.share.total.currency)}, partag\xE9e avec #${escapeHTML(p.share.sales.filter((id) => id !== s.orderId).join(", #"))})` : ""}${p.tracking ? " \xB7 \u{1F4E6} " + escapeHTML(p.tracking) : ""}</label>`).join("")}<p class="muted">Pour ajouter une commande scind\xE9e : ouvre-la sur AliExpress \u2192 \xAB Commande scind\xE9e par AliExpress \xBB.</p>` : ""}
    <p class="muted">Les montants se modifient avec le bouton \xAB Co\xFBts \xBB.</p>
    <div class="grid2">
      <label>Statut<select id="f-status"><option value="to_ship">\xC0 exp\xE9dier</option><option value="shipped">Exp\xE9di\xE9e</option><option value="cancelled">Annul\xE9e</option></select></label>
    </div>
    <label>Num\xE9ro de suivi<input id="f-tracking" value=""></label>
    <label>Notes<textarea id="f-notes" rows="3"></textarea></label>`;
    $("f-status").value = s.status;
    $("f-tracking").value = s.tracking;
    $("f-notes").value = s.notes;
    dialog.returnValue = "";
    dialog.onclose = async () => {
      try {
        if (dialog.returnValue === "delete") {
          if (!confirm("Retirer cette vente de AurOEBay ? (rien n\u2019est modifi\xE9 sur eBay)")) return;
          await message({ type: "SALE_DELETE", orderId: s.orderId });
        } else if (dialog.returnValue === "ok") {
          await message({
            type: "SALE_UPDATE",
            orderId: s.orderId,
            patch: {
              status: $("f-status").value,
              tracking: $("f-tracking").value.trim(),
              notes: $("f-notes").value,
              unlinkPurchases: [...document.querySelectorAll(".f-purchase")].filter((b) => !b.checked).map((b) => b.value)
            }
          });
        } else return;
        await load();
        toast("Vente mise \xE0 jour.");
      } catch (e) {
        toast(e instanceof Error ? e.message : String(e), true);
      }
    };
    dialog.showModal();
  }
  async function removeSale(s) {
    const what = s.items.map((i) => i.title).join(" + ").slice(0, 80);
    if (!confirm(`Supprimer la vente #${s.orderId} (${what}) de AurOEBay ?
Rien n\u2019est modifi\xE9 sur eBay ni sur AliExpress.`))
      return;
    try {
      await message({ type: "SALE_DELETE", orderId: s.orderId });
      await load();
      toast("Vente supprim\xE9e de AurOEBay.");
    } catch (e) {
      toast(e instanceof Error ? e.message : String(e), true);
    }
  }
  function editCosts(s) {
    const dialog = $("costs");
    const read2 = saleNumbers({ ...s, adjust: void 0 }, fallbackRate);
    const n = saleNumbers2(s);
    const cur = n.currency;
    const linkedOrders = purchases(s);
    const sameCurrency = new Set(linkedOrders.map((p) => p.cost.currency)).size === 1;
    const linkedTotal = linkedOrders.length && sameCurrency ? {
      amount: Math.round(linkedOrders.reduce((t, p) => t + p.cost.amount, 0) * 100) / 100,
      currency: linkedOrders[0].cost.currency
    } : null;
    const supplierMoney = s.adjust?.supplierCost ?? linkedTotal ?? s.manualCost;
    const value = (v) => v === null || v === void 0 ? "" : String(v);
    const rateNote = s.rate ? "lu sur la commande eBay" : fallbackRate ? `aucun taux sur cette commande : estim\xE9 avec ta derni\xE8re vente (1 $ = ${fallbackRate})` : "aucun taux connu : saisis-le pour convertir les $";
    $("costs-title").textContent = `Co\xFBts \xB7 vente eBay #${s.orderId}`;
    $("costs-body").innerHTML = `
    <p class="muted">${escapeHTML(s.items.map((i) => (i.quantity > 1 ? i.quantity + "\xD7 " : "") + i.title).join(" + "))}</p>
    <h3>eBay</h3>
    <table class="mini costs">
      <tr><td>Pay\xE9 par l\u2019acheteur</td><td class="n">${money3(s.orderTotal?.amount, s.orderTotal?.currency ?? "USD")}</td></tr>
      ${s.tax ? `<tr><td>Taxe collect\xE9e et revers\xE9e par eBay</td><td class="n">\u2212 ${money3(Math.abs(s.tax.amount), s.tax.currency)}</td></tr>` : ""}
      <tr><td><label for="c-revenue">Chiffre d\u2019affaires hors taxe (${escapeHTML(cur)})</label></td><td class="n"><input id="c-revenue" type="number" step="0.01" min="0" value="${value(n.revenue)}"></td></tr>
      ${s.fees.map((f) => `<tr class="sub"><td>${escapeHTML(f.label)}</td><td class="n">${money3(f.amount.amount, f.amount.currency)}</td></tr>`).join("")}
      <tr><td><label for="c-fees">Total frais eBay (${escapeHTML(cur)})</label></td><td class="n"><input id="c-fees" type="number" step="0.01" min="0" value="${value(n.fees)}"></td></tr>
      <tr><td><label for="c-earnings">Gains eBay vers\xE9s (${escapeHTML(cur)})</label></td><td class="n"><input id="c-earnings" type="number" step="0.01" value="${value(n.earnings)}"></td></tr>
      <tr><td><label for="c-rate">Taux eBay : 1 $ =</label><div class="muted small">${escapeHTML(rateNote)}</div></td><td class="n"><input id="c-rate" type="number" step="0.00001" min="0.01" value="${value(s.adjust?.rate ?? s.rate ?? fallbackRate)}"> ${escapeHTML(cur)}</td></tr>
    </table>
    <h3>AliExpress</h3>
    <table class="mini costs">
      ${linkedOrders.length ? linkedOrders.map(
      (p) => `<tr class="${linkedOrders.length > 1 ? "sub" : ""}"><td>Commande #${escapeHTML(p.orderId)}${p.how === "auto" ? " (li\xE9e auto)" : ""}</td><td class="n">${money3(p.cost.amount, p.cost.currency)}</td></tr>`
    ).join("") : `<tr><td>Commande AliExpress</td><td class="n">non li\xE9e</td></tr>`}
      <tr><td><label for="c-cost">Co\xFBt fournisseur${linkedOrders.length > 1 ? " (total)" : ""}</label></td><td class="n"><input id="c-cost" type="number" step="0.01" min="0" value="${value(supplierMoney?.amount)}"> <select id="c-cur"><option ${supplierMoney?.currency !== "EUR" ? "selected" : ""}>USD</option><option ${supplierMoney?.currency === "EUR" ? "selected" : ""}>EUR</option></select></td></tr>
      <tr><td><label for="c-other">Autres co\xFBts (${escapeHTML(cur)})</label></td><td class="n"><input id="c-other" type="number" step="0.01" min="0" value="${value(s.otherCost || null)}"></td></tr>
    </table>
    <div class="costs-result" id="c-result"></div>
    ${s.adjust ? '<p class="muted">Des montants ont \xE9t\xE9 modifi\xE9s \xE0 la main. \xAB R\xE9tablir \xBB reprend ceux lus sur eBay et AliExpress.</p>' : ""}`;
    const input = (id) => $(id).value.trim();
    const numberOf = (id) => input(id) === "" ? void 0 : Number(input(id));
    const draft = () => {
      const adjust = {};
      const differs = (a, b) => a !== void 0 && Number.isFinite(a) && (b === null || Math.abs(a - b) >= 5e-3);
      const rate = numberOf("c-rate");
      if (rate !== void 0 && rate > 0 && rate !== s.rate && (s.rate || rate !== fallbackRate)) adjust.rate = rate;
      const revenue = numberOf("c-revenue");
      if (differs(revenue, read2.revenue)) adjust.revenue = revenue;
      const fees = numberOf("c-fees");
      if (differs(fees, read2.fees)) adjust.fees = fees;
      const earnings = numberOf("c-earnings");
      const expectedEarnings = adjust.revenue !== void 0 || adjust.fees !== void 0 ? (adjust.revenue ?? read2.revenue ?? 0) - (adjust.fees ?? read2.fees) : read2.earnings;
      if (differs(earnings, expectedEarnings)) adjust.earnings = earnings;
      const cost = numberOf("c-cost");
      const currency = $("c-cur").value;
      let manualCost = s.manualCost;
      if (s.supplier) {
        if (cost !== void 0 && (!linkedTotal || Math.abs(cost - linkedTotal.amount) >= 5e-3 || currency !== linkedTotal.currency))
          adjust.supplierCost = { amount: cost, currency };
      } else manualCost = cost === void 0 ? null : { amount: cost, currency };
      return { adjust, manualCost, otherCost: numberOf("c-other") ?? 0 };
    };
    const preview = () => {
      const d = draft();
      const p = saleNumbers(
        { ...s, adjust: Object.keys(d.adjust).length ? d.adjust : void 0, manualCost: d.manualCost, otherCost: d.otherCost },
        fallbackRate
      );
      const margin = p.profit !== null && p.revenue ? ` \xB7 marge ${(p.profit / p.revenue * 100).toFixed(1).replace(".", ",")} %` : "";
      $("c-result").innerHTML = p.profit === null ? `<b class="warn">B\xE9n\xE9fice : \u2014</b> <span class="muted">${p.supplier === null && (d.manualCost || s.supplier) ? "renseigne le taux eBay pour convertir le co\xFBt" : "renseigne le co\xFBt fournisseur"}</span>` : `Gains eBay ${money3(p.earnings, cur)} \u2212 co\xFBt ${money3(p.cost, cur)} = <b class="${p.profit >= 0 ? "pos" : "neg"}">B\xE9n\xE9fice ${money3(p.profit, cur)}</b>${margin}`;
    };
    $("costs-body").oninput = preview;
    preview();
    dialog.returnValue = "";
    dialog.onclose = async () => {
      try {
        if (dialog.returnValue === "reset") {
          await message({ type: "SALE_UPDATE", orderId: s.orderId, patch: { adjust: null } });
        } else if (dialog.returnValue === "ok") {
          const d = draft();
          await message({
            type: "SALE_UPDATE",
            orderId: s.orderId,
            patch: {
              adjust: Object.keys(d.adjust).length ? d.adjust : null,
              ...s.supplier ? {} : { manualCost: d.manualCost },
              otherCost: d.otherCost
            }
          });
        } else return;
        await load();
        toast("Co\xFBts enregistr\xE9s.");
      } catch (e) {
        toast(e instanceof Error ? e.message : String(e), true);
      }
    };
    dialog.showModal();
  }
  function setTab(next) {
    tab = next;
    document.querySelectorAll("#tabs button").forEach((b) => b.classList.toggle("active", b.dataset.tab === tab));
    renderList();
  }
  async function load() {
    const saved = (await chrome.storage.local.get(RATES_KEY))[RATES_KEY];
    if (saved && Number.isFinite(saved.urssaf) && Number.isFinite(saved.impot)) rates = saved;
    $("rate-urssaf").value = String(rates.urssaf);
    $("rate-impot").value = String(rates.impot);
    sales = DEMO ? demoSales() : await message({ type: "SALES_LIST" });
    fallbackRate = latestRate(sales);
    disputeStore = DEMO ? { items: Object.fromEntries(demoDisputes().map((d) => [d.key, d])), at: Date.now() } : await loadDisputes();
    disputes = disputesByOrder(disputeStore);
    parcels = DEMO ? {} : (await chrome.storage.local.get(PARCELS_KEY))[PARCELS_KEY]?.items ?? {};
    renderDisputeActions();
    await loadProductIndex();
    await loadUrssaf();
    void showProfitSettings();
    renderPriorities();
    renderStats();
    renderList();
    renderUrssaf();
    const last = (await chrome.storage.session.get("aliTrackingRun:v1").catch(() => ({})))["aliTrackingRun:v1"];
    renderTrackingActions(last && Date.now() - last.at < 10 * 6e4 ? last : void 0);
  }
  setupTheme();
  setupAutoBackup($("backup-bar"));
  document.querySelectorAll("#tabs button").forEach((b) => b.addEventListener("click", () => setTab(b.dataset.tab)));
  $("search").addEventListener("input", (e) => {
    query = e.target.value;
    renderList();
  });
  $("period").addEventListener("change", renderStats);
  for (const id of ["rate-urssaf", "rate-impot"])
    $(id).addEventListener("change", () => {
      const value = (x) => Math.min(50, Math.max(0, Number($(x).value.replace(",", ".")) || 0));
      rates = { urssaf: value("rate-urssaf"), impot: value("rate-impot") };
      void chrome.storage.local.set({ [RATES_KEY]: rates });
      renderStats();
      renderUrssaf();
    });
  var waitingTracking = () => sales.filter((s) => s.status !== "cancelled" && purchases(s).some((p) => !p.tracking)).length;
  function renderTrackingActions(run) {
    const fetchBtn = $("fetch-trackings");
    const sendBtn = $("send-trackings");
    const status = $("tracking-status");
    const toSend = sales.filter((s) => trackingToSend(s).length).map((s) => s.orderId);
    sendBtn.disabled = !toSend.length;
    sendBtn.textContent = `\u{1F4E6} Mettre les suivis sur eBay${toSend.length ? ` (${toSend.length})` : ""}`;
    sendBtn.dataset.ids = JSON.stringify(toSend.slice(0, 30));
    const busy = run?.state === "running";
    fetchBtn.disabled = busy;
    fetchBtn.innerHTML = busy ? `<span class="ao-spinner"></span> Lecture AliExpress\u2026 ${run.checked}/${run.total}` : `\u{1F504} R\xE9cup\xE9rer les suivis AliExpress${waitingTracking() ? ` (${waitingTracking()} en attente)` : ""}`;
    status.textContent = !run ? "Lit les num\xE9ros de toutes tes commandes AliExpress li\xE9es, dans un onglet en arri\xE8re-plan." : run.state === "error" ? `\u26A0 ${run.error}` : run.state === "done" ? `\u2713 ${run.total ? `${run.total} commande(s) AliExpress relue(s), ${run.found} nouveau(x) num\xE9ro(s).` : "Aucune commande AliExpress en attente de suivi."} ${toSend.length ? `${toSend.length} commande(s) eBay pr\xEAte(s).` : ""}` : "";
    status.className = run?.state === "error" ? "warn" : "muted";
  }
  $("fetch-trackings").addEventListener("click", () => {
    renderTrackingActions({ state: "running", at: Date.now(), checked: 0, total: waitingTracking(), found: 0, toSend: [] });
    void message({ type: "ALI_TRACKINGS_REFRESH" }).then(async (run) => {
      sales = await message({ type: "SALES_LIST" });
      renderPriorities();
      renderList();
      renderTrackingActions(run);
    }).catch((e) => renderTrackingActions({ state: "error", at: Date.now(), checked: 0, total: 0, found: 0, toSend: [], error: e instanceof Error ? e.message : String(e) }));
  });
  $("send-trackings").addEventListener("click", () => {
    const ids = JSON.parse($("send-trackings").dataset.ids ?? "[]");
    if (ids.length) void message({ type: "OPEN_EBAY_TRACKING", orderIds: ids }).catch((e) => toast(String(e), true));
  });
  chrome.storage.onChanged.addListener((changes, area) => {
    const run = changes["aliTrackingRun:v1"]?.newValue;
    if (area === "session" && run?.state === "running") renderTrackingActions(run);
  });
  var syncingDisputes = false;
  function renderDisputeActions() {
    const btn = $("sync-disputes");
    btn.disabled = syncingDisputes;
    btn.innerHTML = syncingDisputes ? `<span class="ao-spinner"></span> Lecture eBay et AliExpress\u2026` : "\u2696\uFE0F Synchroniser les litiges";
    const { text, outside } = disputeStatus(disputeStore, new Set(sales.map((s) => s.orderId)));
    const status = $("dispute-status");
    status.textContent = syncingDisputes ? "Les onglets s\u2019ouvrent en arri\xE8re-plan et se referment seuls (1 \xE0 2 minutes)." : text;
    status.className = disputeStore.errors?.length && !syncingDisputes ? "warn" : "muted";
    const box = $("dispute-outside");
    box.replaceChildren();
    box.hidden = !outside.length;
    if (outside.length) {
      box.append(Object.assign(document.createElement("span"), { textContent: `\u2696\uFE0F ${outside.length} litige(s) eBay en cours sur des commandes pas encore dans tes ventes (ouvre la commande eBay pour l\u2019ajouter) : ` }));
      for (const d of outside.slice(0, 8)) {
        const a = Object.assign(document.createElement("a"), {
          href: d.orderId ? `https://www.ebay.com/mesh/ord/details?mode=SH&orderid=${d.orderId}` : d.url,
          target: "_blank",
          rel: "noopener",
          textContent: `#${d.orderId ?? d.id} \xB7 ${d.status}`
        });
        box.append(a, " ");
      }
    }
  }
  $("sync-disputes").addEventListener("click", () => {
    syncingDisputes = true;
    renderDisputeActions();
    void message({ type: "DISPUTES_SYNC" }).then((store) => {
      disputeStore = store;
      disputes = disputesByOrder(store);
      const open = Object.values(store.items).filter((d) => d.open).length;
      toast(store.errors?.length ? `Synchro partielle : ${store.errors.join(" ")}` : `Litiges \xE0 jour : ${open} en cours.`, !!store.errors?.length);
    }).catch((e) => toast(e instanceof Error ? e.message : String(e), true)).finally(() => {
      syncingDisputes = false;
      renderDisputeActions();
      renderPriorities();
      renderList();
    });
  });
  var urssaf = { frequency: "month", declared: {} };
  async function loadUrssaf() {
    const saved = (await chrome.storage.local.get(URSSAF_KEY))[URSSAF_KEY];
    urssaf = {
      frequency: saved?.frequency === "quarter" ? "quarter" : "month",
      declared: saved?.declared && typeof saved.declared === "object" ? saved.declared : {}
    };
  }
  function renderUrssaf() {
    const currency = totals(sales).currency;
    const periods = declarationPeriods(sales, saleNumbers2, urssaf.frequency, currency);
    const save = () => void chrome.storage.local.set({ [URSSAF_KEY]: urssaf });
    renderDeclarations($("urssaf"), {
      periods,
      store: urssaf,
      currency,
      charges: chargesOf,
      onFrequency: (f) => {
        urssaf.frequency = f;
        save();
        renderUrssaf();
      },
      onDeclared: (key, declared) => {
        if (declared) urssaf.declared[key] = Date.now();
        else delete urssaf.declared[key];
        save();
        renderUrssaf();
      },
      onExport: (p) => {
        const blob = new Blob([declarationCSV(sales, saleNumbers2, p, urssaf.frequency)], { type: "text/csv;charset=utf-8" });
        const a = Object.assign(document.createElement("a"), {
          href: URL.createObjectURL(blob),
          download: `auroebay-urssaf-${p.key}.csv`
        });
        a.click();
        setTimeout(() => URL.revokeObjectURL(a.href), 2e3);
      }
    });
    $("urssaf").append(ledgerBox());
  }
  var ledgerYear = null;
  function ledgerBox() {
    const box = document.createElement("div");
    box.className = "ledger";
    const years = ledgerYears(sales);
    if (!years.length) return box;
    if (ledgerYear === null || !years.includes(ledgerYear)) ledgerYear = years[0];
    box.innerHTML = `<h3>\u{1F4D7} Livre des recettes et registre des achats</h3>
    <p class="muted">Les deux registres obligatoires d\u2019une micro-entreprise qui vend des marchandises, pr\xEAts pour ton comptable : chaque vente (date, commande, client, montant, mode de r\xE8glement) et chaque achat AliExpress.</p>
    <div class="ledger-actions">
      <label>Ann\xE9e <select id="ledger-year">${years.map((y) => `<option value="${y}" ${y === ledgerYear ? "selected" : ""}>${y}</option>`).join("")}</select></label>
      <button class="btn small" type="button" data-ledger="receipts">Recettes (CSV)</button>
      <button class="btn small" type="button" data-ledger="purchases">Achats (CSV)</button>
      <button class="btn small primary" type="button" data-ledger="print">Imprimer / PDF</button>
    </div>`;
    box.querySelector("#ledger-year").addEventListener("change", (e) => ledgerYear = Number(e.target.value));
    const save = (text, name) => {
      const a = Object.assign(document.createElement("a"), { href: URL.createObjectURL(new Blob([text], { type: "text/csv;charset=utf-8" })), download: name });
      a.click();
      setTimeout(() => URL.revokeObjectURL(a.href), 2e3);
    };
    box.querySelectorAll("[data-ledger]").forEach(
      (b) => b.addEventListener("click", () => {
        const year = ledgerYear;
        const receipts = receiptRows(sales, saleNumbers2, year);
        const buys = purchaseRows(sales, fallbackRate, year);
        if (b.dataset.ledger === "receipts") return save(receiptsCSV(receipts), `auroebay-livre-recettes-${year}.csv`);
        if (b.dataset.ledger === "purchases") return save(purchasesCSV(buys), `auroebay-registre-achats-${year}.csv`);
        const url = URL.createObjectURL(new Blob([ledgerPrintHTML(year, receipts, buys)], { type: "text/html;charset=utf-8" }));
        const w = window.open(url, "_blank");
        if (!w) return toast("Fen\xEAtre bloqu\xE9e : autorise les fen\xEAtres pour AurOEBay, puis r\xE9essaie.", true);
        w.addEventListener("load", () => w.print());
        setTimeout(() => URL.revokeObjectURL(url), 6e4);
      })
    );
    return box;
  }
  async function showProfitSettings() {
    const saved = {
      ...DEFAULT_PROFIT_SETTINGS,
      ...(await chrome.storage.local.get(PROFIT_SETTINGS_KEY))[PROFIT_SETTINGS_KEY] ?? {}
    };
    $("ali-extra").value = String(saved.aliExtra);
    $("fee-rate").value = saved.feeRate === null ? "" : String(saved.feeRate);
    $("ad-rate").value = String(saved.adRate ?? 5);
    $("fee-auto").hidden = saved.feeRate === null;
    const model = await message({ type: "PROFIT_MODEL" }).catch(() => null);
    reviewModel = model;
    computeReviews();
    renderList();
    const sum = reviewSummary([...reviews.values()]);
    $("ali-learnt").textContent = sum.count ? `Pr\xE9vu ou r\xE9el, sur ${sum.count} vente(s) : \xE9cart moyen ${sum.diff >= 0 ? "+" : "\u2212"}${money3(Math.abs(sum.diff), model.currency)} par vente${sum.tax !== null ? ` \xB7 taxe AliExpress r\xE9elle ${String(sum.tax).replace(".", ",")} % (${sum.taxSamples} commandes)` : ""}.` : "";
    const use = $("ali-use");
    use.hidden = sum.tax === null || Math.abs(sum.tax - saved.aliExtra) < 0.5;
    if (sum.tax !== null) {
      use.textContent = `Utiliser ${String(sum.tax).replace(".", ",")} %`;
      use.onclick = () => {
        $("ali-extra").value = String(sum.tax);
        saveProfitSettings();
      };
    }
    const pct = (f) => `${(f * 100).toFixed(1).replace(".", ",").replace(",0", "")} %`;
    $("fee-learnt").textContent = !model ? "" : saved.feeRate !== null ? "(valeur tap\xE9e \xE0 la main : clique \xAB Calcul automatique \xBB pour revenir aux tarifs eBay)" : model.feeSamples ? `(automatique : ${pct(model.feeRate)} + 0,40 $ par vente, vus sur tes ${model.feeSamples} ventes, pub comprise)` : `(automatique : tarifs eBay 13,6 % + 1,65 % vendeur hors USA + ta pub = ${pct(model.feeRate)} + 0,40 $ par vente ; d\xE8s 3 ventes, AurOEBay prend tes vrais frais)`;
  }
  var saveProfitSettings = (fee) => {
    const read2 = (x) => $(x).value.replace(",", ".").trim();
    const extra = Math.min(100, Math.max(0, Number(read2("ali-extra")) || 0));
    const typed = read2("fee-rate") === "" ? null : Math.min(60, Math.max(0, Number(read2("fee-rate")) || 0));
    const ad = Math.min(30, Math.max(0, Number(read2("ad-rate")) || 0));
    void chrome.storage.local.set({ [PROFIT_SETTINGS_KEY]: { aliExtra: extra, feeRate: fee === null ? null : typed, adRate: ad } }).then(showProfitSettings);
  };
  for (const id of ["ali-extra", "fee-rate", "ad-rate"]) $(id).addEventListener("change", () => saveProfitSettings());
  $("fee-auto").addEventListener("click", () => saveProfitSettings(null));
  $("export").addEventListener("click", () => {
    const blob = new Blob([salesCSV(sales, rates)], { type: "text/csv;charset=utf-8" });
    const a = Object.assign(document.createElement("a"), {
      href: URL.createObjectURL(blob),
      download: `auroebay-ventes-${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.csv`
    });
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 2e3);
  });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (!DEMO && area === "local" && changes["sales:v1"]) void load();
  });
  if (DEMO) setupDemo();
  void load().catch((e) => toast(e instanceof Error ? e.message : String(e), true));
  if (!DEMO) void message({ type: "EBAY_TRACKINGS_SYNC" }).catch(() => {
  });
  function setupDemo() {
    const bar = Object.assign(document.createElement("div"), { className: "demo-bar" });
    bar.innerHTML = `<b>\u{1F440} Mode d\xE9mo</b> <span>Ventes d\u2019exemple : rien n\u2019est enregistr\xE9, lu ni envoy\xE9.</span> <a class="btn small" href="routine.html?demo=1">Ma journ\xE9e (d\xE9mo)</a> <a class="btn small primary" href="sales.html">Quitter la d\xE9mo</a>`;
    document.querySelector("main").prepend(bar);
    const free = "#tabs button, #search, #period, #export, #theme-toggle, summary, [data-ledger], #ledger-year, [data-export], .demo-bar a, .topbar a";
    const blocked = (t) => {
      const el3 = t?.closest?.("a, button, input, select, textarea");
      return !!el3 && !el3.matches(free) && !!el3.closest("main, dialog");
    };
    document.addEventListener(
      "click",
      (e) => {
        if (!blocked(e.target)) return;
        const el3 = e.target.closest("a, button, input, select, textarea");
        if (el3.matches("input, select, textarea")) return;
        e.preventDefault();
        e.stopPropagation();
        toast("D\xE9mo : exemple seulement, rien n\u2019est modifi\xE9.");
      },
      true
    );
    document.addEventListener(
      "change",
      (e) => {
        if (!blocked(e.target)) return;
        e.stopImmediatePropagation();
        toast("D\xE9mo : r\xE9glage non enregistr\xE9.");
      },
      true
    );
  }
})();
