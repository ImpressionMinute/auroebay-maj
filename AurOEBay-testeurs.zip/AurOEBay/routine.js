"use strict";
(() => {
  // src/core/text.ts
  var compact = (s) => s.replace(/\s+/g, " ").trim();
  var norm = (s) => compact(s.normalize("NFKC")).toLowerCase().replace(/[\s\W_]+/g, " ").trim();
  var escapeHTML = (s) => s.replace(
    /[&<>"']/g,
    (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]
  );
  function redact(s) {
    return s.replace(/\bsk-[A-Za-z0-9_-]+/g, "[REDACTED_KEY]").replace(/Bearer\s+\S+/gi, "Bearer [REDACTED]").replace(/[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}/g, "[EMAIL]").replace(/https?:\/\/[^\s<>"']+/g, "[URL]");
  }

  // src/core/messaging.ts
  var STALE_PAGE = "AurOEBay a \xE9t\xE9 mis \xE0 jour pendant que cette page \xE9tait ouverte : recharge-la (Cmd + R), puis recommence.";
  async function message(body2) {
    let reply;
    try {
      reply = await chrome.runtime.sendMessage(body2);
    } catch (e) {
      const text = e instanceof Error ? e.message : String(e);
      throw Error(/context invalidated|Receiving end does not exist|message port closed/i.test(text) ? STALE_PAGE : text);
    }
    if (!reply?.ok)
      throw Error(reply?.error ?? "AurOEBay ne r\xE9pond pas. Recharge la page.");
    return reply.data;
  }

  // src/core/shippingText.ts
  var PRICE = String.raw`(?:US\s*)?\$\s*(\d+(?:\.\d{1,2})?)`;
  var NAMED = new RegExp(String.raw`(?:standard|shipping|delivery|livraison)[^$·\d]{0,20}?${PRICE}`, "gi");
  var LABEL = new RegExp(String.raw`\b[A-Za-z][A-Za-z' -]{1,30}:\s*${PRICE}`, "g");

  // src/core/country.ts
  var codes = "AD AE AF AG AI AL AM AO AQ AR AS AT AU AW AX AZ BA BB BD BE BF BG BH BI BJ BL BM BN BO BQ BR BS BT BV BW BY BZ CA CC CD CF CG CH CI CK CL CM CN CO CR CU CV CW CX CY CZ DE DJ DK DM DO DZ EC EE EG EH ER ES ET FI FJ FK FM FO FR GA GB GD GE GF GG GH GI GL GM GN GP GQ GR GS GT GU GW GY HK HM HN HR HT HU ID IE IL IM IN IO IQ IR IS IT JE JM JO JP KE KG KH KI KM KN KP KR KW KY KZ LA LB LC LI LK LR LS LT LU LV LY MA MC MD ME MF MG MH MK ML MM MN MO MP MQ MR MS MT MU MV MW MX MY MZ NA NC NE NF NG NI NL NO NP NR NU NZ OM PA PE PF PG PH PK PL PM PN PR PS PT PW PY QA RE RO RS RU RW SA SB SC SD SE SG SH SI SJ SK SL SM SN SO SR SS ST SV SX SY SZ TC TD TF TG TH TJ TK TL TM TN TO TR TT TV TW TZ UA UG UM US UY UZ VA VC VE VG VI VN VU WF WS YE YT ZA ZM ZW".split(
    " "
  );
  var names = new Intl.DisplayNames(["en"], { type: "region" });
  var map = /* @__PURE__ */ new Map();
  for (const code of codes) {
    const name = names.of(code);
    map.set(norm(code), name);
    map.set(norm(name), name);
  }
  for (const [alias, name] of Object.entries({
    "mainland china": "China",
    "cn origin": "China",
    "china mainland": "China",
    "china origin": "China",
    prc: "China",
    "people s republic of china": "China",
    usa: "United States",
    "u s a": "United States",
    "united states of america": "United States",
    uk: "United Kingdom",
    "great britain": "United Kingdom",
    "south korea": "South Korea",
    "republic of korea": "South Korea",
    taiwan: "Taiwan",
    vietnam: "Vietnam",
    turkey: "T\xFCrkiye"
  }))
    map.set(norm(alias), name);

  // src/ebay/savedDraft.ts
  var SCAN_LIMIT = 3 * 1024 * 1024;

  // src/ebay/draftApi.ts
  var HTML_LIMIT = 8 * 1024 * 1024;

  // src/core/sales.ts
  var round = (n) => Math.round(n * 100) / 100;
  function purchases(sale) {
    return [...sale.supplier ? [sale.supplier] : [], ...sale.extraSuppliers ?? []];
  }
  function trackingCovered(sale) {
    const onEbay = new Set((sale.tracking ?? "").split(/\s*,\s*/).filter(Boolean));
    if (!onEbay.size) return false;
    if (sale.items.length > 1 && sale.trackedItems !== void 0 && sale.trackedItems >= sale.items.length) return true;
    return onEbay.size >= purchases(sale).filter((p) => p.tracking).length && (sale.items.length <= 1 || sale.trackedItems === void 0 || sale.trackedItems >= sale.items.length);
  }
  function trackingsToSend(sale) {
    if (sale.status === "cancelled" || trackingCovered(sale)) return [];
    return purchases(sale).filter((p) => p.tracking && !(sale.tracking ?? "").includes(p.tracking));
  }
  function saleRate(sale, fallback = null) {
    return sale.adjust?.rate ?? sale.rate ?? fallback;
  }
  function latestRate(sales) {
    return [...sales].filter((s) => s.rate).sort((a, b) => (b.soldAt ?? 0) - (a.soldAt ?? 0))[0]?.rate ?? null;
  }
  function toPayout(sale, money2, fallbackRate = null) {
    if (!money2) return null;
    const payout = sale.earnings?.currency ?? "USD";
    const rate = saleRate(sale, fallbackRate);
    if (money2.currency === payout) return money2.amount;
    if (money2.currency === "USD" && rate) return round(money2.amount * rate);
    if (payout === "USD" && rate && money2.currency === "EUR")
      return round(money2.amount / rate);
    return null;
  }
  function saleNumbers(sale, fallbackRate = null) {
    const currency = sale.earnings?.currency ?? "USD";
    const a = sale.adjust ?? {};
    let usedEstimate = false;
    const convert = (m) => {
      if (!m) return null;
      const direct = toPayout(sale, m);
      if (direct !== null) return direct;
      const estimated = toPayout(sale, m, fallbackRate);
      if (estimated !== null) usedEstimate = true;
      return estimated;
    };
    const total = sale.orderTotal ? convert(sale.orderTotal) : sale.subtotal ? (() => {
      const sub = convert(sale.subtotal);
      const ship = sale.shipping ? convert(sale.shipping) : 0;
      return sub === null || ship === null ? null : round(sub + ship);
    })() : null;
    const taxed = sale.orderTotal && sale.tax ? convert({ ...sale.tax, amount: Math.abs(sale.tax.amount) }) : 0;
    let gross = a.revenue ?? (total === null || taxed === null ? null : round(total - taxed));
    if (sale.refund && a.revenue === void 0 && gross !== null && gross < 0) gross = 0;
    const fees = a.fees ?? round(sale.fees.reduce((sum, f) => sum + (convert(f.amount) ?? 0), 0) * -1);
    const earnings = a.earnings ?? (a.revenue !== void 0 || a.fees !== void 0 ? gross === null ? null : round(gross - fees) : sale.earnings?.amount ?? (gross !== null ? round(gross - fees) : null));
    const linked = purchases(sale);
    let supplier;
    if (a.supplierCost) supplier = convert(a.supplierCost);
    else if (linked.length) {
      const parts = linked.map((p) => convert(p.cost));
      supplier = parts.some((x) => x === null) ? null : round(parts.reduce((t, x) => t + x, 0));
    } else supplier = sale.manualCost ? convert(sale.manualCost) : null;
    let supplierRefund = 0;
    if (!a.supplierCost && supplier !== null && sale.supplierRefunds?.length) {
      for (const r of sale.supplierRefunds) supplierRefund += convert(r.amount) ?? 0;
      supplierRefund = round(Math.min(supplierRefund, supplier));
      supplier = round(supplier - supplierRefund);
    }
    const cost = supplier === null ? null : round(supplier + (sale.otherCost || 0));
    const cancelled = sale.status === "cancelled";
    const profit = cancelled ? 0 : earnings === null || cost === null ? null : round(earnings - cost);
    return {
      currency,
      revenue: cancelled ? 0 : gross,
      fees: cancelled ? 0 : fees,
      earnings: cancelled ? 0 : earnings,
      supplier: cancelled ? 0 : supplier,
      cost: cancelled ? 0 : cost,
      profit,
      complete: cancelled || profit !== null,
      estimatedRate: usedEstimate,
      rate: saleRate(sale, usedEstimate ? fallbackRate : null),
      buyerRefund: sale.refund ? convert(sale.refund) : null,
      supplierRefund
    };
  }

  // src/core/disputes.ts
  var DISPUTES_KEY = "disputes:v1";
  var deliveredMissing = (d) => d.source === "aliexpress" && d.open && /delivered but not received/i.test(d.reason ?? "");
  var RETURN_AUTO = /buyer started a return|approved automatically/i;
  var returnToHold = (d) => d.source === "ebay" && d.kind === "return" && d.open && !d.held && !d.photos && RETURN_AUTO.test(`${d.status} ${d.detail ?? ""}`);
  var returnMessageUrl = (orderId2) => `https://www.ebay.com/mesh/ord/details?mode=SH&orderid=${encodeURIComponent(orderId2)}#auroebay-return-hold`;

  // src/core/sellerHealth.ts
  var PERFORMANCE_URL = "https://www.ebay.com/sh/performance";
  var DAY = 864e5;
  var WINDOW_DAYS = 90;
  var HANDLING_DAYS = 3;
  var pct = (n) => `${(Math.round(n * 1e3) / 10).toLocaleString("fr-FR")} %`;
  var NOT_AS_DESCRIBED = /not as described|wrong|different|damag|broken|defect|doesn.?t work|missing|fake|counterfeit/i;
  function sellerHealth(sales, disputes, now = Date.now()) {
    const recent = sales.filter((s) => s.soldAt && now - s.soldAt < WINDOW_DAYS * DAY);
    const ids = new Set(recent.map((s) => s.orderId));
    const live2 = recent.filter((s) => s.status !== "cancelled");
    const ofRecent = disputes.filter((d) => d.source === "ebay" && d.orderId && ids.has(d.orderId));
    const orders = (list2) => new Set(list2.map((d) => d.orderId)).size;
    const metrics = [];
    const late = live2.filter((s) => s.status === "to_ship" && !s.tracking && now - s.soldAt > HANDLING_DAYS * DAY);
    metrics.push({
      key: "late",
      label: "Ventes pas encore exp\xE9di\xE9es apr\xE8s 3 jours",
      value: String(late.length),
      limit: "0",
      tone: late.length ? "hot" : "ok",
      hint: late.length ? "Mets le suivi sur eBay d\xE8s que possible : chaque envoi en retard compte contre toi." : "Aucune vente en retard d\u2019envoi."
    });
    const due = live2.filter((s) => now - s.soldAt > (HANDLING_DAYS + 1) * DAY);
    const tracked = due.filter((s) => s.tracking).length;
    const rate = due.length ? tracked / due.length : null;
    metrics.push({
      key: "tracking",
      label: "Suivi mis sur eBay",
      value: rate === null ? "\u2014" : `${pct(rate)} (${tracked}/${due.length})`,
      limit: "95 % minimum",
      tone: rate === null || rate >= 0.95 ? "ok" : rate < 0.9 ? "hot" : "todo",
      hint: "eBay veut un num\xE9ro de suivi sur au moins 95 % des ventes (\xAB Suivis \xE0 mettre sur eBay \xBB)."
    });
    const cases = orders(ofRecent.filter((d) => d.kind === "case"));
    metrics.push({
      key: "cases",
      label: "Litiges o\xF9 eBay est intervenu (cases)",
      value: live2.length ? `${cases} (${pct(cases / live2.length)})` : String(cases),
      limit: "0,3 % maximum (compt\xE9 \xE0 partir de 2)",
      tone: cases >= 2 ? "hot" : cases ? "todo" : "ok",
      hint: "R\xE8gle chaque retour ou demande avant que le client demande \xE0 eBay d\u2019intervenir."
    });
    const inr = orders(ofRecent.filter((d) => d.kind === "inr"));
    const inrRate = live2.length ? inr / live2.length : 0;
    metrics.push({
      key: "inr",
      label: "Demandes \xAB colis non re\xE7u \xBB",
      value: live2.length ? `${inr} (${pct(inrRate)})` : String(inr),
      limit: "le moins possible",
      tone: inr >= 2 && inrRate > 0.02 ? "todo" : "ok",
      hint: "Beaucoup de \xAB non re\xE7u \xBB : choisis des livraisons plus rapides et surveille tes colis (\xAB \u{1F6E1}\uFE0F Colis \xE0 surveiller \xBB)."
    });
    const snad = orders(ofRecent.filter((d) => d.kind === "return" && NOT_AS_DESCRIBED.test(d.reason ?? "")));
    const snadRate = live2.length ? snad / live2.length : 0;
    metrics.push({
      key: "snad",
      label: "Retours \xAB article non conforme \xBB",
      value: live2.length ? `${snad} (${pct(snadRate)})` : String(snad),
      limit: "le moins possible",
      tone: snad >= 2 && snadRate > 0.02 ? "todo" : "ok",
      hint: "V\xE9rifie la description et les photos de ces produits, ou change de fournisseur."
    });
    const cancelled = recent.length - live2.length;
    const cancelRate = recent.length ? cancelled / recent.length : 0;
    metrics.push({
      key: "cancel",
      label: "Ventes annul\xE9es",
      value: recent.length ? `${cancelled} (${pct(cancelRate)})` : "0",
      limit: "2 % maximum si c\u2019est toi qui annules",
      tone: cancelled >= 2 && cancelRate > 0.02 ? "todo" : "ok",
      hint: "Annuler faute de stock compte comme un d\xE9faut : surveille les ruptures (\xAB V\xE9rifier maintenant \xBB dans Mes produits)."
    });
    const tone = metrics.some((m) => m.tone === "hot") ? "hot" : metrics.some((m) => m.tone === "todo") ? "todo" : "ok";
    return { count: recent.length, tone, metrics, few: recent.length < 10 };
  }

  // src/core/eventSearches.ts
  var EVENT_SEARCHES = {
    superbowl: [
      "football party decorations",
      "game day snack tray",
      "football party supplies",
      "foam finger",
      "football cupcake toppers",
      "stadium snack holder",
      "referee costume",
      "football string lights",
      "football balloons",
      "football table cover",
      "football banner",
      "football napkins",
      "football party plates",
      "chip and dip bowl",
      "football serving bowl",
      "can cooler sleeve",
      "party cups set",
      "face paint sticks",
      "eye black stickers",
      "football centerpiece",
      "touchdown banner",
      "mini foam football",
      "football keychain",
      "sports fan scarf",
      "tv tray table",
      "beer pong set",
      "cornhole bean bags",
      "party noise makers",
      "cheering horn",
      "stadium seat cushion",
      "stadium blanket",
      "clear stadium bag",
      "football pinata",
      "football cookie cutter",
      "football ice mold",
      "chicken wing rack",
      "disposable chafing dish set",
      "party ice bucket",
      "drink dispenser",
      "led cups",
      "game day shirt",
      "referee whistle",
      "football field rug",
      "football throw pillow",
      "beer glass set"
    ],
    valentine: [
      "valentines day gifts",
      "heart necklace",
      "rose bear",
      "couple gifts",
      "preserved rose",
      "led heart light",
      "couple keychain",
      "love lamp",
      "heart pillow",
      "valentines decorations",
      "galaxy rose",
      "couple bracelets",
      "heart balloons",
      "artificial rose petals",
      "heart garland",
      "heart string lights",
      "love letter jar",
      "scratch off date cards",
      "couples card game",
      "matching couple rings",
      "magnetic couple bracelets",
      "heart pendant",
      "name necklace",
      "projection necklace",
      "love bear plush",
      "rose gift box",
      "soap flowers",
      "rose in glass dome",
      "heart cake topper",
      "valentine table runner",
      "valentine banner",
      "heart confetti",
      "couple mugs",
      "heart jewelry box",
      "heart earrings",
      "heart sunglasses",
      "valentine gnome",
      "valentine wreath",
      "neon heart sign",
      "candle gift set",
      "heart bath bombs",
      "valentine socks",
      "couple pajamas",
      "kids valentine cards",
      "valentine treat bags",
      "valentine stickers",
      "heart silicone mold",
      "heart shaped box"
    ],
    stpatrick: [
      "st patricks day decorations",
      "shamrock earrings",
      "leprechaun hat",
      "shamrock garland",
      "green party supplies",
      "shamrock headband",
      "irish party decorations",
      "shamrock sunglasses",
      "green beads necklace",
      "leprechaun costume",
      "green bow tie",
      "shamrock socks",
      "irish flag",
      "shamrock string lights",
      "plastic gold coins",
      "pot of gold decor",
      "rainbow decorations",
      "green tablecloth",
      "shamrock confetti",
      "leprechaun trap kit",
      "st patricks day shirt",
      "green tutu",
      "shamrock hair clip",
      "green feather boa",
      "shamrock wreath",
      "irish door hanger",
      "clover necklace",
      "four leaf clover keychain",
      "shamrock garden flag",
      "green balloons",
      "shamrock banner",
      "green top hat",
      "shamrock tattoos",
      "green wig",
      "shamrock napkins",
      "green party cups",
      "st patricks gnome",
      "lucky charm bracelet",
      "shamrock cookie cutter",
      "green suspenders"
    ],
    easter: [
      "easter decorations",
      "easter basket stuffers",
      "fillable easter eggs",
      "bunny ears headband",
      "easter wreath",
      "egg decorating kit",
      "easter garden flag",
      "bunny plush",
      "easter tablecloth",
      "easter egg hunt kit",
      "easter basket",
      "easter grass",
      "light up easter eggs",
      "easter bunny decor",
      "carrot decor",
      "easter gnome",
      "easter garland",
      "easter banner",
      "easter table runner",
      "easter centerpiece",
      "easter egg tree",
      "egg dye kit",
      "chocolate egg mold",
      "bunny cookie cutter",
      "easter cupcake toppers",
      "easter treat bags",
      "bunny costume",
      "easter dress girls",
      "easter bow tie",
      "egg cup set",
      "easter napkins",
      "easter door hanger",
      "easter string lights",
      "wind up toys",
      "squishy toys",
      "bubble wands",
      "chick plush",
      "easter stickers",
      "easter coloring book",
      "lamb plush",
      "spring wreath",
      "artificial tulips",
      "bunny tail plush",
      "egg shaped containers",
      "easter pillow covers"
    ],
    spring: [
      "solar garden lights",
      "garden kneeler",
      "plant support stakes",
      "seed starter tray",
      "hose nozzle",
      "bird feeder",
      "garden tool set",
      "plant labels",
      "self watering spikes",
      "hanging planter",
      "expandable garden hose",
      "garden gloves",
      "pruning shears",
      "plant grow light",
      "raised garden bed",
      "grow bags",
      "seed storage box",
      "plant mister",
      "soil moisture meter",
      "trellis for climbing plants",
      "garden netting",
      "macrame plant hanger",
      "window bird feeder",
      "hummingbird feeder",
      "bird bath",
      "wind chimes",
      "garden statue",
      "solar fountain pump",
      "solar path lights",
      "garden stepping stones",
      "kitchen compost bin",
      "watering can",
      "lawn sprinkler",
      "hose reel",
      "weeding tool",
      "garden apron",
      "kids gardening set",
      "herb garden kit",
      "mini greenhouse",
      "plant clips",
      "garden border edging",
      "outdoor rug",
      "patio cushion covers",
      "microfiber cleaning cloths",
      "window cleaning tool"
    ],
    mother: [
      "mothers day gifts",
      "jewelry box",
      "flower lamp",
      "mom necklace",
      "spa gift set",
      "preserved flower",
      "mom tumbler",
      "jewelry organizer",
      "bath bombs gift set",
      "eternal rose",
      "mom bracelet",
      "birthstone necklace",
      "family tree necklace",
      "engraved bracelet",
      "mom keychain",
      "mom mug",
      "mom blanket",
      "heated eye mask",
      "neck massager",
      "foot massager",
      "silk pillowcase",
      "satin pajamas set",
      "womens robe",
      "makeup bag",
      "travel jewelry case",
      "ring holder dish",
      "photo frame",
      "digital photo frame",
      "memory book for mom",
      "recipe binder",
      "tote bag women",
      "silk scarf",
      "hair claw clip set",
      "scented candle set",
      "essential oil diffuser",
      "aromatherapy gift set",
      "crystal flower",
      "music box",
      "artificial succulents",
      "artificial flower bouquet",
      "hand cream gift set",
      "makeup brush set",
      "led makeup mirror",
      "wine tumbler"
    ],
    graduation: [
      "graduation decorations",
      "graduation party supplies",
      "graduation cap topper",
      "graduation photo props",
      "graduation gifts",
      "graduation balloons",
      "graduation banner",
      "graduation centerpiece",
      "graduation tablecloth",
      "graduation cupcake toppers",
      "graduation sash",
      "graduation stole",
      "graduation lei",
      "money lei",
      "graduation cap decoration kit",
      "autograph book",
      "graduation photo frame",
      "graduation backdrop",
      "graduation confetti",
      "graduation napkins",
      "graduation plates",
      "graduation yard sign",
      "graduation card box",
      "graduation teddy bear",
      "graduation keychain",
      "graduation bracelet",
      "inspirational necklace",
      "compass necklace",
      "travel organizer",
      "toiletry bag",
      "laptop backpack",
      "dorm essentials",
      "portable charger",
      "money holder card",
      "graduation gift box",
      "graduation party favors",
      "graduation pins",
      "honor cords",
      "diploma frame",
      "graduation mug",
      "balloon arch kit",
      "kindergarten graduation gifts"
    ],
    father: [
      "fathers day gifts",
      "bbq grill tools",
      "multitool",
      "beard grooming kit",
      "whiskey stones",
      "car organizer",
      "mens wallet",
      "grill accessories",
      "tool gifts for men",
      "dad mug",
      "grill thermometer",
      "grill brush",
      "grill mat",
      "meat claws",
      "smoker box",
      "bbq apron",
      "whiskey glass set",
      "whiskey decanter",
      "bottle opener",
      "beer caddy",
      "flask",
      "mens bracelet",
      "mens necklace",
      "cufflinks",
      "tie clip",
      "watch box",
      "valet tray",
      "keychain for men",
      "minimalist wallet",
      "money clip",
      "card holder",
      "mens belt",
      "nose hair trimmer",
      "beard straightener",
      "shaving kit",
      "socks gift box",
      "golf accessories",
      "golf ball marker",
      "fishing tackle box",
      "fishing gifts",
      "tactical flashlight",
      "headlamp",
      "tool belt",
      "magnetic wristband",
      "socket set",
      "car vacuum",
      "mini massage gun"
    ],
    summer: [
      "pool floats",
      "beach tent",
      "cooling towel",
      "portable neck fan",
      "snorkel mask",
      "waterproof phone pouch",
      "camping lantern",
      "water gun",
      "beach bag",
      "inflatable pool",
      "sun shade",
      "pool toys",
      "beach umbrella anchor",
      "sand free beach mat",
      "beach towel clips",
      "beach cart",
      "cooler bag",
      "insulated tumbler",
      "swim goggles",
      "swim cap",
      "pool noodles",
      "dive toys",
      "splash pad",
      "sprinkler for kids",
      "water balloons",
      "bubble machine",
      "outdoor games",
      "frisbee",
      "paddle ball set",
      "sand toys",
      "kite",
      "sun hat",
      "uv umbrella",
      "handheld fan",
      "misting fan",
      "popsicle molds",
      "portable blender",
      "outdoor string lights",
      "citronella candle",
      "bug zapper",
      "mosquito net",
      "hammock",
      "camping chair",
      "camping fan",
      "tent lights",
      "solar shower",
      "beach chair"
    ],
    july4: [
      "american flag decor",
      "patriotic decorations",
      "usa flag string lights",
      "red white blue garland",
      "patriotic tablecloth",
      "american flag bandana",
      "patriotic party supplies",
      "usa flag garden flag",
      "patriotic wreath",
      "patriotic banner",
      "star garland",
      "bunting flags",
      "american flag pinwheels",
      "patriotic balloons",
      "patriotic table runner",
      "patriotic napkins",
      "patriotic plates",
      "star sunglasses",
      "usa headband",
      "patriotic hat",
      "american flag shirt",
      "american flag socks",
      "patriotic earrings",
      "usa flag necklace",
      "light up necklace",
      "glow sticks",
      "led foam sticks",
      "confetti poppers",
      "patriotic gnome",
      "patriotic door hanger",
      "uncle sam hat",
      "patriotic porch sign",
      "solar flag pole light",
      "flag pole kit",
      "american flag 3x5",
      "mini american flags",
      "patriotic tumbler",
      "picnic blanket",
      "patriotic dog bandana",
      "patriotic tutu",
      "star cookie cutter",
      "patriotic cupcake toppers"
    ],
    school: [
      "school supplies",
      "pencil case",
      "desk organizer",
      "kids backpack",
      "lunch box kids",
      "kids water bottle",
      "led desk lamp",
      "book stand",
      "pencil pouch",
      "dorm room essentials",
      "bento box",
      "insulated lunch bag",
      "backpack keychain",
      "name labels kids",
      "highlighters set",
      "gel pens",
      "colored pencils",
      "mechanical pencils",
      "cute erasers",
      "sticky notes",
      "index cards",
      "binder clips",
      "file folders",
      "student planner",
      "electric pencil sharpener",
      "ruler set",
      "geometry set",
      "art supplies kit",
      "watercolor set",
      "scissors kids",
      "kids headphones",
      "laptop sleeve",
      "kids tablet case",
      "dorm storage bins",
      "bed risers",
      "clip on fan",
      "shower caddy dorm",
      "laundry hamper",
      "desk chair cushion",
      "mini whiteboard",
      "cork board",
      "wall calendar",
      "alarm clock",
      "book light",
      "bookmarks",
      "locker organizer",
      "clear backpack"
    ],
    halloween: [
      "halloween decorations",
      "led pumpkin",
      "skeleton decor",
      "spider web decoration",
      "halloween string lights",
      "witch hat",
      "halloween door cover",
      "animated halloween prop",
      "glow in the dark skeleton",
      "halloween costume kids",
      "halloween window clings",
      "fog machine",
      "giant spider",
      "hanging ghost",
      "halloween wreath",
      "halloween garland",
      "halloween tablecloth",
      "candy bowl",
      "trick or treat bag",
      "pumpkin carving kit",
      "halloween masks",
      "witch broom",
      "skull decor",
      "tombstone yard decor",
      "halloween yard stakes",
      "caution tape halloween",
      "creepy cloth",
      "halloween projector",
      "flickering led candles",
      "black cat decor",
      "bat wall decor",
      "halloween pillow covers",
      "halloween doormat",
      "costume makeup kit",
      "fake blood",
      "vampire teeth",
      "witch costume",
      "skeleton costume",
      "inflatable costume",
      "dog halloween costume",
      "halloween headband",
      "halloween party favors",
      "halloween treat bags",
      "halloween gnome",
      "halloween village",
      "scary sound box",
      "motion sensor halloween"
    ],
    thanksgiving: [
      "thanksgiving decorations",
      "fall wreath",
      "turkey decor",
      "harvest table runner",
      "fall garland",
      "pumpkin decor",
      "thanksgiving tablecloth",
      "fall centerpiece",
      "artificial pumpkins",
      "artificial fall leaves",
      "maple leaf garland",
      "fall string lights",
      "fall doormat",
      "fall pillow covers",
      "scarecrow decor",
      "fall gnome",
      "thankful sign",
      "place card holders",
      "napkin rings",
      "cloth napkins",
      "turkey baster",
      "meat thermometer",
      "roasting rack",
      "carving knife set",
      "gravy boat",
      "pie dish",
      "pie crust shield",
      "leaf cookie cutter",
      "serving platter",
      "casserole carrier",
      "food warmer",
      "butter dish",
      "salt and pepper shakers",
      "candle holders",
      "taper candles",
      "fall candles",
      "harvest basket",
      "thanksgiving banner",
      "kids thanksgiving crafts",
      "turkey hat",
      "thanksgiving shirt",
      "round fall tablecloth"
    ],
    blackfriday: [
      "gifts for him",
      "gifts for her",
      "kitchen gadgets",
      "tech gifts",
      "gadget gifts",
      "phone accessories gift",
      "car gadgets",
      "unique gifts",
      "gifts for mom",
      "gifts for dad",
      "gifts for teens",
      "gifts for kids",
      "white elephant gifts",
      "secret santa gifts",
      "gifts under 20",
      "stocking stuffers for men",
      "stocking stuffers for women",
      "mini projector",
      "smart watch band",
      "earbuds case",
      "bluetooth speaker",
      "power bank",
      "wireless charger",
      "phone tripod",
      "ring light",
      "led strip lights",
      "sunset lamp",
      "galaxy projector",
      "massage gun",
      "neck massager",
      "heated blanket",
      "electric lighter",
      "digital photo frame",
      "smart plug",
      "label maker",
      "air fryer accessories",
      "coffee gifts",
      "cocktail kit",
      "wine accessories",
      "bath gift set",
      "makeup organizer",
      "jewelry organizer",
      "travel gadgets",
      "cable organizer",
      "desk gadgets",
      "fidget toys",
      "gaming accessories",
      "controller holder",
      "headphone stand"
    ],
    christmas: [
      "christmas ornaments",
      "christmas lights",
      "advent calendar",
      "stocking stuffers",
      "christmas tree topper",
      "christmas village",
      "star projector",
      "snow globe",
      "christmas tablecloth",
      "family christmas pajamas",
      "christmas window decorations",
      "gift wrap organizer",
      "christmas stockings",
      "personalized ornaments",
      "christmas tree skirt",
      "christmas tree collar",
      "christmas garland",
      "christmas wreath",
      "prelit garland",
      "christmas pillow covers",
      "christmas doormat",
      "christmas table runner",
      "christmas centerpiece",
      "christmas gnome",
      "christmas nutcracker",
      "santa hat",
      "elf costume",
      "ugly christmas sweater",
      "christmas socks",
      "christmas earrings",
      "christmas headband",
      "christmas napkins",
      "christmas cookie cutters",
      "gingerbread house kit",
      "christmas mug",
      "hot cocoa bomb mold",
      "christmas candle",
      "led window lights",
      "icicle lights",
      "curtain lights",
      "christmas projector light",
      "outdoor christmas decorations",
      "inflatable santa",
      "light up reindeer",
      "christmas tree stand",
      "ornament storage box",
      "wreath storage bag",
      "christmas gift bags",
      "gift tags",
      "ribbon bows",
      "christmas cards",
      "santa letter kit",
      "christmas countdown calendar",
      "christmas train set",
      "christmas music box",
      "dog christmas sweater"
    ],
    winter: [
      "rechargeable hand warmer",
      "heated gloves",
      "ice scraper",
      "thermal socks",
      "windshield snow cover",
      "door draft stopper",
      "heated insoles",
      "fleece blanket",
      "touchscreen gloves",
      "snow brush",
      "heated vest",
      "heated scarf",
      "electric blanket",
      "heated throw",
      "thermal underwear",
      "led beanie",
      "balaclava",
      "ear warmers",
      "fleece neck gaiter",
      "ice cleats",
      "shoe spikes",
      "window insulation kit",
      "heated mug",
      "sherpa blanket",
      "wearable blanket",
      "slipper socks",
      "fuzzy socks",
      "house slippers",
      "humidifier",
      "heated seat cover",
      "heated steering wheel cover",
      "snow shovel",
      "snow sled",
      "snowball maker",
      "boot tray",
      "boot dryer",
      "weather stripping",
      "thermal curtains",
      "hot water bottle",
      "microwave heating pad",
      "winter hat",
      "faux fur headband",
      "cold weather face mask",
      "lip balm holder",
      "car snow brush"
    ]
  };

  // src/core/seasons.ts
  var DAY2 = 864e5;
  var CNY = {
    2026: "2026-02-17",
    2027: "2027-02-06",
    2028: "2028-01-26",
    2029: "2029-02-13",
    2030: "2030-02-03",
    2031: "2031-01-23",
    2032: "2032-02-11",
    2033: "2033-01-31",
    2034: "2034-02-19",
    2035: "2035-02-08"
  };
  var CNY_BEFORE = 7;
  var CNY_AFTER = 15;
  var LEAD = 28;
  var SHOW = 60;
  var HORIZON = 120;
  var local = (y, m, d) => new Date(y, m, d).getTime();
  function nthWeekday(y, m, weekday, n) {
    const first = new Date(y, m, 1).getDay();
    return local(y, m, 1 + (weekday - first + 7) % 7 + (n - 1) * 7);
  }
  function easter(y) {
    const a = y % 19, b = Math.floor(y / 100), c = y % 100, d = Math.floor(b / 4), e = b % 4, f = Math.floor((b + 8) / 25), g = Math.floor((b - f + 1) / 3), h = (19 * a + b - d - g + 15) % 30, i = Math.floor(c / 4), k = c % 4, l = (32 + 2 * e + 2 * i - h - k) % 7, m = Math.floor((a + 11 * h + 22 * l) / 451), n = h + l - 7 * m + 114;
    return local(y, Math.floor(n / 31) - 1, n % 31 + 1);
  }
  var day = (t) => new Date(t).toLocaleDateString("fr-FR", { day: "numeric", month: "long" });
  var inDays = (t, now) => Math.max(0, Math.round((t - now) / DAY2));
  var sold = (q) => ({
    label: q,
    href: `https://www.ebay.com/sch/i.html?_nkw=${encodeURIComponent(q)}&LH_Sold=1&LH_Complete=1`
  });
  var US_EVENTS = [
    {
      id: "superbowl",
      icon: "\u{1F3C8}",
      name: "le Super Bowl",
      short: "Super Bowl",
      date: (y) => nthWeekday(y, 1, 0, 2),
      searches: EVENT_SEARCHES.superbowl
    },
    {
      id: "valentine",
      icon: "\u{1F49D}",
      name: "la Saint-Valentin",
      short: "Saint-Valentin",
      date: (y) => local(y, 1, 14),
      searches: EVENT_SEARCHES.valentine
    },
    {
      id: "stpatrick",
      icon: "\u2618\uFE0F",
      name: "la Saint-Patrick",
      short: "Saint-Patrick",
      date: (y) => local(y, 2, 17),
      searches: EVENT_SEARCHES.stpatrick
    },
    {
      id: "easter",
      icon: "\u{1F423}",
      name: "P\xE2ques",
      short: "P\xE2ques",
      date: (y) => easter(y),
      searches: EVENT_SEARCHES.easter
    },
    {
      id: "spring",
      icon: "\u{1F331}",
      name: "le printemps (jardin)",
      short: "Jardin",
      date: (y) => local(y, 3, 15),
      searches: EVENT_SEARCHES.spring
    },
    {
      id: "mother",
      icon: "\u{1F490}",
      name: "la f\xEAte des m\xE8res aux \xC9tats-Unis",
      short: "F\xEAte des m\xE8res",
      date: (y) => nthWeekday(y, 4, 0, 2),
      searches: EVENT_SEARCHES.mother
    },
    {
      id: "graduation",
      icon: "\u{1F393}",
      name: "les remises de dipl\xF4mes",
      short: "Remise des dipl\xF4mes",
      date: (y) => local(y, 4, 25),
      searches: EVENT_SEARCHES.graduation
    },
    {
      id: "father",
      icon: "\u{1F454}",
      name: "la f\xEAte des p\xE8res aux \xC9tats-Unis",
      short: "F\xEAte des p\xE8res",
      date: (y) => nthWeekday(y, 5, 0, 3),
      searches: EVENT_SEARCHES.father
    },
    {
      id: "summer",
      icon: "\u{1F3D6}\uFE0F",
      name: "l\u2019\xE9t\xE9",
      short: "\xC9t\xE9",
      date: (y) => local(y, 5, 21),
      searches: EVENT_SEARCHES.summer
    },
    {
      id: "july4",
      icon: "\u{1F386}",
      name: "le 4 juillet (f\xEAte nationale am\xE9ricaine)",
      short: "4 juillet",
      date: (y) => local(y, 6, 4),
      searches: EVENT_SEARCHES.july4
    },
    {
      id: "school",
      icon: "\u{1F392}",
      name: "la rentr\xE9e scolaire aux \xC9tats-Unis",
      short: "Rentr\xE9e",
      date: (y) => local(y, 7, 15),
      searches: EVENT_SEARCHES.school
    },
    {
      id: "halloween",
      icon: "\u{1F383}",
      name: "Halloween",
      short: "Halloween",
      date: (y) => local(y, 9, 31),
      searches: EVENT_SEARCHES.halloween
    },
    {
      id: "thanksgiving",
      icon: "\u{1F983}",
      name: "Thanksgiving",
      short: "Thanksgiving",
      date: (y) => nthWeekday(y, 10, 4, 4),
      searches: EVENT_SEARCHES.thanksgiving
    },
    {
      id: "blackfriday",
      icon: "\u{1F6CD}\uFE0F",
      name: "le Black Friday",
      short: "Black Friday",
      date: (y) => nthWeekday(y, 10, 4, 4) + DAY2,
      searches: EVENT_SEARCHES.blackfriday,
      note: "Les acheteurs comparent les prix : v\xE9rifie que tes annonces rentables sont en stock chez le fournisseur, et pr\xE9vois une petite promotion seulement si ton b\xE9n\xE9fice le permet."
    },
    {
      id: "christmas",
      icon: "\u{1F384}",
      name: "No\xEBl",
      short: "No\xEBl",
      date: (y) => local(y, 11, 25),
      searches: EVENT_SEARCHES.christmas,
      note: "Apr\xE8s le 5 d\xE9cembre environ, un colis AliExpress risque d\u2019arriver apr\xE8s No\xEBl : ne promets plus de livraison avant le 25 dans tes messages."
    },
    {
      id: "winter",
      icon: "\u2744\uFE0F",
      name: "le grand froid",
      short: "Hiver",
      date: (y) => local(y, 0, 15),
      searches: EVENT_SEARCHES.winter
    }
  ];
  function upcomingEvents(now = Date.now(), horizon = HORIZON) {
    const d = new Date(now);
    const today = local(d.getFullYear(), d.getMonth(), d.getDate());
    const out = [];
    for (const e of US_EVENTS)
      for (const y of [d.getFullYear(), d.getFullYear() + 1]) {
        const date = e.date(y);
        if (date < today || date - today > horizon * DAY2) continue;
        const deadline = date - LEAD * DAY2;
        out.push({
          id: e.id,
          key: `${e.id}:${y}`,
          icon: e.icon,
          name: e.name,
          short: e.short,
          date,
          deadline,
          daysLeft: inDays(date, today),
          ready: today <= deadline,
          searches: e.searches,
          note: e.note
        });
      }
    return out.sort((a, b) => a.date - b.date);
  }
  function seasonAlerts(now = Date.now()) {
    const alerts = [];
    const year = new Date(now).getFullYear();
    const today = local(year, new Date(now).getMonth(), new Date(now).getDate());
    for (const y of [year, year + 1]) {
      const iso = CNY[y];
      if (!iso) continue;
      const [yy, mm, dd] = iso.split("-").map(Number);
      const cny = local(yy, mm - 1, dd);
      const stop = cny - CNY_BEFORE * DAY2;
      const back = cny + CNY_AFTER * DAY2;
      if (today < stop - 35 * DAY2 || today > back) continue;
      const during = today >= stop;
      alerts.push({
        key: `cny:${y}`,
        icon: "\u{1F9E7}",
        title: during ? "Nouvel An chinois : fournisseurs en pause" : `Nouvel An chinois le ${day(cny)}`,
        text: during ? `Beaucoup de fournisseurs AliExpress n\u2019exp\xE9dient pas avant le ${day(back)} environ. Commande quand m\xEAme tout de suite (ta commande passe dans leur file), pr\xE9viens les clients qui attendent (message \xAB \u23F3 Retard \xBB) et garde un d\xE9lai d\u2019exp\xE9dition allong\xE9 sur eBay jusqu\u2019\xE0 la reprise.` : `Beaucoup de fournisseurs AliExpress s\u2019arr\xEAtent du ${day(stop)} au ${day(back)} environ (dans ${inDays(stop, today)} jours). Avant cette date : allonge ton d\xE9lai d\u2019exp\xE9dition sur eBay (\xAB Handling time \xBB dans tes r\xE8gles d\u2019exp\xE9dition) ou pr\xE9vois de mettre ta boutique en pause (\xAB Time away \xBB dans les param\xE8tres eBay), et regarde si tes fournisseurs annoncent leurs dates.`,
        tone: during || today >= stop - 14 * DAY2 ? "hot" : "todo",
        ideas: []
      });
    }
    const events = upcomingEvents(now, SHOW).filter((e) => e.daysLeft >= 5).slice(0, 4);
    for (const e of events)
      alerts.push({
        key: e.key,
        icon: e.icon,
        title: `${e.name.charAt(0).toUpperCase()}${e.name.slice(1)} le ${day(e.date)}`,
        text: [
          e.ready ? `Dans ${e.daysLeft} jours. AliExpress met une \xE0 trois semaines pour livrer aux \xC9tats-Unis : mets tes nouvelles annonces en ligne avant le ${day(e.deadline)}. \xAB Trouver des produits \xBB cherche les produits de cette f\xEAte qui se vendent en ce moment.` : `Dans ${e.daysLeft} jours : trop tard pour de nouvelles annonces livr\xE9es \xE0 temps depuis AliExpress. Mets en avant celles que tu as d\xE9j\xE0.`,
          e.note
        ].filter(Boolean).join(" "),
        tone: "todo",
        ideas: e.ready ? [{ label: `\u{1F50D} Trouver des produits \xB7 ${e.short}`, href: `scout.html?event=${e.id}` }, ...e.searches.slice(0, 3).map(sold)] : []
      });
    return alerts;
  }

  // src/core/protection.ts
  var PARCELS_KEY = "aliParcels:v1";
  var DAY3 = 864e5;
  var MAX_AGE_DAYS = 120;
  var FRESH_HOURS = 6;
  var STUCK_DAYS = 12;
  var LATE_DAYS = 3;
  var URGENT_DAYS = 7;
  var PARCEL_VERSION = 2;
  function watched(sales, now) {
    const out = [];
    for (const s of sales) {
      if (s.status === "cancelled") continue;
      if (now - (s.soldAt ?? now) > MAX_AGE_DAYS * DAY3) continue;
      for (const p of purchases(s)) if (/^\d{8,25}$/.test(p.orderId)) out.push({ sale: s, p });
    }
    return out;
  }
  function parcelsToCheck(sales, store, now = Date.now(), force = false) {
    const ids = /* @__PURE__ */ new Set();
    for (const { p } of watched(sales, now)) {
      if (!p.tracking) continue;
      const known = store.items[p.orderId];
      const current = known?.v === PARCEL_VERSION;
      if (current && (known.delivered || known.closed)) continue;
      if (!force && current && now - known.checkedAt < FRESH_HOURS * 36e5) continue;
      ids.add(p.orderId);
    }
    return [...ids].slice(0, 80);
  }
  var day2 = (t) => new Date(t).toLocaleDateString("fr-FR", { day: "numeric", month: "long" });
  function parcelAlerts(sales, store, disputes = [], now = Date.now()) {
    const inDispute = new Set(disputes.filter((d) => d.source === "aliexpress" && d.aliOrderId).map((d) => d.aliOrderId));
    const out = [];
    const seen = /* @__PURE__ */ new Set();
    for (const { sale, p } of watched(sales, now)) {
      const info = store.items[p.orderId];
      if (!info || info.v !== PARCEL_VERSION || info.delivered || info.closed || inDispute.has(p.orderId) || seen.has(p.orderId)) continue;
      const ends = [info.disputeUntil, info.autoConfirmAt].filter((x) => x !== null);
      const deadline = ends.length ? Math.min(...ends) : null;
      const left = deadline !== null ? Math.ceil((deadline - now) / DAY3) : null;
      const reasons = [];
      let tone = "todo";
      if (info.refundIfNotBy !== null && now > info.refundIfNotBy + DAY3) {
        reasons.push(`AliExpress promettait la livraison avant le ${day2(info.refundIfNotBy)} : tu peux demander le remboursement`);
        tone = "hot";
      } else if (info.etaEnd !== null && now > info.etaEnd + LATE_DAYS * DAY3)
        reasons.push(`En retard : livraison pr\xE9vue au plus tard le ${day2(info.etaEnd)}`);
      if (info.lastEventAt !== null && now - info.lastEventAt > STUCK_DAYS * DAY3)
        reasons.push(`Aucune nouvelle du colis depuis ${Math.floor((now - info.lastEventAt) / DAY3)} jours${info.lastEvent ? ` (\xAB ${info.lastEvent} \xBB)` : ""}`);
      if (left !== null && left <= URGENT_DAYS) {
        reasons.unshift(left < 0 ? "D\xE9lai de protection AliExpress peut-\xEAtre d\xE9pass\xE9 : essaie quand m\xEAme" : `Plus que ${left} jour${left > 1 ? "s" : ""} pour r\xE9clamer \xE0 AliExpress (jusqu\u2019au ${day2(deadline)})`);
        tone = "hot";
      }
      if (!reasons.length) continue;
      if (deadline !== null && left > URGENT_DAYS) reasons.push(`protection jusqu\u2019au ${day2(deadline)}`);
      seen.add(p.orderId);
      out.push({
        saleId: sale.orderId,
        aliOrderId: p.orderId,
        title: sale.items[0]?.title || sale.orderId,
        tone,
        text: reasons.join(" \xB7 "),
        deadline,
        url: disputeStartUrl(notReceivedDraft(sale, p, info, now), info),
        ...p.tracking ? { tracking: p.tracking } : {}
      });
    }
    return out.sort((a, b) => Number(b.tone === "hot") - Number(a.tone === "hot") || (a.deadline ?? Infinity) - (b.deadline ?? Infinity));
  }
  var DRAFT_HASH = "auroebay-dispute=";
  function disputeStartUrl(draft, info) {
    const link = info?.disputeLinks?.[draft.received ? "received" : "notReceived"];
    const base = link || `https://www.aliexpress.com/p/order/detail.html?orderId=${encodeURIComponent(draft.aliOrderId)}`;
    return `${base.split("#")[0]}#${DRAFT_HASH}${encodeURIComponent(JSON.stringify(draft))}`;
  }
  var enDay = (t) => new Date(t).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
  var units = (sale) => sale.items.reduce((n, i) => n + i.quantity, 0) || 1;
  function notReceivedDraft(sale, p, info, now = Date.now()) {
    const facts = [
      info?.placedAt ? `I placed this order on ${enDay(info.placedAt)}` : "I placed this order",
      "and the package has still not been delivered."
    ].join(" ");
    const track = p.tracking ? `Tracking number ${p.tracking}${info?.lastEventAt ? `: no update since ${enDay(info.lastEventAt)}${info.lastEvent ? ` (last status: "${info.lastEvent}")` : ""}` : ""}.` : "";
    const late = info?.etaEnd && info.etaEnd < now ? `The estimated delivery date (${enDay(info.etaEnd)}) has passed.` : "";
    return {
      saleId: sale.orderId,
      aliOrderId: p.orderId,
      received: false,
      reason: "Colis non re\xE7u (\xAB Package not received \xBB / \xAB Didn\u2019t receive the package \xBB)",
      quantity: units(sale),
      message: ["Hello,", [facts, track, late].filter(Boolean).join(" "), "Please refund me for this order. Thank you."].join("\n\n"),
      tips: ["Choisis \xAB No \xBB quand AliExpress demande si tu as re\xE7u le colis.", "Joins une capture du suivi si AliExpress la demande."]
    };
  }
  var priceText = (m) => m.amount.toLocaleString("fr-FR", { style: "currency", currency: m.currency });
  function deliveredMissingDraft(sale, p, info) {
    const when = info?.lastEventAt ? ` on ${enDay(info.lastEventAt)}` : "";
    const total = p.share?.total ?? p.cost;
    return {
      saleId: sale.orderId,
      aliOrderId: p.orderId,
      received: false,
      reason: "Tracking shows delivered but not received",
      quantity: units(sale),
      message: [
        "Hello,",
        `${p.tracking ? `Tracking number ${p.tracking}` : "The tracking"} shows this package as delivered${when}, but the recipient did not receive it or sign for it.`,
        "Please provide the carrier's proof of delivery (signature, photo or drop-off location). If no proof can be provided, please refund this order. Thank you."
      ].join("\n\n"),
      choices: [
        "Delivery status : \xAB Package not received \xBB",
        "Select a reason : \xAB Tracking shows delivered but not received \xBB",
        `Refund amount : le total de la commande, livraison comprise${total?.amount > 0 ? ` (${priceText(total)} selon AurOEBay, v\xE9rifie)` : ""}`,
        "Refund method : \xAB Original payment method \xBB, pas le solde bonus propos\xE9 par d\xE9faut"
      ],
      tips: [
        "\xAB Submit \xBB reste bloqu\xE9 tant qu\u2019aucune preuve n\u2019est jointe : une capture recadr\xE9e du message du client peut suffire.",
        "Sur la capture, garde seulement le message : pas d\u2019adresse ni de t\xE9l\xE9phone."
      ]
    };
  }
  function aliProofDraft(sale, p, ali, ebay, info) {
    const delivered = /delivered but not received/i.test(ali.reason ?? "");
    const changed = /no longer needed|changed my mind|no longer want|ordered by mistake/i.test(`${ali.reason ?? ""} ${ebay?.reason ?? ""}`);
    const track = p.tracking ? ` (tracking ${p.tracking})` : "";
    const when = info?.delivered && info.lastEventAt ? ` was delivered on ${enDay(info.lastEventAt)}` : "";
    const message2 = delivered ? deliveredMissingDraft(sale, p, info).message : changed ? ["Hello,", `My customer changed their mind and opened a return, as shown in the attached screenshot.${when ? ` The package${track}${when}.` : ""}`, "Please provide the return address or a return label, so the item can be sent back and this order refunded once it is returned. Thank you."].join("\n\n") : ["Hello,", `Please find the attached proof for this request${ebay?.reason ? ` (reason given by my customer: "${ebay.reason}")` : ""}.`, "Please tell me how to return the item, or refund this order. Thank you."].join("\n\n");
    return {
      saleId: sale.orderId,
      aliOrderId: p.orderId,
      received: true,
      reason: ali.reason ?? "",
      quantity: units(sale),
      message: message2,
      choices: [
        `Clique \xAB Provide additional information(s) \xBB${ali.deadline ? ` avant le ${ali.deadline}` : ""}`,
        "Photo : une capture recadr\xE9e de ta page de retour ou du message du client",
        "Colle le message dans \xAB Tell Us More About The Issue \xBB",
        "Clique toi-m\xEAme \xAB Submit \xBB"
      ],
      tips: ["Sur la capture : ni nom, ni adresse, ni t\xE9l\xE9phone, ni prix de vente.", "\xC9cris seulement ce qui est vrai : n\u2019invente pas de d\xE9faut sur l\u2019article."]
    };
  }
  var disputeDetailUrl = (url, draft) => `${url.split("#")[0]}#${DRAFT_HASH}${encodeURIComponent(JSON.stringify(draft))}`;
  var REASONS = [
    { test: /wrong|different|not as described|doesn.?t match|not match|incorrect/i, fr: "Article diff\xE9rent de la description (\xAB Item not as described \xBB / \xAB Wrong item \xBB)", en: "the item received is not the one ordered / not as described" },
    { test: /damag|broken|defect|doesn.?t work|not work|faulty/i, fr: "Article endommag\xE9 ou d\xE9fectueux (\xAB Damaged \xBB / \xAB Defective \xBB)", en: "the item arrived damaged or does not work" },
    { test: /missing|parts|incomplete|quantity/i, fr: "Article ou pi\xE8ces manquants (\xAB Missing items \xBB)", en: "items or parts are missing from the package" },
    { test: /fit|size|small|large|big/i, fr: "Mauvaise taille (\xAB Size doesn\u2019t match \xBB / \xAB Not as described \xBB)", en: "the size received does not match the size ordered" },
    { test: /quality|fake|counterfeit/i, fr: "Qualit\xE9 / article diff\xE9rent de la description (\xAB Not as described \xBB)", en: "the quality is not as described" }
  ];
  function ebayDisputeDraft(sale, p, d, info) {
    if (d.kind === "inr") return info?.delivered ? deliveredMissingDraft(sale, p, info) : notReceivedDraft(sale, p, info);
    const r = REASONS.find((x) => x.test.test(d.reason ?? ""));
    const price = sale.items.find((i) => i.price)?.price?.amount ?? 0;
    const asked = d.amount?.amount ?? 0;
    const quantity = price > 0 && asked > 0 ? Math.max(1, Math.min(units(sale), Math.round(asked / price))) : units(sale);
    const variation = sale.items.map((i) => i.variation).filter(Boolean).join("; ");
    return {
      saleId: sale.orderId,
      aliOrderId: p.orderId,
      received: true,
      reason: r ? r.fr : "La raison la plus proche de celle du client eBay",
      quantity,
      message: [
        "Hello,",
        `I received this order and ${r ? r.en : "there is a problem with it"}${d.reason ? ` (reason: "${d.reason}")` : ""}.${variation ? ` I ordered: ${variation}.` : ""}`,
        `Please refund me for ${quantity > 1 ? `these ${quantity} items` : "this item"}. I can send photos if needed. Thank you.`
      ].join("\n\n"),
      tips: ["Ajoute les photos envoy\xE9es par le client si tu en as.", "Si AliExpress fournit une \xE9tiquette retour, envoie-la au client depuis eBay."]
    };
  }

  // src/core/routine.ts
  var DAY4 = 864e5;
  var ORDER_URL = (id) => `https://www.ebay.com/mesh/ord/details?orderid=${id}`;
  var ALI_ORDER = (id) => `https://www.aliexpress.us/p/order/detail.html?orderId=${id}`;
  var ago = (t, now) => {
    if (!t) return "";
    const h = Math.floor((now - t) / 36e5);
    return h < 24 ? `il y a ${Math.max(1, h)} h` : `il y a ${Math.floor(h / 24)} j`;
  };
  var money = (n, cur) => n.toLocaleString("fr-FR", { style: "currency", currency: cur });
  function orderLinks(saleId, aliOrderId, tracking) {
    return [
      { label: `Vente eBay #${saleId}`, href: ORDER_URL(saleId) },
      ...aliOrderId ? [{ label: `Commande AliExpress #${aliOrderId}`, href: ALI_ORDER(aliOrderId) }] : [],
      ...tracking ? [{ label: `Suivi ${tracking}`, href: `https://t.17track.net/en#nums=${encodeURIComponent(tracking)}` }] : []
    ];
  }
  function aliDisputeLink(d, sales, disputes, parcels) {
    if (d.kind !== "return" && d.kind !== "inr") return void 0;
    const sale = sales.find((s) => s.orderId === d.orderId);
    const p = sale && purchases(sale)[0];
    if (!sale || !p) return void 0;
    if (disputes.some((x) => x.source === "aliexpress" && purchases(sale).some((q) => q.orderId === x.aliOrderId))) return void 0;
    return { label: "Pr\xE9parer le litige AliExpress", href: disputeStartUrl(ebayDisputeDraft(sale, p, d, parcels?.items[p.orderId]), parcels?.items[p.orderId]) };
  }
  function routineTasks(input, now = Date.now()) {
    const live2 = input.sales.filter((s) => s.status !== "cancelled");
    const shown = (task, key) => !input.hidden?.has(`${task}:${key}`);
    const tasks = [];
    const toOrder = live2.filter((s) => s.status === "to_ship" && !purchases(s).length && !s.manualCost && shown("order", s.orderId)).sort((a, b) => (a.soldAt ?? 0) - (b.soldAt ?? 0));
    tasks.push({
      id: "order",
      icon: "\u{1F6D2}",
      title: "\xC0 commander sur AliExpress",
      count: toOrder.length,
      tone: toOrder.some((s) => now - (s.soldAt ?? now) > DAY4) ? "hot" : toOrder.length ? "todo" : "ok",
      hint: toOrder.length ? "Ouvre la commande eBay puis \xAB \u{1F6D2} Commander sur AliExpress \xBB : variante, quantit\xE9 et adresse sont pr\xEAtes." : "Toutes les ventes ont leur achat AliExpress.",
      more: Math.max(0, toOrder.length - 6),
      items: toOrder.slice(0, 6).map((s) => ({
        key: `order:${s.orderId}`,
        text: s.items[0]?.title ?? s.orderId,
        sub: `${s.orderId} \xB7 ${s.country || "?"} \xB7 vendu ${ago(s.soldAt, now)}${s.items[0]?.variation ? ` \xB7 ${s.items[0].variation}` : ""}`,
        href: ORDER_URL(s.orderId)
      }))
    });
    if (input.disputes) {
      const disputes = input.disputes;
      const groups = /* @__PURE__ */ new Map();
      for (const d of disputes) {
        if (!d.open || !shown("disputes", d.key)) continue;
        const g = groups.get(d.orderId ?? d.key) ?? { ebay: [], ali: [] };
        (d.source === "ebay" ? g.ebay : g.ali).push(d);
        groups.set(d.orderId ?? d.key, g);
      }
      const kind = { return: "Retour", inr: "Colis non re\xE7u", case: "Litige eBay (case)", refund: "Remboursement" };
      const rows = [...groups].map(([orderId2, g]) => {
        const ebay = g.ebay.sort((a2, b) => Number(returnToHold(b)) - Number(returnToHold(a2)) || Number(!!b.deadline) - Number(!!a2.deadline) || Number(b.kind === "case") - Number(a2.kind === "case"));
        const e = ebay[0];
        const a = g.ali.find((d) => d.awaitingProof) ?? g.ali.find((d) => d.awaitingReturn) ?? g.ali[0];
        const sale = input.sales.find((s) => s.orderId === orderId2);
        const p = sale && (purchases(sale).find((x) => x.orderId === a?.aliOrderId) ?? purchases(sale)[0]);
        const anyAli = disputes.some((x) => x.source === "aliexpress" && x.orderId === orderId2);
        const [rank, text, href, extra] = a?.awaitingProof ? [0, "AliExpress attend ta r\xE9ponse", a.url, sale && p ? { label: "Pr\xE9parer ma r\xE9ponse", href: disputeDetailUrl(a.url, aliProofDraft(sale, p, a, e, input.parcels?.items[p.orderId])) } : void 0] : e && returnToHold(e) && !anyAli ? [1, "Retour accept\xE9 par eBay : dis au client de ne rien renvoyer", e.orderId ? returnMessageUrl(e.orderId) : e.url, void 0] : e && (e.deadline || e.kind === "case") ? [2, `${kind[e.kind]} \xB7 ${e.status}`, e.url, aliDisputeLink(e, input.sales, disputes, input.parcels)] : a?.awaitingReturn ? [3, "AliExpress attend le retour de l\u2019article", a.url, void 0] : e && e.photos && !anyAli ? [4, `\u{1F4F7} Le client a envoy\xE9 ${e.photos} photo(s) : ouvre le litige AliExpress`, e.url, aliDisputeLink(e, input.sales, disputes, input.parcels)] : e ? [5, `${kind[e.kind]} \xB7 ${e.status}`, e.url, aliDisputeLink(e, input.sales, disputes, input.parcels)] : a && deliveredMissing(a) ? [6, "Livr\xE9 mais pas re\xE7u : litige AliExpress en cours", a.url, void 0] : [7, "Litige AliExpress en cours", a.url, void 0];
        const head = rank === 0 || rank === 3 || rank >= 6 ? a : e;
        const item = {
          key: `disputes:${head.key}`,
          image: e?.image,
          text,
          sub: [
            sale?.items[0]?.title.slice(0, 60),
            `#${orderId2}`,
            e && `eBay : ${e.status}${e.deadline ? ` \xB7 \u23F0 avant le ${e.deadline}` : ""}`,
            // AliExpress' date only when it is the user's step (proof, return) or the seller's reply.
            a && `AliExpress : ${a.status}${a.deadline && (a.awaitingProof || a.awaitingReturn || deliveredMissing(a)) ? ` \xB7 \u23F0 ${deliveredMissing(a) && !a.awaitingProof ? "r\xE9ponse du vendeur avant le" : "avant le"} ${a.deadline}` : ""}`
          ].filter(Boolean).join(" \xB7 "),
          href,
          links: sale || e?.orderId ? orderLinks(orderId2, a?.aliOrderId ?? p?.orderId) : void 0,
          extra
        };
        return { rank, item };
      });
      rows.sort((x, y) => x.rank - y.rank);
      const hot = rows.filter((r) => r.rank <= 2).length;
      tasks.push({
        id: "disputes",
        icon: "\u2696\uFE0F",
        title: "Litiges",
        count: rows.length,
        tone: hot ? "hot" : rows.length ? "todo" : "ok",
        hint: rows.some((r) => r.rank === 0) ? "AliExpress attend ta r\xE9ponse : sans preuve avant la date, le litige peut se fermer sans remboursement." : rows.length ? "Une ligne par vente, avec ses deux c\xF4t\xE9s : r\xE9ponds d\u2019abord sur eBay, puis suis AliExpress jusqu\u2019au remboursement. AurOEBay ne r\xE9pond jamais \xE0 ta place." : "Aucun litige eBay en cours.",
        more: Math.max(0, rows.length - 6),
        items: rows.slice(0, 6).map((r) => r.item),
        action: { label: "Synchroniser les litiges", kind: "disputes" }
      });
    }
    if (input.parcels) {
      const store = input.parcels;
      const alerts2 = parcelAlerts(input.sales, store, input.disputes ?? [], now).filter((a) => shown("parcels", a.aliOrderId));
      const never = parcelsToCheck(input.sales, store, now, true).filter((id) => store.items[id]?.v !== PARCEL_VERSION).length;
      tasks.push({
        id: "parcels",
        icon: "\u{1F6E1}\uFE0F",
        title: "Colis \xE0 surveiller",
        count: alerts2.length || never,
        tone: alerts2.some((a) => a.tone === "hot") ? "hot" : alerts2.length || never ? "todo" : "ok",
        hint: alerts2.length ? "Colis en retard ou sans nouvelles : r\xE9clame \xE0 AliExpress avant la fin de sa protection. Le titre ouvre la commande AliExpress ; \xAB Pr\xE9parer le litige \xBB ouvre sa page \xAB Returns/refunds \xBB avec le message pr\xEAt \xE0 copier, tu valides toi-m\xEAme." : never ? `${never} colis en route \xE0 v\xE9rifier : \xAB V\xE9rifier mes colis \xBB lit leur suivi et leur protection sur AliExpress.` : store.error ? `Derni\xE8re v\xE9rification incompl\xE8te : ${store.error}` : store.at ? `Aucun colis en retard (v\xE9rifi\xE9 ${ago(store.at, now)}).` : "Aucun colis en route \xE0 surveiller.",
        more: Math.max(0, alerts2.length - 6),
        // The title opens the AliExpress order (its tracking); the dispute is its own link.
        items: alerts2.slice(0, 6).map((a) => ({
          key: `parcels:${a.aliOrderId}`,
          text: a.title,
          sub: a.text,
          href: ALI_ORDER(a.aliOrderId),
          links: orderLinks(a.saleId, a.aliOrderId, a.tracking),
          extra: { label: "Pr\xE9parer le litige AliExpress", href: a.url }
        })),
        action: { label: "V\xE9rifier mes colis", kind: "parcels" }
      });
    }
    const late = live2.flatMap(
      (s) => s.status === "to_ship" ? purchases(s).filter((p) => !p.tracking && now - (p.linkedAt || s.soldAt || now) > 5 * DAY4 && shown("late", p.orderId)).map((p) => ({ s, p })) : []
    );
    tasks.push({
      id: "late",
      icon: "\u23F0",
      title: "Colis sans suivi depuis 5 jours",
      count: late.length,
      tone: late.length ? "hot" : "ok",
      hint: late.length ? "Contacte le vendeur AliExpress (lien direct vers la commande)." : "Aucun colis en retard.",
      more: Math.max(0, late.length - 6),
      items: late.slice(0, 6).map(({ s, p }) => ({
        key: `late:${p.orderId}`,
        text: s.items[0]?.title ?? s.orderId,
        sub: `AliExpress ${p.orderId} \xB7 achet\xE9 ${ago(p.linkedAt || s.soldAt, now)}`,
        href: ALI_ORDER(p.orderId)
      }))
    });
    const toTrack = live2.filter(
      (s) => trackingsToSend(s).length > 0 && shown("tracking", s.orderId)
    );
    const waitingOrders = /* @__PURE__ */ new Map();
    for (const s of live2)
      if (s.status === "to_ship") {
        for (const p of purchases(s)) if (!p.tracking) waitingOrders.set(p.orderId, p.status ?? "");
      }
    const waiting = waitingOrders.size;
    const notShipped = [...waitingOrders.values()].filter((st) => /processing|awaiting shipment|to ship|pending/i.test(st)).length;
    tasks.push({
      id: "tracking",
      icon: "\u{1F4E6}",
      title: "Suivis \xE0 mettre sur eBay",
      count: toTrack.length,
      tone: toTrack.length ? "todo" : "ok",
      hint: toTrack.length ? "Un clic : AurOEBay relit AliExpress puis ouvre la page eBay des suivis d\xE9j\xE0 remplie ; tu cliques \xAB Save \xBB." : waiting ? notShipped === waiting ? `Tous les suivis disponibles sont sur eBay. ${waiting} commande(s) AliExpress pas encore exp\xE9di\xE9e(s) par le fournisseur : leur num\xE9ro arrivera \xE0 l\u2019exp\xE9dition.` : `${waiting} commande(s) AliExpress sans num\xE9ro${notShipped ? ` (dont ${notShipped} pas encore exp\xE9di\xE9e(s))` : ""} : r\xE9cup\xE8re-les.` : "Tous les suivis connus sont sur eBay.",
      more: Math.max(0, toTrack.length - 6),
      items: toTrack.slice(0, 6).map((s) => ({
        key: `tracking:${s.orderId}`,
        text: s.items[0]?.title ?? s.orderId,
        sub: `${s.orderId} \xB7 ${trackingsToSend(s).map((p) => p.tracking).join(", ")}`
      })),
      action: toTrack.length || waiting ? { label: "R\xE9cup\xE9rer et mettre les suivis", kind: "trackings" } : void 0
    });
    const alerts = input.watch.filter((w) => w.issues > 0 && !w.dismissed && shown("watch", w.productId));
    tasks.push({
      id: "watch",
      icon: "\u{1F4C9}",
      title: "Alertes stock / prix",
      count: alerts.length,
      tone: alerts.length ? "todo" : "ok",
      hint: alerts.length ? "Ouvre la fiche puis \xAB Mettre \xE0 jour stock/prix \xBB." : "Aucune alerte (derni\xE8re v\xE9rification dans Mes produits).",
      more: Math.max(0, alerts.length - 6),
      items: alerts.slice(0, 6).map((w) => ({
        key: `watch:${w.productId}`,
        text: w.name,
        sub: `${w.issues} variante(s) \xE0 corriger`,
        href: `dashboard.html?product=${encodeURIComponent(w.productId)}`
      }))
    });
    const losses = live2.filter((s) => now - (s.soldAt ?? 0) < 7 * DAY4 && shown("loss", s.orderId)).map((s) => {
      const n = input.numbers(s);
      return { s, net: n.complete && n.profit !== null ? n.profit - input.charges(n.revenue ?? 0) : null, cur: n.currency };
    }).filter((x) => x.net !== null && x.net < 0);
    tasks.push({
      id: "loss",
      icon: "\u26A0\uFE0F",
      title: "Ventes \xE0 perte (7 jours)",
      count: losses.length,
      tone: losses.length ? "todo" : "ok",
      hint: losses.length ? "Monte le prix de ces annonces (b\xE9n\xE9fice net apr\xE8s URSSAF n\xE9gatif)." : "Aucune vente \xE0 perte cette semaine.",
      more: Math.max(0, losses.length - 6),
      items: losses.slice(0, 6).map(({ s, net, cur }) => ({
        key: `loss:${s.orderId}`,
        text: s.items[0]?.title ?? s.orderId,
        sub: `${money(net, cur)} net \xB7 ${s.orderId}`,
        href: s.items[0]?.itemId ? `https://www.ebay.com/itm/${s.items[0].itemId}` : void 0
      }))
    });
    if (input.sales.length) {
      const health = sellerHealth(input.sales, input.disputes ?? [], now);
      const metricKey = (m) => m.tone === "hot" ? `${m.key}:hot` : m.key;
      const bad = health.metrics.filter((m) => m.tone !== "ok");
      const open = bad.filter((m) => shown("seller", metricKey(m)));
      const tone = open.some((m) => m.tone === "hot") ? "hot" : open.length ? "todo" : "ok";
      tasks.push({
        id: "seller",
        icon: "\u{1FA7A}",
        title: "Sant\xE9 du compte eBay",
        count: open.length,
        tone,
        hint: open.length ? `\xC0 surveiller pour garder ton niveau vendeur (90 derniers jours, ${health.count} vente(s))${health.few ? ", peu de ventes : chiffres indicatifs" : ""}.` : bad.length ? `Rien de nouveau \xE0 surveiller : ${bad.length} point(s) masqu\xE9(s) (il r\xE9appara\xEEt s\u2019il devient rouge).` : `Tout est dans les limites d\u2019eBay sur 90 jours (${health.count} vente(s)) : suivi ${health.metrics.find((m) => m.key === "tracking").value}.`,
        items: (open.length ? open : bad.length ? [] : health.metrics.filter((m) => m.key === "tracking")).map((m) => ({
          key: `seller:${metricKey(m)}`,
          text: `${m.label} : ${m.value}`,
          sub: `eBay : ${m.limit} \xB7 ${m.hint}`,
          href: PERFORMANCE_URL
        }))
      });
    }
    const fresh = input.rivals.reduce((n, r) => n + (r.lastNew || 0), 0);
    const stale = input.rivals.filter((r) => !r.lastCheck || now - r.lastCheck > DAY4).length;
    tasks.push({
      id: "rivals",
      icon: "\u{1F52D}",
      title: "Concurrents",
      count: input.rivals.length ? fresh : 0,
      tone: input.rivals.length && (fresh || stale) ? "todo" : "ok",
      hint: !input.rivals.length ? "Aucun concurrent suivi (\xAB \u2B50 Suivre \xBB sur un vendeur)." : stale ? `${stale} concurrent(s) pas v\xE9rifi\xE9(s) depuis 24 h.` : fresh ? `${fresh} nouvelle(s) annonce(s) \xE0 la derni\xE8re v\xE9rification.` : "Rien de neuf \xE0 la derni\xE8re v\xE9rification.",
      items: input.rivals.filter((r) => r.lastNew && shown("rivals", r.seller)).slice(0, 6).map((r) => ({ key: `rivals:${r.seller}`, text: r.seller, sub: `${r.lastNew} nouvelle(s) annonce(s)` })),
      action: input.rivals.length ? { label: "Voir leurs nouveaut\xE9s", kind: "rivals" } : void 0
    });
    const seasons = seasonAlerts(now).filter((a) => shown("season", a.key));
    if (seasons.length)
      tasks.push({
        id: "season",
        icon: "\u{1F4C6}",
        title: "\xC0 pr\xE9voir",
        count: seasons.length,
        tone: seasons.some((a) => a.tone === "hot") ? "hot" : "todo",
        hint: "Des dates qui changent ton travail dans les semaines qui viennent. AurOEBay ne change rien sur eBay : tu d\xE9cides.",
        items: seasons.map((a) => ({
          key: `season:${a.key}`,
          text: `${a.icon} ${a.title}`,
          sub: a.text,
          links: a.ideas.length ? a.ideas : void 0
        }))
      });
    const weight = { hot: 0, todo: 1, ok: 2 };
    const sorted = tasks.sort((a, b) => weight[a.tone] - weight[b.tone]);
    const week = weekReview(input, now);
    return week ? [week, ...sorted] : sorted;
  }
  function weekReview(input, now = Date.now()) {
    const today = new Date(now);
    if (today.getDay() !== 1) return null;
    const start2 = new Date(today.getFullYear(), today.getMonth(), today.getDate()).getTime();
    const from = start2 - 7 * DAY4;
    const before = from - 7 * DAY4;
    const live2 = input.sales.filter((s) => s.status !== "cancelled" && s.soldAt);
    const sum = (a, b) => {
      const list2 = live2.filter((s) => s.soldAt >= a && s.soldAt < b);
      let net = 0;
      let revenue = 0;
      let cur = "EUR";
      const byProduct = /* @__PURE__ */ new Map();
      for (const s of list2) {
        const n = input.numbers(s);
        cur = n.currency;
        revenue += n.revenue ?? 0;
        const one = n.complete && n.profit !== null ? n.profit - input.charges(n.revenue ?? 0) : null;
        if (one === null) continue;
        net += one;
        const item = s.items[0];
        const key = item?.itemId ?? item?.title ?? s.orderId;
        const p = byProduct.get(key) ?? { title: item?.title ?? s.orderId, itemId: item?.itemId, net: 0, count: 0 };
        p.net += one;
        p.count += Math.max(1, item?.quantity ?? 1);
        byProduct.set(key, p);
      }
      return { count: list2.length, revenue, net: Math.round(net * 100) / 100, cur, byProduct };
    };
    const last = sum(from, start2);
    const prev = sum(before, from);
    const day3 = (t) => new Date(t).toLocaleDateString("fr-FR", { day: "numeric", month: "long" });
    const trend = prev.count && prev.net ? ` (${last.net >= prev.net ? "\u25B2" : "\u25BC"} ${Math.abs(Math.round((last.net - prev.net) / Math.abs(prev.net) * 100))} % par rapport \xE0 la semaine d\u2019avant)` : "";
    const top = [...last.byProduct.values()].sort((a, b) => b.net - a.net).slice(0, 3);
    const toCut = input.watch.filter((w) => w.issues > 0 && !w.dismissed);
    const fresh = input.rivals.reduce((n, r) => n + (r.lastNew || 0), 0);
    const items = top.map((p, i) => ({
      key: `week:top:${i}`,
      text: `${["\u{1F947}", "\u{1F948}", "\u{1F949}"][i]} ${p.title}`,
      sub: `${money(p.net, last.cur)} net \xB7 ${p.count} vendu${p.count > 1 ? "s" : ""}`,
      href: p.itemId ? `https://www.ebay.com/itm/${p.itemId}` : void 0
    }));
    if (toCut.length)
      items.push({ key: "week:cut", text: `\u2702\uFE0F ${toCut.length} annonce${toCut.length > 1 ? "s" : ""} \xE0 revoir ou couper`, sub: "Fournisseur en rupture ou devenu trop cher : voir la carte \xAB Alertes stock / prix \xBB." });
    if (fresh)
      items.push({ key: "week:rivals", text: `\u{1F52D} ${fresh} nouveaut\xE9${fresh > 1 ? "s" : ""} chez tes concurrents`, sub: "\xAB Voir leurs nouveaut\xE9s \xBB dans la carte Concurrents (fournisseurs cherch\xE9s en m\xEAme temps)." });
    return {
      id: "week",
      icon: "\u{1F4C5}",
      title: "Ta semaine",
      count: last.count,
      tone: "todo",
      hint: last.count ? `Du ${day3(from)} au ${day3(start2 - DAY4)} : ${last.count} vente${last.count > 1 ? "s" : ""}, ${money(last.revenue, last.cur)} encaiss\xE9s, ${money(last.net, last.cur)} de b\xE9n\xE9fice net${trend}.` : `Aucune vente du ${day3(from)} au ${day3(start2 - DAY4)}. Cette semaine : \xAB \u{1F50D} Trouver des produits \xBB pour de nouvelles annonces.`,
      items,
      action: { label: "Voir mes ventes", kind: "sales" }
    };
  }

  // src/core/license.ts
  var LICENSE_KEY = "license:v1";
  var CHECKOUT_URL = "https://auroebay.lemonsqueezy.com/checkout/buy/1b765c13-2f39-4847-82fa-e7950d112d63";
  var TRIAL_DAYS = 15;
  var CODE_MAX_DAYS = 93;
  var GRACE_DAYS = 3;
  var DAY5 = 864e5;
  var OWNER_EXTENSION_ID = "bbedjpfnnkjadfjpbbmppikmgocoglfh";
  var SKEW = 10 * 6e4;
  var extensionId = () => globalThis.chrome?.runtime?.id ?? "";
  var ownerInstall = () => extensionId() === OWNER_EXTENSION_ID;
  function licenseActive(s, now = Date.now()) {
    if (!s) return false;
    if (s.owner) return ownerInstall();
    if (s.status === "trial") return trialActive(s, now);
    if (!s.key || s.status !== "active" || !s.checkedAt) return false;
    if (s.checkedAt > now + SKEW || (s.triedAt ?? 0) > now + SKEW) return false;
    if (typeof s.expiresAt === "string" && Date.parse(s.expiresAt) < now - DAY5) return false;
    return now - s.checkedAt < GRACE_DAYS * DAY5;
  }
  var PEPPER = "AurOEBay\xB7licence\xB7v1\xB74f1c9e27b8d36a05";
  var SEALED = ["owner", "key", "instanceId", "status", "checkedAt", "triedAt", "email", "expiresAt", "error", "trialUntil", "trialId"];
  async function hmac(text) {
    const enc = new TextEncoder();
    const raw = await crypto.subtle.digest("SHA-256", enc.encode(PEPPER + "|" + extensionId()));
    const key = await crypto.subtle.importKey("raw", raw, { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
    const sig = await crypto.subtle.sign("HMAC", key, enc.encode(text));
    return [...new Uint8Array(sig)].map((b) => b.toString(16).padStart(2, "0")).join("");
  }
  var body = (s) => JSON.stringify(SEALED.map((k) => s[k] ?? null));
  async function sealValid(s) {
    if (!s || typeof s.seal !== "string") return false;
    try {
      return s.seal === await hmac(body(s));
    } catch {
      return false;
    }
  }
  async function trustedLicense(raw) {
    const s = raw && typeof raw === "object" ? raw : {};
    if (await sealValid(s)) return { state: s, sealed: true };
    if (s.owner === true && ownerInstall()) return { state: { owner: true }, sealed: false };
    if (typeof s.key === "string" && typeof s.instanceId === "string")
      return { state: { key: s.key, instanceId: s.instanceId, status: "unverified" }, sealed: false };
    return { state: {}, sealed: false };
  }
  async function readLicense() {
    const raw = (await chrome.storage.local.get(LICENSE_KEY))[LICENSE_KEY];
    return (await trustedLicense(raw)).state;
  }
  var GIFT_CODES = [
    // An owner's friend, 2 months (11/11/2026 → 10/01/2027).
    { hash: "17d203ba3126fbb6d37dd5140799c68f5b838f94e15027b54a99ce12b10724bc", until: Date.UTC(2027, 0, 10, 22, 59) }
  ];
  function trialActive(s, now = Date.now()) {
    if (typeof s.trialUntil !== "number" || now >= s.trialUntil) return false;
    if ((s.checkedAt ?? 0) > now + SKEW) return false;
    return s.trialUntil - now <= (CODE_MAX_DAYS + 1) * DAY5;
  }
  var trialDaysLeft = (s, now = Date.now()) => s?.status === "trial" && trialActive(s, now) ? Math.ceil((s.trialUntil - now) / DAY5) : 0;
  function licenseLabel(s, now = Date.now()) {
    if (s?.owner) return "Version propri\xE9taire : aucune licence n\xE9cessaire.";
    if (s?.status === "trial" && trialActive(s, now)) {
      const left = trialDaysLeft(s, now);
      const end = new Date(s.trialUntil).toLocaleDateString("fr-FR", { day: "numeric", month: "long" });
      return `Essai gratuit : encore ${left} jour${left > 1 ? "s" : ""} (jusqu\u2019au ${end}). Abonne-toi avant pour continuer sans coupure.`;
    }
    if (s?.status === "trial" || s?.status === "trial-ended") return "Ton essai gratuit est termin\xE9 : abonne-toi pour continuer. Tes donn\xE9es sont gard\xE9es.";
    if (!s?.key) return `Aucune cl\xE9 de licence : commence ton essai gratuit de ${TRIAL_DAYS} jours, puis colle la cl\xE9 re\xE7ue par e-mail.`;
    if (licenseActive(s, now)) return `Abonnement actif${s.email ? ` (${s.email})` : ""}.`;
    if (s.status === "unverified") return s.error ? `${s.error} Ta licence sera v\xE9rifi\xE9e d\xE8s le retour de la connexion.` : "V\xE9rification de ta licence aupr\xE8s de Lemon Squeezy\u2026";
    if (s.status === "active") return "Impossible de v\xE9rifier ta licence depuis plus de 3 jours : v\xE9rifie ta connexion internet.";
    if (s.status === "expired") return "Abonnement termin\xE9 : renouvelle-le pour r\xE9activer AurOEBay.";
    if (s.status === "disabled") return "Licence d\xE9sactiv\xE9e : contacte bonjour@impression-minute.fr.";
    return s.error ?? "Licence inactive.";
  }
  function versionBelow(version, than) {
    if (!version) return false;
    const a = version.split(".").map(Number);
    const b = than.split(".").map(Number);
    for (let i = 0; i < 3; i++) if ((a[i] ?? 0) !== (b[i] ?? 0)) return (a[i] ?? 0) < (b[i] ?? 0);
    return false;
  }

  // src/ui/license.ts
  var read = () => message({ type: "LICENSE_STATE" }).catch(() => readLicense());
  function licenseBanner(doc = document) {
    if (/\/(welcome|options)\.html$/.test(location.pathname)) return;
    const show = async () => {
      doc.getElementById("lic-banner")?.remove();
      const s = await read();
      const left = trialDaysLeft(s);
      if (left > 0 && left <= 3) {
        const note = doc.createElement("div");
        note.id = "lic-banner";
        note.className = "lic-banner";
        note.innerHTML = `<span>\u23F3 ${escapeHTML(licenseLabel(s))}</span>
        <span><a class="btn small primary" href="${CHECKOUT_URL}" target="_blank" rel="noopener">S\u2019abonner</a> <a class="btn small secondary" href="welcome.html">Entrer ma cl\xE9</a></span>`;
        doc.body.prepend(note);
        return;
      }
      if (licenseActive(s)) return;
      const bar = doc.createElement("div");
      bar.id = "lic-banner";
      bar.className = "lic-banner";
      bar.innerHTML = `<span>\u{1F512} ${escapeHTML(licenseLabel(s))} AurOEBay est en pause ; tes donn\xE9es restent ici.</span>
      <span><a class="btn small primary" href="welcome.html">Entrer ma cl\xE9</a> <a class="btn small secondary" href="${CHECKOUT_URL}" target="_blank" rel="noopener">${s.key || s.status?.startsWith("trial") ? "S\u2019abonner" : `Essai gratuit ${TRIAL_DAYS} jours`}</a></span>`;
      doc.body.prepend(bar);
    };
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "local" && changes[LICENSE_KEY]) void show();
    });
    void show().catch(() => {
    });
  }

  // src/core/update.ts
  var UPDATE_KEY = "update:v1";
  var VERSION_URL = "https://auroebay.netlify.app/version.json";
  var MIRROR = "https://raw.githubusercontent.com/ImpressionMinute/auroebay-maj/main/";
  var VERSION_URLS = [VERSION_URL, MIRROR + "version.json"];
  var UPDATE_GUIDE_URL = "https://auroebay.netlify.app/mise-a-jour.html";
  var UPDATE_EVERY_MS = 24 * 36e5;
  var UPDATE_RECHECK_MS = 2 * 6e4;
  var WHATS_NEW_KEY = "whatsNew:v1";
  var NEWS_URL = "https://auroebay.netlify.app/nouveautes.html";
  var MAC_COMMAND = `curl -fsSL ${MIRROR}maj-mac.sh | bash`;
  var WINDOWS_COMMAND = `powershell -ExecutionPolicy Bypass -c "[Net.ServicePointManager]::SecurityProtocol=3072;irm ${MIRROR}maj-windows.ps1|iex"`;
  var DISK_WAIT_KEY = "updateOnDisk:v1";
  var SITE = "https://auroebay.netlify.app/";
  function cleanNotes(value) {
    if (!Array.isArray(value)) return [];
    return value.filter((n) => typeof n === "string").map((n) => n.replace(/\s+/g, " ").trim().slice(0, 240)).filter(Boolean).slice(0, 8);
  }
  function parseReleaseNotes(value) {
    if (!Array.isArray(value)) return [];
    return value.flatMap((r) => {
      const v = r;
      if (typeof v?.version !== "string" || !/^\d{1,4}\.\d{1,5}\.\d{1,6}$/.test(v.version)) return [];
      const notes = cleanNotes(v.notes);
      return notes.length ? [{ version: v.version, date: typeof v.date === "string" ? v.date.slice(0, 10) : "", notes }] : [];
    });
  }
  function parseVersionFile(value) {
    const v = value;
    if (typeof v?.version !== "string" || !/^\d{1,4}\.\d{1,5}\.\d{1,6}$/.test(v.version)) return null;
    if (typeof v.url !== "string" || !(v.url.startsWith(SITE) || v.url.startsWith(MIRROR)) || /["'<>\s]/.test(v.url)) return null;
    return { latest: v.version, url: v.url, notes: cleanNotes(v.notes) };
  }
  function updateAvailable(info, current) {
    return !!info?.latest && !!info.url && versionBelow(current, info.latest);
  }

  // src/ui/update.ts
  var DISMISSED = "updateDismissed:v1";
  var isWindows = () => /Windows/i.test(navigator.userAgent);
  function steps() {
    return isWindows() ? `<ol class="upd-steps"><li>Clique <b>Copier</b>.</li><li>Appuie sur les touches <kbd>\u229E Windows</kbd> + <kbd>R</kbd>.</li><li>Appuie sur <kbd>Ctrl</kbd> + <kbd>V</kbd>, puis <kbd>Entr\xE9e</kbd>.</li><li>Quand \xAB C\u2019est fait \xBB s\u2019affiche : <b>ferme compl\xE8tement Chrome et rouvre-le</b> (obligatoire).</li></ol>` : `<ol class="upd-steps"><li>Clique <b>Copier</b>.</li><li>Appuie sur <kbd>\u2318 Cmd</kbd> + <kbd>Espace</kbd>, tape <b>Terminal</b>, puis <kbd>Entr\xE9e</kbd>.</li><li>Appuie sur <kbd>\u2318 Cmd</kbd> + <kbd>V</kbd>, puis <kbd>Entr\xE9e</kbd>.</li><li>Quand \xAB C\u2019est fait \xBB s\u2019affiche : <b>quitte Chrome</b> (<kbd>\u2318 Cmd</kbd> + <kbd>Q</kbd>) <b>et rouvre-le</b> (obligatoire).</li></ol>`;
  }
  var list = (notes) => notes.length ? `<ul class="upd-notes">${notes.map((n) => `<li>${escapeHTML(n)}</li>`).join("")}</ul>` : "";
  function updateBanner(doc = document) {
    const current = chrome.runtime.getManifest().version;
    const show = async () => {
      doc.getElementById("upd-banner")?.remove();
      const got = await chrome.storage.local.get([UPDATE_KEY, DISMISSED]);
      const saved2 = got[UPDATE_KEY];
      const ok = parseVersionFile({ version: saved2?.latest, url: saved2?.url, notes: saved2?.notes });
      const info = ok ? { ...ok, checkedAt: saved2?.checkedAt } : void 0;
      if (!updateAvailable(info, current) || got[DISMISSED] === info.latest) return;
      const bar = doc.createElement("div");
      bar.id = "upd-banner";
      bar.className = "lic-banner upd-banner";
      const waiting = (await chrome.storage.local.get(DISK_WAIT_KEY))[DISK_WAIT_KEY];
      bar.innerHTML = waiting?.version ? `<div><b>\u2705 AurOEBay ${escapeHTML(waiting.version)} est pr\xEAt.</b> Il se recharge tout seul d\xE8s que ${escapeHTML(waiting.reason ?? "le travail en cours")} sera fini.</div>
      <span><button type="button" class="btn small primary" id="upd-now">Recharger maintenant</button></span>` : `<div><b>\u{1F195} AurOEBay ${escapeHTML(info.latest)} est disponible</b> (tu as ${escapeHTML(current)}).${ok.notes.length ? ` Ce que \xE7a apporte :${list(ok.notes)}` : ""}<p class="upd-how">Mise \xE0 jour en 1 minute, tes donn\xE9es sont gard\xE9es :</p>${steps()}<p class="upd-how small">Sans red\xE9marrer Chrome, les boutons AurOEBay ne marchent pas sur les pages eBay et AliExpress.</p></div>
      <span><button type="button" class="btn small primary" id="upd-copy">\u{1F4CB} Copier</button>
      <a class="btn small secondary" href="${UPDATE_GUIDE_URL}" target="_blank" rel="noopener">Aide en images</a>
      <button type="button" class="btn small secondary" id="upd-later">Plus tard</button></span>`;
      bar.querySelector("#upd-later")?.addEventListener("click", () => {
        void chrome.storage.local.set({ [DISMISSED]: info.latest });
      });
      bar.querySelector("#upd-now")?.addEventListener("click", () => {
        if (confirm("Recharger AurOEBay maintenant ? Le travail en cours sera interrompu (tes donn\xE9es sont gard\xE9es)."))
          void chrome.runtime.sendMessage({ type: "UPDATE_RELOAD_NOW" }).catch(() => {
          });
      });
      const copy = bar.querySelector("#upd-copy");
      copy?.addEventListener("click", () => {
        void navigator.clipboard.writeText(isWindows() ? WINDOWS_COMMAND : MAC_COMMAND).then(() => copy.textContent = "\u2713 Copi\xE9 ! \xC9tape 2 \u2192").catch(() => copy.textContent = "\u26A0 Copie impossible : utilise l\u2019aide en images");
      });
      doc.body.prepend(bar);
      poll();
    };
    let polling;
    const poll = () => {
      if (polling) return;
      polling = setInterval(() => {
        if (!doc.getElementById("upd-banner")) return void (clearInterval(polling), polling = void 0);
        void chrome.runtime.sendMessage({ type: "UPDATE_DISK" }).catch(() => {
        });
      }, 4e3);
    };
    const news = async () => {
      doc.getElementById("upd-news")?.remove();
      if ((await chrome.storage.local.get(WHATS_NEW_KEY))[WHATS_NEW_KEY] !== current) return;
      const notes = await fetch(chrome.runtime.getURL("release-notes.json")).then((r) => r.json()).then((v) => parseReleaseNotes(v).find((r) => r.version === current)?.notes ?? []).catch(() => []);
      if (!notes.length) return;
      const bar = doc.createElement("div");
      bar.id = "upd-news";
      bar.className = "lic-banner upd-banner upd-news";
      bar.innerHTML = `<div><b>\u{1F389} AurOEBay est \xE0 jour (${escapeHTML(current)}). Les nouveaut\xE9s :</b>${list(notes)}<p class="upd-how small">Si ce n\u2019est pas d\xE9j\xE0 fait : ferme compl\xE8tement Chrome et rouvre-le, sinon les boutons AurOEBay ne marchent pas sur les pages eBay et AliExpress d\xE9j\xE0 ouvertes.</p></div>
      <span><a class="btn small secondary" href="${NEWS_URL}" target="_blank" rel="noopener">Toutes les nouveaut\xE9s</a>
      <button type="button" class="btn small primary" id="upd-news-ok">J\u2019ai compris</button></span>`;
      bar.querySelector("#upd-news-ok")?.addEventListener("click", () => void chrome.storage.local.remove(WHATS_NEW_KEY));
      doc.body.prepend(bar);
    };
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "local") return;
      if (changes[UPDATE_KEY] || changes[DISMISSED] || changes[DISK_WAIT_KEY]) void show().catch(() => {
      });
      if (changes[WHATS_NEW_KEY]) void news().catch(() => {
      });
    });
    void show().catch(() => {
    });
    void news().catch(() => {
    });
    void chrome.runtime.sendMessage({ type: "UPDATE_CHECK" }).catch(() => {
    });
  }

  // src/core/links.ts
  var DISCORD_URL = "https://discord.gg/sr2g2ZZZQ9";

  // src/core/journal.ts
  var DAY6 = 864e5;
  var time = (at) => new Date(at).toLocaleString("fr-FR", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit", second: "2-digit" });
  var ICON = { msg: "\xB7", error: "\u2717", shown: "\u26A0", step: "\u2192", start: "\u25B6" };
  function journalLine(e) {
    const icon = e.kind === "msg" ? e.ok ? "\u2713" : "\u2717" : ICON[e.kind];
    return [
      time(e.at),
      icon,
      e.what,
      e.where ? `[${e.where}]` : "",
      e.ms !== void 0 && e.ms >= 50 ? `${e.ms} ms` : "",
      e.count && e.count > 1 ? `\xD7${e.count}` : "",
      e.text ? `\u2014 ${e.text}` : ""
    ].filter(Boolean).join(" ");
  }
  function journalProblems(list2, now = Date.now()) {
    return list2.filter((e) => now - e.at < DAY6 && (e.kind === "error" || e.kind === "shown" || e.kind === "msg" && !e.ok)).length;
  }

  // src/ui/report.ts
  var REPORT_URL = "https://auroebay.netlify.app/";
  var SUPPORT_EMAIL = "bonjour@impression-minute.fr";
  var MAX_IMAGE = 5 * 1024 * 1024;
  function section(title, body2) {
    const lines = (value, indent = "") => {
      if (value === null || value === void 0) return [`${indent}\u2014`];
      if (Array.isArray(value)) return value.length ? value.flatMap((v) => typeof v === "object" && v ? lines(v, indent + "  ") : [`${indent}- ${String(v)}`]) : [`${indent}(rien)`];
      if (typeof value === "object")
        return Object.entries(value).flatMap(
          ([k, v]) => v && typeof v === "object" && (Array.isArray(v) ? v.length : true) ? [`${indent}${k} :`, ...lines(v, indent + "  ")] : [`${indent}${k} : ${Array.isArray(v) ? "(rien)" : String(v ?? "\u2014")}`]
        );
      return [`${indent}${String(value)}`];
    };
    return `
=== ${title} ===
${lines(body2).join("\n")}
`;
  }
  async function technicalReport(extra, full = false) {
    const [health, snapshot, journal] = await Promise.all([
      message({ type: "HEALTH_CHECK" }).catch((e) => `illisible : ${e instanceof Error ? e.message : String(e)}`),
      message({ type: "DEBUG_SNAPSHOT" }).catch((e) => `le moteur ne r\xE9pond pas : ${e instanceof Error ? e.message : String(e)}`),
      message({ type: "JOURNAL_GET" }).catch(() => [])
    ]);
    let session = {};
    try {
      session = await chrome.storage.session.get(["apiTrace:v1", "lastPanelError:v1"]);
    } catch {
    }
    const problems = journal.filter((e) => e.kind === "error" || e.kind === "shown" || e.kind === "msg" && !e.ok);
    const version = chrome.runtime.getManifest().version;
    const head = [
      `RAPPORT AUROEBAY ${version} \u2014 ${(/* @__PURE__ */ new Date()).toLocaleString("fr-FR")}`,
      `Ouvert depuis : ${location.pathname.replace(/^\//, "")}`,
      `Probl\xE8mes sur 24 h : ${journalProblems(journal)} \xB7 lignes de journal : ${journal.length}${journal.length ? ` (depuis le ${new Date(journal[0].at).toLocaleString("fr-FR")})` : ""}`
    ].join("\n");
    const parts = [
      head,
      section("Derni\xE8res erreurs (les plus r\xE9centes en bas)", problems.slice(-25).map(journalLine)),
      section("\xC9tat d'AurOEBay", snapshot),
      section("Tout va bien ?", Array.isArray(health) ? health.map((x) => `${x.ok ? "OK" : x.unknown ? "?" : "!!"} ${x.title} : ${x.text}`) : health),
      section("Derni\xE8re erreur du panneau", session["lastPanelError:v1"] ?? null),
      extra ? section("Panneau", extra) : "",
      section(full ? "Journal complet" : "Journal (300 derni\xE8res lignes)", (full ? journal : journal.slice(-300)).map(journalLine)),
      full ? section("Trace des imports (brute)", JSON.stringify(session["apiTrace:v1"] ?? [], null, 1)) : ""
    ];
    const text = redact(parts.join(""));
    return full ? text : text.slice(0, 6e4);
  }
  async function downloadReport(extra) {
    const text = await technicalReport(extra, true);
    const url = URL.createObjectURL(new Blob([text], { type: "text/plain;charset=utf-8" }));
    const a = document.createElement("a");
    a.href = url;
    a.download = `AurOEBay-rapport-${chrome.runtime.getManifest().version}-${(/* @__PURE__ */ new Date()).toISOString().slice(0, 16).replace(/[T:]/g, "-")}.txt`;
    document.body.append(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1e4);
  }
  var CSS = `
.rp{border:0;border-radius:18px;padding:0;max-width:520px;width:calc(100vw - 32px);background:var(--surface,#fff);color:var(--text,#1d1a24);box-shadow:0 24px 60px rgba(0,0,0,.4);font:14px system-ui,-apple-system,sans-serif}
.rp::backdrop{background:rgba(10,8,14,.55)}
.rp form{display:grid;gap:12px;padding:20px 22px}
.rp h2{margin:0;font-size:19px}
.rp p{margin:0;color:var(--muted,#a49bb0);line-height:1.45}
.rp .rp-community a{color:#ff8a3d;font-weight:600}
.rp label{display:grid;gap:6px;font-weight:600}
.rp textarea,.rp input[type=email]{font:inherit;padding:10px 12px;border-radius:10px;border:1px solid var(--line,#3a3346);background:var(--bg,var(--field,#faf7f3));color:inherit}
.rp textarea{min-height:110px;resize:vertical}
.rp .rp-check{display:flex;align-items:center;gap:8px;font-weight:500;color:var(--muted,#75697d)}.rp .rp-check input{width:auto;flex:none;margin:0}.rp h2{color:inherit}
.rp .rp-actions{display:flex;flex-wrap:wrap;gap:8px;justify-content:flex-end}.rp .rp-copy{margin-right:auto;font-weight:500}
.rp button{font:600 14px system-ui;border-radius:10px;padding:9px 16px;border:1px solid var(--line,#ddd);background:transparent;color:var(--text,#1d1a24);cursor:pointer}
.rp button.primary{background:linear-gradient(135deg,#ff5f3a,#ff8a3d 50%,#ffb347);border-color:transparent;color:#fff}
.rp button:disabled{opacity:.6;cursor:default}
.rp .rp-msg{font-weight:600}
.rp .rp-file{padding:10px 12px;border:1px dashed var(--line,#3a3346);border-radius:10px}.rp .rp-file button{margin:4px 0;padding:6px 12px}
.rp .rp-msg.ok{color:#3fd09a}.rp .rp-msg.err{color:#ff6b78}
`;
  function openReport(extra) {
    document.getElementById("auroebay-report")?.remove();
    if (!document.getElementById("auroebay-report-css")) {
      const style = document.createElement("style");
      style.id = "auroebay-report-css";
      style.textContent = CSS;
      document.head.append(style);
    }
    const dialog = document.createElement("dialog");
    dialog.id = "auroebay-report";
    dialog.className = "rp";
    dialog.innerHTML = `<form method="dialog">
      <h2>\u{1F198} Un souci avec AurOEBay ?</h2>
      <p>Explique simplement ce qui ne marche pas. Le message part directement, pas besoin de bo\xEEte e-mail.</p>
      <p class="rp-community">\u{1F4AC} Plut\xF4t une question ? <a href="${DISCORD_URL}" target="_blank" rel="noopener">Demande \xE0 la communaut\xE9 AurOEBay sur Discord \u2197</a></p>
      <label>Qu\u2019est-ce qui ne marche pas ?<textarea name="message" required maxlength="4000" placeholder="Ex. : quand je clique \xAB Cr\xE9er le brouillon \xBB, rien ne se passe."></textarea></label>
      <label>Une capture d\u2019\xE9cran (si tu veux)<input name="capture" type="file" accept="image/*"></label>
      <label>Ton e-mail, pour te r\xE9pondre (si tu veux)<input name="email" type="email" maxlength="200" placeholder="toi@exemple.fr"></label>
      <label class="rp-check"><input name="tech" type="checkbox" checked> Joindre le rapport technique (aucun mot de passe ni cl\xE9)</label>
      <p class="rp-msg" hidden></p>
      <p class="rp-file">\u{1F9FE} Pour aider quelqu\u2019un ou te faire aider : <button type="button" class="rp-download">\u{1F4E5} T\xE9l\xE9charger le rapport complet</button> puis envoie le fichier sur Discord (aucun mot de passe, cl\xE9, adresse ni acheteur dedans).</p>
      <div class="rp-actions"><button type="button" class="rp-copy" title="Pour le coller dans un message">\u{1F4CB} Copier le rapport</button><button type="button" value="cancel" class="rp-cancel">Annuler</button><button type="submit" class="primary">Envoyer</button></div>
    </form>`;
    document.body.append(dialog);
    const form = dialog.querySelector("form");
    const msg = dialog.querySelector(".rp-msg");
    const send = dialog.querySelector("button[type=submit]");
    const say = (text, kind = "") => {
      msg.hidden = false;
      msg.className = `rp-msg ${kind}`;
      msg.textContent = text;
    };
    dialog.querySelector(".rp-cancel").addEventListener("click", () => dialog.close());
    dialog.querySelector(".rp-copy").addEventListener("click", async () => {
      try {
        await navigator.clipboard.writeText(await technicalReport(extra ? await extra().catch(() => "") : void 0));
        say("\u{1F4CB} Rapport copi\xE9 (aucun mot de passe ni cl\xE9).", "ok");
      } catch {
        say("Copie impossible.", "err");
      }
    });
    dialog.querySelector(".rp-download").addEventListener("click", async (e) => {
      const b = e.currentTarget;
      b.disabled = true;
      say("Pr\xE9paration du rapport (tests de connexion compris)\u2026");
      try {
        await downloadReport(extra ? await extra().catch(() => "") : void 0);
        say("\u{1F4E5} Rapport t\xE9l\xE9charg\xE9 (dossier T\xE9l\xE9chargements) : envoie-le \xE0 la personne qui t\u2019aide.", "ok");
      } catch (err) {
        say(`Rapport impossible : ${err instanceof Error ? err.message : String(err)}`, "err");
      } finally {
        b.disabled = false;
      }
    });
    dialog.addEventListener("close", () => dialog.remove());
    form.addEventListener("submit", async (event) => {
      event.preventDefault();
      const text = form.elements.namedItem("message").value.trim();
      if (!text) return say("\xC9cris d\u2019abord ce qui ne marche pas.", "err");
      const file = form.elements.namedItem("capture").files?.[0];
      if (file && file.size > MAX_IMAGE) return say("Capture trop lourde (5 Mo au plus).", "err");
      send.disabled = true;
      say("Envoi\u2026");
      const version = chrome.runtime.getManifest().version;
      const tech = form.elements.namedItem("tech").checked ? await technicalReport(extra ? await extra().catch(() => "") : void 0).catch(() => "") : "";
      const body2 = new FormData();
      body2.set("form-name", "probleme");
      body2.set("bot-field", "");
      body2.set("message", text);
      body2.set("email", form.elements.namedItem("email").value.trim());
      body2.set("version", version);
      body2.set("rapport", tech);
      if (file) body2.set("capture", file, file.name);
      try {
        const r = await fetch(REPORT_URL, { method: "POST", body: body2, signal: AbortSignal.timeout(3e4) });
        if (!r.ok) throw Error(String(r.status));
        say("\u2705 Envoy\xE9, merci ! Tu auras une r\xE9ponse par e-mail si tu as laiss\xE9 ton adresse.", "ok");
        send.textContent = "Fermer";
        send.disabled = false;
        send.type = "button";
        send.addEventListener("click", () => dialog.close(), { once: true });
      } catch {
        try {
          await navigator.clipboard.writeText(`${text}

${tech}`);
        } catch {
        }
        window.open(
          `mailto:${SUPPORT_EMAIL}?subject=${encodeURIComponent(`AurOEBay ${version} : un probl\xE8me`)}&body=${encodeURIComponent(`${text}

(Le rapport est copi\xE9 : colle-le ici avec Cmd+V ou Ctrl+V.)`)}`,
          "_blank"
        );
        say("L\u2019envoi direct n\u2019a pas march\xE9 : un e-mail s\u2019ouvre, ton message y est d\xE9j\xE0 (colle le rapport avec Cmd+V ou Ctrl+V).", "err");
        send.disabled = false;
      }
    });
    dialog.showModal();
    form.elements.namedItem("message").focus();
  }

  // src/core/errorLog.ts
  function logToJournal(kind, what, text) {
    try {
      void chrome.runtime.sendMessage({ type: "LOG", kind, what, text: text.slice(0, 600) }).catch(() => {
      });
    } catch {
    }
  }
  var ownError = (stack) => {
    try {
      return stack.includes(`chrome-extension://${chrome.runtime.id}`);
    } catch {
      return false;
    }
  };
  var describe = (reason) => reason instanceof Error ? `${reason.message} ${reason.stack?.split("\n").slice(1, 3).map((l) => l.trim()).join(" ") ?? ""}` : String(reason);
  function watchErrors(extensionPage, win = window) {
    win.addEventListener("error", (e) => {
      const where = `${e.filename ?? ""} ${e.error instanceof Error ? e.error.stack ?? "" : ""}`;
      if (!extensionPage && !ownError(where)) return;
      if (/Extension context invalidated|ResizeObserver loop/i.test(e.message)) return;
      logToJournal("error", "page", `${e.message} (${String(e.filename ?? "").split("/").pop()}:${e.lineno})`);
    });
    win.addEventListener("unhandledrejection", (e) => {
      const text = describe(e.reason);
      if (!extensionPage && !ownError(e.reason instanceof Error ? e.reason.stack ?? "" : "")) return;
      if (/Extension context invalidated/i.test(text)) return;
      logToJournal("error", "page", text);
    });
  }
  function watchShownErrors(doc = document) {
    let last = "";
    const check = () => {
      const box = doc.getElementById("toast");
      if (!box || box.hidden || !box.classList.contains("error")) return;
      const text = (box.textContent ?? "").trim();
      if (text && text !== last) logToJournal("shown", "message", last = text);
    };
    const start2 = () => {
      const box = doc.getElementById("toast");
      if (!box) return;
      new MutationObserver(check).observe(box, { attributes: true, childList: true, characterData: true, subtree: true });
    };
    if (doc.readyState === "loading") doc.addEventListener("DOMContentLoaded", start2, { once: true });
    else start2();
  }

  // src/ui/theme.ts
  function setupTheme() {
    watchErrors(true);
    watchShownErrors();
    licenseBanner();
    updateBanner();
    simpleTopbar();
    const system = matchMedia("(prefers-color-scheme: dark)");
    const button = document.getElementById("theme-toggle");
    const choice = document.getElementById(
      "theme-choice"
    );
    let theme = "system";
    let revision = 0;
    const valid = (value) => value === "light" || value === "dark" ? value : "system";
    const render2 = () => {
      const dark = theme === "dark" || theme === "system" && system.matches;
      document.documentElement.dataset.theme = dark ? "dark" : "light";
      if (button) {
        button.textContent = dark ? "\u2600" : "\u263E";
        button.setAttribute("aria-pressed", String(dark));
        button.setAttribute(
          "aria-label",
          dark ? "Activer le mode clair" : "Activer le mode sombre"
        );
        button.title = button.getAttribute("aria-label");
      }
      if (choice) choice.value = theme;
    };
    const save2 = async (value) => {
      revision++;
      theme = value;
      render2();
      try {
        await chrome.storage.local.set({ uiTheme: value });
      } catch {
      }
    };
    button?.addEventListener(
      "click",
      () => void save2(
        document.documentElement.dataset.theme === "dark" ? "light" : "dark"
      )
    );
    choice?.addEventListener("change", () => void save2(valid(choice.value)));
    system.addEventListener("change", render2);
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "local" && changes.uiTheme) {
        revision++;
        theme = valid(changes.uiTheme.newValue);
        render2();
      }
    });
    const initial = revision;
    void chrome.storage.local.get("uiTheme").then(({ uiTheme }) => {
      if (revision === initial) theme = valid(uiTheme);
      render2();
    }).catch(() => render2());
    render2();
  }
  var PAGES = [
    ["routine.html", "\u2600\uFE0F Ma journ\xE9e"],
    ["dashboard.html", "\u{1F4E6} Mes produits"],
    ["scout.html", "\u{1F50D} Trouver"],
    ["sales.html", "\u{1F4D2} Ventes"]
  ];
  function simpleTopbar() {
    const bar = document.querySelector("header.topbar");
    const actions = bar?.querySelector(".top-actions");
    if (!bar || !actions || bar.querySelector(".ao-nav")) return;
    const here = location.pathname.split("/").pop() || "";
    if (here === "welcome.html") return;
    actions.querySelectorAll("a[href]").forEach((a) => {
      if (PAGES.some(([href]) => a.getAttribute("href") === href)) a.remove();
    });
    const nav = document.createElement("nav");
    nav.className = "ao-nav";
    nav.setAttribute("aria-label", "Pages d\u2019AurOEBay");
    for (const [href, label] of PAGES) {
      const a = document.createElement("a");
      a.href = href;
      a.textContent = label;
      if (href === here) {
        a.className = "on";
        a.setAttribute("aria-current", "page");
      }
      nav.append(a);
    }
    bar.querySelector(".brand")?.after(nav);
    bar.querySelector(".brand .crumb")?.remove();
    if (here !== "options.html") {
      const settings = document.createElement("a");
      settings.className = "btn ghost";
      settings.href = "options.html";
      settings.textContent = "\u2699\uFE0F Param\xE8tres";
      actions.append(settings);
    }
    const help = document.createElement("button");
    help.id = "help-report";
    help.type = "button";
    help.className = "btn ghost";
    help.textContent = "\u{1F198} Aide";
    help.title = "Un souci ? \xC9cris-nous, c\u2019est envoy\xE9 tout de suite";
    help.addEventListener("click", () => openReport());
    actions.append(help);
  }

  // src/core/backupExtras.ts
  var BACKUP_EXTRA_KEYS = [
    "taxRates:v1",
    "disputes:v1",
    "aliParcels:v1",
    "hiddenProducts:v1",
    "monthGoal:v1",
    "firstSale:v1",
    "watch:v1",
    "competitorSuppliers:v1",
    "productShipping:v1",
    "listingPrices:v1"
  ];
  function backupExtras(local2) {
    return Object.fromEntries(BACKUP_EXTRA_KEYS.flatMap((k) => local2[k] === void 0 ? [] : [[k, local2[k]]]));
  }

  // src/ui/backup.ts
  var STATUS = "backupStatus:v1";
  var MAIN_FILE = "auroebay-sauvegarde.json";
  var KEEP_DAYS = 14;
  var EVERY_MS = 6 * 36e5;
  async function fullBackup() {
    const local2 = await chrome.storage.local.get([
      "sales:v1",
      "listingSuppliers:v1",
      "variantPricing",
      "competitors:v1",
      "profitSettings:v1",
      "urssafDeclarations:v1",
      ...BACKUP_EXTRA_KEYS
    ]);
    return {
      format: "auroebay-full",
      version: 1,
      exportedAt: Date.now(),
      library: await message({ type: "LIBRARY", command: { action: "export" } }),
      sales: local2["sales:v1"] ?? {},
      listingSuppliers: local2["listingSuppliers:v1"] ?? {},
      variantPricing: local2.variantPricing ?? null,
      competitors: local2["competitors:v1"] ?? {},
      profitSettings: local2["profitSettings:v1"] ?? null,
      urssafDeclarations: local2["urssafDeclarations:v1"] ?? null,
      extras: backupExtras(local2)
    };
  }
  function db() {
    return new Promise((resolve, reject) => {
      const open = indexedDB.open("auroebay-backup", 1);
      open.onupgradeneeded = () => open.result.createObjectStore("kv");
      open.onsuccess = () => resolve(open.result);
      open.onerror = () => reject(open.error);
    });
  }
  async function kv(mode, value) {
    const d = await db();
    return new Promise((resolve, reject) => {
      const store = d.transaction("kv", mode === "get" ? "readonly" : "readwrite").objectStore("kv");
      const req = mode === "get" ? store.get("folder") : mode === "put" ? store.put(value, "folder") : store.delete("folder");
      req.onsuccess = () => resolve(mode === "get" ? req.result : void 0);
      req.onerror = () => reject(req.error);
    });
  }
  var backupFolder = () => kv("get").catch(() => void 0);
  async function backupStatus() {
    const status = (await chrome.storage.local.get(STATUS))[STATUS] ?? { at: null, folder: null };
    const handle = await backupFolder();
    return {
      ...status,
      folder: handle?.name ?? null,
      permission: handle ? await handle.queryPermission({ mode: "readwrite" }).catch(() => "denied") : "none"
    };
  }
  var writing = null;
  async function writeBackup(force = false) {
    if (writing) return writing;
    writing = (async () => {
      const handle = await backupFolder();
      if (!handle || await handle.queryPermission({ mode: "readwrite" }) !== "granted") return;
      const status = (await chrome.storage.local.get(STATUS))[STATUS] ?? {};
      if (!force && status.at && Date.now() - status.at < 6e4) return;
      try {
        const text = JSON.stringify(await fullBackup());
        const day3 = `auroebay-${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.json`;
        for (const name of [MAIN_FILE, day3]) {
          const file = await handle.getFileHandle(name, { create: true });
          const w = await file.createWritable();
          await w.write(text);
          await w.close();
        }
        const dated = [];
        for await (const name of handle.keys()) if (/^auroebay-\d{4}-\d{2}-\d{2}\.json$/.test(name)) dated.push(name);
        for (const old of dated.sort().slice(0, Math.max(0, dated.length - KEEP_DAYS)))
          await handle.removeEntry(old).catch(() => {
          });
        await chrome.storage.local.set({ [STATUS]: { at: Date.now(), folder: handle.name } });
      } catch (e) {
        await chrome.storage.local.set({
          [STATUS]: { ...status, folder: handle.name, error: e instanceof Error ? e.message : String(e) }
        });
      }
    })().finally(() => writing = null);
    return writing;
  }
  function setupAutoBackup(bar) {
    let timer;
    const refresh = async () => {
      const s = await backupStatus();
      bar.hidden = true;
      bar.replaceChildren();
      if (s.permission === "none") return;
      if (s.permission !== "granted") {
        const button = document.createElement("button");
        button.className = "btn small";
        button.type = "button";
        button.textContent = "R\xE9activer";
        button.addEventListener("click", async () => {
          const handle = await backupFolder();
          if (handle && await handle.requestPermission({ mode: "readwrite" }) === "granted") {
            await writeBackup(true);
            await refresh();
          }
        });
        bar.append(`Sauvegarde automatique en pause : Chrome demande d\u2019autoriser \xE0 nouveau le dossier \xAB ${s.folder} \xBB. `, button);
        bar.hidden = false;
        return;
      }
      if (!s.at || Date.now() - s.at > EVERY_MS) {
        await writeBackup(true);
      }
    };
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "local" || !(changes.libraryRevision || changes["sales:v1"] || changes["listingSuppliers:v1"] || changes["competitors:v1"] || changes["urssafDeclarations:v1"]))
        return;
      clearTimeout(timer);
      timer = setTimeout(() => void writeBackup(true), 2e4);
    });
    void refresh().catch(() => {
    });
    return { refresh };
  }

  // src/core/rivalSuppliers.ts
  var RIVAL_SUPPLIERS_KEY = "competitorSuppliers:v1";
  async function rivalSuppliersOn() {
    return message({ type: "PAGE_PREF", key: RIVAL_SUPPLIERS_KEY }).catch(() => true);
  }
  function rivalSuppliersToggle(doc, className = "rival-sup") {
    const label = doc.createElement("label");
    label.className = className;
    label.title = "Pendant la v\xE9rification, chercher le fournisseur AliExpress des nouvelles annonces (une \xE0 la fois, 20 au plus)";
    const box = doc.createElement("input");
    box.type = "checkbox";
    box.checked = true;
    label.append(box, " Chercher aussi les fournisseurs AliExpress");
    void rivalSuppliersOn().then((on) => box.checked = on);
    box.addEventListener("change", () => void message({ type: "PAGE_PREF", key: RIVAL_SUPPLIERS_KEY, value: box.checked }).catch(() => {
    }));
    try {
      const sync = (changes, area) => {
        if (!label.isConnected) return chrome.storage.onChanged.removeListener(sync);
        if (area === "local" && changes[RIVAL_SUPPLIERS_KEY]) box.checked = changes[RIVAL_SUPPLIERS_KEY].newValue !== false;
      };
      chrome.storage.onChanged.addListener(sync);
    } catch {
    }
    return label;
  }

  // src/core/health.ts
  var EBAY_SESSION_KEY = "ebaySession:v1";
  var ALI_REGION_KEY = "aliRegion:v1";
  function healthSummary(items) {
    const problems = items.filter((x) => !x.ok && !x.unknown).length;
    const unknown = items.filter((x) => x.unknown && !x.ok).length;
    return { problems, unknown, ok: problems === 0 };
  }

  // src/ui/health.ts
  var OPEN = "healthOpen:v1";
  function setupHealth(box) {
    let all = false;
    const row = (x) => `<li class="hc-item ${x.ok ? "ok" : x.unknown ? "unknown" : "bad"}"><span class="hc-dot">${x.ok ? "\u2705" : x.unknown ? "\u2754" : "\u26A0\uFE0F"}</span>
      <div><b>${escapeHTML(x.title)}</b><span>${escapeHTML(x.text)}</span></div>
      ${x.action && !x.ok ? `<a class="btn small ${x.unknown ? "" : "primary"}" href="${escapeHTML(x.action.href)}"${/^https:/.test(x.action.href) ? ' target="_blank" rel="noopener"' : ""}>${escapeHTML(x.action.label)}</a>` : ""}</li>`;
    const draw = async () => {
      const items = await message({ type: "HEALTH_CHECK" }).catch(() => null);
      if (!items) return void (box.hidden = true);
      const s = healthSummary(items);
      const shown = all ? items : items.filter((x) => !x.ok);
      box.hidden = false;
      box.className = `hc ${s.problems ? "bad" : s.unknown ? "unknown" : "ok"}`;
      box.innerHTML = `<div class="hc-head"><b>\u{1FA7A} Tout va bien ?</b><span>${s.problems ? `${s.problems} r\xE9glage${s.problems > 1 ? "s" : ""} \xE0 faire pour qu\u2019AurOEBay marche bien.` : s.unknown ? "Presque : il me reste \xE0 v\xE9rifier ce qui est en gris." : "Oui, tout est bien r\xE9gl\xE9."}</span><button type="button" class="link-button" id="hc-toggle">${all ? "Masquer le d\xE9tail" : "Voir tout"}</button></div>
      ${shown.length ? `<ul class="hc-list">${shown.map(row).join("")}</ul>` : ""}`;
      box.querySelector("#hc-toggle")?.addEventListener("click", () => {
        all = !all;
        try {
          localStorage.setItem(OPEN, all ? "1" : "");
        } catch {
        }
        void draw();
      });
    };
    try {
      all = localStorage.getItem(OPEN) === "1";
    } catch {
    }
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "local") return;
      if (Object.keys(changes).some((k) => /^(ebaySession|aliRegion|update|settings|variantPricing|backupStatus|license)/.test(k))) void draw();
    });
    document.addEventListener("visibilitychange", () => document.visibilityState === "visible" && void draw());
    void draw();
  }

  // src/core/firstSale.ts
  var FIRST_SALE_KEY = "firstSale:v1";
  var BEGINNER_URL = "https://auroebay.netlify.app/debuter.html";
  function firstSaleSteps(i) {
    const live2 = i.sales.filter((s) => s.status !== "cancelled");
    const ordered = live2.some((s) => purchases(s).length > 0 || !!s.manualCost);
    return [
      {
        id: "understand",
        title: "Comprendre le principe",
        what: "Le dropshipping : tu vends sur eBay un objet que tu n\u2019as pas ; quand un client l\u2019ach\xE8te, tu le commandes sur AliExpress et le fournisseur le livre directement chez ton client.",
        how: "Lis \xAB D\xE9buter de z\xE9ro \xBB (10 minutes) : ce que tu gagnes vraiment, ce qu\u2019il te faut (statut, compte eBay), les risques et un lexique.",
        done: i.understood,
        action: { label: "Lire \xAB D\xE9buter de z\xE9ro \xBB", href: BEGINNER_URL }
      },
      {
        id: "ebay",
        title: "Te connecter \xE0 ton compte vendeur eBay.com",
        what: "eBay.com, c\u2019est le site am\xE9ricain o\xF9 tu vas vendre. Il te faut un compte vendeur (avec ton identit\xE9 et ton compte bancaire).",
        how: "Ouvre ebay.com (pas ebay.fr) dans ce Chrome et connecte-toi. Pas encore de compte ? Cr\xE9e un compte professionnel (\xAB Business account \xBB) sur ebay.com/sl/sell.",
        done: i.ebaySignedIn === true,
        action: { label: "Ouvrir eBay.com", href: "https://www.ebay.com/" }
      },
      {
        id: "aliexpress",
        title: "R\xE9gler AliExpress en mode US",
        what: "AliExpress, c\u2019est l\xE0 que tu ach\xE8tes tes produits. En mode US (aliexpress.us, en dollars), tu vois les vrais prix et d\xE9lais vers tes clients am\xE9ricains.",
        how: "Ouvre aliexpress.us, connecte-toi, et choisis en haut \xE0 droite : United States, USD.",
        done: i.aliUS === true,
        action: { label: "Ouvrir AliExpress US", href: "https://www.aliexpress.us/" }
      },
      {
        id: "product",
        title: "Trouver un produit qui se vend d\xE9j\xE0",
        what: "Ne devine pas : copie ce qui marche. AurOEBay te montre des objets que d\u2019autres vendeurs vendent d\xE9j\xE0 sur eBay, avec leurs ventes.",
        how: "Clique \xAB Trouver des produits \xBB : choisis un objet vendu par plusieurs vendeurs, et ouvre son annonce eBay. Tu peux aussi, sur une recherche eBay, cliquer \xAB \u{1F3C6} Classer cette page par ventes \xBB.",
        done: i.products.length > 0,
        action: { label: "\u{1F50D} Trouver des produits", href: "scout.html" }
      },
      {
        id: "supplier",
        title: "Trouver son fournisseur AliExpress",
        what: "Le fournisseur, c\u2019est le vendeur AliExpress qui enverra l\u2019objet \xE0 ton client. AurOEBay le cherche par photo.",
        how: "Sur l\u2019annonce eBay, clique \xAB Trouver le fournisseur AliExpress \xBB : prends un r\xE9sultat \xAB \u{1F4F8} Photo exacte \xBB avec un bon b\xE9n\xE9fice, puis \xAB Enregistrer eBay + AliExpress \xBB pour le garder dans Mes produits.",
        done: i.products.some((p) => p.suppliers > 0),
        action: { label: "Voir Mes produits", href: "dashboard.html" }
      },
      {
        id: "draft",
        title: "Cr\xE9er ton annonce en brouillon",
        what: "Un brouillon, c\u2019est une annonce pr\xE9par\xE9e mais pas encore en ligne. AurOEBay la remplit : titre, photos, description, tailles et couleurs, prix rentable.",
        how: "Dans Mes produits, clique \xAB Cr\xE9er le brouillon \xBB (ou, sur l\u2019annonce eBay, \xAB Cr\xE9er un brouillon \xB7 AurOEBay \xBB). Choisis \xAB Rentable \xE0 X \u20AC \xBB : tape ce que tu veux gagner par vente, AurOEBay calcule le prix.",
        done: i.products.some((p) => p.draft || p.live),
        action: { label: "Cr\xE9er le brouillon", href: "dashboard.html" }
      },
      {
        id: "publish",
        title: "Publier ton annonce toi-m\xEAme",
        what: "Publier, c\u2019est mettre l\u2019annonce en ligne : les acheteurs peuvent la voir et l\u2019acheter. AurOEBay ne publie jamais \xE0 ta place.",
        how: "Ouvre ton brouillon sur eBay, v\xE9rifie tout (photos, prix, d\xE9lai de livraison), puis clique \xAB List it \xBB.",
        done: i.products.some((p) => p.live),
        action: { label: "Mes brouillons eBay", href: "https://www.ebay.com/sh/lst/drafts" }
      },
      {
        id: "sale",
        title: "Ta premi\xE8re vente",
        what: "Quand un client ach\xE8te, eBay t\u2019envoie un e-mail et la commande appara\xEEt dans ton Seller Hub. \xC7a peut prendre quelques jours ou quelques semaines : publie plusieurs produits.",
        how: "Ouvre la commande sur eBay (Seller Hub \u2192 Orders) : AurOEBay l\u2019enregistre tout seul dans Ventes.",
        done: live2.length > 0,
        action: { label: "Mes commandes eBay", href: "https://www.ebay.com/sh/ord" }
      },
      {
        id: "order",
        title: "Commander chez le fournisseur",
        what: "Tu ach\xE8tes l\u2019objet sur AliExpress avec l\u2019adresse de ton client : c\u2019est le fournisseur qui le lui envoie.",
        how: "Sur la commande eBay, clique \xAB \u{1F6D2} Commander sur AliExpress \xBB : la variante et l\u2019adresse sont pr\xEAtes. V\xE9rifie, puis paie toi-m\xEAme.",
        done: ordered,
        action: { label: "Mes commandes eBay", href: "https://www.ebay.com/sh/ord" }
      },
      {
        id: "tracking",
        title: "Mettre le num\xE9ro de suivi sur eBay",
        what: "Le num\xE9ro de suivi permet \xE0 ton client (et \xE0 eBay) de suivre le colis. eBay veut qu\u2019il soit mis vite.",
        how: "Quand AliExpress a exp\xE9di\xE9 (quelques jours), clique \xAB R\xE9cup\xE9rer et mettre les suivis \xBB dans Ma journ\xE9e, puis \xAB Save \xBB sur eBay.",
        done: live2.some((s) => !!s.tracking)
      }
    ];
  }
  var firstSaleDone = (steps2) => steps2.every((s) => s.done);

  // src/ui/firstSale.ts
  var opened = null;
  async function saved() {
    return (await chrome.storage.local.get(FIRST_SALE_KEY))[FIRST_SALE_KEY] ?? {};
  }
  async function save(patch) {
    await chrome.storage.local.set({ [FIRST_SALE_KEY]: { ...await saved(), ...patch } });
  }
  async function renderFirstSale(box, sales) {
    const [state, local2, products] = await Promise.all([
      saved(),
      chrome.storage.local.get([EBAY_SESSION_KEY, ALI_REGION_KEY]),
      message({ type: "LIBRARY", command: { action: "list" } }).catch(() => [])
    ]);
    const ebay = local2[EBAY_SESSION_KEY];
    const ali = local2[ALI_REGION_KEY];
    const steps2 = firstSaleSteps({
      understood: !!state.understood,
      ebaySignedIn: ebay ? !!ebay.signedIn : null,
      aliUS: ali ? !ali.problem : null,
      products: products.filter((p) => !p.archived).map((p) => ({ suppliers: p.suppliers.length, draft: p.ownListings.some((l) => l.kind === "draft"), live: p.ownListings.some((l) => l.kind === "item") })),
      sales
    });
    const finished = firstSaleDone(steps2);
    const foot = document.getElementById("fs-back");
    if (finished || state.hidden) {
      box.hidden = true;
      if (!finished && state.hidden && !foot) {
        const p = Object.assign(document.createElement("p"), { id: "fs-back", className: "rt-foot" });
        const b = Object.assign(document.createElement("button"), { type: "button", className: "link-button", textContent: "\u{1F3AF} R\xE9afficher le guide \xAB Ta premi\xE8re vente \xBB" });
        b.addEventListener("click", () => void save({ hidden: false }).then(() => renderFirstSale(box, sales)));
        p.append(b);
        box.after(p);
      }
      return;
    }
    foot?.remove();
    const done = steps2.filter((s) => s.done).length;
    const current = steps2.find((s) => !s.done);
    const open = opened && steps2.some((s) => s.id === opened) ? opened : current.id;
    box.hidden = false;
    box.innerHTML = `<header class="fs-head">
      <div><h2>\u{1F3AF} Ta premi\xE8re vente</h2><p>D\xE9butant ? Suis les \xE9tapes dans l\u2019ordre : elles se cochent toutes seules. <a href="${BEGINNER_URL}" target="_blank" rel="noopener">\u{1F4D6} D\xE9buter de z\xE9ro</a> \xB7 <a href="${BEGINNER_URL}#lexique" target="_blank" rel="noopener">Lexique</a></p></div>
      <div class="fs-score"><b>${done}/${steps2.length}</b><button type="button" class="link-button" id="fs-hide">Masquer</button></div>
    </header>
    <div class="fs-bar"><i style="width:${Math.round(done / steps2.length * 100)}%"></i></div>
    <ol class="fs-steps">${steps2.map((s, k) => {
      const isOpen = s.id === open;
      const buttons = [
        s.action ? `<a class="btn small ${s.id === current.id ? "primary" : ""}" href="${escapeHTML(s.action.href)}" ${/^https:/.test(s.action.href) ? 'target="_blank" rel="noopener"' : ""}>${escapeHTML(s.action.label)}${/^https:/.test(s.action.href) ? " \u2197" : ""}</a>` : "",
        s.id === "understand" && !s.done ? '<button type="button" class="btn small" data-understood>\u2713 J\u2019ai lu, c\u2019est compris</button>' : ""
      ].join("");
      return `<li class="${s.done ? "done" : s.id === current.id ? "now" : "later"}${isOpen ? " open" : ""}" data-step="${s.id}">
          <button type="button" class="fs-title"><span class="fs-n">${s.done ? "\u2713" : k + 1}</span>${escapeHTML(s.title)}</button>
          ${isOpen ? `<div class="fs-body"><p class="fs-what">${escapeHTML(s.what)}</p><p class="fs-how"><b>\xC0 faire :</b> ${escapeHTML(s.how)}</p>${buttons ? `<div class="fs-actions">${buttons}</div>` : ""}</div>` : ""}
        </li>`;
    }).join("")}</ol>`;
    box.querySelector("#fs-hide").addEventListener("click", () => void save({ hidden: true }).then(() => renderFirstSale(box, sales)));
    box.querySelector("[data-understood]")?.addEventListener("click", () => {
      opened = null;
      void save({ understood: true }).then(() => renderFirstSale(box, sales));
    });
    box.querySelectorAll(".fs-title").forEach(
      (b) => b.addEventListener("click", () => {
        const id = b.closest("li").dataset.step;
        opened = opened === id ? current.id : id;
        void renderFirstSale(box, sales);
      })
    );
  }

  // src/core/goal.ts
  var GOAL_KEY = "monthGoal:v1";
  function cleanGoal(x) {
    const v = x ?? {};
    const num = (n, max) => {
      const value = typeof n === "string" ? Number(n.replace(",", ".").trim() || NaN) : typeof n === "number" ? n : NaN;
      return Number.isFinite(value) && value >= 1 ? Math.min(max, Math.round(value)) : null;
    };
    return { sales: num(v.sales, 1e5), profit: num(v.profit, 1e7) };
  }
  var hasGoal = (g) => !!g && (g.sales !== null || g.profit !== null);
  var line = (done, target) => ({
    done,
    target,
    pct: Math.max(0, Math.min(100, Math.round(done / target * 100))),
    left: Math.max(0, Math.round((target - done) * 100) / 100)
  });
  function goalProgress(goal, sales, numbers, charges, now = Date.now()) {
    if (!hasGoal(goal)) return null;
    const d = new Date(now);
    const start2 = new Date(d.getFullYear(), d.getMonth(), 1).getTime();
    const end = new Date(d.getFullYear(), d.getMonth() + 1, 1).getTime();
    const days = Math.round((end - start2) / 864e5);
    const daysLeft = days - d.getDate() + 1;
    const month = live(sales).filter((s) => s.soldAt >= start2 && s.soldAt < end);
    let net = 0;
    let currency = "EUR";
    for (const s of month) {
      const n = numbers(s);
      currency = n.currency;
      if (n.complete && n.profit !== null) net += n.profit - charges(n.revenue ?? 0);
    }
    net = Math.round(net * 100) / 100;
    const salesLine = goal.sales !== null ? line(month.length, goal.sales) : null;
    const profitLine = goal.profit !== null ? line(net, goal.profit) : null;
    const money2 = (n) => n.toLocaleString("fr-FR", { style: "currency", currency, maximumFractionDigits: 0 });
    const expected = d.getDate() / days;
    const lines = [salesLine, profitLine].filter((l) => !!l);
    const reached = lines.every((l) => l.left === 0);
    const ahead = lines.every((l) => l.done >= l.target * expected);
    const weeks = Math.max(1, daysLeft / 7);
    const perWeek = (left) => Math.ceil(left / weeks);
    const missing = [
      salesLine && salesLine.left ? `${salesLine.left} vente${salesLine.left > 1 ? "s" : ""} (environ ${perWeek(salesLine.left)} par semaine)` : "",
      profitLine && profitLine.left ? `${money2(profitLine.left)} de b\xE9n\xE9fice net` : ""
    ].filter(Boolean);
    const text = reached ? "Objectif atteint ce mois-ci \u{1F389} Tout ce qui vient en plus est du bonus." : `Encore ${missing.join(" et ")} d\u2019ici la fin du mois (${daysLeft} jour${daysLeft > 1 ? "s" : ""}).${ahead ? " Tu es dans les temps \u{1F44D}" : " Ajoute des annonces : \xAB \u{1F50D} Trouver des produits \xBB."}`;
    return {
      month: d.toLocaleDateString("fr-FR", { month: "long" }),
      daysLeft,
      currency,
      sales: salesLine,
      profit: profitLine,
      text,
      tone: reached || ahead ? "ok" : "todo"
    };
  }
  var live = (sales) => sales.filter((s) => s.status !== "cancelled" && s.soldAt);

  // src/core/demo.ts
  var DAY7 = 864e5;
  var H = 36e5;
  var isDemo = (search) => new URLSearchParams(search).get("demo") === "1";
  var EXAMPLES = [
    { id: 1, title: "Silicone Solo Loop Watch Band for Apple Watch", variation: "Color: Black \xB7 Size: S", buyer: "mike_t2024", country: "United States", ago: 30 * H, price: 9.99 },
    { id: 2, title: "Mini LED Desk Lamp USB Rechargeable", variation: "Color: White", buyer: "sarah.home", country: "United States", ago: 3 * DAY7, price: 14.99, cost: 4.2, status: "shipped", aliTracking: "1ST06015360001", boughtAgo: 3 * DAY7 },
    { id: 3, title: "Car Dashboard Crack Repair Gel 60ml", buyer: "garage_joe", country: "United States", ago: 7 * DAY7, price: 12.49, cost: 3.1, aliTracking: "SPXDEM039711300003", aliStatus: "Processing", boughtAgo: 6.5 * DAY7 },
    { id: 4, title: "Fiber Optic Side Glow Cable 2m", buyer: "lightfan_88", country: "United States", ago: 52 * DAY7, price: 18.99, cost: 5.4, status: "shipped", aliTracking: "GFUS01081060000004", ebayTracking: "AP00100060000004", boughtAgo: 52 * DAY7 },
    { id: 5, title: "Silicone Solo Loop Watch Band for Apple Watch", variation: "Color: Pink \xB7 Size: M", buyer: "joli_shop", country: "Mexico", ago: 15 * DAY7, price: 9.99, quantity: 2, cost: 4.8, status: "shipped", aliTracking: "1ST06015350005", ebayTracking: "1ST06015350005", boughtAgo: 15 * DAY7 },
    { id: 6, title: "RC Plane Balance Stand CG Tool", buyer: "flyhigh_rc", country: "United States", ago: 4 * DAY7, price: 6.99, cost: 7.9, status: "shipped", aliTracking: "1ST06015360006", ebayTracking: "1ST06015360006", boughtAgo: 4 * DAY7 },
    { id: 7, title: "UV Resin Curing Lamp 9 LED", buyer: "crafty_ann", country: "United States", ago: 9 * DAY7, price: 11.99, cost: 3.6, status: "shipped", aliTracking: "9C1821J621007", ebayTracking: "9C1821J621007", boughtAgo: 9 * DAY7 },
    { id: 8, title: "Mini LED Desk Lamp USB Rechargeable", variation: "Color: Black", buyer: "desk_dan", country: "United States", ago: 11 * DAY7, price: 14.99, cost: 4.2, status: "shipped", aliTracking: "1ST06015340008", ebayTracking: "1ST06015340008", boughtAgo: 11 * DAY7 }
  ];
  var orderId = (n) => `00-00000-${String(n).padStart(5, "0")}`;
  var aliId = (n) => `30000000000000${String(n).padStart(2, "0")}`;
  var RATE = 0.86;
  var r2 = (n) => Math.round(n * 100) / 100;
  function demoSales(now = Date.now()) {
    return EXAMPLES.map((e) => {
      const quantity = e.quantity ?? 1;
      const total = r2(e.price * quantity);
      const fees = r2(total * RATE * 0.153 + 0.4 * RATE);
      const soldAt = now - e.ago;
      return {
        orderId: orderId(e.id),
        soldAt,
        buyer: e.buyer,
        country: e.country,
        items: [{ title: e.title, itemId: `99000000000${e.id}`, variation: e.variation ?? "", quantity, price: { amount: e.price, currency: "USD" }, sku: null, supplierId: null }],
        subtotal: { amount: total, currency: "USD" },
        shipping: { amount: 0, currency: "USD" },
        tax: null,
        orderTotal: { amount: total, currency: "USD" },
        fees: [{ label: "Fees", amount: { amount: -fees, currency: "EUR" } }],
        earnings: { amount: r2(total * RATE - fees), currency: "EUR" },
        rate: RATE,
        status: e.status ?? "to_ship",
        tracking: e.ebayTracking ?? "",
        supplier: e.cost !== void 0 ? {
          orderId: aliId(e.id),
          cost: { amount: e.cost, currency: "USD" },
          status: e.aliStatus ?? "Awaiting delivery",
          ...e.aliTracking && e.aliStatus !== "Processing" ? { tracking: e.aliTracking } : {},
          how: "auto",
          linkedAt: now - (e.boughtAgo ?? e.ago)
        } : null,
        manualCost: null,
        otherCost: 0,
        notes: "Exemple (d\xE9mo)",
        savedAt: soldAt,
        updatedAt: soldAt
      };
    });
  }
  function demoDisputes(now = Date.now()) {
    const respond = new Date(now + 2 * DAY7).toLocaleDateString("en-US", { month: "short", day: "numeric" });
    return [
      {
        key: "ebay:demo-return-5",
        source: "ebay",
        kind: "return",
        id: "5300000005",
        url: "https://www.ebay.com/sh/ord/return",
        orderId: orderId(5),
        open: true,
        status: "Provide a return shipping label",
        reason: "Doesn't fit",
        amount: { amount: 9.99, currency: "USD" },
        deadline: respond,
        updatedAt: now - 3 * H
      }
    ];
  }
  function demoParcels(now = Date.now()) {
    const placed = now - 52 * DAY7;
    return {
      at: now - 2 * H,
      items: {
        [aliId(4)]: {
          v: PARCEL_VERSION,
          orderId: aliId(4),
          status: "Awaiting delivery",
          placedAt: placed,
          disputeUntil: placed + 90 * DAY7,
          autoConfirmAt: now + 5 * DAY7,
          etaEnd: now - 12 * DAY7,
          refundIfNotBy: now - 4 * DAY7,
          lastEventAt: now - 16 * DAY7,
          lastEvent: "Package arrived at local carrier facility",
          delivered: false,
          closed: false,
          checkedAt: now - 2 * H
        }
      }
    };
  }
  var demoWatch = () => [{ productId: "demo-1", name: "Mini LED Desk Lamp USB Rechargeable", issues: 2 }];
  var demoRivals = (now = Date.now()) => [{ seller: "gadget_world_us", lastNew: 3, lastCheck: now - 3 * H }];

  // src/ui/routine.ts
  var DEMO = isDemo(location.search);
  var $ = (id) => document.getElementById(id);
  var toastTimer;
  function toast(text, error = false) {
    const t = $("toast");
    t.textContent = text;
    t.className = "toast" + (error ? " error" : "");
    t.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => t.hidden = true, 4e3);
  }
  var HIDDEN = "routineHidden:v1";
  var hidden = { items: [], tasks: {} };
  async function loadHidden() {
    const v = (await chrome.storage.local.get(HIDDEN))[HIDDEN];
    hidden = {
      items: Array.isArray(v?.items) ? v.items.slice(-500) : [],
      tasks: Object.fromEntries(Object.entries(v?.tasks ?? {}).filter(([, until]) => until > Date.now()))
    };
  }
  var saveHidden = () => chrome.storage.local.set({ [HIDDEN]: hidden });
  var tomorrow = () => {
    const d = /* @__PURE__ */ new Date();
    d.setDate(d.getDate() + 1);
    d.setHours(5, 0, 0, 0);
    return d.getTime();
  };
  var syncing = false;
  async function load() {
    if (DEMO) return loadDemo();
    await loadHidden();
    const [sales, watch, rivals, local2] = await Promise.all([
      message({ type: "SALES_LIST" }).catch(() => []),
      message({ type: "WATCH_STATE" }).catch(() => ({ results: {} })),
      message({ type: "COMPETITOR_LIST" }).catch(() => []),
      chrome.storage.local.get(["taxRates:v1", DISPUTES_KEY, PARCELS_KEY, GOAL_KEY])
    ]);
    const rate = latestRate(sales);
    const numbers = (s) => saleNumbers(s, rate);
    const taxes = local2["taxRates:v1"] ?? { urssaf: 12.3, impot: 1 };
    const charges = (revenue) => Math.round(revenue * (taxes.urssaf + taxes.impot)) / 100;
    const tasks = routineTasks({
      sales,
      numbers,
      charges,
      watch: Object.values(watch.results ?? {}).map((r) => ({
        productId: r.productId,
        name: r.name,
        issues: Array.isArray(r.issues) ? r.issues.length : 0,
        dismissed: r.dismissed,
        supplierUrl: r.supplierUrl
      })),
      rivals,
      hidden: new Set(hidden.items),
      parcels: local2[PARCELS_KEY]?.items ? local2[PARCELS_KEY] : { items: {}, at: 0 },
      disputes: Object.values(local2[DISPUTES_KEY]?.items ?? {})
    });
    render(tasks, sales.length);
    renderGoal(cleanGoal(local2[GOAL_KEY]), sales, numbers, charges);
    void renderFirstSale($("first-sale"), sales).catch(() => {
    });
  }
  function loadDemo() {
    const now = Date.now();
    const sales = demoSales(now);
    const numbers = (s) => saleNumbers(s, null);
    const tasks = routineTasks({
      sales,
      numbers,
      charges: (revenue) => Math.round(revenue * 13.3) / 100,
      watch: demoWatch(),
      rivals: demoRivals(now),
      disputes: demoDisputes(now),
      parcels: demoParcels(now)
    });
    render(tasks, sales.length);
    renderGoal({ sales: 10, profit: 150 }, sales, numbers, (revenue) => Math.round(revenue * 13.3) / 100);
  }
  function renderGoal(goal, sales, numbers, charges) {
    const box = $("goal");
    const p = goalProgress(goal, sales, numbers, charges);
    box.hidden = !p;
    if (!p) return box.replaceChildren();
    const money2 = (n) => n.toLocaleString("fr-FR", { style: "currency", currency: p.currency, maximumFractionDigits: 0 });
    const bar = (label, done, target, pct2) => `<div class="rt-goal-line"><div class="rt-goal-top"><span>${label}</span><b>${escapeHTML(done)} / ${escapeHTML(target)}</b></div><div class="rt-goal-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${pct2}"><i style="width:${pct2}%"></i></div></div>`;
    box.className = `rt-goal ${p.tone}`;
    box.innerHTML = `<header><h2>\u{1F3AF} Objectif de ${escapeHTML(p.month)}</h2><a class="link-button" href="options.html#goal-card" target="_blank" rel="noopener">Modifier</a></header>
    ${p.sales ? bar("Ventes", String(p.sales.done), String(p.sales.target), p.sales.pct) : ""}
    ${p.profit ? bar("B\xE9n\xE9fice net (apr\xE8s URSSAF)", money2(p.profit.done), money2(p.profit.target), p.profit.pct) : ""}
    <p class="rt-hint">${escapeHTML(p.text)}</p>`;
  }
  function render(all, salesCount) {
    const skipped = all.filter((t) => hidden.tasks[t.id]);
    const tasks = all.filter((t) => !hidden.tasks[t.id]);
    const todo = tasks.filter((t) => t.tone !== "ok");
    const hot = tasks.filter((t) => t.tone === "hot").length;
    const date = (/* @__PURE__ */ new Date()).toLocaleDateString("fr-FR", { weekday: "long", day: "numeric", month: "long" });
    const hour = (/* @__PURE__ */ new Date()).getHours();
    const hello = hour < 12 ? "Bonjour \u2600\uFE0F" : hour < 18 ? "Bon apr\xE8s-midi \u{1F324}\uFE0F" : "Bonsoir \u{1F319}";
    $("hero").innerHTML = `<div class="rt-sun" aria-hidden="true"><span class="ao-mark"></span></div>
    <div><p class="rt-date">${escapeHTML(date.charAt(0).toUpperCase() + date.slice(1))}</p>
    <h1>${hello}</h1>
    <p class="rt-sum">${todo.length ? `<b>${todo.length}</b> chose${todo.length > 1 ? "s" : ""} \xE0 faire aujourd\u2019hui${hot ? ` dont <b class="hot">${hot} urgente${hot > 1 ? "s" : ""}</b>` : ""}.` : salesCount ? "Tout est \xE0 jour. Belle journ\xE9e !" : "Pas encore de vente : suis le guide \xAB \u{1F3AF} Ta premi\xE8re vente \xBB juste en dessous, \xE9tape par \xE9tape."}</p>${!salesCount && !DEMO ? '<p class="rt-sum"><a class="btn small" href="routine.html?demo=1">\u{1F440} Voir une d\xE9mo avec des ventes d\u2019exemple</a></p>' : ""}</div>`;
    const grid = $("tasks");
    grid.replaceChildren(
      ...tasks.map((t, i) => {
        const card = document.createElement("article");
        card.className = `rt-card ${t.tone}`;
        card.dataset.task = t.id;
        card.style.animationDelay = `${i * 0.05}s`;
        card.innerHTML = `<header><span class="rt-icon">${t.icon}</span><h2>${escapeHTML(t.title)}</h2><b class="rt-count">${t.tone === "ok" ? "\u2713" : t.count}</b>${t.tone === "ok" ? "" : '<button type="button" class="rt-skip" title="Masquer cette carte jusqu\u2019\xE0 demain">Masquer</button>'}</header>
        <p class="rt-hint">${escapeHTML(t.id === "tracking" && syncing ? "V\xE9rification des suivis d\xE9j\xE0 sur eBay\u2026" : t.hint)}</p>
        ${t.items.length ? `<ul>${t.items.map((it) => `<li>${it.image && /^https:\/\//.test(it.image) ? `<img class="rt-thumb" src="${escapeHTML(it.image)}" alt="" loading="lazy" referrerpolicy="no-referrer">` : ""}<div>${it.href ? `<a href="${escapeHTML(it.href)}" target="_blank" rel="noopener">${escapeHTML(it.text)}</a>` : `<span>${escapeHTML(it.text)}</span>`}${it.sub ? `<small>${escapeHTML(it.sub)}</small>` : ""}${it.links?.length ? `<span class="rt-links">${it.links.map((l) => `<a href="${escapeHTML(l.href)}" target="_blank" rel="noopener">${escapeHTML(l.label)} \u2197</a>`).join("")}</span>` : ""}${it.extra ? `<a class="rt-extra" href="${escapeHTML(it.extra.href)}" target="_blank" rel="noopener">\u{1F6E1}\uFE0F ${escapeHTML(it.extra.label)} \u2197</a>` : ""}</div><button type="button" class="rt-x" data-key="${escapeHTML(it.key)}" title="Masquer (d\xE9j\xE0 trait\xE9)">\u2715</button></li>`).join("")}</ul>` : ""}
        ${t.more ? `<p class="rt-more">\u2026 et ${t.more} autre(s)</p>` : ""}`;
        card.querySelector(".rt-skip")?.addEventListener("click", () => {
          hidden.tasks[t.id] = tomorrow();
          void saveHidden().then(load);
        });
        card.querySelectorAll(".rt-x").forEach(
          (x) => x.addEventListener("click", () => {
            hidden.items = [...hidden.items.filter((k) => k !== x.dataset.key), x.dataset.key];
            x.closest("li")?.classList.add("rt-gone");
            setTimeout(() => void saveHidden().then(load), 250);
          })
        );
        if (t.action) {
          const b = document.createElement("button");
          b.type = "button";
          b.className = "btn small " + (t.tone === "ok" ? "" : "primary");
          b.textContent = t.action.label;
          b.addEventListener("click", () => void act(t, b));
          card.append(b);
          if (t.action.kind === "rivals") card.append(rivalSuppliersToggle(document));
        }
        return card;
      })
    );
    const quiet = tasks.filter((t) => t.tone === "ok");
    const line2 = document.getElementById("rt-quiet") ?? Object.assign(document.createElement("p"), { id: "rt-quiet", className: "rt-quiet" });
    grid.before(line2);
    line2.hidden = !quiet.length || !salesCount;
    let openQuiet = false;
    try {
      openQuiet = localStorage.getItem("routineQuietOpen") === "1";
    } catch {
    }
    grid.classList.toggle("show-ok", openQuiet);
    line2.innerHTML = `<span>\u2705 Rien \xE0 faire aujourd\u2019hui pour :</span> ${quiet.map((t) => `<b>${t.icon} ${escapeHTML(t.title)}</b>`).join(" ")} <button type="button" class="link-button">${openQuiet ? "Masquer" : "Voir"}</button>`;
    line2.querySelector("button")?.addEventListener("click", () => {
      try {
        localStorage.setItem("routineQuietOpen", grid.classList.contains("show-ok") ? "" : "1");
      } catch {
      }
      grid.classList.toggle("show-ok");
      line2.querySelector("button").textContent = grid.classList.contains("show-ok") ? "Masquer" : "Voir";
    });
    const foot = document.getElementById("skipped") ?? Object.assign(document.createElement("p"), { id: "skipped", className: "rt-foot" });
    grid.after(foot);
    foot.replaceChildren();
    if (skipped.length || hidden.items.length) {
      foot.append(
        [
          skipped.length ? `Masqu\xE9 jusqu\u2019\xE0 demain : ${skipped.map((t) => t.title).join(", ")}` : "",
          hidden.items.length ? `${hidden.items.length} \xE9l\xE9ment(s) masqu\xE9(s)` : ""
        ].filter(Boolean).join(" \xB7 ") + " \xB7 "
      );
      const back = Object.assign(document.createElement("button"), { type: "button", className: "link-button", textContent: "Tout r\xE9afficher" });
      back.addEventListener("click", () => {
        hidden = { items: [], tasks: {} };
        void saveHidden().then(load);
      });
      foot.append(back);
    }
  }
  async function act(task, button) {
    const kind = task.action?.kind;
    if (DEMO) return toast("D\xE9mo : rien n\u2019est lu ni envoy\xE9. Sur tes vraies ventes, ce bouton fait le travail.");
    if (kind === "sales") return void chrome.tabs.create({ url: chrome.runtime.getURL("sales.html") });
    if (kind === "disputes") {
      button.disabled = true;
      button.innerHTML = '<span class="ao-spinner"></span> Lecture eBay et AliExpress\u2026';
      try {
        const store = await message({ type: "DISPUTES_SYNC" });
        if (store.errors?.length) toast(`Synchro partielle : ${store.errors.join(" ")}`, true);
      } catch (e) {
        toast(String(e instanceof Error ? e.message : e), true);
      }
      return void load();
    }
    if (kind === "parcels") {
      button.disabled = true;
      button.innerHTML = '<span class="ao-spinner"></span> Ouverture d\u2019AliExpress\u2026';
      const watch = (changes, area) => {
        const run = area === "session" ? changes["parcelRun:v1"]?.newValue : void 0;
        if (run?.total) button.innerHTML = `<span class="ao-spinner"></span> Lecture AliExpress\u2026 ${run.done}/${run.total}`;
      };
      chrome.storage.onChanged.addListener(watch);
      try {
        const store = await message({ type: "PARCELS_REFRESH", force: true });
        if (store.error) toast(store.error, true);
        else toast("Colis v\xE9rifi\xE9s sur AliExpress.");
      } catch (e) {
        toast(String(e instanceof Error ? e.message : e), true);
      } finally {
        chrome.storage.onChanged.removeListener(watch);
      }
      return void load();
    }
    if (kind === "rivals")
      return void message({ type: "COMPETITOR_OPEN" }).catch((e) => toast(String(e instanceof Error ? e.message : e), true));
    if (kind === "trackings") {
      button.disabled = true;
      button.innerHTML = '<span class="ao-spinner"></span> Lecture AliExpress\u2026';
      try {
        await message({ type: "ALI_TRACKINGS_REFRESH" });
        const sales = await message({ type: "SALES_LIST" });
        const ids = sales.filter((s) => trackingsToSend(s).length).map((s) => s.orderId).slice(0, 30);
        if (ids.length) {
          await message({ type: "OPEN_EBAY_TRACKING", orderIds: ids });
          toast(`Page eBay des suivis ouverte (${ids.length} commande(s)) : v\xE9rifie puis \xAB Save \xBB.`);
        } else toast("Aucun nouveau suivi \xE0 mettre sur eBay pour l\u2019instant.");
      } catch (e) {
        toast(String(e instanceof Error ? e.message : e), true);
      } finally {
        await load();
      }
    }
  }
  setupTheme();
  setupAutoBackup($("backup-bar"));
  if (DEMO) setupDemo();
  else setupHealth($("health"));
  $("refresh").addEventListener("click", () => void load());
  chrome.storage.onChanged.addListener((changes, area) => {
    if (!DEMO && area === "local" && (changes["sales:v1"] || changes["watch:v1"] || changes["competitors:v1"] || changes[GOAL_KEY]) && !syncing) void load();
  });
  function setupDemo() {
    const bar = Object.assign(document.createElement("div"), { className: "demo-bar" });
    bar.innerHTML = `<b>\u{1F440} Mode d\xE9mo</b> <span>Ventes, litiges et colis d\u2019exemple : rien n\u2019est enregistr\xE9, lu ni envoy\xE9.</span> <a class="btn small" href="sales.html?demo=1">Voir les ventes (d\xE9mo)</a> <a class="btn small primary" href="routine.html">Quitter la d\xE9mo</a>`;
    document.querySelector("main").prepend(bar);
    document.addEventListener(
      "click",
      (e) => {
        const target = e.target.closest("a, button");
        if (!target || target.closest(".demo-bar, .topbar")) return;
        if (target.matches(".rt-skip, .rt-x, a")) {
          e.preventDefault();
          e.stopPropagation();
          toast("D\xE9mo : exemple seulement. Sur tes vraies ventes, ce lien ouvre eBay ou AliExpress.");
        }
      },
      true
    );
  }
  async function start() {
    await load();
    if (DEMO) return;
    syncing = true;
    await load();
    try {
      const r = await message({ type: "EBAY_TRACKINGS_SYNC" });
      if (r.updated) toast(`${r.updated} suivi(s) d\xE9j\xE0 sur eBay pris en compte.`);
    } catch {
    } finally {
      syncing = false;
      await load();
    }
  }
  void start().catch((e) => toast(String(e instanceof Error ? e.message : e), true));
})();
