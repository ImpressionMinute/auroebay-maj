"use strict";
(() => {
  // src/ui/offscreen.ts
  var urls = [];
  chrome.runtime.onMessage.addListener((msg, sender, reply) => {
    if (sender.id !== chrome.runtime.id) return;
    if (msg?.type === "OFFSCREEN_BACKUP_URL" && typeof msg.text === "string") {
      const url = URL.createObjectURL(new Blob([msg.text], { type: "application/json" }));
      urls.push(url);
      reply({ url });
      return;
    }
    if (msg?.type === "OFFSCREEN_RELEASE") {
      for (const url of urls.splice(0)) URL.revokeObjectURL(url);
      reply({ ok: true });
    }
  });
})();
