"use strict";
(() => {
  // src/core/messaging.ts
  var STALE_PAGE = "AurOEBay a \xE9t\xE9 mis \xE0 jour pendant que cette page \xE9tait ouverte : recharge-la (Cmd + R), puis recommence.";
  async function message(body2) {
    let reply;
    try {
      reply = await chrome.runtime.sendMessage(body2);
    } catch (e) {
      const text = e instanceof Error ? e.message : String(e);
      throw Error(/context invalidated|Receiving end does not exist|message port closed/i.test(text) ? STALE_PAGE : text);
    }
    if (!reply?.ok)
      throw Error(reply?.error ?? "AurOEBay ne r\xE9pond pas. Recharge la page.");
    return reply.data;
  }

  // src/core/license.ts
  var LICENSE_KEY = "license:v1";
  var CHECKOUT_URL = "https://auroebay.lemonsqueezy.com/checkout/buy/1b765c13-2f39-4847-82fa-e7950d112d63";
  var TRIAL_DAYS = 15;
  var CODE_MAX_DAYS = 93;
  var MANAGE_URL = "https://app.lemonsqueezy.com/my-orders";
  var GRACE_DAYS = 3;
  var DAY = 864e5;
  var OWNER_EXTENSION_ID = "bbedjpfnnkjadfjpbbmppikmgocoglfh";
  var SKEW = 10 * 6e4;
  var extensionId = () => globalThis.chrome?.runtime?.id ?? "";
  var ownerInstall = () => extensionId() === OWNER_EXTENSION_ID;
  function licenseActive(s, now = Date.now()) {
    if (!s) return false;
    if (s.owner) return ownerInstall();
    if (s.status === "trial") return trialActive(s, now);
    if (!s.key || s.status !== "active" || !s.checkedAt) return false;
    if (s.checkedAt > now + SKEW || (s.triedAt ?? 0) > now + SKEW) return false;
    if (typeof s.expiresAt === "string" && Date.parse(s.expiresAt) < now - DAY) return false;
    return now - s.checkedAt < GRACE_DAYS * DAY;
  }
  var PEPPER = "AurOEBay\xB7licence\xB7v1\xB74f1c9e27b8d36a05";
  var SEALED = ["owner", "key", "instanceId", "status", "checkedAt", "triedAt", "email", "expiresAt", "error", "trialUntil", "trialId"];
  async function hmac(text) {
    const enc = new TextEncoder();
    const raw = await crypto.subtle.digest("SHA-256", enc.encode(PEPPER + "|" + extensionId()));
    const key = await crypto.subtle.importKey("raw", raw, { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
    const sig = await crypto.subtle.sign("HMAC", key, enc.encode(text));
    return [...new Uint8Array(sig)].map((b) => b.toString(16).padStart(2, "0")).join("");
  }
  var body = (s) => JSON.stringify(SEALED.map((k) => s[k] ?? null));
  async function sealValid(s) {
    if (!s || typeof s.seal !== "string") return false;
    try {
      return s.seal === await hmac(body(s));
    } catch {
      return false;
    }
  }
  async function trustedLicense(raw) {
    const s = raw && typeof raw === "object" ? raw : {};
    if (await sealValid(s)) return { state: s, sealed: true };
    if (s.owner === true && ownerInstall()) return { state: { owner: true }, sealed: false };
    if (typeof s.key === "string" && typeof s.instanceId === "string")
      return { state: { key: s.key, instanceId: s.instanceId, status: "unverified" }, sealed: false };
    return { state: {}, sealed: false };
  }
  async function readLicense() {
    const raw = (await chrome.storage.local.get(LICENSE_KEY))[LICENSE_KEY];
    return (await trustedLicense(raw)).state;
  }
  function cleanLicenseInput(raw) {
    const flat = String(raw ?? "").replace(/[\u200B-\u200D\u2060\uFEFF\u00AD]/g, "").replace(/[\s`'"«»“”‘’<>]/g, "");
    const trial = flat.match(/ESSAI[-‐‑–—]?([A-Za-z0-9_-]{8,400})\.([A-Za-z0-9_-]{86})/i) ?? flat.match(/ESSAI[-‐‑–—]?([A-Za-z0-9_-]{8,400})\.([A-Za-z0-9_-]{40,200})/i);
    return trial ? `ESSAI-${trial[1]}.${trial[2]}` : flat;
  }
  var GIFT_CODES = [
    // An owner's friend, 2 months (11/11/2026 → 10/01/2027).
    { hash: "17d203ba3126fbb6d37dd5140799c68f5b838f94e15027b54a99ce12b10724bc", until: Date.UTC(2027, 0, 10, 22, 59) }
  ];
  var giftCodeText = (raw) => {
    const t = String(raw ?? "").toUpperCase().replace(/[^A-Z0-9]/g, "");
    return /^AURO[2-9A-HJKMNP-Z]{8}$/.test(t) ? t : null;
  };
  var isTrialCode = (text) => /^ESSAI-/i.test(cleanLicenseInput(text)) || !!giftCodeText(text);
  function trialActive(s, now = Date.now()) {
    if (typeof s.trialUntil !== "number" || now >= s.trialUntil) return false;
    if ((s.checkedAt ?? 0) > now + SKEW) return false;
    return s.trialUntil - now <= (CODE_MAX_DAYS + 1) * DAY;
  }
  var trialDaysLeft = (s, now = Date.now()) => s?.status === "trial" && trialActive(s, now) ? Math.ceil((s.trialUntil - now) / DAY) : 0;
  function licenseLabel(s, now = Date.now()) {
    if (s?.owner) return "Version propri\xE9taire : aucune licence n\xE9cessaire.";
    if (s?.status === "trial" && trialActive(s, now)) {
      const left = trialDaysLeft(s, now);
      const end = new Date(s.trialUntil).toLocaleDateString("fr-FR", { day: "numeric", month: "long" });
      return `Essai gratuit : encore ${left} jour${left > 1 ? "s" : ""} (jusqu\u2019au ${end}). Abonne-toi avant pour continuer sans coupure.`;
    }
    if (s?.status === "trial" || s?.status === "trial-ended") return "Ton essai gratuit est termin\xE9 : abonne-toi pour continuer. Tes donn\xE9es sont gard\xE9es.";
    if (!s?.key) return `Aucune cl\xE9 de licence : commence ton essai gratuit de ${TRIAL_DAYS} jours, puis colle la cl\xE9 re\xE7ue par e-mail.`;
    if (licenseActive(s, now)) return `Abonnement actif${s.email ? ` (${s.email})` : ""}.`;
    if (s.status === "unverified") return s.error ? `${s.error} Ta licence sera v\xE9rifi\xE9e d\xE8s le retour de la connexion.` : "V\xE9rification de ta licence aupr\xE8s de Lemon Squeezy\u2026";
    if (s.status === "active") return "Impossible de v\xE9rifier ta licence depuis plus de 3 jours : v\xE9rifie ta connexion internet.";
    if (s.status === "expired") return "Abonnement termin\xE9 : renouvelle-le pour r\xE9activer AurOEBay.";
    if (s.status === "disabled") return "Licence d\xE9sactiv\xE9e : contacte bonjour@impression-minute.fr.";
    return s.error ?? "Licence inactive.";
  }
  function versionBelow(version, than) {
    if (!version) return false;
    const a = version.split(".").map(Number);
    const b = than.split(".").map(Number);
    for (let i = 0; i < 3; i++) if ((a[i] ?? 0) !== (b[i] ?? 0)) return (a[i] ?? 0) < (b[i] ?? 0);
    return false;
  }

  // src/core/text.ts
  var compact = (s) => s.replace(/\s+/g, " ").trim();
  var norm = (s) => compact(s.normalize("NFKC")).toLowerCase().replace(/[\s\W_]+/g, " ").trim();
  var escapeHTML = (s) => s.replace(
    /[&<>"']/g,
    (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]
  );
  function redact(s) {
    return s.replace(/\bsk-[A-Za-z0-9_-]+/g, "[REDACTED_KEY]").replace(/Bearer\s+\S+/gi, "Bearer [REDACTED]").replace(/[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}/g, "[EMAIL]").replace(/https?:\/\/[^\s<>"']+/g, "[URL]");
  }

  // src/ui/license.ts
  var read = () => message({ type: "LICENSE_STATE" }).catch(() => readLicense());
  function licenseBox(root) {
    const draw = async (note = "", error = false) => {
      const s = await read();
      const on = licenseActive(s);
      root.innerHTML = `
      <p class="lic-status ${on ? "ok" : "off"}">${on ? "\u2705" : "\u{1F512}"} ${escapeHTML(licenseLabel(s))}</p>
      ${s.owner ? "" : `
      <div class="lic-row">
        <input id="lic-key" placeholder="Colle ta cl\xE9 de licence, ton code d\u2019essai ou tape ton code cadeau" autocomplete="off" spellcheck="false" value="" />
        <button type="button" class="btn primary" id="lic-go">${s.key && on ? "Changer de cl\xE9" : "Activer"}</button>
      </div>
      <p class="lic-links">
        ${on && s.status !== "trial" ? "" : `<a class="btn small secondary" href="${CHECKOUT_URL}" target="_blank" rel="noopener">${s.key || s.status?.startsWith("trial") ? "S\u2019abonner \xB7 9,99 \u20AC/mois" : `Essai gratuit ${TRIAL_DAYS} jours`}</a>`}
        ${s.key ? `<a class="btn small secondary" href="${MANAGE_URL}" target="_blank" rel="noopener">G\xE9rer mon abonnement \u2197</a>
        <button type="button" class="btn small secondary" id="lic-check">V\xE9rifier maintenant</button>
        <button type="button" class="btn small secondary" id="lic-release" title="Pour utiliser ta cl\xE9 sur un autre ordinateur (2 au plus)">Lib\xE9rer cette cl\xE9</button>` : ""}
      </p>`}
      ${note ? `<p class="lic-note${error ? " err" : ""}">${escapeHTML(note)}</p>` : ""}`;
    };
    root.addEventListener("keydown", (e) => {
      if (e.key === "Enter" && e.target.id === "lic-key") {
        e.preventDefault();
        root.querySelector("#lic-go")?.click();
      }
    });
    root.addEventListener("click", async (e) => {
      const t = e.target;
      const run = async (button, job, done) => {
        button.disabled = true;
        try {
          await job();
          await draw(done);
        } catch (err) {
          await draw(err instanceof Error ? err.message : String(err), true);
        }
      };
      if (t.id === "lic-go") {
        const key = root.querySelector("#lic-key").value;
        await run(t, () => message({ type: "LICENSE_ACTIVATE", key }), isTrialCode(key) ? "Essai activ\xE9 : AurOEBay est pr\xEAt \u2713" : "Licence activ\xE9e : AurOEBay est pr\xEAt \u2713");
      } else if (t.id === "lic-check") await run(t, () => message({ type: "LICENSE_REFRESH" }), "V\xE9rifi\xE9 aupr\xE8s de Lemon Squeezy.");
      else if (t.id === "lic-release" && confirm("Lib\xE9rer la cl\xE9 sur ce navigateur ? AurOEBay se mettra en pause ici jusqu\u2019\xE0 ce que tu la remettes."))
        await run(t, () => message({ type: "LICENSE_RELEASE" }), "Cl\xE9 lib\xE9r\xE9e : tu peux l\u2019activer sur un autre ordinateur.");
    });
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "local" && changes[LICENSE_KEY] && !root.contains(document.activeElement)) void draw();
    });
    void draw();
  }
  function licenseBanner(doc = document) {
    if (/\/(welcome|options)\.html$/.test(location.pathname)) return;
    const show = async () => {
      doc.getElementById("lic-banner")?.remove();
      const s = await read();
      const left = trialDaysLeft(s);
      if (left > 0 && left <= 3) {
        const note = doc.createElement("div");
        note.id = "lic-banner";
        note.className = "lic-banner";
        note.innerHTML = `<span>\u23F3 ${escapeHTML(licenseLabel(s))}</span>
        <span><a class="btn small primary" href="${CHECKOUT_URL}" target="_blank" rel="noopener">S\u2019abonner</a> <a class="btn small secondary" href="welcome.html">Entrer ma cl\xE9</a></span>`;
        doc.body.prepend(note);
        return;
      }
      if (licenseActive(s)) return;
      const bar = doc.createElement("div");
      bar.id = "lic-banner";
      bar.className = "lic-banner";
      bar.innerHTML = `<span>\u{1F512} ${escapeHTML(licenseLabel(s))} AurOEBay est en pause ; tes donn\xE9es restent ici.</span>
      <span><a class="btn small primary" href="welcome.html">Entrer ma cl\xE9</a> <a class="btn small secondary" href="${CHECKOUT_URL}" target="_blank" rel="noopener">${s.key || s.status?.startsWith("trial") ? "S\u2019abonner" : `Essai gratuit ${TRIAL_DAYS} jours`}</a></span>`;
      doc.body.prepend(bar);
    };
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "local" && changes[LICENSE_KEY]) void show();
    });
    void show().catch(() => {
    });
  }

  // src/core/update.ts
  var UPDATE_KEY = "update:v1";
  var VERSION_URL = "https://auroebay.netlify.app/version.json";
  var MIRROR = "https://raw.githubusercontent.com/ImpressionMinute/auroebay-maj/main/";
  var VERSION_URLS = [VERSION_URL, MIRROR + "version.json"];
  var UPDATE_GUIDE_URL = "https://auroebay.netlify.app/mise-a-jour.html";
  var UPDATE_EVERY_MS = 24 * 36e5;
  var UPDATE_RECHECK_MS = 2 * 6e4;
  var WHATS_NEW_KEY = "whatsNew:v1";
  var NEWS_URL = "https://auroebay.netlify.app/nouveautes.html";
  var MAC_COMMAND = `curl -fsSL ${MIRROR}maj-mac.sh | bash`;
  var WINDOWS_COMMAND = `powershell -ExecutionPolicy Bypass -c "[Net.ServicePointManager]::SecurityProtocol=3072;irm ${MIRROR}maj-windows.ps1|iex"`;
  var DISK_WAIT_KEY = "updateOnDisk:v1";
  var SITE = "https://auroebay.netlify.app/";
  function cleanNotes(value) {
    if (!Array.isArray(value)) return [];
    return value.filter((n) => typeof n === "string").map((n) => n.replace(/\s+/g, " ").trim().slice(0, 240)).filter(Boolean).slice(0, 8);
  }
  function parseReleaseNotes(value) {
    if (!Array.isArray(value)) return [];
    return value.flatMap((r) => {
      const v = r;
      if (typeof v?.version !== "string" || !/^\d{1,4}\.\d{1,5}\.\d{1,6}$/.test(v.version)) return [];
      const notes = cleanNotes(v.notes);
      return notes.length ? [{ version: v.version, date: typeof v.date === "string" ? v.date.slice(0, 10) : "", notes }] : [];
    });
  }
  function parseVersionFile(value) {
    const v = value;
    if (typeof v?.version !== "string" || !/^\d{1,4}\.\d{1,5}\.\d{1,6}$/.test(v.version)) return null;
    if (typeof v.url !== "string" || !(v.url.startsWith(SITE) || v.url.startsWith(MIRROR)) || /["'<>\s]/.test(v.url)) return null;
    return { latest: v.version, url: v.url, notes: cleanNotes(v.notes) };
  }
  function updateAvailable(info, current) {
    return !!info?.latest && !!info.url && versionBelow(current, info.latest);
  }

  // src/ui/update.ts
  var DISMISSED = "updateDismissed:v1";
  var isWindows = () => /Windows/i.test(navigator.userAgent);
  function steps() {
    return isWindows() ? `<ol class="upd-steps"><li>Clique <b>Copier</b>.</li><li>Appuie sur les touches <kbd>\u229E Windows</kbd> + <kbd>R</kbd>.</li><li>Appuie sur <kbd>Ctrl</kbd> + <kbd>V</kbd>, puis <kbd>Entr\xE9e</kbd>.</li><li>Quand \xAB C\u2019est fait \xBB s\u2019affiche : <b>ferme compl\xE8tement Chrome et rouvre-le</b> (obligatoire).</li></ol>` : `<ol class="upd-steps"><li>Clique <b>Copier</b>.</li><li>Appuie sur <kbd>\u2318 Cmd</kbd> + <kbd>Espace</kbd>, tape <b>Terminal</b>, puis <kbd>Entr\xE9e</kbd>.</li><li>Appuie sur <kbd>\u2318 Cmd</kbd> + <kbd>V</kbd>, puis <kbd>Entr\xE9e</kbd>.</li><li>Quand \xAB C\u2019est fait \xBB s\u2019affiche : <b>quitte Chrome</b> (<kbd>\u2318 Cmd</kbd> + <kbd>Q</kbd>) <b>et rouvre-le</b> (obligatoire).</li></ol>`;
  }
  var list = (notes) => notes.length ? `<ul class="upd-notes">${notes.map((n) => `<li>${escapeHTML(n)}</li>`).join("")}</ul>` : "";
  function updateBanner(doc = document) {
    const current = chrome.runtime.getManifest().version;
    const show = async () => {
      doc.getElementById("upd-banner")?.remove();
      const got = await chrome.storage.local.get([UPDATE_KEY, DISMISSED]);
      const saved = got[UPDATE_KEY];
      const ok = parseVersionFile({ version: saved?.latest, url: saved?.url, notes: saved?.notes });
      const info = ok ? { ...ok, checkedAt: saved?.checkedAt } : void 0;
      if (!updateAvailable(info, current) || got[DISMISSED] === info.latest) return;
      const bar = doc.createElement("div");
      bar.id = "upd-banner";
      bar.className = "lic-banner upd-banner";
      const waiting = (await chrome.storage.local.get(DISK_WAIT_KEY))[DISK_WAIT_KEY];
      bar.innerHTML = waiting?.version ? `<div><b>\u2705 AurOEBay ${escapeHTML(waiting.version)} est pr\xEAt.</b> Il se recharge tout seul d\xE8s que ${escapeHTML(waiting.reason ?? "le travail en cours")} sera fini.</div>
      <span><button type="button" class="btn small primary" id="upd-now">Recharger maintenant</button></span>` : `<div><b>\u{1F195} AurOEBay ${escapeHTML(info.latest)} est disponible</b> (tu as ${escapeHTML(current)}).${ok.notes.length ? ` Ce que \xE7a apporte :${list(ok.notes)}` : ""}<p class="upd-how">Mise \xE0 jour en 1 minute, tes donn\xE9es sont gard\xE9es :</p>${steps()}<p class="upd-how small">Sans red\xE9marrer Chrome, les boutons AurOEBay ne marchent pas sur les pages eBay et AliExpress.</p></div>
      <span><button type="button" class="btn small primary" id="upd-copy">\u{1F4CB} Copier</button>
      <a class="btn small secondary" href="${UPDATE_GUIDE_URL}" target="_blank" rel="noopener">Aide en images</a>
      <button type="button" class="btn small secondary" id="upd-later">Plus tard</button></span>`;
      bar.querySelector("#upd-later")?.addEventListener("click", () => {
        void chrome.storage.local.set({ [DISMISSED]: info.latest });
      });
      bar.querySelector("#upd-now")?.addEventListener("click", () => {
        if (confirm("Recharger AurOEBay maintenant ? Le travail en cours sera interrompu (tes donn\xE9es sont gard\xE9es)."))
          void chrome.runtime.sendMessage({ type: "UPDATE_RELOAD_NOW" }).catch(() => {
          });
      });
      const copy = bar.querySelector("#upd-copy");
      copy?.addEventListener("click", () => {
        void navigator.clipboard.writeText(isWindows() ? WINDOWS_COMMAND : MAC_COMMAND).then(() => copy.textContent = "\u2713 Copi\xE9 ! \xC9tape 2 \u2192").catch(() => copy.textContent = "\u26A0 Copie impossible : utilise l\u2019aide en images");
      });
      doc.body.prepend(bar);
      poll();
    };
    let polling;
    const poll = () => {
      if (polling) return;
      polling = setInterval(() => {
        if (!doc.getElementById("upd-banner")) return void (clearInterval(polling), polling = void 0);
        void chrome.runtime.sendMessage({ type: "UPDATE_DISK" }).catch(() => {
        });
      }, 4e3);
    };
    const news = async () => {
      doc.getElementById("upd-news")?.remove();
      if ((await chrome.storage.local.get(WHATS_NEW_KEY))[WHATS_NEW_KEY] !== current) return;
      const notes = await fetch(chrome.runtime.getURL("release-notes.json")).then((r) => r.json()).then((v) => parseReleaseNotes(v).find((r) => r.version === current)?.notes ?? []).catch(() => []);
      if (!notes.length) return;
      const bar = doc.createElement("div");
      bar.id = "upd-news";
      bar.className = "lic-banner upd-banner upd-news";
      bar.innerHTML = `<div><b>\u{1F389} AurOEBay est \xE0 jour (${escapeHTML(current)}). Les nouveaut\xE9s :</b>${list(notes)}<p class="upd-how small">Si ce n\u2019est pas d\xE9j\xE0 fait : ferme compl\xE8tement Chrome et rouvre-le, sinon les boutons AurOEBay ne marchent pas sur les pages eBay et AliExpress d\xE9j\xE0 ouvertes.</p></div>
      <span><a class="btn small secondary" href="${NEWS_URL}" target="_blank" rel="noopener">Toutes les nouveaut\xE9s</a>
      <button type="button" class="btn small primary" id="upd-news-ok">J\u2019ai compris</button></span>`;
      bar.querySelector("#upd-news-ok")?.addEventListener("click", () => void chrome.storage.local.remove(WHATS_NEW_KEY));
      doc.body.prepend(bar);
    };
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "local") return;
      if (changes[UPDATE_KEY] || changes[DISMISSED] || changes[DISK_WAIT_KEY]) void show().catch(() => {
      });
      if (changes[WHATS_NEW_KEY]) void news().catch(() => {
      });
    });
    void show().catch(() => {
    });
    void news().catch(() => {
    });
    void chrome.runtime.sendMessage({ type: "UPDATE_CHECK" }).catch(() => {
    });
  }

  // src/core/links.ts
  var DISCORD_URL = "https://discord.gg/sr2g2ZZZQ9";

  // src/core/journal.ts
  var DAY2 = 864e5;
  var time = (at) => new Date(at).toLocaleString("fr-FR", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit", second: "2-digit" });
  var ICON = { msg: "\xB7", error: "\u2717", shown: "\u26A0", step: "\u2192", start: "\u25B6" };
  function journalLine(e) {
    const icon = e.kind === "msg" ? e.ok ? "\u2713" : "\u2717" : ICON[e.kind];
    return [
      time(e.at),
      icon,
      e.what,
      e.where ? `[${e.where}]` : "",
      e.ms !== void 0 && e.ms >= 50 ? `${e.ms} ms` : "",
      e.count && e.count > 1 ? `\xD7${e.count}` : "",
      e.text ? `\u2014 ${e.text}` : ""
    ].filter(Boolean).join(" ");
  }
  function journalProblems(list2, now = Date.now()) {
    return list2.filter((e) => now - e.at < DAY2 && (e.kind === "error" || e.kind === "shown" || e.kind === "msg" && !e.ok)).length;
  }

  // src/ui/report.ts
  var REPORT_URL = "https://auroebay.netlify.app/";
  var SUPPORT_EMAIL = "bonjour@impression-minute.fr";
  var MAX_IMAGE = 5 * 1024 * 1024;
  function section(title, body2) {
    const lines = (value, indent = "") => {
      if (value === null || value === void 0) return [`${indent}\u2014`];
      if (Array.isArray(value)) return value.length ? value.flatMap((v) => typeof v === "object" && v ? lines(v, indent + "  ") : [`${indent}- ${String(v)}`]) : [`${indent}(rien)`];
      if (typeof value === "object")
        return Object.entries(value).flatMap(
          ([k, v]) => v && typeof v === "object" && (Array.isArray(v) ? v.length : true) ? [`${indent}${k} :`, ...lines(v, indent + "  ")] : [`${indent}${k} : ${Array.isArray(v) ? "(rien)" : String(v ?? "\u2014")}`]
        );
      return [`${indent}${String(value)}`];
    };
    return `
=== ${title} ===
${lines(body2).join("\n")}
`;
  }
  async function technicalReport(extra, full = false) {
    const [health, snapshot, journal] = await Promise.all([
      message({ type: "HEALTH_CHECK" }).catch((e) => `illisible : ${e instanceof Error ? e.message : String(e)}`),
      message({ type: "DEBUG_SNAPSHOT" }).catch((e) => `le moteur ne r\xE9pond pas : ${e instanceof Error ? e.message : String(e)}`),
      message({ type: "JOURNAL_GET" }).catch(() => [])
    ]);
    let session = {};
    try {
      session = await chrome.storage.session.get(["apiTrace:v1", "lastPanelError:v1"]);
    } catch {
    }
    const problems = journal.filter((e) => e.kind === "error" || e.kind === "shown" || e.kind === "msg" && !e.ok);
    const version = chrome.runtime.getManifest().version;
    const head = [
      `RAPPORT AUROEBAY ${version} \u2014 ${(/* @__PURE__ */ new Date()).toLocaleString("fr-FR")}`,
      `Ouvert depuis : ${location.pathname.replace(/^\//, "")}`,
      `Probl\xE8mes sur 24 h : ${journalProblems(journal)} \xB7 lignes de journal : ${journal.length}${journal.length ? ` (depuis le ${new Date(journal[0].at).toLocaleString("fr-FR")})` : ""}`
    ].join("\n");
    const parts = [
      head,
      section("Derni\xE8res erreurs (les plus r\xE9centes en bas)", problems.slice(-25).map(journalLine)),
      section("\xC9tat d'AurOEBay", snapshot),
      section("Tout va bien ?", Array.isArray(health) ? health.map((x) => `${x.ok ? "OK" : x.unknown ? "?" : "!!"} ${x.title} : ${x.text}`) : health),
      section("Derni\xE8re erreur du panneau", session["lastPanelError:v1"] ?? null),
      extra ? section("Panneau", extra) : "",
      section(full ? "Journal complet" : "Journal (300 derni\xE8res lignes)", (full ? journal : journal.slice(-300)).map(journalLine)),
      full ? section("Trace des imports (brute)", JSON.stringify(session["apiTrace:v1"] ?? [], null, 1)) : ""
    ];
    const text = redact(parts.join(""));
    return full ? text : text.slice(0, 6e4);
  }
  async function downloadReport(extra) {
    const text = await technicalReport(extra, true);
    const url = URL.createObjectURL(new Blob([text], { type: "text/plain;charset=utf-8" }));
    const a = document.createElement("a");
    a.href = url;
    a.download = `AurOEBay-rapport-${chrome.runtime.getManifest().version}-${(/* @__PURE__ */ new Date()).toISOString().slice(0, 16).replace(/[T:]/g, "-")}.txt`;
    document.body.append(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1e4);
  }
  var CSS = `
.rp{border:0;border-radius:18px;padding:0;max-width:520px;width:calc(100vw - 32px);background:var(--surface,#fff);color:var(--text,#1d1a24);box-shadow:0 24px 60px rgba(0,0,0,.4);font:14px system-ui,-apple-system,sans-serif}
.rp::backdrop{background:rgba(10,8,14,.55)}
.rp form{display:grid;gap:12px;padding:20px 22px}
.rp h2{margin:0;font-size:19px}
.rp p{margin:0;color:var(--muted,#a49bb0);line-height:1.45}
.rp .rp-community a{color:#ff8a3d;font-weight:600}
.rp label{display:grid;gap:6px;font-weight:600}
.rp textarea,.rp input[type=email]{font:inherit;padding:10px 12px;border-radius:10px;border:1px solid var(--line,#3a3346);background:var(--bg,var(--field,#faf7f3));color:inherit}
.rp textarea{min-height:110px;resize:vertical}
.rp .rp-check{display:flex;align-items:center;gap:8px;font-weight:500;color:var(--muted,#75697d)}.rp .rp-check input{width:auto;flex:none;margin:0}.rp h2{color:inherit}
.rp .rp-actions{display:flex;flex-wrap:wrap;gap:8px;justify-content:flex-end}.rp .rp-copy{margin-right:auto;font-weight:500}
.rp button{font:600 14px system-ui;border-radius:10px;padding:9px 16px;border:1px solid var(--line,#ddd);background:transparent;color:var(--text,#1d1a24);cursor:pointer}
.rp button.primary{background:linear-gradient(135deg,#ff5f3a,#ff8a3d 50%,#ffb347);border-color:transparent;color:#fff}
.rp button:disabled{opacity:.6;cursor:default}
.rp .rp-msg{font-weight:600}
.rp .rp-file{padding:10px 12px;border:1px dashed var(--line,#3a3346);border-radius:10px}.rp .rp-file button{margin:4px 0;padding:6px 12px}
.rp .rp-msg.ok{color:#3fd09a}.rp .rp-msg.err{color:#ff6b78}
`;
  function openReport(extra) {
    document.getElementById("auroebay-report")?.remove();
    if (!document.getElementById("auroebay-report-css")) {
      const style = document.createElement("style");
      style.id = "auroebay-report-css";
      style.textContent = CSS;
      document.head.append(style);
    }
    const dialog = document.createElement("dialog");
    dialog.id = "auroebay-report";
    dialog.className = "rp";
    dialog.innerHTML = `<form method="dialog">
      <h2>\u{1F198} Un souci avec AurOEBay ?</h2>
      <p>Explique simplement ce qui ne marche pas. Le message part directement, pas besoin de bo\xEEte e-mail.</p>
      <p class="rp-community">\u{1F4AC} Plut\xF4t une question ? <a href="${DISCORD_URL}" target="_blank" rel="noopener">Demande \xE0 la communaut\xE9 AurOEBay sur Discord \u2197</a></p>
      <label>Qu\u2019est-ce qui ne marche pas ?<textarea name="message" required maxlength="4000" placeholder="Ex. : quand je clique \xAB Cr\xE9er le brouillon \xBB, rien ne se passe."></textarea></label>
      <label>Une capture d\u2019\xE9cran (si tu veux)<input name="capture" type="file" accept="image/*"></label>
      <label>Ton e-mail, pour te r\xE9pondre (si tu veux)<input name="email" type="email" maxlength="200" placeholder="toi@exemple.fr"></label>
      <label class="rp-check"><input name="tech" type="checkbox" checked> Joindre le rapport technique (aucun mot de passe ni cl\xE9)</label>
      <p class="rp-msg" hidden></p>
      <p class="rp-file">\u{1F9FE} Pour aider quelqu\u2019un ou te faire aider : <button type="button" class="rp-download">\u{1F4E5} T\xE9l\xE9charger le rapport complet</button> puis envoie le fichier sur Discord (aucun mot de passe, cl\xE9, adresse ni acheteur dedans).</p>
      <div class="rp-actions"><button type="button" class="rp-copy" title="Pour le coller dans un message">\u{1F4CB} Copier le rapport</button><button type="button" value="cancel" class="rp-cancel">Annuler</button><button type="submit" class="primary">Envoyer</button></div>
    </form>`;
    document.body.append(dialog);
    const form = dialog.querySelector("form");
    const msg = dialog.querySelector(".rp-msg");
    const send = dialog.querySelector("button[type=submit]");
    const say = (text, kind = "") => {
      msg.hidden = false;
      msg.className = `rp-msg ${kind}`;
      msg.textContent = text;
    };
    dialog.querySelector(".rp-cancel").addEventListener("click", () => dialog.close());
    dialog.querySelector(".rp-copy").addEventListener("click", async () => {
      try {
        await navigator.clipboard.writeText(await technicalReport(extra ? await extra().catch(() => "") : void 0));
        say("\u{1F4CB} Rapport copi\xE9 (aucun mot de passe ni cl\xE9).", "ok");
      } catch {
        say("Copie impossible.", "err");
      }
    });
    dialog.querySelector(".rp-download").addEventListener("click", async (e) => {
      const b = e.currentTarget;
      b.disabled = true;
      say("Pr\xE9paration du rapport (tests de connexion compris)\u2026");
      try {
        await downloadReport(extra ? await extra().catch(() => "") : void 0);
        say("\u{1F4E5} Rapport t\xE9l\xE9charg\xE9 (dossier T\xE9l\xE9chargements) : envoie-le \xE0 la personne qui t\u2019aide.", "ok");
      } catch (err) {
        say(`Rapport impossible : ${err instanceof Error ? err.message : String(err)}`, "err");
      } finally {
        b.disabled = false;
      }
    });
    dialog.addEventListener("close", () => dialog.remove());
    form.addEventListener("submit", async (event) => {
      event.preventDefault();
      const text = form.elements.namedItem("message").value.trim();
      if (!text) return say("\xC9cris d\u2019abord ce qui ne marche pas.", "err");
      const file = form.elements.namedItem("capture").files?.[0];
      if (file && file.size > MAX_IMAGE) return say("Capture trop lourde (5 Mo au plus).", "err");
      send.disabled = true;
      say("Envoi\u2026");
      const version = chrome.runtime.getManifest().version;
      const tech = form.elements.namedItem("tech").checked ? await technicalReport(extra ? await extra().catch(() => "") : void 0).catch(() => "") : "";
      const body2 = new FormData();
      body2.set("form-name", "probleme");
      body2.set("bot-field", "");
      body2.set("message", text);
      body2.set("email", form.elements.namedItem("email").value.trim());
      body2.set("version", version);
      body2.set("rapport", tech);
      if (file) body2.set("capture", file, file.name);
      try {
        const r = await fetch(REPORT_URL, { method: "POST", body: body2, signal: AbortSignal.timeout(3e4) });
        if (!r.ok) throw Error(String(r.status));
        say("\u2705 Envoy\xE9, merci ! Tu auras une r\xE9ponse par e-mail si tu as laiss\xE9 ton adresse.", "ok");
        send.textContent = "Fermer";
        send.disabled = false;
        send.type = "button";
        send.addEventListener("click", () => dialog.close(), { once: true });
      } catch {
        try {
          await navigator.clipboard.writeText(`${text}

${tech}`);
        } catch {
        }
        window.open(
          `mailto:${SUPPORT_EMAIL}?subject=${encodeURIComponent(`AurOEBay ${version} : un probl\xE8me`)}&body=${encodeURIComponent(`${text}

(Le rapport est copi\xE9 : colle-le ici avec Cmd+V ou Ctrl+V.)`)}`,
          "_blank"
        );
        say("L\u2019envoi direct n\u2019a pas march\xE9 : un e-mail s\u2019ouvre, ton message y est d\xE9j\xE0 (colle le rapport avec Cmd+V ou Ctrl+V).", "err");
        send.disabled = false;
      }
    });
    dialog.showModal();
    form.elements.namedItem("message").focus();
  }

  // src/core/errorLog.ts
  function logToJournal(kind, what, text) {
    try {
      void chrome.runtime.sendMessage({ type: "LOG", kind, what, text: text.slice(0, 600) }).catch(() => {
      });
    } catch {
    }
  }
  var ownError = (stack) => {
    try {
      return stack.includes(`chrome-extension://${chrome.runtime.id}`);
    } catch {
      return false;
    }
  };
  var describe = (reason) => reason instanceof Error ? `${reason.message} ${reason.stack?.split("\n").slice(1, 3).map((l) => l.trim()).join(" ") ?? ""}` : String(reason);
  function watchErrors(extensionPage, win = window) {
    win.addEventListener("error", (e) => {
      const where = `${e.filename ?? ""} ${e.error instanceof Error ? e.error.stack ?? "" : ""}`;
      if (!extensionPage && !ownError(where)) return;
      if (/Extension context invalidated|ResizeObserver loop/i.test(e.message)) return;
      logToJournal("error", "page", `${e.message} (${String(e.filename ?? "").split("/").pop()}:${e.lineno})`);
    });
    win.addEventListener("unhandledrejection", (e) => {
      const text = describe(e.reason);
      if (!extensionPage && !ownError(e.reason instanceof Error ? e.reason.stack ?? "" : "")) return;
      if (/Extension context invalidated/i.test(text)) return;
      logToJournal("error", "page", text);
    });
  }
  function watchShownErrors(doc = document) {
    let last = "";
    const check = () => {
      const box = doc.getElementById("toast");
      if (!box || box.hidden || !box.classList.contains("error")) return;
      const text = (box.textContent ?? "").trim();
      if (text && text !== last) logToJournal("shown", "message", last = text);
    };
    const start = () => {
      const box = doc.getElementById("toast");
      if (!box) return;
      new MutationObserver(check).observe(box, { attributes: true, childList: true, characterData: true, subtree: true });
    };
    if (doc.readyState === "loading") doc.addEventListener("DOMContentLoaded", start, { once: true });
    else start();
  }

  // src/ui/theme.ts
  function setupTheme() {
    watchErrors(true);
    watchShownErrors();
    licenseBanner();
    updateBanner();
    simpleTopbar();
    const system = matchMedia("(prefers-color-scheme: dark)");
    const button = document.getElementById("theme-toggle");
    const choice = document.getElementById(
      "theme-choice"
    );
    let theme = "system";
    let revision = 0;
    const valid = (value) => value === "light" || value === "dark" ? value : "system";
    const render = () => {
      const dark = theme === "dark" || theme === "system" && system.matches;
      document.documentElement.dataset.theme = dark ? "dark" : "light";
      if (button) {
        button.textContent = dark ? "\u2600" : "\u263E";
        button.setAttribute("aria-pressed", String(dark));
        button.setAttribute(
          "aria-label",
          dark ? "Activer le mode clair" : "Activer le mode sombre"
        );
        button.title = button.getAttribute("aria-label");
      }
      if (choice) choice.value = theme;
    };
    const save = async (value) => {
      revision++;
      theme = value;
      render();
      try {
        await chrome.storage.local.set({ uiTheme: value });
      } catch {
      }
    };
    button?.addEventListener(
      "click",
      () => void save(
        document.documentElement.dataset.theme === "dark" ? "light" : "dark"
      )
    );
    choice?.addEventListener("change", () => void save(valid(choice.value)));
    system.addEventListener("change", render);
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "local" && changes.uiTheme) {
        revision++;
        theme = valid(changes.uiTheme.newValue);
        render();
      }
    });
    const initial = revision;
    void chrome.storage.local.get("uiTheme").then(({ uiTheme }) => {
      if (revision === initial) theme = valid(uiTheme);
      render();
    }).catch(() => render());
    render();
  }
  var PAGES = [
    ["routine.html", "\u2600\uFE0F Ma journ\xE9e"],
    ["dashboard.html", "\u{1F4E6} Mes produits"],
    ["scout.html", "\u{1F50D} Trouver"],
    ["sales.html", "\u{1F4D2} Ventes"]
  ];
  function simpleTopbar() {
    const bar = document.querySelector("header.topbar");
    const actions = bar?.querySelector(".top-actions");
    if (!bar || !actions || bar.querySelector(".ao-nav")) return;
    const here = location.pathname.split("/").pop() || "";
    if (here === "welcome.html") return;
    actions.querySelectorAll("a[href]").forEach((a) => {
      if (PAGES.some(([href]) => a.getAttribute("href") === href)) a.remove();
    });
    const nav = document.createElement("nav");
    nav.className = "ao-nav";
    nav.setAttribute("aria-label", "Pages d\u2019AurOEBay");
    for (const [href, label] of PAGES) {
      const a = document.createElement("a");
      a.href = href;
      a.textContent = label;
      if (href === here) {
        a.className = "on";
        a.setAttribute("aria-current", "page");
      }
      nav.append(a);
    }
    bar.querySelector(".brand")?.after(nav);
    bar.querySelector(".brand .crumb")?.remove();
    if (here !== "options.html") {
      const settings = document.createElement("a");
      settings.className = "btn ghost";
      settings.href = "options.html";
      settings.textContent = "\u2699\uFE0F Param\xE8tres";
      actions.append(settings);
    }
    const help = document.createElement("button");
    help.id = "help-report";
    help.type = "button";
    help.className = "btn ghost";
    help.textContent = "\u{1F198} Aide";
    help.title = "Un souci ? \xC9cris-nous, c\u2019est envoy\xE9 tout de suite";
    help.addEventListener("click", () => openReport());
    actions.append(help);
  }

  // src/core/descriptionDesign.ts
  var listingStore = "";
  var DESCRIPTION_THEMES = {
    classic: { label: "Vert classique", font: "Arial,Helvetica,sans-serif", ink: "#213a37", page: "#f3f5f3", brand: "#44645b", header: "#183e35", headerInk: "white", card: "white", border: "#dce5dd", radius: "14px", note: "#587064" },
    minimal: { label: "Blanc minimal", font: "Helvetica,Arial,sans-serif", ink: "#1d1d1f", page: "#ffffff", brand: "#86868b", header: "#ffffff;border-bottom:2px solid #1d1d1f", headerInk: "#1d1d1f", card: "white", border: "#e5e5e7", radius: "4px", note: "#6e6e73" },
    ocean: { label: "Bleu oc\xE9an", font: "Arial,Helvetica,sans-serif", ink: "#13293d", page: "#eef4fa", brand: "#2f6690", header: "linear-gradient(135deg,#0b4f9c,#1677d2)", headerInk: "white", card: "white", border: "#d4e3f2", radius: "14px", note: "#4a6582" },
    noir: { label: "Noir & or", font: "Georgia,'Times New Roman',serif", ink: "#1a1a1a", page: "#f5f3ee", brand: "#a8842c", header: "#111111", headerInk: "#f5c451", card: "white", border: "#e6dfcf", radius: "6px", note: "#6b6252" },
    sunset: { label: "Orange \xE9nergie", font: "Arial,Helvetica,sans-serif", ink: "#2b1d16", page: "#fff6ef", brand: "#e8590c", header: "linear-gradient(135deg,#ff5f3a,#ff8a3d 50%,#ffb347)", headerInk: "white", card: "white", border: "#ffe0cc", radius: "18px", note: "#7a5a48" },
    rose: { label: "Rose doux", font: "'Trebuchet MS',Arial,sans-serif", ink: "#3b1f2b", page: "#fff0f5", brand: "#c2255c", header: "linear-gradient(135deg,#f06595,#faa2c1)", headerInk: "white", card: "white", border: "#fcd6e3", radius: "20px", note: "#86566a" },
    tech: { label: "Tech sombre", font: "Verdana,Arial,sans-serif", ink: "#1b2733", page: "#e9eef2", brand: "#0c8599", header: "linear-gradient(135deg,#1b2733,#22394d)", headerInk: "#66d9e8", card: "white", border: "#cfd9e1", radius: "10px", note: "#52667a" }
  };
  var listingTheme = "classic";
  function setListingTheme(id) {
    listingTheme = typeof id === "string" && id in DESCRIPTION_THEMES ? id : "classic";
  }
  function setListingStore(name) {
    listingStore = typeof name === "string" ? name.trim().slice(0, 40) : "";
  }

  // src/core/bannerStyle.ts
  var BANNER_PRESETS = {
    aurore: { label: "Orange Aurore", stops: ["#ff5f3a", "#ff8a3d", "#ffb347"], ink: "#ffffff", shadow: "rgba(150,30,10,.25)" },
    rouge: { label: "Rouge promo", stops: ["#c8102e", "#e3262f", "#ff4d4d"], ink: "#ffffff", shadow: "rgba(80,0,0,.3)" },
    noir: { label: "Noir & or", stops: ["#0d0d0d", "#1c1c1c", "#2b2b2b"], ink: "#f5c451", shadow: "rgba(0,0,0,.5)" },
    bleu: { label: "Bleu oc\xE9an", stops: ["#0b4f9c", "#1677d2", "#36a3f5"], ink: "#ffffff", shadow: "rgba(0,30,80,.3)" },
    vert: { label: "Vert frais", stops: ["#0f7a4a", "#16a05e", "#3cc77c"], ink: "#ffffff", shadow: "rgba(0,60,30,.3)" },
    rose: { label: "Rose", stops: ["#d6336c", "#f06595", "#faa2c1"], ink: "#ffffff", shadow: "rgba(110,0,40,.25)" },
    violet: { label: "Violet n\xE9on", stops: ["#5f3dc4", "#7950f2", "#b197fc"], ink: "#ffffff", shadow: "rgba(40,0,90,.3)" },
    jaune: { label: "Jaune flash", stops: ["#ffd43b", "#ffe066", "#fff3bf"], ink: "#1a1a1a", shadow: "rgba(120,90,0,.2)" },
    blanc: { label: "Blanc sobre", stops: ["#ffffff", "#f6f6f6", "#ececec"], ink: "#1a1a1a", shadow: "rgba(0,0,0,.08)" }
  };
  var BANNER_TEXT = /^[\p{L}\p{N} !%&'+.,:/#$€£-]*$/u;

  // src/core/settings.ts
  var DEFAULTS = {
    enabled: true,
    model: "gpt-5-nano",
    reasoningEffort: "minimal",
    temperature: null,
    timeoutMs: 9e4,
    maxTitle: 80,
    minTitle: 65,
    autoConfidence: 0.9,
    probableConfidence: 0.75,
    strictFactual: true,
    rewriteDescription: true,
    aiSpecifics: true,
    captureEnabled: true,
    sourceExpiryMinutes: 120,
    sellerEnabled: true,
    haloEnabled: true,
    sellerTtlDays: 7,
    resultsEnabled: false,
    saleBanner: true,
    bannerPreset: "aurore",
    bannerMain: "SALE",
    bannerTitle: "HOT DEALS",
    bannerSub: "SHOP NOW",
    bannerPosition: "top",
    descriptionTemplate: "classic",
    storeName: "",
    debug: false,
    showSelectors: false,
    fallbackSelectors: { title: "", description: "", specifics: "" }
  };
  function validateSettings(input) {
    const s = {
      ...DEFAULTS,
      ...input,
      fallbackSelectors: {
        ...DEFAULTS.fallbackSelectors,
        ...input.fallbackSelectors
      }
    };
    const range = (key, min, max) => {
      const n = s[key];
      if (typeof n !== "number" || !Number.isFinite(n) || n < min || n > max)
        throw Error(`Invalid setting: ${key} (${min}\u2013${max})`);
    };
    range("timeoutMs", 5e3, 18e4);
    range("maxTitle", 20, 80);
    range("minTitle", 0, s.maxTitle);
    range("autoConfidence", 0.9, 1);
    range("probableConfidence", 0.75, s.autoConfidence);
    range("sourceExpiryMinutes", 1, 1440);
    if (![1, 3, 7, 14, 30].includes(s.sellerTtlDays))
      throw Error("Invalid seller TTL");
    if (!/^[a-zA-Z0-9._:-]{1,100}$/.test(s.model))
      throw Error("Invalid model name");
    if (!["", "none", "minimal", "low", "medium", "high"].includes(
      s.reasoningEffort
    ))
      throw Error("Invalid reasoning effort");
    if (s.temperature !== null && (typeof s.temperature !== "number" || !Number.isFinite(s.temperature) || s.temperature < 0 || s.temperature > 2))
      throw Error("Invalid temperature");
    for (const k of [
      "enabled",
      "strictFactual",
      "rewriteDescription",
      "aiSpecifics",
      "captureEnabled",
      "sellerEnabled",
      "haloEnabled",
      "resultsEnabled",
      "saleBanner",
      "debug",
      "showSelectors"
    ])
      if (typeof s[k] !== "boolean") throw Error(`Invalid ${k}`);
    if (typeof s.storeName !== "string" || s.storeName.length > 40 || /[<>{}]/.test(s.storeName))
      throw Error("Nom de boutique invalide (40 caract\xE8res, sans < > { }).");
    s.storeName = s.storeName.trim();
    if (!(s.bannerPreset in BANNER_PRESETS)) throw Error("Couleurs du bandeau inconnues.");
    if (!["top", "bottom"].includes(s.bannerPosition)) throw Error("Position du bandeau invalide.");
    for (const [k, max] of [["bannerMain", 12], ["bannerTitle", 20], ["bannerSub", 24]]) {
      if (typeof s[k] !== "string" || s[k].length > max || !BANNER_TEXT.test(s[k]))
        throw Error(`Texte du bandeau trop long ou avec des signes non permis (${max} caract\xE8res au plus).`);
      s[k] = s[k].trim();
    }
    if (!s.bannerMain && !s.bannerTitle && !s.bannerSub) throw Error("Le bandeau a besoin d\u2019au moins un texte.");
    if (!(s.descriptionTemplate in DESCRIPTION_THEMES)) throw Error("Mod\xE8le de description inconnu.");
    for (const v of Object.values(s.fallbackSelectors))
      if (typeof v !== "string" || v.length > 500)
        throw Error("Invalid selector");
    return s;
  }
  async function getSettings() {
    const { settings, extensionEnabled = true, [LICENSE_KEY]: license } = await chrome.storage.local.get([
      "settings",
      "extensionEnabled",
      LICENSE_KEY
    ]);
    const on = extensionEnabled !== false && licenseActive((await trustedLicense(license)).state);
    try {
      const s = validateSettings({
        ...settings,
        enabled: on
      });
      setListingStore(s.storeName);
      setListingTheme(s.descriptionTemplate);
      return s;
    } catch {
      return {
        ...structuredClone(DEFAULTS),
        enabled: on
      };
    }
  }

  // src/core/taxes.ts
  function ratesFor(status, liberatory, urssaf, impot) {
    const clamp = (n) => Number.isFinite(n) ? Math.min(50, Math.max(0, Math.round(n * 10) / 10)) : 0;
    return status === "micro" ? { urssaf: 12.3, impot: liberatory ? 1 : 0 } : { urssaf: clamp(urssaf), impot: clamp(impot) };
  }

  // src/core/shippingText.ts
  var PRICE = String.raw`(?:US\s*)?\$\s*(\d+(?:\.\d{1,2})?)`;
  var NAMED = new RegExp(String.raw`(?:standard|shipping|delivery|livraison)[^$·\d]{0,20}?${PRICE}`, "gi");
  var LABEL = new RegExp(String.raw`\b[A-Za-z][A-Za-z' -]{1,30}:\s*${PRICE}`, "g");

  // src/core/country.ts
  var codes = "AD AE AF AG AI AL AM AO AQ AR AS AT AU AW AX AZ BA BB BD BE BF BG BH BI BJ BL BM BN BO BQ BR BS BT BV BW BY BZ CA CC CD CF CG CH CI CK CL CM CN CO CR CU CV CW CX CY CZ DE DJ DK DM DO DZ EC EE EG EH ER ES ET FI FJ FK FM FO FR GA GB GD GE GF GG GH GI GL GM GN GP GQ GR GS GT GU GW GY HK HM HN HR HT HU ID IE IL IM IN IO IQ IR IS IT JE JM JO JP KE KG KH KI KM KN KP KR KW KY KZ LA LB LC LI LK LR LS LT LU LV LY MA MC MD ME MF MG MH MK ML MM MN MO MP MQ MR MS MT MU MV MW MX MY MZ NA NC NE NF NG NI NL NO NP NR NU NZ OM PA PE PF PG PH PK PL PM PN PR PS PT PW PY QA RE RO RS RU RW SA SB SC SD SE SG SH SI SJ SK SL SM SN SO SR SS ST SV SX SY SZ TC TD TF TG TH TJ TK TL TM TN TO TR TT TV TW TZ UA UG UM US UY UZ VA VC VE VG VI VN VU WF WS YE YT ZA ZM ZW".split(
    " "
  );
  var names = new Intl.DisplayNames(["en"], { type: "region" });
  var map = /* @__PURE__ */ new Map();
  for (const code of codes) {
    const name = names.of(code);
    map.set(norm(code), name);
    map.set(norm(name), name);
  }
  for (const [alias, name] of Object.entries({
    "mainland china": "China",
    "cn origin": "China",
    "china mainland": "China",
    "china origin": "China",
    prc: "China",
    "people s republic of china": "China",
    usa: "United States",
    "u s a": "United States",
    "united states of america": "United States",
    uk: "United Kingdom",
    "great britain": "United Kingdom",
    "south korea": "South Korea",
    "republic of korea": "South Korea",
    taiwan: "Taiwan",
    vietnam: "Vietnam",
    turkey: "T\xFCrkiye"
  }))
    map.set(norm(alias), name);

  // src/ebay/savedDraft.ts
  var SCAN_LIMIT = 3 * 1024 * 1024;

  // src/ebay/draftApi.ts
  var HTML_LIMIT = 8 * 1024 * 1024;

  // src/core/profit.ts
  var PROFIT_SETTINGS_KEY = "profitSettings:v1";
  var DEFAULT_PROFIT_SETTINGS = { aliExtra: 10, feeRate: null, adRate: 5 };
  var EBAY_PERCENT = (0.136 + 0.0165) * 1.07;

  // src/ui/welcome.ts
  var $ = (id) => document.getElementById(id);
  var RATES_KEY = "taxRates:v1";
  var WELCOME_KEY = "welcomeDone:v1";
  setupTheme();
  async function load() {
    const s = await getSettings();
    $("wl-store").value = s.storeName;
    const saved = (await chrome.storage.local.get(RATES_KEY))[RATES_KEY];
    if (saved && (saved.urssaf !== 12.3 || ![0, 1].includes(saved.impot))) {
      $("wl-urssaf").value = String(saved.urssaf);
      $("wl-impot").value = String(saved.impot);
      document.querySelector('input[name="wl-status"][value="custom"]').checked = true;
      $("wl-custom").hidden = false;
    } else if (saved) $("wl-vl").checked = saved.impot === 1;
    const profit = (await chrome.storage.local.get(PROFIT_SETTINGS_KEY))[PROFIT_SETTINGS_KEY];
    if (Number.isFinite(profit?.adRate)) $("wl-ad").value = String(profit.adRate);
    const rule = (await chrome.storage.local.get("variantPricing")).variantPricing;
    if (typeof rule?.target === "number") $("wl-target").value = String(rule.target);
  }
  document.querySelectorAll('input[name="wl-status"]').forEach(
    (r) => r.addEventListener("change", () => {
      const custom = r.value === "custom" && r.checked;
      $("wl-custom").hidden = !custom;
      $("wl-vl").disabled = custom;
    })
  );
  $("wl-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const status = $("wl-status");
    try {
      const s = await getSettings();
      const next = validateSettings({ ...s, storeName: $("wl-store").value });
      const choice = document.querySelector('input[name="wl-status"]:checked').value;
      const rates = ratesFor(
        choice,
        $("wl-vl").checked,
        Number($("wl-urssaf").value.replace(",", ".")),
        Number($("wl-impot").value.replace(",", "."))
      );
      const old = (await chrome.storage.local.get(PROFIT_SETTINGS_KEY))[PROFIT_SETTINGS_KEY];
      const ad = Math.min(30, Math.max(0, Number($("wl-ad").value.replace(",", ".")) || 0));
      await chrome.storage.local.set({
        settings: next,
        [RATES_KEY]: rates,
        [PROFIT_SETTINGS_KEY]: { ...DEFAULT_PROFIT_SETTINGS, ...old, adRate: ad },
        [WELCOME_KEY]: Date.now()
      });
      const target = Number($("wl-target").value.replace(",", "."));
      const current = (await chrome.storage.local.get("variantPricing")).variantPricing;
      if (Number.isFinite(target) && target >= 0 && (!current || typeof current.target === "number"))
        await message({ type: "PRICE_TARGET", target, rounding: "49-or-99" }).catch(() => {
        });
      status.textContent = "Enregistr\xE9 \u2713";
      location.href = "routine.html";
    } catch (err) {
      status.textContent = err instanceof Error ? err.message : String(err);
    }
  });
  licenseBox($("wl-license"));
  void load();
})();
