// src/core/aliVerify.ts
var ALI_VERIFY = "AliExpress demande une v\xE9rification anti-robot";
var ALI_COOKIES = "AliExpress refuse les recherches : trop de cookies AliExpress dans Chrome";
var ALI_COOKIES_TEXT = `${ALI_COOKIES} (erreur \xAB Cookie Too Large \xBB). Clique \xAB \u{1F9F9} Nettoyer AliExpress dans Chrome \xBB, supprime les donn\xE9es d\u2019aliexpress (ic\xF4ne corbeille), reconnecte-toi sur aliexpress.us, puis relance.`;
var ALI_COOKIES_URL = "chrome://settings/content/all?searchSubpage=aliexpress";
var ALI_REGION = "AliExpress n\u2019est pas pr\xEAt pour les \xC9tats-Unis";
function aliRegionText(r) {
  if (!r) return null;
  const wrong = [];
  if (!/(^|\.)aliexpress\.us$/.test(r.host)) wrong.push(`AliExpress s\u2019est ouvert sur ${r.host} au lieu d\u2019aliexpress.us`);
  if (r.signedIn === false) wrong.push("tu n\u2019es pas connect\xE9 \xE0 ton compte AliExpress");
  if (r.country && r.country !== "US") wrong.push(`le pays de livraison est ${r.country} au lieu de United States`);
  if (r.currency && r.currency !== "USD") wrong.push(`la devise est ${r.currency} au lieu de USD`);
  if (!wrong.length) return null;
  return `${ALI_REGION} : ${wrong.join(", ")}. Clique \xAB Ouvrir AliExpress US \xBB, connecte-toi, puis en haut \xE0 droite choisis United States et USD (Save), et relance. Sinon les prix et les fournisseurs trouv\xE9s seraient faux.`;
}

// src/core/aliProduct.ts
var DAY = 864e5;
var KEEP_DAYS = 365;
function addPricePoint(history, price, now = Date.now()) {
  const list2 = (Array.isArray(history) ? history : []).filter(
    (p) => Array.isArray(p) && Number.isFinite(p[0]) && Number.isFinite(p[1]) && now - p[0] <= KEEP_DAYS * DAY
  );
  if (price === null || !Number.isFinite(price) || price <= 0) return list2;
  const today = new Date(now);
  const day = new Date(today.getFullYear(), today.getMonth(), today.getDate()).getTime();
  const out = list2.filter((p) => p[0] !== day);
  out.push([day, Math.round(price * 100) / 100]);
  return out.sort((a, b) => a[0] - b[0]);
}

// src/background/aliProduct.ts
var HISTORY = "aliPriceHistory:v1";
var MAX_PRODUCTS = 400;
async function aliProductInPage() {
  const w = window;
  if (typeof w.__INIT_DATA_CALLBACK__ !== "function") return null;
  let raw;
  try {
    raw = await new Promise((resolve, reject) => {
      w.__INIT_DATA_CALLBACK__(resolve, reject);
      setTimeout(() => reject(Error("timeout")), 8e3);
    });
  } catch {
    return null;
  }
  const r = raw?.data?.result;
  if (!r) return null;
  const num2 = (v) => {
    const n = typeof v === "number" ? v : Number(String(v ?? "").replace(/[^\d.]/g, ""));
    return Number.isFinite(n) && String(v ?? "") !== "" ? n : null;
  };
  const productId2 = location.pathname.match(/\/item\/(\d+)\.html/)?.[1] ?? "";
  const price = r.PRICE?.targetSkuPriceInfo ?? {};
  const shop = r.SHOP_CARD_PC ?? {};
  const info = shop.sellerInfo ?? {};
  const opened = typeof info.openTime === "string" ? Date.parse(info.openTime.replace(" ", "T")) : NaN;
  const end = Number(r.PRICE_BANNER?.targetSkuBanner?.endTimer?.endTime);
  const images = (Array.isArray(r.HEADER_IMAGE_PC?.imagePathList) ? r.HEADER_IMAGE_PC.imagePathList : []).filter((u) => typeof u === "string").map((u) => u.startsWith("//") ? `https:${u}` : u).slice(0, 10);
  const variantImages = [];
  for (const prop of Array.isArray(r.SKU?.skuProperties) ? r.SKU.skuProperties : [])
    for (const v of Array.isArray(prop?.skuPropertyValues) ? prop.skuPropertyValues : []) {
      const raw2 = typeof v?.skuPropertyImagePath === "string" ? v.skuPropertyImagePath : "";
      const url = raw2.startsWith("//") ? `https:${raw2}` : raw2;
      if (/^https:\/\//.test(url) && !variantImages.some((x) => x.url === url) && !images.includes(url))
        variantImages.push({ url, name: String(v.propertyValueDisplayName ?? v.propertyValueName ?? "").slice(0, 60) });
    }
  const sold = (Array.isArray(shop.benefitInfoList) ? shop.benefitInfoList : []).find((b) => /sold/i.test(b?.title ?? ""));
  const out = {
    productId: productId2,
    title: String(r.PRODUCT_TITLE?.text ?? document.title).slice(0, 300),
    image: images[0] ?? null,
    images,
    variantImages: variantImages.slice(0, 24),
    price: num2(price.salePrice?.value) ?? num2(String(price.salePriceString ?? "").replace(/,/g, "")),
    original: num2(price.originalPrice?.value),
    currency: price.originalPrice?.currency ?? price.salePrice?.currency ?? (/\$/.test(String(price.salePriceString ?? "")) ? "USD" : null),
    promoEnd: Number.isFinite(end) && end > Date.now() ? end : null,
    seller: {
      name: typeof shop.storeName === "string" ? shop.storeName : null,
      positiveRate: num2(shop.sellerPositiveRate),
      ratings: num2(shop.sellerTotalNum),
      openedAt: Number.isFinite(opened) ? opened : null,
      country: typeof info.countryCompleteName === "string" ? info.countryCompleteName : null,
      topRated: info.topRatedSeller === true,
      sold180: typeof sold?.value === "string" ? sold.value : null,
      storeUrl: typeof info.storeURL === "string" ? `https:${info.storeURL.replace(/^https?:/, "")}` : null
    },
    rating: {
      stars: num2(r.PC_RATING?.rating),
      count: num2(r.PC_RATING?.totalValidNum),
      sold: typeof r.PC_RATING?.otherText === "string" ? r.PC_RATING.otherText : null
    },
    reviews: null
  };
  if (productId2)
    try {
      const res = await fetch(
        `https://feedback.aliexpress.com/pc/searchEvaluation.do?productId=${productId2}&lang=en_US&country=US&page=1&pageSize=20&filter=image&sort=complex_default`,
        { credentials: "include", signal: AbortSignal.timeout(1e4) }
      );
      const d = (await res.json())?.data ?? {};
      const stats = d.productEvaluationStatistic ?? {};
      out.reviews = {
        total: num2(stats.totalNum) ?? out.rating.count,
        positiveRate: num2(stats.positiveRate),
        oneStar: num2(stats.oneStarNum),
        photoCount: num2(d.totalNum),
        withPhotos: (Array.isArray(d.evaViewList) ? d.evaViewList : []).slice(0, 20).map(
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          (e) => ({
            stars: num2(e.buyerEval) !== null ? Math.round(num2(e.buyerEval) / 20) : null,
            text: String(e.buyerTranslationFeedback || e.buyerFeedback || "").slice(0, 400),
            date: String(e.evalDate ?? ""),
            country: typeof e.buyerCountry === "string" ? e.buyerCountry : null,
            images: (Array.isArray(e.images) ? e.images : []).filter((u) => typeof u === "string" && /^https:\/\//.test(u)).slice(0, 6)
          })
        )
      };
    } catch {
    }
  return out;
}
async function aliProductInfo(tabId, frameId = 0) {
  const [res] = await chrome.scripting.executeScript({ target: { tabId, frameIds: [frameId] }, world: "MAIN", func: aliProductInPage });
  const info = res?.result;
  if (!info?.productId) return null;
  const store = (await chrome.storage.local.get(HISTORY))[HISTORY] ?? {};
  const points = info.currency === "USD" ? addPricePoint(store[info.productId]?.points, info.price) : store[info.productId]?.points ?? [];
  store[info.productId] = { at: Date.now(), points };
  const ids = Object.keys(store);
  if (ids.length > MAX_PRODUCTS)
    for (const id of ids.sort((a, b) => store[a].at - store[b].at).slice(0, ids.length - MAX_PRODUCTS)) delete store[id];
  await chrome.storage.local.set({ [HISTORY]: store });
  return { info, history: points };
}

// src/core/license.ts
var LICENSE_KEY = "license:v1";
var LICENSE_PRODUCT_ID = 1457902;
var CODE_MAX_DAYS = 93;
var GRACE_DAYS = 3;
var CHECK_HOURS = 12;
var DAY2 = 864e5;
var OWNER_EXTENSION_ID = "bbedjpfnnkjadfjpbbmppikmgocoglfh";
var SKEW = 10 * 6e4;
var extensionId = () => globalThis.chrome?.runtime?.id ?? "";
var ownerInstall = () => extensionId() === OWNER_EXTENSION_ID;
function licenseActive(s, now = Date.now()) {
  if (!s) return false;
  if (s.owner) return ownerInstall();
  if (s.status === "trial") return trialActive(s, now);
  if (!s.key || s.status !== "active" || !s.checkedAt) return false;
  if (s.checkedAt > now + SKEW || (s.triedAt ?? 0) > now + SKEW) return false;
  if (typeof s.expiresAt === "string" && Date.parse(s.expiresAt) < now - DAY2) return false;
  return now - s.checkedAt < GRACE_DAYS * DAY2;
}
var licenseCheckDue = (s, now = Date.now()) => !!s?.key && !s.owner && (now - (s.triedAt ?? 0) > (s.status === "unverified" ? 5 * 6e4 : CHECK_HOURS * 36e5) || (s.triedAt ?? 0) > now + SKEW);
var PEPPER = "AurOEBay\xB7licence\xB7v1\xB74f1c9e27b8d36a05";
var SEALED = ["owner", "key", "instanceId", "status", "checkedAt", "triedAt", "email", "expiresAt", "error", "trialUntil", "trialId"];
async function hmac(text3) {
  const enc = new TextEncoder();
  const raw = await crypto.subtle.digest("SHA-256", enc.encode(PEPPER + "|" + extensionId()));
  const key4 = await crypto.subtle.importKey("raw", raw, { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const sig = await crypto.subtle.sign("HMAC", key4, enc.encode(text3));
  return [...new Uint8Array(sig)].map((b) => b.toString(16).padStart(2, "0")).join("");
}
var body = (s) => JSON.stringify(SEALED.map((k) => s[k] ?? null));
async function sealLicense(s) {
  const clean = {};
  for (const k of SEALED) if (s[k] !== void 0) clean[k] = s[k];
  return { ...clean, seal: await hmac(body(clean)) };
}
async function sealValid(s) {
  if (!s || typeof s.seal !== "string") return false;
  try {
    return s.seal === await hmac(body(s));
  } catch {
    return false;
  }
}
async function trustedLicense(raw) {
  const s = raw && typeof raw === "object" ? raw : {};
  if (await sealValid(s)) return { state: s, sealed: true };
  if (s.owner === true && ownerInstall()) return { state: { owner: true }, sealed: false };
  if (typeof s.key === "string" && typeof s.instanceId === "string")
    return { state: { key: s.key, instanceId: s.instanceId, status: "unverified" }, sealed: false };
  return { state: {}, sealed: false };
}
async function readLicense() {
  const raw = (await chrome.storage.local.get(LICENSE_KEY))[LICENSE_KEY];
  return (await trustedLicense(raw)).state;
}
var TRIAL_PUBLIC_KEY = {
  kty: "EC",
  crv: "P-256",
  x: "oW_tvz9jLYnRwKjCHieju0cdXWAgrSokQz803K4dmYg",
  y: "Y1zCRxUMfeYgWN8XEUpbTfxw0_ZS8NgqafW-bXO20wU"
};
function cleanLicenseInput(raw) {
  const flat = String(raw ?? "").replace(/[\u200B-\u200D\u2060\uFEFF\u00AD]/g, "").replace(/[\s`'"«»“”‘’<>]/g, "");
  const trial = flat.match(/ESSAI[-‐‑–—]?([A-Za-z0-9_-]{8,400})\.([A-Za-z0-9_-]{86})/i) ?? flat.match(/ESSAI[-‐‑–—]?([A-Za-z0-9_-]{8,400})\.([A-Za-z0-9_-]{40,200})/i);
  return trial ? `ESSAI-${trial[1]}.${trial[2]}` : flat;
}
var isTrialCode = (text3) => /^ESSAI-/i.test(cleanLicenseInput(text3));
var fromB64url = (t) => Uint8Array.from(atob(t.replace(/-/g, "+").replace(/_/g, "/") + "===".slice((t.length + 3) % 4)), (c) => c.charCodeAt(0));
async function readTrialCode(raw, now = Date.now()) {
  const bad = "Code d\u2019essai incorrect : copie-le en entier, depuis \xAB ESSAI- \xBB jusqu\u2019au dernier caract\xE8re.";
  const m = cleanLicenseInput(raw).match(/^ESSAI-([A-Za-z0-9_-]{8,400})\.([A-Za-z0-9_-]{40,200})$/i);
  if (!m) throw Error(bad);
  let ok = false;
  let data = {};
  try {
    const key4 = await crypto.subtle.importKey("jwk", TRIAL_PUBLIC_KEY, { name: "ECDSA", namedCurve: "P-256" }, false, ["verify"]);
    ok = await crypto.subtle.verify({ name: "ECDSA", hash: "SHA-256" }, key4, fromB64url(m[2]), new TextEncoder().encode(m[1]));
    data = JSON.parse(new TextDecoder().decode(fromB64url(m[1])));
  } catch {
    ok = false;
  }
  if (!ok || data.v !== 1 || typeof data.u !== "number" || typeof data.i !== "string") throw Error(bad);
  if (data.u <= now) throw Error("Ce code d\u2019essai est expir\xE9 : abonne-toi pour continuer.");
  if (data.u > now + (CODE_MAX_DAYS + 1) * DAY2) throw Error(bad);
  return { until: data.u, id: data.i };
}
function trialActive(s, now = Date.now()) {
  if (typeof s.trialUntil !== "number" || now >= s.trialUntil) return false;
  if ((s.checkedAt ?? 0) > now + SKEW) return false;
  return s.trialUntil - now <= (CODE_MAX_DAYS + 1) * DAY2;
}
function versionBelow(version, than) {
  if (!version) return false;
  const a = version.split(".").map(Number);
  const b = than.split(".").map(Number);
  for (let i = 0; i < 3; i++) if ((a[i] ?? 0) !== (b[i] ?? 0)) return (a[i] ?? 0) < (b[i] ?? 0);
  return false;
}
var FREE = /* @__PURE__ */ new Set([
  "PUBLIC_SETTINGS",
  "UPDATE_CHECK",
  "UPDATE_DISK",
  "UPDATE_RELOAD_NOW",
  "HEALTH_CHECK",
  "STATUS_NOTE",
  "PAGE_PREF",
  "SALES_LIST",
  "WATCH_STATE",
  "COMPETITOR_LIST",
  "PROFIT_MODEL",
  "SCOUT_STOP",
  "OPTIMIZE_UNLOCK"
]);
var FREE_LIBRARY = /* @__PURE__ */ new Set(["list", "get-product", "export", "import"]);
function allowedWithoutLicense(msg) {
  const m = msg;
  if (typeof m?.type !== "string") return false;
  if (m.type.startsWith("LICENSE_") || FREE.has(m.type)) return true;
  return m.type === "LIBRARY" && FREE_LIBRARY.has(String(m.command?.action));
}

// src/background/apiTrace.ts
var KEY = "apiTrace:v1";
var queue = Promise.resolve();
var kept = null;
function apiTrace(jobId, step, detail) {
  const entry = {
    at: (/* @__PURE__ */ new Date()).toISOString(),
    jobId,
    step,
    ...detail === void 0 ? {} : { detail: scrub(detail) }
  };
  queue = queue.then(async () => {
    kept ??= (await chrome.storage.session.get(KEY))[KEY] ?? [];
    kept = [...kept, entry].slice(-200);
    await chrome.storage.session.set({ [KEY]: kept });
  }).catch(() => {
  });
}
function scrub(value, depth = 0) {
  if (depth > 5) return "\u2026";
  if (typeof value === "string")
    return value.replace(/([?&](?:srt|token|csrf|s|n|uaes|uaek)=)[^&]*/gi, "$1\u2026").slice(0, 1500);
  if (Array.isArray(value))
    return value.slice(0, 40).map((v) => scrub(v, depth + 1));
  if (value && typeof value === "object")
    return Object.fromEntries(
      Object.entries(value).filter(([k]) => !/csrf|srt|token|cookie|uaes|uaek|secret|epsData/i.test(k)).map(([k, v]) => [k, scrub(v, depth + 1)])
    );
  return value;
}

// src/background/license.ts
var API = "https://api.lemonsqueezy.com/v1/licenses";
async function call(action, fields) {
  const r = await fetch(`${API}/${action}`, {
    method: "POST",
    headers: { Accept: "application/json", "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams(fields).toString(),
    credentials: "omit",
    signal: AbortSignal.timeout(2e4)
  });
  if (typeof r.status !== "number" || r.status >= 500) throw Error(`HTTP ${r.status}`);
  const body2 = await r.json().catch(() => null);
  return body2 && typeof body2 === "object" ? body2 : { error: `HTTP ${r.status}` };
}
var expired = (at) => typeof at === "string" && Date.parse(at) < Date.now() - 864e5;
var confirms = (a) => a.meta?.product_id === LICENSE_PRODUCT_ID && a.license_key?.status === "active" && !expired(a.license_key?.expires_at);
var licenseState = readLicense;
async function save(s) {
  const sealed = await sealLicense(s);
  await chrome.storage.local.set({ [LICENSE_KEY]: sealed });
  return sealed;
}
async function checkLicenseSeal() {
  const raw = (await chrome.storage.local.get(LICENSE_KEY))[LICENSE_KEY];
  if (raw === void 0) return;
  const { state, sealed } = await trustedLicense(raw);
  if (sealed) return;
  await save(state);
  if (state.key) await refreshLicense(true).catch(() => {
  });
}
var french = (error) => {
  const e = String(error ?? "");
  if (/activation limit/i.test(e)) return "Cette cl\xE9 est d\xE9j\xE0 utilis\xE9e sur 2 navigateurs : lib\xE8re-la sur l\u2019autre ordinateur (Param\xE8tres \u2192 Abonnement), puis r\xE9essaie.";
  if (/not found|invalid|does not exist/i.test(e)) return "Cl\xE9 de licence introuvable : v\xE9rifie-la dans l\u2019e-mail re\xE7u apr\xE8s le paiement.";
  if (/expired/i.test(e)) return "Abonnement termin\xE9 : renouvelle-le pour r\xE9activer AurOEBay.";
  if (/disabled/i.test(e)) return "Licence d\xE9sactiv\xE9e : contacte bonjour@impression-minute.fr.";
  return e ? `Lemon Squeezy : ${e}` : "R\xE9ponse inattendue de Lemon Squeezy.";
};
async function activateLicense(rawKey) {
  const key4 = typeof rawKey === "string" ? cleanLicenseInput(rawKey) : "";
  if (!key4)
    throw Error("La case est vide : rien n\u2019a \xE9t\xE9 coll\xE9. Copie le code sur CET ordinateur (pas sur ton t\xE9l\xE9phone), colle-le dans la case avec Cmd+V (Ctrl+V sur Windows), puis clique \xAB Activer \xBB.");
  if (isTrialCode(key4) || /essai/i.test(key4)) return activateTrial(key4);
  if (!/^[A-Za-z0-9-]{16,64}$/.test(key4))
    throw Error("Colle la cl\xE9 de licence compl\xE8te re\xE7ue par e-mail (lettres, chiffres et tirets). Un code d\u2019essai, lui, commence par \xAB ESSAI- \xBB : copie-le en entier, sans le retaper.");
  const previous = await licenseState();
  if (previous.key && previous.key !== key4 && previous.instanceId)
    await call("deactivate", { license_key: previous.key, instance_id: previous.instanceId }).catch(() => {
    });
  let a;
  try {
    a = await call("activate", { license_key: key4, instance_name: `AurOEBay Chrome ${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}` });
  } catch {
    throw Error("Pas de connexion \xE0 Lemon Squeezy : v\xE9rifie ta connexion internet, puis r\xE9essaie.");
  }
  if (a.activated !== true || typeof a.instance?.id !== "string" || !a.instance.id) throw Error(french(a.error));
  if (a.meta?.product_id !== LICENSE_PRODUCT_ID) {
    await call("deactivate", { license_key: key4, instance_id: a.instance.id }).catch(() => {
    });
    throw Error("Cette cl\xE9 n\u2019est pas une licence AurOEBay.");
  }
  if (!confirms(a)) {
    await call("deactivate", { license_key: key4, instance_id: a.instance.id }).catch(() => {
    });
    throw Error(french(a.license_key?.status === "active" ? "expired" : a.license_key?.status ?? a.error));
  }
  apiTrace("license", "activated", { status: a.license_key?.status });
  const now = Date.now();
  return save({
    key: key4,
    instanceId: a.instance.id,
    status: "active",
    checkedAt: now,
    triedAt: now,
    email: a.meta?.customer_email,
    expiresAt: a.license_key?.expires_at ?? null
  });
}
async function activateTrial(code) {
  const previous = await licenseState();
  if (previous.key && licenseActive(previous)) throw Error("Ton abonnement est d\xE9j\xE0 actif : pas besoin de code d\u2019essai.");
  const { until, id } = await readTrialCode(code);
  if (previous.key && previous.instanceId)
    await call("deactivate", { license_key: previous.key, instance_id: previous.instanceId }).catch(() => {
    });
  apiTrace("license", "trial", { until: new Date(until).toISOString().slice(0, 10) });
  const now = Date.now();
  return save({ status: "trial", trialUntil: until, trialId: id, checkedAt: now, triedAt: now });
}
async function refreshLicense(force = false) {
  const s = await licenseState();
  if (s.status === "trial" && !trialActive(s)) return save({ status: "trial-ended", trialId: s.trialId });
  if (!s.key || !s.instanceId || s.owner || !force && !licenseCheckDue(s)) return s;
  const now = Date.now();
  let a;
  try {
    a = await call("validate", { license_key: s.key, instance_id: s.instanceId });
  } catch {
    return save({ ...s, triedAt: now, error: "Pas de connexion \xE0 Lemon Squeezy." });
  }
  if (a.valid === true && confirms(a) && (a.instance?.id == null || a.instance.id === s.instanceId))
    return save({ ...s, status: "active", checkedAt: now, triedAt: now, expiresAt: a.license_key?.expires_at ?? null, error: void 0 });
  apiTrace("license", "invalid", { status: a.license_key?.status, error: a.error ?? "" });
  const status = a.license_key?.status && a.license_key.status !== "active" ? a.license_key.status : expired(a.license_key?.expires_at) ? "expired" : "inactive";
  return save({ ...s, status, triedAt: now, error: french(a.error ?? status) });
}
async function releaseLicense() {
  const s = await licenseState();
  if (s.key && s.instanceId) {
    const a = await call("deactivate", { license_key: s.key, instance_id: s.instanceId }).catch(() => null);
    if (a?.deactivated !== true)
      throw Error("La cl\xE9 n\u2019a pas pu \xEAtre lib\xE9r\xE9e (connexion \xE0 Lemon Squeezy). Elle reste sur ce navigateur : r\xE9essaie une fois connect\xE9.");
  }
  return save(s.owner ? { owner: true } : {});
}

// src/core/health.ts
var EBAY_SESSION_KEY = "ebaySession:v1";
var ALI_REGION_KEY = "aliRegion:v1";
var DAY3 = 864e5;
var ago = (at, now) => {
  const d = Math.floor((now - at) / DAY3);
  return d <= 0 ? "aujourd\u2019hui" : d === 1 ? "hier" : `il y a ${d} jours`;
};
var HELP = "https://auroebay.netlify.app/guide.html";
function healthItems(i) {
  const now = i.now ?? Date.now();
  const items = [
    i.licenseActive ? { id: "license", ok: true, title: "Abonnement", text: "Ta licence est active." } : { id: "license", ok: false, title: "Abonnement", text: "AurOEBay est en pause : entre ta cl\xE9 de licence (re\xE7ue par e-mail).", action: { label: "Entrer ma cl\xE9", href: "options.html#license-box" } },
    i.latest ? { id: "update", ok: false, title: "Version", text: `La version ${i.latest} est sortie (tu as ${i.version}). Mise \xE0 jour en 1 minute, tes donn\xE9es sont gard\xE9es.`, action: { label: "Mettre \xE0 jour", href: "https://auroebay.netlify.app/mise-a-jour" } } : { id: "update", ok: true, title: "Version", text: `Tu as la derni\xE8re version (${i.version}).` },
    !i.ebay ? { id: "ebay", ok: false, unknown: true, title: "Compte eBay", text: "Ouvre ebay.com une fois pour que je v\xE9rifie ta connexion.", action: { label: "Ouvrir eBay", href: "https://www.ebay.com/" } } : i.ebay.signedIn ? { id: "ebay", ok: true, title: "Compte eBay", text: `Tu es connect\xE9 \xE0 eBay (v\xE9rifi\xE9 ${ago(i.ebay.at, now)}).` } : { id: "ebay", ok: false, title: "Compte eBay", text: "Tu n\u2019es pas connect\xE9 \xE0 eBay dans ce Chrome : connecte-toi sur ebay.com.", action: { label: "Me connecter", href: "https://signin.ebay.com/" } },
    !i.ali ? { id: "aliexpress", ok: false, unknown: true, title: "AliExpress en mode US", text: "Ouvre aliexpress.us une fois pour que je v\xE9rifie le mode US.", action: { label: "Ouvrir AliExpress US", href: "https://www.aliexpress.us/" } } : i.ali.problem ? { id: "aliexpress", ok: false, title: "AliExpress en mode US", text: i.ali.problem === "domain" ? "Tu n\u2019\xE9tais pas sur aliexpress.us : passe toujours par aliexpress.us." : "AliExpress affichait des euros : en haut \xE0 droite, choisis United States et USD, puis Save.", action: { label: "Comment faire ?", href: `${HELP}#aliexpress` } } : { id: "aliexpress", ok: true, title: "AliExpress en mode US", text: `AliExpress est en mode US (v\xE9rifi\xE9 ${ago(i.ali.at, now)}).` },
    i.pinned === false ? { id: "pin", ok: false, title: "Ic\xF4ne AurOEBay", text: "\xC9pingle AurOEBay : clique la pi\xE8ce de puzzle \u{1F9E9} en haut \xE0 droite de Chrome, puis la punaise \u{1F4CC} \xE0 c\xF4t\xE9 d\u2019AurOEBay." } : { id: "pin", ok: true, unknown: i.pinned === null, title: "Ic\xF4ne AurOEBay", text: "AurOEBay est \xE9pingl\xE9 en haut de Chrome." },
    i.pricing ? { id: "pricing", ok: true, title: "R\xE8gle de prix", text: "Ta r\xE8gle de prix est enregistr\xE9e." } : { id: "pricing", ok: false, title: "R\xE8gle de prix", text: "Pas encore de r\xE8gle de prix : elle sera demand\xE9e \xE0 ton premier brouillon eBay (coefficient, montant fixe, arrondi).", action: { label: "Voir comment", href: `${HELP}#brouillon` } },
    i.shopName ? { id: "shop", ok: true, title: "Nom de la boutique", text: `\xAB ${i.shopName} \xBB en haut de tes descriptions.` } : { id: "shop", ok: false, title: "Nom de la boutique", text: "Indique le nom de ta boutique : il s\u2019affiche en haut de tes descriptions.", action: { label: "L\u2019indiquer", href: "options.html" } },
    i.backupFolder && i.backupAt && now - i.backupAt < 3 * DAY3 ? { id: "backup", ok: true, title: "Sauvegarde", text: `Sauvegarde automatique active (derni\xE8re ${ago(i.backupAt, now)}).` } : { id: "backup", ok: false, title: "Sauvegarde", text: i.backupFolder ? "La sauvegarde automatique n\u2019a pas tourn\xE9 depuis 3 jours : ouvre Mes produits pour la relancer." : "Active la sauvegarde automatique (un dossier iCloud ou Google Drive) : tes produits et ventes seront \xE0 l\u2019abri.", action: { label: "R\xE9gler", href: "dashboard.html#backup" } }
  ];
  return items;
}

// src/core/text.ts
var compact = (s) => s.replace(/\s+/g, " ").trim();
var norm = (s) => compact(s.normalize("NFKC")).toLowerCase().replace(/[\s\W_]+/g, " ").trim();
var escapeHTML = (s) => s.replace(
  /[&<>"']/g,
  (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]
);
function validTitle(s, max = 80) {
  return !!s.trim() && !/[\r\n]/.test(s) && s.length <= Math.min(80, max);
}
var delay = (ms) => new Promise((r) => setTimeout(r, ms));
function withTimeout(promise, ms) {
  let timer;
  return Promise.race([
    promise,
    new Promise((_, reject) => timer = setTimeout(() => reject(Error("Pas de r\xE9ponse \xE0 temps.")), ms))
  ]).finally(() => clearTimeout(timer));
}

// src/core/descriptionDesign.ts
var DESCRIPTION_TEMPLATE = '<style>\n.auro-listing{font-family:Arial,Helvetica,sans-serif;color:#213a37;background:#f3f5f3;max-width:960px;margin:0 auto;padding:24px;box-sizing:border-box;line-height:1.65}\n.auro-listing *{box-sizing:border-box}.auro-listing .auro-brand{font-size:12px;letter-spacing:3px;font-weight:bold;margin-bottom:20px;color:#44645b}.auro-listing .auro-header{background:#183e35;color:white;border-radius:14px;padding:30px}.auro-listing h1{font-size:26px;line-height:1.3;margin:10px 0 0}.auro-listing .auro-eyebrow{font-size:11px;letter-spacing:2px;text-transform:uppercase}.auro-listing .auro-body{background:white;border:1px solid #dce5dd;border-radius:14px;margin-top:18px;padding:24px;overflow-wrap:anywhere}.auro-listing .auro-body img{max-width:100%!important;height:auto!important;display:block;margin:18px auto}.auro-listing .auro-body table{max-width:100%;width:auto}.auro-listing .auro-body p{margin:12px 0}.auro-listing .auro-note{font-size:13px;color:#587064;padding:18px 4px}.auro-listing .auro-note strong{color:#213a37}@media(max-width:600px){.auro-listing{padding:12px}.auro-listing .auro-header,.auro-listing .auro-body{padding:18px}.auro-listing h1{font-size:22px}}\n</style>\n<div class="auro-listing">\n{store}\n<div class="auro-header"><div class="auro-eyebrow">Product details</div><h1>{title}</h1></div>\n<div class="auro-body">{description}</div>\n<div class="auro-note"><strong>Choose your option</strong><br>Please check the selected variation, dimensions and item details before ordering.<br>Delivery estimates, shipping charges and return terms are shown in this eBay listing.</div>\n</div>\n';
var listingStore = "";
var DESCRIPTION_THEMES = {
  classic: { label: "Vert classique", font: "Arial,Helvetica,sans-serif", ink: "#213a37", page: "#f3f5f3", brand: "#44645b", header: "#183e35", headerInk: "white", card: "white", border: "#dce5dd", radius: "14px", note: "#587064" },
  minimal: { label: "Blanc minimal", font: "Helvetica,Arial,sans-serif", ink: "#1d1d1f", page: "#ffffff", brand: "#86868b", header: "#ffffff;border-bottom:2px solid #1d1d1f", headerInk: "#1d1d1f", card: "white", border: "#e5e5e7", radius: "4px", note: "#6e6e73" },
  ocean: { label: "Bleu oc\xE9an", font: "Arial,Helvetica,sans-serif", ink: "#13293d", page: "#eef4fa", brand: "#2f6690", header: "linear-gradient(135deg,#0b4f9c,#1677d2)", headerInk: "white", card: "white", border: "#d4e3f2", radius: "14px", note: "#4a6582" },
  noir: { label: "Noir & or", font: "Georgia,'Times New Roman',serif", ink: "#1a1a1a", page: "#f5f3ee", brand: "#a8842c", header: "#111111", headerInk: "#f5c451", card: "white", border: "#e6dfcf", radius: "6px", note: "#6b6252" },
  sunset: { label: "Orange \xE9nergie", font: "Arial,Helvetica,sans-serif", ink: "#2b1d16", page: "#fff6ef", brand: "#e8590c", header: "linear-gradient(135deg,#ff5f3a,#ff8a3d 50%,#ffb347)", headerInk: "white", card: "white", border: "#ffe0cc", radius: "18px", note: "#7a5a48" },
  rose: { label: "Rose doux", font: "'Trebuchet MS',Arial,sans-serif", ink: "#3b1f2b", page: "#fff0f5", brand: "#c2255c", header: "linear-gradient(135deg,#f06595,#faa2c1)", headerInk: "white", card: "white", border: "#fcd6e3", radius: "20px", note: "#86566a" },
  tech: { label: "Tech sombre", font: "Verdana,Arial,sans-serif", ink: "#1b2733", page: "#e9eef2", brand: "#0c8599", header: "linear-gradient(135deg,#1b2733,#22394d)", headerInk: "#66d9e8", card: "white", border: "#cfd9e1", radius: "10px", note: "#52667a" }
};
var listingTheme = "classic";
function setListingTheme(id) {
  listingTheme = typeof id === "string" && id in DESCRIPTION_THEMES ? id : "classic";
}
function descriptionTemplate(id = listingTheme) {
  const t = DESCRIPTION_THEMES[id];
  if (!t || id === "classic") return DESCRIPTION_TEMPLATE;
  return DESCRIPTION_TEMPLATE.replace("font-family:Arial,Helvetica,sans-serif", `font-family:${t.font}`).replace("color:#213a37;background:#f3f5f3", `color:${t.ink};background:${t.page}`).replace("color:#44645b", `color:${t.brand}`).replace("background:#183e35;color:white;border-radius:14px", `background:${t.header};color:${t.headerInk};border-radius:${t.radius}`).replace("background:white;border:1px solid #dce5dd;border-radius:14px", `background:${t.card};border:1px solid ${t.border};border-radius:${t.radius}`).replace("color:#587064", `color:${t.note}`).replace(".auro-note strong{color:#213a37}", `.auro-note strong{color:${t.ink}}`);
}
function setListingStore(name) {
  listingStore = typeof name === "string" ? name.trim().slice(0, 40) : "";
}
function listingDescriptionHTML(title, bodyHTML, store = listingStore, theme = listingTheme) {
  const text3 = escapeHTML(title).replace(/&#39;/g, "'").replace(/&quot;/g, '"').replace(/\u00a0/g, "&nbsp;");
  const brand = store ? `<div class="auro-brand">${escapeHTML(store.toUpperCase().replace(/\s+/g, ""))}</div>
` : "";
  return descriptionTemplate(theme).replace(
    /\{title\}|\{description\}|\{store\}\n?/g,
    (placeholder) => placeholder === "{title}" ? text3 : placeholder === "{description}" ? bodyHTML : brand
  );
}

// src/core/bannerStyle.ts
var BANNER_PRESETS = {
  aurore: { label: "Orange Aurore", stops: ["#ff5f3a", "#ff8a3d", "#ffb347"], ink: "#ffffff", shadow: "rgba(150,30,10,.25)" },
  rouge: { label: "Rouge promo", stops: ["#c8102e", "#e3262f", "#ff4d4d"], ink: "#ffffff", shadow: "rgba(80,0,0,.3)" },
  noir: { label: "Noir & or", stops: ["#0d0d0d", "#1c1c1c", "#2b2b2b"], ink: "#f5c451", shadow: "rgba(0,0,0,.5)" },
  bleu: { label: "Bleu oc\xE9an", stops: ["#0b4f9c", "#1677d2", "#36a3f5"], ink: "#ffffff", shadow: "rgba(0,30,80,.3)" },
  vert: { label: "Vert frais", stops: ["#0f7a4a", "#16a05e", "#3cc77c"], ink: "#ffffff", shadow: "rgba(0,60,30,.3)" },
  rose: { label: "Rose", stops: ["#d6336c", "#f06595", "#faa2c1"], ink: "#ffffff", shadow: "rgba(110,0,40,.25)" },
  violet: { label: "Violet n\xE9on", stops: ["#5f3dc4", "#7950f2", "#b197fc"], ink: "#ffffff", shadow: "rgba(40,0,90,.3)" },
  jaune: { label: "Jaune flash", stops: ["#ffd43b", "#ffe066", "#fff3bf"], ink: "#1a1a1a", shadow: "rgba(120,90,0,.2)" },
  blanc: { label: "Blanc sobre", stops: ["#ffffff", "#f6f6f6", "#ececec"], ink: "#1a1a1a", shadow: "rgba(0,0,0,.08)" }
};
var BANNER_TEXT = /^[\p{L}\p{N} !%&'+.,:/#$€£-]*$/u;
function bannerStyle(s) {
  const preset = BANNER_PRESETS[s.bannerPreset ?? "aurore"] ?? BANNER_PRESETS.aurore;
  return {
    stops: preset.stops,
    ink: preset.ink,
    shadow: preset.shadow,
    main: (s.bannerMain ?? "SALE").trim(),
    title: (s.bannerTitle ?? "HOT DEALS").trim(),
    sub: (s.bannerSub ?? "SHOP NOW").trim(),
    position: s.bannerPosition === "bottom" ? "bottom" : "top"
  };
}

// src/core/settings.ts
var DEFAULTS = {
  enabled: true,
  model: "gpt-5-nano",
  reasoningEffort: "minimal",
  temperature: null,
  timeoutMs: 9e4,
  maxTitle: 80,
  minTitle: 65,
  autoConfidence: 0.9,
  probableConfidence: 0.75,
  strictFactual: true,
  rewriteDescription: true,
  aiSpecifics: true,
  captureEnabled: true,
  sourceExpiryMinutes: 120,
  sellerEnabled: true,
  haloEnabled: true,
  sellerTtlDays: 7,
  resultsEnabled: false,
  saleBanner: true,
  bannerPreset: "aurore",
  bannerMain: "SALE",
  bannerTitle: "HOT DEALS",
  bannerSub: "SHOP NOW",
  bannerPosition: "top",
  descriptionTemplate: "classic",
  storeName: "",
  debug: false,
  showSelectors: false,
  fallbackSelectors: { title: "", description: "", specifics: "" }
};
function validateSettings(input) {
  const s = {
    ...DEFAULTS,
    ...input,
    fallbackSelectors: {
      ...DEFAULTS.fallbackSelectors,
      ...input.fallbackSelectors
    }
  };
  const range = (key4, min, max) => {
    const n = s[key4];
    if (typeof n !== "number" || !Number.isFinite(n) || n < min || n > max)
      throw Error(`Invalid setting: ${key4} (${min}\u2013${max})`);
  };
  range("timeoutMs", 5e3, 18e4);
  range("maxTitle", 20, 80);
  range("minTitle", 0, s.maxTitle);
  range("autoConfidence", 0.9, 1);
  range("probableConfidence", 0.75, s.autoConfidence);
  range("sourceExpiryMinutes", 1, 1440);
  if (![1, 3, 7, 14, 30].includes(s.sellerTtlDays))
    throw Error("Invalid seller TTL");
  if (!/^[a-zA-Z0-9._:-]{1,100}$/.test(s.model))
    throw Error("Invalid model name");
  if (!["", "none", "minimal", "low", "medium", "high"].includes(
    s.reasoningEffort
  ))
    throw Error("Invalid reasoning effort");
  if (s.temperature !== null && (typeof s.temperature !== "number" || !Number.isFinite(s.temperature) || s.temperature < 0 || s.temperature > 2))
    throw Error("Invalid temperature");
  for (const k of [
    "enabled",
    "strictFactual",
    "rewriteDescription",
    "aiSpecifics",
    "captureEnabled",
    "sellerEnabled",
    "haloEnabled",
    "resultsEnabled",
    "saleBanner",
    "debug",
    "showSelectors"
  ])
    if (typeof s[k] !== "boolean") throw Error(`Invalid ${k}`);
  if (typeof s.storeName !== "string" || s.storeName.length > 40 || /[<>{}]/.test(s.storeName))
    throw Error("Nom de boutique invalide (40 caract\xE8res, sans < > { }).");
  s.storeName = s.storeName.trim();
  if (!(s.bannerPreset in BANNER_PRESETS)) throw Error("Couleurs du bandeau inconnues.");
  if (!["top", "bottom"].includes(s.bannerPosition)) throw Error("Position du bandeau invalide.");
  for (const [k, max] of [["bannerMain", 12], ["bannerTitle", 20], ["bannerSub", 24]]) {
    if (typeof s[k] !== "string" || s[k].length > max || !BANNER_TEXT.test(s[k]))
      throw Error(`Texte du bandeau trop long ou avec des signes non permis (${max} caract\xE8res au plus).`);
    s[k] = s[k].trim();
  }
  if (!s.bannerMain && !s.bannerTitle && !s.bannerSub) throw Error("Le bandeau a besoin d\u2019au moins un texte.");
  if (!(s.descriptionTemplate in DESCRIPTION_THEMES)) throw Error("Mod\xE8le de description inconnu.");
  for (const v of Object.values(s.fallbackSelectors))
    if (typeof v !== "string" || v.length > 500)
      throw Error("Invalid selector");
  return s;
}
async function getSettings() {
  const { settings, extensionEnabled = true, [LICENSE_KEY]: license } = await chrome.storage.local.get([
    "settings",
    "extensionEnabled",
    LICENSE_KEY
  ]);
  const on = extensionEnabled !== false && licenseActive((await trustedLicense(license)).state);
  try {
    const s = validateSettings({
      ...settings,
      enabled: on
    });
    setListingStore(s.storeName);
    setListingTheme(s.descriptionTemplate);
    return s;
  } catch {
    return {
      ...structuredClone(DEFAULTS),
      enabled: on
    };
  }
}

// src/core/country.ts
var codes = "AD AE AF AG AI AL AM AO AQ AR AS AT AU AW AX AZ BA BB BD BE BF BG BH BI BJ BL BM BN BO BQ BR BS BT BV BW BY BZ CA CC CD CF CG CH CI CK CL CM CN CO CR CU CV CW CX CY CZ DE DJ DK DM DO DZ EC EE EG EH ER ES ET FI FJ FK FM FO FR GA GB GD GE GF GG GH GI GL GM GN GP GQ GR GS GT GU GW GY HK HM HN HR HT HU ID IE IL IM IN IO IQ IR IS IT JE JM JO JP KE KG KH KI KM KN KP KR KW KY KZ LA LB LC LI LK LR LS LT LU LV LY MA MC MD ME MF MG MH MK ML MM MN MO MP MQ MR MS MT MU MV MW MX MY MZ NA NC NE NF NG NI NL NO NP NR NU NZ OM PA PE PF PG PH PK PL PM PN PR PS PT PW PY QA RE RO RS RU RW SA SB SC SD SE SG SH SI SJ SK SL SM SN SO SR SS ST SV SX SY SZ TC TD TF TG TH TJ TK TL TM TN TO TR TT TV TW TZ UA UG UM US UY UZ VA VC VE VG VI VN VU WF WS YE YT ZA ZM ZW".split(
  " "
);
var names = new Intl.DisplayNames(["en"], { type: "region" });
var map = /* @__PURE__ */ new Map();
for (const code of codes) {
  const name = names.of(code);
  map.set(norm(code), name);
  map.set(norm(name), name);
}
for (const [alias, name] of Object.entries({
  "mainland china": "China",
  "cn origin": "China",
  "china mainland": "China",
  "china origin": "China",
  prc: "China",
  "people s republic of china": "China",
  usa: "United States",
  "u s a": "United States",
  "united states of america": "United States",
  uk: "United Kingdom",
  "great britain": "United Kingdom",
  "south korea": "South Korea",
  "republic of korea": "South Korea",
  taiwan: "Taiwan",
  vietnam: "Vietnam",
  turkey: "T\xFCrkiye"
}))
  map.set(norm(alias), name);
function normalizeCountry(value) {
  return map.get(norm(value)) ?? null;
}
function manufactureLabel(label) {
  return [
    "origin",
    "country region of manufacture",
    "country of manufacture",
    "country of origin",
    "manufactured in",
    "made in",
    "origine",
    "pays de fabrication",
    "pays d origine"
  ].includes(norm(label));
}

// src/core/product.ts
var unknownShipping = () => ({
  status: "UNKNOWN",
  cost: null,
  currency: null,
  freeShippingThreshold: null,
  minimumOrder: null,
  destination: null,
  deliveryEstimate: null,
  evidence: ""
});
function normalizeProduct(p) {
  const countries = [
    ...new Set(
      p.specs.filter((s) => manufactureLabel(s.label)).map((s) => normalizeCountry(s.value)).filter((c) => !!c)
    )
  ];
  return {
    schemaVersion: 1,
    supplier: "aliexpress",
    supplierProductId: p.id,
    sourceUrl: p.url,
    sourceTitle: p.title,
    basePrice: null,
    currency: null,
    shipping: p.shippingDetails ?? unknownShipping(),
    images: p.images ?? [],
    specifications: p.specs,
    axes: p.variants,
    variantImages: p.variantImages ?? [],
    variants: (p.variantCosts ?? []).map((v) => ({
      attributes: v.values,
      cost: v.cost,
      currency: v.currency,
      stock: "UNKNOWN"
    })),
    description: p.description,
    descriptionHTML: p.descriptionHTML,
    descriptionStatus: p.descriptionStatus,
    descriptionImageCount: p.descriptionImageCount,
    countryOfOrigin: countries.length === 1 ? countries[0] : null,
    stock: "UNKNOWN",
    supplierMetadata: { names: p.supplierNames },
    extractedAt: p.capturedAt
  };
}

// src/core/shippingText.ts
var PRICE = String.raw`(?:US\s*)?\$\s*(\d+(?:\.\d{1,2})?)`;
var NAMED = new RegExp(String.raw`(?:standard|shipping|delivery|livraison)[^$·\d]{0,20}?${PRICE}`, "gi");
var LABEL = new RegExp(String.raw`\b[A-Za-z][A-Za-z' -]{1,30}:\s*${PRICE}`, "g");
var NOT_A_FEE = /over|orders|min|save|off\b|coupon|discount|code|price|extra/i;
function paidShipping(text3) {
  if (!text3) return null;
  const hit = [...text3.matchAll(NAMED), ...text3.matchAll(LABEL)].find((m) => !NOT_A_FEE.test(m[0]));
  const cost = hit ? Number(hit[1]) : 0;
  return cost > 0 && cost < 200 ? cost : null;
}

// src/aliexpress/images.ts
function supplierImageURL(value) {
  try {
    const u = new URL(value.startsWith("//") ? "https:" + value : value);
    if (u.protocol !== "https:" || u.username || u.password || u.port || !/(^|\.)(alicdn\.com|aliexpress-media\.com)$/.test(u.hostname))
      return null;
    u.pathname = u.pathname.replace(
      /\.(jpg|jpeg|png|webp)(?:_\d+x\d+[^/]*)?(?:_\.avif)?$/i,
      ".$1"
    );
    u.hash = "";
    for (const key4 of [...u.searchParams.keys()]) {
      if (!["has_lang", "ver"].includes(key4)) u.searchParams.delete(key4);
      else
        u.searchParams.set(
          key4,
          u.searchParams.get(key4).replace(/_\d+x\d+.*$/, "")
        );
    }
    if (!/\.(jpe?g|png|webp)$/i.test(u.pathname)) return null;
    return u.href;
  } catch {
    return null;
  }
}
function ebayListingImageURL(value) {
  try {
    const u = new URL(value.startsWith("//") ? "https:" + value : value);
    const id = u.pathname.match(/^\/images\/g\/([A-Za-z0-9~_-]{6,40})\/s-l\d+\.(?:jpe?g|png|webp)$/i)?.[1];
    if (u.protocol !== "https:" || u.username || u.password || u.port || u.hostname !== "i.ebayimg.com" || !id)
      return null;
    return `https://i.ebayimg.com/images/g/${id}/s-l1600.jpg`;
  } catch {
    return null;
  }
}
function importImageURL(value) {
  return supplierImageURL(value) ?? ebayListingImageURL(value);
}

// src/core/ebayLibrary.ts
var EBAY_LIBRARY_LIMITS = {
  htmlCharacters: 4e5,
  bytes: 15e5
};
function fail(message2 = "Capture eBay invalide.") {
  throw Error(message2);
}
function record(value) {
  if (!value || typeof value !== "object" || Array.isArray(value) || ![Object.prototype, null].includes(Object.getPrototypeOf(value)))
    fail();
  return value;
}
function text(value, max, empty2 = true) {
  if (typeof value !== "string" || value.length > max || !empty2 && !value.trim() || /[\u0000-\u0008\u000b\u000c\u000e-\u001f]/.test(value))
    fail();
  return value;
}
function timestamp(value) {
  if (typeof value !== "number" || !Number.isSafeInteger(value) || value < 0 || value > 864e13)
    fail("Date de capture eBay invalide.");
  return value;
}
function array(value, max, read2) {
  if (!Array.isArray(value) || value.length > max) fail();
  return value.map(read2);
}
function nullable(value, read2) {
  return value === null ? null : read2(value);
}
function https(value) {
  let url;
  try {
    url = new URL(text(value, 4096, false).trim());
  } catch {
    fail("Lien eBay HTTPS invalide.");
  }
  if (url.protocol !== "https:" || url.username || url.password || url.port)
    fail("Lien eBay HTTPS public requis.");
  return url;
}
function canonicalEbayLibraryURL(value) {
  const u = https(value);
  if (!/(^|\.)ebay\.com$/.test(u.hostname)) fail("Lien eBay US invalide.");
  const item = u.pathname.match(/^\/itm\/(?:[^/]+\/)?(\d{5,30})\/?$/)?.[1];
  if (item) return { url: `https://www.ebay.com/itm/${item}`, kind: "item" };
  const camel = u.searchParams.get("draftId"), alias = u.searchParams.get("draft_id");
  if (camel && alias && camel !== alias)
    fail("Identifiant de brouillon eBay ambigu.");
  const id = camel ?? alias;
  if (u.pathname === "/lstng" && id && /^\d{5,30}$/.test(id)) {
    const mode = u.searchParams.get("mode");
    if (mode && !["AddItem", "SellLikeItem", "SellSimilarItem"].includes(mode))
      fail("Mode de brouillon eBay invalide.");
    return {
      url: `https://www.ebay.com/lstng?draftId=${id}${mode ? `&mode=${mode}` : ""}`,
      kind: "draft"
    };
  }
  fail("Colle le lien d\u2019une annonce eBay ou d\u2019un brouillon eBay.");
}
function ebayLibraryImageURL(value) {
  try {
    const u = https(value);
    if (!/(^|\.)ebayimg\.com$/.test(u.hostname) || !/\.(?:jpe?g|png|webp|gif|avif)$/i.test(u.pathname))
      return null;
    u.hash = "";
    u.search = "";
    return u.href;
  } catch {
    return null;
  }
}
function specifics(value) {
  return array(value, 200, (v) => {
    const x = record(v);
    return { label: text(x.label, 300, false), value: text(x.value, 3e3) };
  });
}
function validateHistoricalEbaySeed(value) {
  const x = record(value), canonical = canonicalEbayLibraryURL(x.url);
  if (canonical.kind !== "item")
    fail("La r\xE9f\xE9rence eBay doit \xEAtre une annonce publique.");
  const itemId = canonical.url.split("/").pop();
  if (text(x.itemId, 30, false) !== itemId)
    fail("Identifiant eBay incoh\xE9rent.");
  const copy = https(x.copyUrl);
  if (copy.hostname !== "www.ebay.com" || copy.pathname !== "/sl/list" || copy.searchParams.get("itemId") !== itemId || !["SellLikeItem", "SellSimilarItem"].includes(
    copy.searchParams.get("mode") ?? ""
  ))
    fail("Lien de copie eBay invalide.");
  const title = text(x.title, 80, false);
  if (!validTitle(title)) fail("Titre de r\xE9f\xE9rence eBay invalide.");
  if (typeof x.hasVariations !== "boolean") fail();
  const seed = {
    itemId,
    url: canonical.url,
    copyUrl: `https://www.ebay.com/sl/list?mode=SellLikeItem&itemId=${itemId}&rt=nc`,
    title,
    category: text(x.category, 2e3),
    specifics: specifics(x.specifics),
    price: nullable(x.price, (v) => text(v, 300)),
    currency: nullable(x.currency, (v) => {
      if (v !== "USD") fail();
      return "USD";
    }),
    hasVariations: x.hasVariations,
    capturedAt: timestamp(x.capturedAt)
  };
  if (seed.specifics.length > 100) fail();
  if (x.categoryFromCopy !== void 0) {
    if (x.categoryFromCopy !== true) fail();
    seed.categoryFromCopy = true;
  }
  return seed;
}
function validateEbayLibrarySnapshot(value) {
  let serialized;
  try {
    serialized = JSON.stringify(value);
  } catch {
    fail();
  }
  if (typeof serialized !== "string" || new TextEncoder().encode(serialized).byteLength > EBAY_LIBRARY_LIMITS.bytes)
    fail("Capture eBay trop volumineuse.");
  const x = record(value), canonical = canonicalEbayLibraryURL(x.url);
  if (x.kind !== canonical.kind) fail("Type de capture eBay incoh\xE9rent.");
  const images = array(x.images, 100, (v) => {
    const image = ebayLibraryImageURL(text(v, 4096, false));
    if (!image) fail("Photo eBay non reconnue.");
    return image;
  });
  if (new Set(images).size !== images.length) fail("Photos eBay dupliqu\xE9es.");
  const snapshot = {
    ...canonical,
    title: text(x.title, 2e3, false),
    capturedAt: timestamp(x.capturedAt),
    category: text(x.category, 2e3),
    specifics: specifics(x.specifics),
    price: nullable(x.price, (v) => text(v, 500, false)),
    currency: nullable(x.currency, (v) => text(v, 8, false)),
    quantity: nullable(x.quantity, (v) => text(v, 300, false)),
    images,
    descriptionHTML: text(
      x.descriptionHTML,
      EBAY_LIBRARY_LIMITS.htmlCharacters
    ),
    descriptionText: text(
      x.descriptionText,
      EBAY_LIBRARY_LIMITS.htmlCharacters
    ),
    variants: array(x.variants, 10, (v) => {
      const a = record(v);
      return {
        name: text(a.name, 300, false),
        values: array(a.values, 200, (s) => text(s, 300, false)),
        ...a.price === void 0 ? {} : { price: text(a.price, 500) }
      };
    }),
    warnings: array(x.warnings, 100, (v) => text(v, 2e3, false))
  };
  if (x.seed !== void 0) {
    snapshot.seed = validateHistoricalEbaySeed(x.seed);
    if (snapshot.seed.url !== snapshot.url || snapshot.kind !== "item")
      fail(
        "La capture et la r\xE9f\xE9rence eBay d\xE9signent des annonces diff\xE9rentes."
      );
  }
  return snapshot;
}

// src/core/library.ts
var LIBRARY_LIMITS = {
  products: 1500,
  suppliers: 20,
  sourceBytes: 15e5,
  backupBytes: 1e8,
  htmlCharacters: 4e5
};
function fail2(message2 = "Donn\xE9es de biblioth\xE8que invalides.") {
  throw Error(message2);
}
function object(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) fail2();
  const proto = Object.getPrototypeOf(value);
  if (proto !== Object.prototype && proto !== null) fail2();
  return value;
}
function string(value, max, allowEmpty = true) {
  if (typeof value !== "string" || value.length > max || !allowEmpty && !value.trim() || /[\u0000-\u0008\u000b\u000c\u000e-\u001f]/.test(value))
    fail2();
  return value;
}
function number(value, min = 0, max = Number.MAX_SAFE_INTEGER) {
  if (typeof value !== "number" || !Number.isFinite(value) || value < min || value > max)
    fail2();
  return value;
}
function integer(value, min = 0, max = Number.MAX_SAFE_INTEGER) {
  const n = number(value, min, max);
  if (!Number.isSafeInteger(n)) fail2();
  return n;
}
function timestamp2(value) {
  return integer(value, 0, 864e13);
}
function bool(value) {
  if (typeof value !== "boolean") fail2();
  return value;
}
function list(value, max, validate) {
  if (!Array.isArray(value) || value.length > max) fail2();
  return value.map(validate);
}
function optional(value, validate) {
  return value === void 0 ? void 0 : validate(value);
}
function nullable2(value, validate) {
  return value === null ? null : validate(value);
}
function enumValue(value, choices) {
  if (typeof value !== "string" || !choices.includes(value)) fail2();
  return value;
}
function unique(values) {
  if (new Set(values).size !== values.length)
    fail2("Identifiants ou options dupliqu\xE9s dans la biblioth\xE8que.");
}
function libraryJSONBytes(value) {
  let serialized;
  try {
    serialized = JSON.stringify(value);
  } catch {
    fail2();
  }
  if (typeof serialized !== "string") fail2();
  return new TextEncoder().encode(serialized).byteLength;
}
function bounded(value, max) {
  if (libraryJSONBytes(value) > max)
    fail2(
      "La biblioth\xE8que d\xE9passe la taille maximale autoris\xE9e. Exporte une sauvegarde et retire des fournisseurs devenus inutiles."
    );
}
function https2(value) {
  let u;
  try {
    u = new URL(string(value, 4096, false).trim());
  } catch {
    fail2("Lien HTTPS invalide.");
  }
  if (u.protocol !== "https:" || u.username || u.password || u.port)
    fail2("Utilise un lien HTTPS public sans identifiants.");
  return u;
}
function canonicalLibraryAliURL(value) {
  const u = https2(value);
  if (!/(^|\.)aliexpress\.(com|us)$/.test(u.hostname) || !/^\/item\/\d{5,30}\.html$/.test(u.pathname))
    fail2("Lien de fiche AliExpress invalide.");
  return `https://www.aliexpress.com${u.pathname}`;
}
function canonicalLibraryEbayURL(value) {
  return canonicalEbayLibraryURL(value);
}
function imageURL(value) {
  const url = supplierImageURL(string(value, 4096, false));
  if (!url) fail2("Image fournisseur invalide.");
  return url;
}
function strings(value, max = 200, length = 300) {
  return list(value, max, (v) => string(v, length, false));
}
function pairs(value, max = 200) {
  return list(value, max, (v) => {
    const x = object(v);
    return { label: string(x.label, 300, false), value: string(x.value, 3e3) };
  });
}
function costs(value) {
  const result = list(value, 1e3, (v) => {
    const x = object(v);
    return {
      values: strings(x.values, 10),
      cost: number(x.cost, 0, 1e6),
      currency: enumValue(x.currency, [
        "USD",
        "EUR",
        "GBP",
        "CAD",
        "AUD",
        "CNY",
        "BRL",
        "JPY",
        "KRW",
        "MXN",
        "RUB",
        "TRY",
        "ILS",
        "PLN",
        "SAR",
        "AED",
        "CHF",
        "NZD",
        "SEK",
        "NOK",
        "DKK",
        "HUF",
        "CZK",
        "CLP",
        "UAH",
        "VND",
        "THB",
        "IDR",
        "MYR",
        "PHP",
        "SGD",
        "INR",
        "PKR",
        "ZAR",
        "BDT",
        "ARS",
        "COP",
        "PEN",
        "EGP"
      ])
    };
  });
  unique(result.map((x) => JSON.stringify(x.values)));
  return result;
}
function shipping(value) {
  const x = object(value);
  return {
    status: enumValue(x.status, ["KNOWN", "CONDITIONAL", "UNKNOWN"]),
    cost: nullable2(x.cost, (v) => number(v, 0, 1e6)),
    currency: nullable2(x.currency, (v) => string(v, 8, false)),
    freeShippingThreshold: nullable2(
      x.freeShippingThreshold,
      (v) => number(v, 0, 1e6)
    ),
    minimumOrder: nullable2(x.minimumOrder, (v) => number(v, 0, 1e6)),
    destination: nullable2(x.destination, (v) => string(v, 300)),
    deliveryEstimate: nullable2(x.deliveryEstimate, (v) => string(v, 1e3)),
    evidence: string(x.evidence, 3e3)
  };
}
function validateLibrarySource(value) {
  bounded(value, LIBRARY_LIMITS.sourceBytes);
  const x = object(value), url = canonicalLibraryAliURL(x.url);
  const id = url.match(/\/(\d+)\.html$/)[1];
  if (string(x.id, 30, false) !== id)
    fail2("L\u2019identifiant AliExpress ne correspond pas au lien.");
  const variants2 = list(x.variants, 10, (v) => {
    const a = object(v), values = strings(a.values);
    unique(values);
    return {
      name: string(a.name, 300, false),
      values,
      ...a.price === void 0 ? {} : { price: string(a.price, 300) }
    };
  });
  unique(variants2.map((v) => v.name));
  const source = {
    id,
    url,
    title: string(x.title, 2e3, false),
    capturedAt: timestamp2(x.capturedAt),
    specs: pairs(x.specs),
    description: string(x.description, LIBRARY_LIMITS.htmlCharacters),
    variants: variants2,
    supplierNames: strings(x.supplierNames, 30, 500)
  };
  if (x.descriptionHTML !== void 0)
    source.descriptionHTML = string(
      x.descriptionHTML,
      LIBRARY_LIMITS.htmlCharacters
    );
  if (x.descriptionStatus !== void 0)
    source.descriptionStatus = enumValue(x.descriptionStatus, [
      "loaded",
      "unavailable",
      "unsupported",
      "too-large"
    ]);
  if (x.descriptionImageCount !== void 0)
    source.descriptionImageCount = integer(x.descriptionImageCount, 0, 1e3);
  if (x.price !== void 0) source.price = string(x.price, 500);
  if (x.shipping !== void 0) source.shipping = string(x.shipping, 3e3);
  if (x.extractionVersion !== void 0)
    source.extractionVersion = enumValue(String(x.extractionVersion), ["1"]) === "1" ? 1 : fail2();
  if (x.images !== void 0)
    source.images = list(x.images, 300, (v) => {
      const i = object(v);
      return {
        url: imageURL(i.url),
        role: enumValue(i.role, ["gallery", "description"]),
        width: nullable2(i.width, (n) => integer(n, 1, 1e5)),
        height: nullable2(i.height, (n) => integer(n, 1, 1e5))
      };
    });
  if (x.variantImages !== void 0)
    source.variantImages = list(x.variantImages, 1e3, (v) => {
      const i = object(v);
      return {
        axis: string(i.axis, 300, false),
        value: string(i.value, 300, false),
        url: imageURL(i.url)
      };
    });
  if (x.shippingDetails !== void 0)
    source.shippingDetails = shipping(x.shippingDetails);
  if (x.variantCosts !== void 0) source.variantCosts = costs(x.variantCosts);
  if (x.variantScan !== void 0) {
    const scan = object(x.variantScan);
    source.variantScan = {
      at: timestamp2(scan.at),
      costs: costs(scan.costs),
      unavailable: list(scan.unavailable, 1e3, (v) => ({
        values: strings(object(v).values, 10)
      }))
    };
    if (scan.durationMs !== void 0)
      source.variantScan.durationMs = number(scan.durationMs, 0, 36e5);
    unique(source.variantScan.unavailable.map((v) => JSON.stringify(v.values)));
  }
  return source;
}
function validateLibraryPricing(value) {
  const x = object(value);
  return {
    coefficient: number(x.coefficient, 1e-3, 1e3),
    fixed: number(x.fixed, 0, 1e6),
    rounding: enumValue(x.rounding, ["none", "49", "99", "49-or-99"]),
    // « Rentable à X € »: shipping is then counted in the price.
    ...typeof x.target === "number" && Number.isFinite(x.target) && x.target >= 0 && x.target <= 1e3 ? { target: x.target } : {}
  };
}
function validateSeed(value) {
  return validateHistoricalEbaySeed(value);
}
function validateLink(value) {
  const x = object(value), canonical = canonicalLibraryEbayURL(x.url);
  if (x.kind !== canonical.kind) fail2("Type de lien eBay incoh\xE9rent.");
  const link = {
    ...canonical,
    title: string(x.title, 2e3),
    savedAt: timestamp2(x.savedAt)
  };
  if (x.seed !== void 0) {
    link.seed = validateSeed(x.seed);
    if (link.seed.url !== link.url)
      fail2("La r\xE9f\xE9rence eBay ne correspond pas \xE0 son instantan\xE9.");
  }
  if (x.snapshot !== void 0) {
    link.snapshot = validateEbayLibrarySnapshot(x.snapshot);
    if (ebayLinkIdentity(link.snapshot) !== ebayLinkIdentity(link))
      fail2("La capture eBay ne correspond pas au lien enregistr\xE9.");
  }
  return link;
}
function ebayLinkIdentity(link) {
  const u = new URL(link.url);
  return link.kind === "draft" ? `draft:${u.searchParams.get("draftId")}` : `item:${u.pathname.split("/").pop()}`;
}
function productId(value) {
  const id = string(value, 100, false);
  if (!/^[a-zA-Z0-9_-]{8,100}$/.test(id))
    fail2("Identifiant de produit invalide.");
  return id;
}
function validateLibraryProduct(value) {
  const x = object(value);
  const suppliers = list(x.suppliers, LIBRARY_LIMITS.suppliers, (v) => {
    const s = object(v), source = validateLibrarySource(s.source), url = canonicalLibraryAliURL(s.url);
    if (string(s.id, 30, false) !== source.id || url !== source.url)
      fail2("Fournisseur incoh\xE9rent.");
    return {
      id: source.id,
      url,
      source,
      addedAt: timestamp2(s.addedAt),
      updatedAt: timestamp2(s.updatedAt),
      ...s.descriptionReadAt === void 0 ? {} : { descriptionReadAt: timestamp2(s.descriptionReadAt) }
    };
  });
  unique(suppliers.map((s) => s.id));
  const primarySupplierId = nullable2(
    x.primarySupplierId,
    (v) => string(v, 30, false)
  );
  if (primarySupplierId !== null && !suppliers.some((s) => s.id === primarySupplierId))
    fail2("Fournisseur principal introuvable.");
  const ownListings = list(x.ownListings, 100, validateLink);
  unique(ownListings.map(ebayLinkIdentity));
  const ebayReference = nullable2(x.ebayReference, validateLink);
  if (ebayReference?.kind === "draft")
    fail2("La r\xE9f\xE9rence eBay doit \xEAtre une annonce, pas ton brouillon.");
  return {
    id: productId(x.id),
    name: string(x.name, 2e3, false),
    notes: string(x.notes, 2e4),
    archived: bool(x.archived),
    createdAt: timestamp2(x.createdAt),
    updatedAt: timestamp2(x.updatedAt),
    revision: integer(x.revision, 1),
    suppliers,
    primarySupplierId,
    pricing: nullable2(x.pricing, validateLibraryPricing),
    ebayReference,
    ownListings
  };
}
function validateLibraryBackup(value) {
  bounded(value, LIBRARY_LIMITS.backupBytes);
  const x = object(value);
  if (x.format !== "auroebay-library" || x.version !== 1)
    fail2("Sauvegarde AurOEBay inconnue ou version non prise en charge.");
  const products = list(
    x.products,
    LIBRARY_LIMITS.products,
    validateLibraryProduct
  );
  unique(products.map((p) => p.id));
  return {
    format: "auroebay-library",
    version: 1,
    exportedAt: timestamp2(x.exportedAt),
    products
  };
}
var sorted = (products) => products.sort(
  (a, b) => b.updatedAt - a.updatedAt || a.id.localeCompare(b.id)
);
var newId = () => `product_${crypto.randomUUID()}`;
function listProjection(product2) {
  const projectLink = (link) => ({
    ...link,
    ...link.snapshot ? {
      snapshot: {
        ...link.snapshot,
        descriptionHTML: "",
        descriptionText: ""
      }
    } : {}
  });
  return {
    ...product2,
    ebayReference: product2.ebayReference ? projectLink(product2.ebayReference) : null,
    ownListings: product2.ownListings.map(projectLink),
    suppliers: product2.suppliers.map((s) => {
      const {
        descriptionHTML: _html,
        description: _text,
        ...source
      } = s.source;
      return { ...s, source: { ...source, description: "" } };
    })
  };
}
function importedContent(product2) {
  return JSON.stringify({
    ...product2,
    id: "",
    name: product2.name.replace(/ \(copie importée\)$/, ""),
    updatedAt: 0,
    revision: 0
  });
}
function assertProduct(products, id) {
  const p = products.find((p2) => p2.id === productId(id));
  if (!p) fail2("Produit introuvable. Actualise le tableau de bord.");
  return p;
}
function createLink(url, title, now, seed) {
  const canonical = canonicalLibraryEbayURL(url);
  return validateLink({
    ...canonical,
    title: title ?? "",
    savedAt: now,
    ...seed === void 0 ? {} : { seed }
  });
}
function completeDescription(source) {
  return source.descriptionStatus === "loaded" && !!source.descriptionHTML?.trim();
}
function mergeSupplierCapture(previous, current2, now) {
  const old = previous.source;
  const merged = { ...current2 };
  const complete = completeDescription(current2);
  const fullyRead = complete && !!current2.variantScan;
  if (!complete && completeDescription(old)) {
    merged.description = old.description;
    merged.descriptionHTML = old.descriptionHTML;
    merged.descriptionStatus = old.descriptionStatus;
    merged.descriptionImageCount = old.descriptionImageCount;
  }
  if (!fullyRead) {
    if (!current2.images?.length && old.images) merged.images = old.images;
    if (!current2.variantImages?.length && old.variantImages)
      merged.variantImages = old.variantImages.filter(
        (image) => current2.variants.some(
          (axis) => axis.name === image.axis && axis.values.includes(image.value)
        )
      );
    if (!current2.specs.length && old.specs.length) merged.specs = old.specs;
    if (!current2.supplierNames.length && old.supplierNames.length)
      merged.supplierNames = old.supplierNames;
    if (current2.price === void 0 && old.price !== void 0)
      merged.price = old.price;
    if (current2.shipping === void 0 && old.shipping !== void 0)
      merged.shipping = old.shipping;
    if (current2.shippingDetails === void 0 && old.shippingDetails)
      merged.shippingDetails = old.shippingDetails;
  }
  const sameAxes = JSON.stringify(
    current2.variants.map((v) => ({ name: v.name, values: v.values }))
  ) === JSON.stringify(
    old.variants.map((v) => ({ name: v.name, values: v.values }))
  );
  if (sameAxes && old.variantScan && (!current2.variantScan || old.variantScan.at > current2.variantScan.at)) {
    merged.variantScan = old.variantScan;
    merged.variantCosts = old.variantCosts ?? old.variantScan.costs;
  } else if (!current2.variantScan && sameAxes && !current2.variantCosts && old.variantCosts) {
    merged.variantCosts = old.variantCosts;
  }
  return {
    ...previous,
    source: validateLibrarySource(merged),
    url: current2.url,
    updatedAt: now,
    ...complete ? { descriptionReadAt: current2.capturedAt } : completeDescription(old) ? { descriptionReadAt: previous.descriptionReadAt ?? old.capturedAt } : {}
  };
}
function applyLibraryCommand(current2, command, now = Date.now(), makeId = newId) {
  now = timestamp2(now);
  const products = current2.map(validateLibraryProduct);
  unique(products.map((p2) => p2.id));
  const c = object(command);
  if (c.action === "list")
    return { products, result: sorted([...products]).map(listProjection) };
  if (c.action === "get-product")
    return { products, result: assertProduct(products, c.productId) };
  if (c.action === "export") {
    const result = {
      format: "auroebay-library",
      version: 1,
      exportedAt: now,
      products: sorted([...products])
    };
    bounded(result, LIBRARY_LIMITS.backupBytes);
    return { products, result };
  }
  if (c.action === "import") {
    const incoming = validateLibraryBackup(c.backup);
    let added = 0, unchanged = 0, conflicts = 0;
    for (const p2 of incoming.products) {
      const existing = products.find((local) => local.id === p2.id);
      if (existing && JSON.stringify(existing) === JSON.stringify(p2)) {
        unchanged++;
        continue;
      }
      if (existing) {
        if (products.some(
          (local) => local.name.endsWith(" (copie import\xE9e)") && importedContent(local) === importedContent(p2)
        )) {
          unchanged++;
          continue;
        }
        p2.id = productId(makeId());
        if (products.some((local) => local.id === p2.id))
          fail2("Identifiant de copie dupliqu\xE9 : import annul\xE9.");
        p2.name = `${p2.name.slice(0, 1950)} (copie import\xE9e)`;
        p2.updatedAt = now;
        p2.revision = 1;
        conflicts++;
      }
      products.push(p2);
      added++;
    }
    if (products.length > LIBRARY_LIMITS.products)
      fail2(
        "La biblioth\xE8que est limit\xE9e \xE0 1 500 produits. L\u2019import a \xE9t\xE9 annul\xE9."
      );
    bounded(
      { format: "auroebay-library", version: 1, exportedAt: now, products },
      LIBRARY_LIMITS.backupBytes
    );
    return {
      products,
      result: { added, unchanged, conflicts, products: sorted([...products]) }
    };
  }
  if (c.action === "save-pair") {
    const ebay = validateEbayLibrarySnapshot(c.ebay);
    const role = enumValue(c.role, ["reference", "own"]);
    if (role === "reference" && ebay.kind !== "item")
      fail2("Un brouillon eBay ne peut pas servir de r\xE9f\xE9rence publique.");
    const transition = applyLibraryCommand(
      current2,
      {
        action: "save-source",
        source: c.source,
        ...c.productId === void 0 ? {} : { productId: c.productId },
        ...c.expectedRevision === void 0 ? {} : { expectedRevision: c.expectedRevision },
        ...c.newProduct === void 0 ? {} : { newProduct: c.newProduct },
        ...role === "reference" ? {
          referenceUrl: ebay.url,
          ...ebay.seed ? { ebaySeed: ebay.seed } : {}
        } : {}
      },
      now,
      makeId
    );
    const product2 = transition.result;
    const link = {
      url: ebay.url,
      kind: ebay.kind,
      title: ebay.title,
      savedAt: now,
      snapshot: ebay,
      ...ebay.seed ? { seed: ebay.seed } : {}
    };
    if (role === "reference") product2.ebayReference = link;
    else {
      const existing = product2.ownListings.findIndex(
        (l) => ebayLinkIdentity(l) === ebayLinkIdentity(link)
      );
      if (existing >= 0) product2.ownListings[existing] = link;
      else {
        if (product2.ownListings.length >= 100)
          fail2("Ce produit poss\xE8de d\xE9j\xE0 100 liens eBay.");
        product2.ownListings.push(link);
      }
    }
    if (!current2.some((p2) => p2.id === product2.id)) product2.name = ebay.title;
    validateLibraryProduct(product2);
    bounded(
      {
        format: "auroebay-library",
        version: 1,
        exportedAt: now,
        products: transition.products
      },
      LIBRARY_LIMITS.backupBytes
    );
    return { products: transition.products, result: product2 };
  }
  let p;
  if (c.action === "save-source") {
    const source = validateLibrarySource(c.source);
    const seed = optional(c.ebaySeed, validateSeed);
    if (c.newProduct !== void 0) bool(c.newProduct);
    if (c.newProduct === true && c.productId !== void 0)
      fail2("Choisis soit une nouvelle fiche, soit un produit existant.");
    const reference = c.referenceUrl === void 0 ? void 0 : canonicalLibraryEbayURL(c.referenceUrl);
    if (reference?.kind === "draft")
      fail2("La r\xE9f\xE9rence eBay doit \xEAtre une annonce publique.");
    if (reference && seed && reference.url !== seed.url)
      fail2("Le lien eBay et sa capture d\xE9signent deux r\xE9f\xE9rences diff\xE9rentes.");
    const referenceURL = reference?.url ?? seed?.url;
    if (c.productId !== void 0) {
      p = assertProduct(products, c.productId);
      if (c.expectedRevision !== void 0 && integer(c.expectedRevision, 1) !== p.revision)
        fail2(
          "Cette fiche a chang\xE9 pendant la lecture du fournisseur. Actualise-la avant d\u2019enregistrer cette capture."
        );
      if (referenceURL && p.ebayReference && p.ebayReference.url !== referenceURL)
        fail2(
          "Ce produit poss\xE8de une autre r\xE9f\xE9rence eBay. Modifie explicitement le lien de r\xE9f\xE9rence avant d\u2019enregistrer cette capture."
        );
    } else {
      if (c.expectedRevision !== void 0)
        fail2("Choisis le produit dont la r\xE9vision doit \xEAtre v\xE9rifi\xE9e.");
      const referenceMatch = referenceURL ? products.filter((v) => v.ebayReference?.url === referenceURL) : [];
      const supplierMatch = products.filter(
        (v) => v.suppliers.some((s) => s.id === source.id) && (!referenceURL || !v.ebayReference || v.ebayReference.url === referenceURL)
      );
      const matches = c.newProduct === true ? [] : referenceMatch.length ? referenceMatch : supplierMatch;
      if (matches.length > 1)
        fail2(
          "Ce fournisseur est li\xE9 \xE0 plusieurs produits : choisis la fiche \xE0 actualiser."
        );
      p = matches[0] ?? {
        id: productId(makeId()),
        name: seed?.title ?? source.title,
        notes: "",
        archived: false,
        createdAt: now,
        updatedAt: now,
        revision: 0,
        primarySupplierId: null,
        pricing: null,
        suppliers: [],
        ebayReference: null,
        ownListings: []
      };
      if (!matches.length) {
        if (products.some((local) => local.id === p.id))
          fail2("Identifiant de produit dupliqu\xE9.");
        products.push(p);
      }
    }
    const supplier = p.suppliers.find((s) => s.id === source.id);
    if (supplier) {
      if (source.capturedAt >= supplier.source.capturedAt) {
        Object.assign(supplier, mergeSupplierCapture(supplier, source, now));
      }
    } else {
      if (p.suppliers.length >= LIBRARY_LIMITS.suppliers)
        fail2("Ce produit poss\xE8de d\xE9j\xE0 20 fournisseurs.");
      p.suppliers.push({
        id: source.id,
        url: source.url,
        source,
        addedAt: now,
        updatedAt: now,
        ...completeDescription(source) ? { descriptionReadAt: source.capturedAt } : {}
      });
      p.primarySupplierId ??= source.id;
    }
    if (referenceURL) {
      const previous = p.ebayReference;
      p.ebayReference = createLink(referenceURL, seed?.title ?? "", now, seed);
      if (previous?.snapshot && ebayLinkIdentity(previous) === ebayLinkIdentity(p.ebayReference))
        p.ebayReference.snapshot = previous.snapshot;
    }
    if (c.pricing !== void 0) p.pricing = validateLibraryPricing(c.pricing);
  } else {
    p = assertProduct(products, c.productId);
    if (c.action === "patch-product") {
      if (c.expectedRevision !== void 0 && integer(c.expectedRevision, 1) !== p.revision)
        fail2(
          "Cette fiche a chang\xE9 dans un autre onglet. Actualise-la avant d\u2019enregistrer tes modifications."
        );
      const patch = object(c.patch);
      if (Object.keys(patch).some(
        (key4) => ![
          "name",
          "notes",
          "archived",
          "primarySupplierId",
          "pricing"
        ].includes(key4)
      ))
        fail2("Modification de biblioth\xE8que non prise en charge.");
      if (patch.name !== void 0)
        p.name = string(patch.name, 2e3, false).trim();
      if (patch.notes !== void 0) p.notes = string(patch.notes, 2e4);
      if (patch.archived !== void 0) p.archived = bool(patch.archived);
      if (patch.pricing !== void 0)
        p.pricing = nullable2(patch.pricing, validateLibraryPricing);
      if (patch.primarySupplierId !== void 0) {
        const id = nullable2(
          patch.primarySupplierId,
          (v) => string(v, 30, false)
        );
        if (id !== null && !p.suppliers.some((s) => s.id === id))
          fail2("Ce fournisseur n\u2019appartient pas au produit.");
        p.primarySupplierId = id;
      }
    } else if (c.action === "link-ebay") {
      const link = createLink(c.url, c.title, now, c.seed);
      if (c.role === "reference") {
        if (link.kind !== "item")
          fail2("Utilise une annonce publique comme r\xE9f\xE9rence eBay.");
        if (p.ebayReference?.snapshot && ebayLinkIdentity(p.ebayReference) === ebayLinkIdentity(link))
          link.snapshot = p.ebayReference.snapshot;
        p.ebayReference = link;
      } else if (c.role === "own") {
        const existing = p.ownListings.findIndex(
          (l) => ebayLinkIdentity(l) === ebayLinkIdentity(link)
        );
        if (existing >= 0) {
          if (p.ownListings[existing].snapshot)
            link.snapshot = p.ownListings[existing].snapshot;
          p.ownListings[existing] = link;
        } else {
          if (p.ownListings.length >= 100)
            fail2("Ce produit poss\xE8de d\xE9j\xE0 100 liens eBay.");
          p.ownListings.push(link);
        }
      } else fail2();
    } else if (c.action === "unlink-ebay") {
      if (c.role === "reference") p.ebayReference = null;
      else if (c.role === "own") {
        const key4 = ebayLinkIdentity(canonicalLibraryEbayURL(c.url));
        if (!p.ownListings.some((l) => ebayLinkIdentity(l) === key4))
          fail2("Ce lien eBay n\u2019appartient pas au produit.");
        p.ownListings = p.ownListings.filter(
          (l) => ebayLinkIdentity(l) !== key4
        );
      } else fail2();
    } else if (c.action === "remove-supplier") {
      const id = string(c.supplierId, 30, false);
      if (!p.suppliers.some((s) => s.id === id))
        fail2("Fournisseur introuvable.");
      p.suppliers = p.suppliers.filter((s) => s.id !== id);
      if (p.primarySupplierId === id)
        p.primarySupplierId = p.suppliers[0]?.id ?? null;
    } else fail2("Action de biblioth\xE8que inconnue.");
  }
  p.updatedAt = now;
  p.revision++;
  validateLibraryProduct(p);
  if (products.length > LIBRARY_LIMITS.products)
    fail2("La biblioth\xE8que est limit\xE9e \xE0 1 500 produits.");
  bounded(
    { format: "auroebay-library", version: 1, exportedAt: now, products },
    LIBRARY_LIMITS.backupBytes
  );
  return { products, result: p };
}

// src/core/libraryStore.ts
var DB_NAME = "auroebay-library";
var STORE_NAME = "products";
var connection;
function storageError(error) {
  const name = error && typeof error === "object" && "name" in error ? String(error.name) : "";
  if (name === "QuotaExceededError")
    return Error(
      "L\u2019espace de stockage de la biblioth\xE8que est plein. Exporte une sauvegarde avant de retirer des fournisseurs ou des produits."
    );
  if (error instanceof Error && error.name !== "AbortError") return error;
  return Error(
    "La biblioth\xE8que n\u2019a pas pu \xEAtre enregistr\xE9e. Aucune modification partielle n\u2019a \xE9t\xE9 conserv\xE9e ; r\xE9essaie."
  );
}
function database() {
  connection ??= new Promise((resolve, reject) => {
    if (typeof indexedDB === "undefined") {
      reject(
        Error(
          "Le stockage local de la biblioth\xE8que est indisponible dans ce contexte."
        )
      );
      return;
    }
    const request = indexedDB.open(DB_NAME, 1);
    let blocked = false;
    request.onupgradeneeded = () => {
      if (!request.result.objectStoreNames.contains(STORE_NAME))
        request.result.createObjectStore(STORE_NAME, { keyPath: "id" });
    };
    request.onerror = () => reject(storageError(request.error));
    request.onblocked = () => {
      blocked = true;
      reject(
        Error(
          "La biblioth\xE8que est ouverte dans une ancienne version. Ferme ses anciens onglets puis r\xE9essaie."
        )
      );
    };
    request.onsuccess = () => {
      const db = request.result;
      if (blocked) {
        db.close();
        return;
      }
      db.onversionchange = () => {
        db.close();
        connection = void 0;
      };
      db.onclose = () => {
        connection = void 0;
      };
      resolve(db);
    };
  }).catch((error) => {
    connection = void 0;
    throw storageError(error);
  });
  return connection;
}
async function executeLibrary(command) {
  const db = await database();
  const readonly = ["list", "get-product", "export"].includes(command?.action);
  return new Promise((resolve, reject) => {
    let result, failure;
    let tx;
    try {
      tx = db.transaction(STORE_NAME, readonly ? "readonly" : "readwrite");
    } catch (error) {
      connection = void 0;
      reject(storageError(error));
      return;
    }
    tx.oncomplete = () => resolve(result);
    tx.onabort = () => reject(storageError(failure ?? tx.error));
    tx.onerror = (event) => {
      failure ??= event.target?.error ?? tx.error;
    };
    const store = tx.objectStore(STORE_NAME);
    const request = store.getAll();
    request.onsuccess = () => {
      try {
        const before = request.result;
        const transition = applyLibraryCommand(before, command);
        result = transition.result;
        if (!readonly) {
          const original = new Map(
            before.map((p) => [p.id, JSON.stringify(p)])
          );
          for (const product2 of transition.products) {
            if (original.get(product2.id) !== JSON.stringify(product2))
              store.put(product2);
          }
        }
      } catch (error) {
        failure = error;
        tx.abort();
      }
    };
  });
}

// src/core/backupExtras.ts
var BACKUP_EXTRA_KEYS = [
  "taxRates:v1",
  "disputes:v1",
  "aliParcels:v1",
  "hiddenProducts:v1",
  "monthGoal:v1",
  "firstSale:v1",
  "watch:v1",
  "competitorSuppliers:v1",
  "productShipping:v1",
  "listingPrices:v1"
];
function backupExtras(local) {
  return Object.fromEntries(BACKUP_EXTRA_KEYS.flatMap((k) => local[k] === void 0 ? [] : [[k, local[k]]]));
}

// src/background/safetyBackup.ts
var SAFETY_KEY = "safetyBackups:v1";
var KEEP = 3;
async function buildFullBackup() {
  const local = await chrome.storage.local.get([
    "sales:v1",
    "listingSuppliers:v1",
    "variantPricing",
    "competitors:v1",
    "profitSettings:v1",
    "urssafDeclarations:v1",
    ...BACKUP_EXTRA_KEYS
  ]);
  return {
    format: "auroebay-full",
    version: 1,
    exportedAt: Date.now(),
    library: await executeLibrary({ action: "export" }),
    sales: local["sales:v1"] ?? {},
    listingSuppliers: local["listingSuppliers:v1"] ?? {},
    variantPricing: local.variantPricing ?? null,
    competitors: local["competitors:v1"] ?? {},
    profitSettings: local["profitSettings:v1"] ?? null,
    urssafDeclarations: local["urssafDeclarations:v1"] ?? null,
    extras: backupExtras(local)
  };
}
var two = (n) => String(n).padStart(2, "0");
var safetyFileName = (version, now = /* @__PURE__ */ new Date()) => `AurOEBay-sauvegardes/avant-mise-a-jour-${version}-${now.getFullYear()}-${two(now.getMonth() + 1)}-${two(now.getDate())}-${two(now.getHours())}h${two(now.getMinutes())}.json`;
var wait = (ms) => new Promise((r) => setTimeout(r, ms));
async function offscreenReady() {
  const has = await chrome.offscreen.hasDocument?.().catch(() => false);
  if (!has)
    await chrome.offscreen.createDocument({
      url: "offscreen.html",
      reasons: [chrome.offscreen.Reason.BLOBS],
      justification: "Sauvegarde AurOEBay avant une mise \xE0 jour"
    });
}
async function backupBeforeUpdate(toVersion) {
  const state = (await chrome.storage.local.get(SAFETY_KEY))[SAFETY_KEY] ?? { ids: [] };
  try {
    if (!chrome.downloads || !chrome.offscreen) throw Error("Sauvegarde indisponible dans ce navigateur.");
    const text3 = JSON.stringify(await buildFullBackup());
    await offscreenReady();
    const { url } = await chrome.runtime.sendMessage({ type: "OFFSCREEN_BACKUP_URL", text: text3 });
    const file = safetyFileName(toVersion);
    const id = await chrome.downloads.download({ url, filename: file, saveAs: false, conflictAction: "uniquify" });
    let done = false;
    for (let i = 0; i < 40 && !done; i++) {
      const [item] = await chrome.downloads.search({ id });
      if (item?.state === "complete") done = true;
      else if (item?.state === "interrupted") throw Error(`Sauvegarde interrompue (${item.error ?? "erreur"}).`);
      else await wait(500);
    }
    if (!done) throw Error("Sauvegarde trop lente.");
    await chrome.runtime.sendMessage({ type: "OFFSCREEN_RELEASE" }).catch(() => {
    });
    await chrome.offscreen.closeDocument().catch(() => {
    });
    const ids = [...state.ids.filter((x) => x !== id), id];
    for (const old of ids.splice(0, Math.max(0, ids.length - KEEP))) await chrome.downloads.removeFile(old).catch(() => {
    });
    for (const old of state.ids.filter((x) => !ids.includes(x))) await chrome.downloads.erase({ id: old }).catch(() => {
    });
    await chrome.storage.local.set({ [SAFETY_KEY]: { ids, last: { at: Date.now(), version: toVersion, file }, error: null } });
    return true;
  } catch (error) {
    await chrome.offscreen?.closeDocument().catch(() => {
    });
    await chrome.storage.local.set({
      [SAFETY_KEY]: { ...state, error: error instanceof Error ? error.message : String(error) }
    });
    return false;
  }
}

// src/core/update.ts
var UPDATE_KEY = "update:v1";
var VERSION_URL = "https://auroebay.netlify.app/version.json";
var MIRROR = "https://raw.githubusercontent.com/ImpressionMinute/auroebay-maj/main/";
var VERSION_URLS = [VERSION_URL, MIRROR + "version.json"];
var UPDATE_GUIDE_URL = "https://auroebay.netlify.app/mise-a-jour.html";
var UPDATE_EVERY_MS = 24 * 36e5;
var UPDATE_RECHECK_MS = 2 * 6e4;
var WHATS_NEW_KEY = "whatsNew:v1";
var MAC_COMMAND = `curl -fsSL ${MIRROR}maj-mac.sh | bash`;
var WINDOWS_COMMAND = `powershell -ExecutionPolicy Bypass -c "[Net.ServicePointManager]::SecurityProtocol=3072;irm ${MIRROR}maj-windows.ps1|iex"`;
var DISK_WAIT_KEY = "updateOnDisk:v1";
var REOPEN_KEY = "reopenAfterUpdate:v1";
var SITE = "https://auroebay.netlify.app/";
function cleanNotes(value) {
  if (!Array.isArray(value)) return [];
  return value.filter((n) => typeof n === "string").map((n) => n.replace(/\s+/g, " ").trim().slice(0, 240)).filter(Boolean).slice(0, 8);
}
function parseVersionFile(value) {
  const v = value;
  if (typeof v?.version !== "string" || !/^\d{1,4}\.\d{1,5}\.\d{1,6}$/.test(v.version)) return null;
  if (typeof v.url !== "string" || !(v.url.startsWith(SITE) || v.url.startsWith(MIRROR)) || /["'<>\s]/.test(v.url)) return null;
  return { latest: v.version, url: v.url, notes: cleanNotes(v.notes) };
}
function updateAvailable(info, current2) {
  return !!info?.latest && !!info.url && versionBelow(current2, info.latest);
}
function updateCheckDue(info, now = Date.now(), every = UPDATE_EVERY_MS) {
  return !info?.checkedAt || now - info.checkedAt >= every || info.checkedAt > now;
}

// src/background/update.ts
var NOTIFIED = "updateNotified:v1";
var NOTIFICATION = "auroebay-update";
var running = null;
function checkUpdate(force = false, every = UPDATE_EVERY_MS) {
  running ??= (async () => {
    const saved = (await chrome.storage.local.get(UPDATE_KEY))[UPDATE_KEY];
    if (!force && !updateCheckDue(saved, Date.now(), every)) return;
    let next = { ...saved, checkedAt: Date.now() };
    let best = null;
    for (const url of VERSION_URLS)
      try {
        const r = await fetch(url, { cache: "no-store", credentials: "omit", signal: AbortSignal.timeout(1e4) });
        const found = r.ok ? parseVersionFile(await r.json()) : null;
        if (found && (!best || versionBelow(best.latest, found.latest))) best = found;
      } catch {
      }
    if (best) next = { ...best, checkedAt: Date.now() };
    await chrome.storage.local.set({ [UPDATE_KEY]: next });
    await announceUpdate(next);
  })().finally(() => {
    running = null;
  });
  return running;
}
async function pendingUpdate() {
  const saved = (await chrome.storage.local.get(UPDATE_KEY))[UPDATE_KEY];
  const ok = parseVersionFile({ version: saved?.latest, url: saved?.url });
  return ok && updateAvailable(ok, chrome.runtime.getManifest().version) ? ok.latest : null;
}
async function announceUpdate(info) {
  const ok = parseVersionFile({ version: info.latest, url: info.url, notes: info.notes });
  if (!ok || !updateAvailable(ok, chrome.runtime.getManifest().version)) return void await watchDisk(false);
  await watchDisk(true);
  const shown = await chrome.action?.getBadgeText({}).catch(() => "");
  if (!shown || shown === "MAJ") await showUpdateBadge(ok.latest);
  const told = (await chrome.storage.local.get(NOTIFIED))[NOTIFIED];
  if (told === ok.latest || !chrome.notifications) return;
  await chrome.storage.local.set({ [NOTIFIED]: ok.latest });
  await chrome.notifications.create(NOTIFICATION, {
    type: "basic",
    iconUrl: chrome.runtime.getURL("icons/128.png"),
    title: `AurOEBay ${ok.latest} est disponible`,
    message: ok.notes.length ? `Nouveau : ${ok.notes.slice(0, 2).join(" \xB7 ")}`.slice(0, 220) + " \u2014 clique pour mettre \xE0 jour." : `Tu as la version ${chrome.runtime.getManifest().version}. Clique ici pour voir comment mettre \xE0 jour (2 minutes, tes donn\xE9es sont gard\xE9es).`,
    priority: 1
  }).catch(() => {
  });
}
async function showUpdateBadge(latest) {
  await chrome.action?.setBadgeText({ text: "MAJ" }).catch(() => {
  });
  await chrome.action?.setBadgeBackgroundColor({ color: "#ff8a3d" }).catch(() => {
  });
  await chrome.action?.setTitle({ title: `AurOEBay ${latest} est disponible \u2014 ouvre AurOEBay pour mettre \xE0 jour` }).catch(() => {
  });
}
function setupUpdateNotifications() {
  chrome.notifications?.onClicked.addListener((id) => {
    if (id !== NOTIFICATION) return;
    void chrome.tabs.create({ url: UPDATE_GUIDE_URL }).catch(() => {
    });
    void chrome.notifications.clear(id).catch(() => {
    });
  });
}
var DISK_ALARM = "auroebay-disk-update";
var reloading = null;
async function checkDiskUpdate(busy2, now = false) {
  if (reloading) return { ready: reloading, waiting: null };
  const running9 = chrome.runtime.getManifest().version;
  const onDisk = await fetch(chrome.runtime.getURL("manifest.json"), { cache: "no-store" }).then((r) => r.json()).then((m) => m?.name === "AurOEBay" && typeof m.version === "string" ? m.version : null).catch(() => null);
  if (!onDisk || !/^\d+\.\d+\.\d+$/.test(onDisk) || !versionBelow(running9, onDisk)) {
    await chrome.storage.local.remove(DISK_WAIT_KEY).catch(() => {
    });
    return { ready: null, waiting: null };
  }
  const reason = now ? null : await busy2().catch(() => null);
  if (reason) {
    await chrome.storage.local.set({ [DISK_WAIT_KEY]: { version: onDisk, reason } });
    await watchDisk(true);
    return { ready: onDisk, waiting: reason };
  }
  reloading = onDisk;
  await backupBeforeUpdate(onDisk);
  await chrome.storage.local.set({ [REOPEN_KEY]: onDisk });
  await chrome.storage.local.remove(DISK_WAIT_KEY).catch(() => {
  });
  setTimeout(() => chrome.runtime.reload(), 300);
  return { ready: onDisk, waiting: null };
}
async function watchDisk(on) {
  if (!chrome.alarms) return;
  if (on) {
    if (!await chrome.alarms.get(DISK_ALARM).catch(() => void 0)) await chrome.alarms.create(DISK_ALARM, { periodInMinutes: 1 }).catch(() => {
    });
  } else await chrome.alarms.clear(DISK_ALARM).catch(() => {
  });
}
function setupDiskWatch(busy2) {
  chrome.alarms?.onAlarm.addListener((alarm) => {
    if (alarm.name === DISK_ALARM) void checkDiskUpdate(busy2).catch(() => {
    });
  });
}

// src/background/health.ts
async function healthCheck(licenseActive2) {
  const local = await chrome.storage.local.get([EBAY_SESSION_KEY, ALI_REGION_KEY, "variantPricing", "backupStatus:v1"]);
  const pinned = await chrome.action.getUserSettings?.().then((s) => s.isOnToolbar).catch(() => null);
  const folder = local["backupStatus:v1"];
  const rule = local.variantPricing;
  return healthItems({
    licenseActive: licenseActive2,
    version: chrome.runtime.getManifest().version,
    latest: await pendingUpdate().catch(() => null),
    ebay: local[EBAY_SESSION_KEY] ?? null,
    ali: local[ALI_REGION_KEY] ?? null,
    pinned: typeof pinned === "boolean" ? pinned : null,
    pricing: typeof rule?.coefficient === "number" && Number.isFinite(rule.coefficient),
    shopName: (await getSettings()).storeName,
    backupAt: folder?.at ?? null,
    backupFolder: !!folder?.folder
  });
}

// src/core/rivalSuppliers.ts
var RIVAL_SUPPLIERS_KEY = "competitorSuppliers:v1";

// src/core/brandRisk.ts
var DANGER = [
  // Characters and licences
  "Disney",
  "Pixar",
  "Marvel",
  "Avengers",
  "Spider-Man",
  "Spiderman",
  "Batman",
  "Superman",
  "Deadpool",
  "Iron Man",
  "Captain America",
  "DC Comics",
  "Star Wars",
  "Baby Yoda",
  "Grogu",
  "Mandalorian",
  "Harry Potter",
  "Hogwarts",
  "Mickey Mouse",
  "Minnie Mouse",
  "Lilo and Stitch",
  "Lilo & Stitch",
  "Toy Story",
  "Winnie the Pooh",
  "Pokemon",
  "Pikachu",
  "Super Mario",
  "Mario Kart",
  "Zelda",
  "Sonic the Hedgehog",
  "Minecraft",
  "Fortnite",
  "Roblox",
  "Among Us",
  "Squid Game",
  "Hello Kitty",
  "Sanrio",
  "Kuromi",
  "Cinnamoroll",
  "My Melody",
  "Labubu",
  "Pop Mart",
  "Squishmallow",
  "Squishmallows",
  "Bluey",
  "Paw Patrol",
  "Peppa Pig",
  "Cocomelon",
  "Minions",
  "Barbie",
  "Hot Wheels",
  "LEGO",
  "Nerf",
  "Fisher-Price",
  "Naruto",
  "Dragon Ball",
  "Demon Slayer",
  "Jujutsu Kaisen",
  "My Hero Academia",
  "Sailor Moon",
  "Studio Ghibli",
  "Totoro",
  "Looney Tunes",
  "Snoopy",
  "Sesame Street",
  "Taylor Swift",
  "NFL",
  "NBA",
  "MLB",
  "NHL",
  "NCAA",
  "Harley-Davidson",
  "John Deere",
  "Coca-Cola",
  "Starbucks",
  // Fashion, luxury, sport
  "Nike",
  "Adidas",
  "Puma",
  "Reebok",
  "Under Armour",
  "New Balance",
  "Air Jordan",
  "Converse",
  "The North Face",
  "Patagonia",
  "Lululemon",
  "Gucci",
  "Louis Vuitton",
  "Chanel",
  "Dior",
  "Hermes",
  "Prada",
  "Versace",
  "Burberry",
  "Balenciaga",
  "Fendi",
  "Givenchy",
  "Yves Saint Laurent",
  "YSL",
  "Michael Kors",
  "Kate Spade",
  "Tory Burch",
  "Ralph Lauren",
  "Tommy Hilfiger",
  "Calvin Klein",
  "Rolex",
  "Cartier",
  "Tag Heuer",
  "Pandora",
  "Swarovski",
  "Ray-Ban",
  "Rayban",
  "Oakley",
  "Crocs",
  "Jibbitz",
  "UGG",
  "Birkenstock",
  "Dr Martens",
  "Timberland",
  // Copied household products
  "Stanley",
  "Yeti",
  "Hydro Flask",
  "Owala",
  "OtterBox",
  "PopSocket",
  "PopSockets",
  "Dyson",
  // Added 11/2026 (user's request « des mots / marques à bannir »)
  // Toys, collectibles, kids' licences
  "NeeDoh",
  "Nee Doh",
  "Schylling",
  "Jellycat",
  "Sonny Angel",
  "Smiski",
  "Funko",
  "Beanie Babies",
  "Ty Beanie",
  "Ms Rachel",
  "Blippi",
  "Gabby's Dollhouse",
  "Gabbys Dollhouse",
  "PJ Masks",
  "Thomas the Tank Engine",
  "SpongeBob",
  "Garfield",
  "Pusheen",
  "Care Bears",
  "My Little Pony",
  "Transformers",
  "Hasbro",
  "Mattel",
  "Play-Doh",
  "Magna-Tiles",
  "Tamagotchi",
  "Bandai",
  "Yu-Gi-Oh",
  "Magic the Gathering",
  "Bratz",
  "LOL Surprise",
  "Polly Pocket",
  "Tonka",
  "Crayola",
  "Hatchimals",
  "Kirby",
  "Animal Crossing",
  "Splatoon",
  "Call of Duty",
  "Pac-Man",
  "Tetris",
  "Rubik's",
  "Rubiks",
  "Pochacco",
  "Pompompurin",
  "Keroppi",
  "Badtz-Maru",
  "Chainsaw Man",
  "Attack on Titan",
  "Hunter x Hunter",
  "Tokyo Ghoul",
  "Spy x Family",
  "Stranger Things",
  "Moana",
  "Encanto",
  "Frozen Elsa",
  "Bluey Bingo",
  "Grinch",
  "Dr Seuss",
  "Elf on the Shelf",
  "Charlie Brown",
  "Jack Skellington",
  "Nightmare Before Christmas",
  "Hocus Pocus",
  "Beetlejuice",
  "Freddy Krueger",
  "Michael Myers",
  "Chucky",
  "Ghostface",
  "Lord of the Rings",
  "Game of Thrones",
  "Wednesday Addams",
  // Fashion, beauty, luxury
  "Vans Old Skool",
  "Skechers",
  "Hoka",
  "Asics",
  "Fila",
  "Carhartt",
  "Levi's",
  "Levis",
  "Wrangler Jeans",
  "Off-White",
  "Bape",
  "Stussy",
  "Fear of God",
  "Moncler",
  "Canada Goose",
  "Arc'teryx",
  "Arcteryx",
  "Longchamp",
  "Goyard",
  "Celine",
  "Bottega Veneta",
  "Valentino",
  "Miu Miu",
  "Loewe",
  "Van Cleef",
  "Bvlgari",
  "Bulgari",
  "Chrome Hearts",
  "Casio",
  "G-Shock",
  "Seiko",
  "Alo Yoga",
  "Gymshark",
  "Skims",
  "Victoria's Secret",
  "Bath and Body Works",
  "Sol de Janeiro",
  "Olaplex",
  "Beautyblender",
  "Fenty",
  "Rare Beauty",
  "Charlotte Tilbury",
  "Revlon",
  "Gillette",
  "Oral-B",
  "Sonicare",
  // Tech and home brands often copied
  "Anker",
  "Beats by Dre",
  "Beats Studio",
  "Beats Solo",
  "Beats Fit Pro",
  "Skullcandy",
  "Logitech",
  "Razer",
  "Corsair",
  "SteelSeries",
  "HyperX",
  "Roomba",
  "iRobot",
  "Vitamix",
  "Le Creuset",
  "Pyrex",
  "Tupperware",
  "Bissell",
  "Contigo",
  "Ember Mug",
  "Ka-Bar",
  "Kabar",
  "Lego Star Wars",
  // Sport teams, cars (logos)
  "FIFA",
  "UEFA",
  "Real Madrid",
  "FC Barcelona",
  "Manchester United",
  "Manchester City",
  "Liverpool FC",
  "Chelsea FC",
  "Dallas Cowboys",
  "Kansas City Chiefs",
  "New York Yankees",
  "Los Angeles Lakers",
  "Chicago Bulls",
  "Golden State Warriors",
  "Ferrari",
  "Lamborghini",
  "Porsche",
  "Red Bull",
  "Monster Energy",
  "Jack Daniels",
  "Jack Daniel's"
];
var COMPATIBLE = [
  "iPhone",
  "iPad",
  "MacBook",
  "iMac",
  "Apple Watch",
  "Apple Pencil",
  "MagSafe",
  "AirPods",
  "AirTag",
  "Samsung",
  "Google Pixel",
  "Fitbit",
  "Garmin",
  "Nintendo",
  "PlayStation",
  "PS4",
  "PS5",
  "Xbox",
  "Tesla",
  "GoPro",
  "DJI",
  "Kindle",
  "JBL",
  "Bose",
  "Sony",
  "Microsoft",
  "Keurig",
  "Nespresso",
  "KitchenAid",
  "Instant Pot",
  "Cricut",
  "DeWalt",
  "Makita",
  "Bosch",
  // Added 11/2026: devices and cars accessories name (« for Toyota RAV4 »)
  "Steam Deck",
  "Meta Quest",
  "Oculus",
  "Echo Dot",
  "Alexa",
  "Roku",
  "Chromecast",
  "Ring Doorbell",
  "Polaroid",
  "Instax",
  "Fujifilm",
  "Canon",
  "Nikon",
  "Milwaukee",
  "Ryobi",
  "Ninja Creami",
  "Ninja Foodi",
  "Xiaomi",
  "Huawei",
  "OnePlus",
  "Motorola",
  "Lenovo",
  "Dell",
  "Toyota",
  "Honda",
  "Ford",
  "Chevrolet",
  "Chevy",
  "Jeep",
  "BMW",
  "Mercedes",
  "Audi",
  "Volkswagen",
  "Subaru",
  "Nissan",
  "Hyundai",
  "Kia",
  "Mazda",
  "Lexus",
  "Dodge",
  "RAM 1500"
];
var words = (text3) => ` ${text3.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, " ").trim()} `;
var LIST = [
  ...DANGER.map((name) => ({ name, level: "danger", w: words(name) })),
  ...COMPATIBLE.map((name) => ({ name, level: "compatible", w: words(name) }))
];
function brandRisks(text3) {
  if (!text3) return [];
  const t = words(text3);
  const hits = [];
  const seen = /* @__PURE__ */ new Set();
  for (const b of LIST) {
    const key4 = b.w.replace(/ /g, "");
    if (seen.has(key4) || !t.includes(b.w)) continue;
    if (hits.some((h) => words(h.name).includes(b.w) || b.w.includes(words(h.name)))) continue;
    seen.add(key4);
    hits.push({ name: b.name, level: b.level });
  }
  return hits.sort((a, b) => Number(a.level !== "danger") - Number(b.level !== "danger"));
}

// src/core/hiddenProducts.ts
var HIDDEN_PRODUCTS_KEY = "hiddenProducts:v1";
var MAX_ITEMS = 1e3;
function cleanHidden(x) {
  const v = x ?? {};
  const items = (Array.isArray(v.items) ? v.items : []).filter((i) => !!i && typeof i.itemId === "string" && /^\d{9,15}$/.test(i.itemId) && typeof i.title === "string").slice(-MAX_ITEMS).map((i) => ({ itemId: i.itemId, title: i.title.slice(0, 200), at: Number(i.at) || 0 }));
  const brands = (Array.isArray(v.brands) ? v.brands : []).filter((b) => typeof b === "string").map((b) => b.slice(0, 60)).slice(0, 300);
  return { items, brands: [...new Set(brands)] };
}
var NOISE = new Set(
  "a an and the of in on to for with new brand free fast shipping ship us usa uk seller stock lot set pack pcs pc piece pieces 2024 2025 2026 2027 2028".split(" ")
);

// src/background/pagePrefs.ts
var FILTERS_KEY = "winnersFilters:v1";
var where = ["all", "non_us", "us"];
var num = (v) => typeof v === "number" && Number.isFinite(v) && v >= 0 && v < 1e7 ? v : null;
async function statusNote(from, msg) {
  if (from === "ebay" && typeof msg.signedIn === "boolean")
    await chrome.storage.local.set({ [EBAY_SESSION_KEY]: { at: Date.now(), signedIn: msg.signedIn } });
  if (from === "ali" && (msg.problem === null || msg.problem === "domain" || msg.problem === "currency"))
    await chrome.storage.local.set({ [ALI_REGION_KEY]: { at: Date.now(), problem: msg.problem } });
  return true;
}
async function pagePref(key4, value) {
  if (key4 === RIVAL_SUPPLIERS_KEY) {
    if (typeof value === "boolean") await chrome.storage.local.set({ [key4]: value });
    return (await chrome.storage.local.get(key4))[key4] !== false;
  }
  if (key4 === HIDDEN_PRODUCTS_KEY) {
    if (value && typeof value === "object") await chrome.storage.local.set({ [key4]: cleanHidden(value) });
    return cleanHidden((await chrome.storage.local.get(key4))[key4]);
  }
  if (key4 === FILTERS_KEY) {
    if (value && typeof value === "object") {
      const f = value;
      await chrome.storage.local.set({
        [key4]: {
          seller: where.includes(f.seller) ? f.seller : "all",
          ships: where.includes(f.ships) ? f.ships : "all",
          minD30: num(f.minD30),
          minPrice: num(f.minPrice),
          maxPrice: num(f.maxPrice),
          maxFeedback: num(f.maxFeedback)
        }
      });
    }
    return (await chrome.storage.local.get(key4))[key4] ?? null;
  }
  throw Error("R\xE9glage inconnu.");
}

// src/ebay/prices.ts
var USUAL_SHIPPING = { cost: 1.99, freeOver: 10, usual: true };
function shippingCharge(d) {
  const threshold = d?.freeShippingThreshold && d.freeShippingThreshold > 0 ? d.freeShippingThreshold : null;
  if (d && d.cost !== null && d.cost > 0 && (d.currency === null || d.currency === "USD"))
    return { cost: d.cost, freeOver: threshold };
  const written = d && d.cost === null ? paidShipping(d.evidence) : null;
  if (written !== null) return { cost: written, freeOver: threshold };
  return threshold ? { ...USUAL_SHIPPING, freeOver: threshold } : USUAL_SHIPPING;
}
function ruledPrice(cost, rule) {
  const ship = typeof rule.target === "number" ? shippingFor(cost, rule.shipping) : 0;
  return sellingPrice(cost + ship, rule.coefficient, rule.fixed, rule.rounding);
}
var shippingFor = (cost, s) => s && !(s.freeOver !== null && cost >= s.freeOver) ? s.cost : 0;
function sellingPrice(cost, coefficient, fixed, rounding = "none") {
  if (![cost, coefficient, fixed].every(Number.isFinite) || cost <= 0 || coefficient <= 0 || fixed < 0)
    return null;
  let cents = Math.round((cost * coefficient + fixed + Number.EPSILON) * 100);
  if (!Number.isSafeInteger(cents) || cents <= 0) return null;
  const ending = (n) => Math.ceil((cents - n) / 100) * 100 + n;
  if (rounding === "49") cents = ending(49);
  else if (rounding === "99") cents = ending(99);
  else if (rounding === "49-or-99") cents = Math.min(ending(49), ending(99));
  else if (rounding !== "none") return null;
  return cents > 0 && cents <= 1e8 ? (cents / 100).toFixed(2) : null;
}

// src/core/supplierImport.ts
var DEFAULT_IMPORT_QUANTITY = 3;
function supplierImportPlan(p, rule, options = {}) {
  const scan = p.variantScan;
  if (!scan || Date.now() - scan.at > 15 * 6e4 || scan.at > Date.now() + 3e4)
    throw Error("Relis les co\xFBts AliExpress avant de cr\xE9er le brouillon.");
  if (!rule || !sellingPrice(1, rule.coefficient, rule.fixed, rule.rounding))
    throw Error(
      "Renseigne ton coefficient, montant fixe et arrondi dans Prix des variantes."
    );
  const axes = p.variants.filter((a) => a.values.length);
  if (axes.length > 5 || axes.some(
    (a) => !a.name.trim() || a.name.length > 30 || a.values.some((v) => v.length > 50)
  ) || new Set(axes.map((a) => norm(a.name))).size !== axes.length)
    throw Error(
      "Axes fournisseur incompatibles avec les limites eBay (5 axes, noms de 30 caract\xE8res, options de 50 caract\xE8res)."
    );
  const costs2 = scan.costs;
  if (!costs2.length || costs2.length > 250)
    throw Error(
      "Prix AliExpress introuvable (en USD) pour ce produit. Ouvre la fiche AliExpress, v\xE9rifie qu\u2019un prix en $ s\u2019affiche, puis r\xE9essaie."
    );
  const seen = /* @__PURE__ */ new Set();
  const rows = costs2.map((c) => {
    const id = JSON.stringify(c.values.map(norm));
    const price = c.currency === "USD" ? ruledPrice(c.cost, { ...rule, shipping: shippingCharge(p.shippingDetails) }) : null;
    if (!price || c.values.length !== axes.length || c.values.some((v, i) => !axes[i].values.includes(v)) || seen.has(id))
      throw Error(
        "Co\xFBts fournisseur incomplets, ambigus ou hors USD. Relis la fiche."
      );
    seen.add(id);
    return {
      values: c.values,
      cost: c.cost,
      price,
      quantity: DEFAULT_IMPORT_QUANTITY
    };
  });
  for (const out of scan.unavailable) {
    const id = JSON.stringify(out.values.map(norm));
    if (out.values.length !== axes.length || out.values.some((v, i) => !axes[i].values.includes(v)) || seen.has(id))
      throw Error(
        "\xC9tats de stock AliExpress contradictoires. Relis les co\xFBts."
      );
    seen.add(id);
  }
  if (seen.size !== axes.reduce((n, a) => n * a.values.length, 1))
    throw Error(
      "Certaines combinaisons AliExpress n\u2019ont ni co\xFBt ni rupture confirm\xE9e. Relis les co\xFBts ; aucun import partiel."
    );
  const zero = scan.unavailable.map((out) => {
    let best = null, bestScore = -1;
    for (const r of rows) {
      const score = r.values.filter((v, i) => v === out.values[i]).length;
      if (score > bestScore || score === bestScore && Number(r.price) > Number(best.price))
        best = r, bestScore = score;
    }
    return { values: out.values, cost: best.cost, price: best.price, quantity: 0 };
  });
  const all3 = options.keepOutOfStock && axes.length && rows.length + zero.length <= 250 ? [...rows, ...zero] : [...rows];
  const order = (values) => values.map((v, i) => String(axes[i].values.indexOf(v)).padStart(4, "0")).join("|");
  all3.sort((a, b) => order(a.values).localeCompare(order(b.values)));
  return {
    axes: axes.map((a, i) => ({
      name: a.name,
      values: a.values.filter((v) => all3.some((r) => r.values[i] === v))
    })),
    rows: all3,
    omitted: scan.unavailable.length - (all3.length - rows.length),
    rule
  };
}

// src/core/ebayApiVariations.ts
function ebayVariationImageKey(value) {
  const source = importImageURL(value);
  if (!source) return null;
  const url = new URL(source);
  if (url.hostname === "i.ebayimg.com")
    return `ebay:${url.pathname.split("/")[3]}`;
  const id = url.pathname.match(/\/kf\/([^/.?#]+)/i)?.[1];
  return id ? `kf:${id.toLowerCase()}` : url.origin + url.pathname;
}
function hostedImage(value) {
  try {
    const url = new URL(value);
    if (url.protocol === "https:" && !url.username && !url.password && !url.port && /(^|\.)(ebayimg|ebaystatic)\.com$/.test(url.hostname))
      return url.href;
  } catch {
  }
  throw Error("Photo de variante non h\xE9berg\xE9e par eBay.");
}
function validatePlan(plan) {
  if (!plan || !Array.isArray(plan.axes) || !Array.isArray(plan.rows) || plan.axes.length < 1 || plan.axes.length > 5 || plan.rows.length < 2 || !plan.rows.some((row) => row.quantity > 0) || plan.rows.length > 250)
    throw Error("Plan de variantes eBay invalide (2 \xE0 250 combinaisons).");
  const names2 = /* @__PURE__ */ new Set();
  for (const axis of plan.axes) {
    const name = typeof axis.name === "string" ? norm(axis.name) : "";
    if (!name || axis.name.length > 30 || names2.has(name) || !Array.isArray(axis.values) || !axis.values.length || axis.values.some(
      (value) => typeof value !== "string" || !value.trim() || value.length > 50
    ) || new Set(axis.values.map(norm)).size !== axis.values.length)
      throw Error("Axe ou option de variante eBay invalide ou ambigu.");
    names2.add(name);
  }
  const rows = /* @__PURE__ */ new Set();
  for (const row of plan.rows) {
    if (!Array.isArray(row.values) || row.values.length !== plan.axes.length || row.values.some(
      (value, index) => !plan.axes[index].values.includes(value)
    ) || typeof row.price !== "string" || !/^\d+(?:\.\d{1,2})?$/.test(row.price) || !Number.isFinite(Number(row.price)) || Number(row.price) <= 0)
      throw Error("Combinaison ou prix AliExpress invalide pour eBay.");
    const key4 = JSON.stringify(row.values);
    if (rows.has(key4))
      throw Error("Combinaison AliExpress dupliqu\xE9e : import interrompu.");
    rows.add(key4);
  }
  for (let index = 0; index < plan.axes.length; index++) {
    const observed = new Set(plan.rows.map((row) => row.values[index]));
    if (plan.axes[index].values.some((value) => !observed.has(value)))
      throw Error(
        "Une option sans combinaison disponible subsiste dans le plan."
      );
  }
}
function buildEbayApiVariations(input) {
  if (!/^\d{6,20}$/.test(input.draftId))
    throw Error("Identifiant de brouillon eBay invalide.");
  validatePlan(input.plan);
  const identifier = input.upiFieldName ?? "ean";
  if (!["upc", "ean", "isbn"].includes(identifier))
    throw Error("Champ d\u2019identification eBay non reconnu.");
  const hostedByImage = /* @__PURE__ */ new Map();
  for (const [source, hosted] of Object.entries(input.uploadedImages)) {
    const key4 = ebayVariationImageKey(source);
    if (!key4) throw Error("Source de photo de variante AliExpress invalide.");
    const url = hostedImage(hosted);
    if (!hostedByImage.has(key4)) hostedByImage.set(key4, url);
  }
  const imagesByAxis = input.plan.axes.map((axis) => {
    const values = /* @__PURE__ */ new Map();
    for (const value of axis.values) {
      const sources = input.variantImages.filter(
        (image) => norm(image.axis) === norm(axis.name) && image.value === value
      );
      const urls = [];
      for (const image of sources) {
        const key4 = ebayVariationImageKey(image.url);
        if (!key4) throw Error("Photo AliExpress de variante invalide.");
        const uploaded = hostedByImage.get(key4);
        if (!uploaded)
          throw Error(
            `Photo de variante non envoy\xE9e sur eBay : ${axis.name} / ${value}.`
          );
        if (!urls.includes(uploaded)) urls.push(uploaded);
      }
      if (urls.length > 12)
        throw Error(
          "eBay accepte au maximum 12 photos par option de variante."
        );
      values.set(value, urls);
    }
    return { axis, values };
  });
  const pictureAxis = imagesByAxis.find(
    (group) => [...group.values.values()].every((images) => images.length > 0)
  ) ?? imagesByAxis.find(
    (group) => [...group.values.values()].some((images) => images.length > 0)
  );
  return {
    action: "save",
    draftId: input.draftId,
    listingMode: "AddItem",
    restricted: false,
    upiFieldName: identifier,
    variationItem: input.plan.rows.map((row, index) => ({
      variationSpecific: Object.fromEntries(
        input.plan.axes.map((axis, axisIndex) => [
          axis.name,
          row.values[axisIndex]
        ])
      ),
      listingVariation: {
        price: row.price,
        // 0 for an out-of-stock combination, otherwise always 3 (never the
        // supplier's stock).
        quantity: row.quantity === 0 ? 0 : DEFAULT_IMPORT_QUANTITY
      },
      sku: "",
      state: "enabled",
      // An empty new productInfo mirrors the eBay draft variation contract.
      // Setting an exemption here requires the category's actual serialized
      // identifier model; a guessed UPC/EAN field must not corrupt the save.
      productInfo: input.identifierExempt ? { [identifier]: "Does not apply" } : {},
      edited: true,
      index
    })),
    variationSpecificPictureSet: pictureAxis ? {
      [pictureAxis.axis.name]: Object.fromEntries(pictureAxis.values)
    } : {},
    variationSpecificsMetaData: input.plan.axes.map((axis) => ({
      name: axis.name,
      value: [...axis.values]
    }))
  };
}
function removeVariationSpecifics(specifics2, axes) {
  const labels = new Set(axes.map((axis) => variationAxisKey(axis.name)));
  return specifics2.filter((specific) => !labels.has(variationAxisKey(specific.label))).map((specific) => ({ ...specific }));
}
function variationAxisKey(name) {
  const key4 = norm(name);
  if (["color", "colors", "colour", "colours"].includes(key4)) return "color";
  if (["size", "sizes"].includes(key4)) return "size";
  return key4;
}
function missingSpecificRename(text3, axes) {
  const want = text3.match(/item specific ([A-Za-z][A-Za-z0-9 /&-]{1,40}?) is missing/i)?.[1]?.trim();
  if (!want || axes.some((a) => norm(a.name) === norm(want))) return null;
  const kind = /colou?r/i.test(want) ? /colou?r/i : /size/i.test(want) ? /size/i : null;
  const matches = kind ? axes.filter((a) => kind.test(a.name)) : [];
  return matches.length === 1 ? { from: matches[0].name, to: want } : null;
}
function renameAxes(plan, images, renames) {
  if (!renames || !Object.keys(renames).length) return { plan, images };
  const to = (name) => renames[name] ?? Object.entries(renames).find(([k]) => norm(k) === norm(name))?.[1] ?? name;
  return {
    plan: { ...plan, axes: plan.axes.map((a) => ({ ...a, name: to(a.name) })) },
    images: images.map((i) => ({ ...i, axis: to(i.axis) }))
  };
}

// src/ebay/savedDraft.ts
var SCAN_LIMIT = 3 * 1024 * 1024;
function readValue(text3, start) {
  let i = start;
  while (/\s/.test(text3[i] ?? "")) i++;
  const begin = i;
  const first2 = text3[i];
  let end = -1;
  if (first2 === "{" || first2 === "[") {
    let depth = 0, quoted = false;
    for (; i < Math.min(text3.length, begin + SCAN_LIMIT); i++) {
      const c = text3[i];
      if (quoted) {
        if (c === "\\") i++;
        else if (c === '"') quoted = false;
        continue;
      }
      if (c === '"') quoted = true;
      else if (c === "{" || c === "[") depth++;
      else if ((c === "}" || c === "]") && --depth === 0) {
        end = i + 1;
        break;
      }
    }
  } else if (first2 === '"') {
    for (i = begin + 1; i < Math.min(text3.length, begin + SCAN_LIMIT); i++) {
      if (text3[i] === "\\") i++;
      else if (text3[i] === '"') {
        end = i + 1;
        break;
      }
    }
  } else {
    const m = /^(?:-?\d+(?:\.\d+)?|true|false|null)/.exec(
      text3.slice(begin, begin + 40)
    );
    if (m) end = begin + m[0].length;
  }
  if (end < 0) return void 0;
  try {
    return JSON.parse(text3.slice(begin, end));
  } catch {
    return void 0;
  }
}
function modelTexts(source) {
  const texts = [source];
  const marker = /\\"(?:photosInput|attributeList|titleField|conditionField)\\"/g;
  const seen = /* @__PURE__ */ new Set();
  for (const hit of source.matchAll(marker)) {
    if (texts.length > 4) break;
    let a = hit.index;
    for (; a > 0; a--) {
      if (source[a] !== '"') continue;
      let run6 = 0;
      while (source[a - 1 - run6] === "\\") run6++;
      if (run6 % 2 === 0) break;
    }
    if (seen.has(a)) continue;
    seen.add(a);
    let b = hit.index;
    for (; b < source.length; b++) {
      if (source[b] === "\\") {
        b++;
        continue;
      }
      if (source[b] === '"') break;
    }
    try {
      const decoded = JSON.parse(source.slice(a, b + 1));
      if (typeof decoded === "string") texts.push(decoded);
    } catch {
    }
  }
  return texts;
}
function namedValues(text3, test) {
  const out = [];
  const pattern = /\{"name":"((?:\\.|[^"\\]){1,200})","value":/g;
  for (const m of text3.matchAll(pattern)) {
    if (out.length > 2e3) break;
    let name;
    try {
      name = JSON.parse(`"${m[1]}"`);
    } catch {
      continue;
    }
    if (!test(name)) continue;
    const value = readValue(text3, m.index + m[0].length);
    if (value !== void 0) out.push([name, value]);
  }
  return out;
}
function photosFrom(text3) {
  const m = /"photosInput":\{"photos":/.exec(text3);
  if (!m) return null;
  const photos = readValue(text3, m.index + m[0].length);
  if (!Array.isArray(photos)) return null;
  return photos.map(
    (photo) => photo && typeof photo === "object" ? photo.url : photo
  ).filter((url) => typeof url === "string" && !!url);
}
function readSavedDraft(source) {
  const result = {
    title: null,
    description: null,
    categoryId: null,
    pictures: null,
    price: null,
    quantity: null,
    conditionId: null,
    attributes: null
  };
  if (typeof source !== "string" || source.length > 12 * 1024 * 1024)
    return result;
  const simple = /* @__PURE__ */ new Set([
    "title",
    "description",
    "categoryId",
    "price",
    "quantity",
    "condition"
  ]);
  const attributes2 = /* @__PURE__ */ Object.create(null);
  const texts = modelTexts(source);
  const pairs2 = texts.flatMap(
    (text3) => namedValues(text3, (n) => simple.has(n) || n.startsWith("attributes."))
  );
  for (const [name, value] of pairs2) {
    if (name.startsWith("attributes.")) {
      const key4 = name.slice("attributes.".length);
      if (!(key4 in attributes2) && Array.isArray(value) && value.every((v) => typeof v === "string"))
        attributes2[key4] = value;
      continue;
    }
    if (name === "title" && typeof value === "string" && result.title === null)
      result.title = value;
    if (name === "description" && typeof value === "string" && result.description === null)
      result.description = value;
    if (name === "categoryId" && result.categoryId === null && /^\d{1,20}$/.test(String(value ?? "")))
      result.categoryId = String(value);
    if (name === "price" && result.price === null && value !== null && value !== "" && /^\d+(?:\.\d{1,2})?$/.test(String(value)))
      result.price = String(value);
    if (name === "quantity" && result.quantity === null && value !== null && value !== "" && Number.isSafeInteger(Number(value)))
      result.quantity = Number(value);
    if (name === "condition" && result.conditionId === null && /^\d{1,6}$/.test(String(value ?? "")))
      result.conditionId = Number(value);
  }
  if (Object.keys(attributes2).length) result.attributes = attributes2;
  for (const text3 of texts) {
    result.pictures = photosFrom(text3);
    if (result.pictures) break;
  }
  return result;
}
function ebayPictureKey(url) {
  try {
    const u = new URL(url);
    return (u.hostname + u.pathname).replace(/\/\$_\d+\.(?:jpe?g|png|webp)$/i, "").replace(/\/s-l\d+\.(?:jpe?g|png|webp)$/i, "").toLowerCase();
  } catch {
    return url;
  }
}
function mskuSaveErrors(text3) {
  let body2;
  try {
    body2 = JSON.parse(text3);
  } catch {
    return null;
  }
  if (!body2 || typeof body2 !== "object") return null;
  const bag = body2;
  if (typeof bag.ack !== "string") return null;
  const messages = (Array.isArray(bag.variationErrors) ? bag.variationErrors : []).filter(
    (e) => !!e && typeof e === "object" && !/^warning$/i.test(String(e.severity ?? ""))
  ).map((e) => String(e.message ?? e.shortMessage ?? "").trim()).filter(Boolean);
  if (/^(success|warning)$/i.test(bag.ack) && !messages.length) return [];
  return messages.length ? messages : ["eBay a refus\xE9 les variantes."];
}

// src/ebay/draftApi.ts
var ID = /^\d{1,20}$/;
var DRAFT_ID = /^\d{5,20}$/;
var HTML_LIMIT = 8 * 1024 * 1024;
var exactDraftRoutes = [
  "/lstng/api/listing_draft/:draftId(\\d+)",
  "/lstng/api/listing_draft/:draftId"
];
var record2 = (v) => !!v && typeof v === "object" && !Array.isArray(v);
function entities(value) {
  return value.replace(
    /&(quot|apos|amp|lt|gt|#\d+|#x[\da-f]+);/gi,
    (all3, key4) => {
      const named = {
        quot: '"',
        apos: "'",
        amp: "&",
        lt: "<",
        gt: ">"
      };
      const lower = key4.toLowerCase();
      if (named[lower] !== void 0) return named[lower];
      const code = lower.startsWith("#x") ? parseInt(lower.slice(2), 16) : parseInt(lower.slice(1), 10);
      return Number.isFinite(code) && code > 0 && code <= 1114111 ? String.fromCodePoint(code) : all3;
    }
  );
}
function variants(html) {
  if (html.length > HTML_LIMIT)
    throw Error("R\xE9ponse du brouillon eBay trop volumineuse.");
  const decoded = entities(html);
  const quotedHydration = [];
  for (const match of decoded.matchAll(/"(?:\\.|[^"\\])*"/g)) {
    const literal = match[0];
    if (!/^"\s*[\[{]/.test(literal) || !/(?:attributeList|titleField|epsData|\/lstng\/api\/listing_draft)/.test(
      literal
    ))
      continue;
    try {
      const value = JSON.parse(literal);
      if (typeof value === "string") quotedHydration.push(value);
    } catch {
    }
    if (quotedHydration.length >= 20) break;
  }
  const unquoted = decoded.replace(/\\+"/g, '"').replace(/\\+\//g, "/");
  return [.../* @__PURE__ */ new Set([html, decoded, ...quotedHydration, unquoted])];
}
function attributes(tag) {
  const result = /* @__PURE__ */ Object.create(null);
  for (const m of tag.matchAll(/([\w:-]+)\s*=\s*(?:"([^"]*)"|'([^']*)')/g))
    result[m[1].toLowerCase()] = entities(m[2] ?? m[3]);
  return result;
}
function objectAfter(source, index) {
  const whitespace = source.slice(index, index + 120).match(/^\s*/)?.[0].length ?? 0;
  const start = index + whitespace;
  if (source[start] !== "{") return null;
  let depth = 0, quoted = false, escaped = false;
  for (let i = start; i < Math.min(source.length, start + 512 * 1024); i++) {
    const c = source[i];
    if (escaped) {
      escaped = false;
      continue;
    }
    if (quoted && c === "\\") {
      escaped = true;
      continue;
    }
    if (c === '"') {
      quoted = !quoted;
      continue;
    }
    if (quoted) continue;
    if (c === "{") depth++;
    if (c === "}" && --depth === 0) {
      try {
        const result = JSON.parse(source.slice(start, i + 1));
        return record2(result) ? result : null;
      } catch {
        return null;
      }
    }
  }
  return null;
}
function csrfFromBag(value) {
  if (!record2(value)) return null;
  const bag = record2(value.csrf) ? value.csrf : value;
  for (const route of exactDraftRoutes) {
    const token = bag[route];
    if (typeof token === "string" && token.length > 0 && token.length <= 16384)
      return token;
  }
  return null;
}
function arrayAfter(source, index) {
  const whitespace = source.slice(index, index + 120).match(/^\s*/)?.[0].length ?? 0;
  const start = index + whitespace;
  if (source[start] !== "[") return null;
  let depth = 0, quoted = false, escaped = false;
  for (let i = start; i < Math.min(source.length, start + 1024 * 1024); i++) {
    const c = source[i];
    if (escaped) {
      escaped = false;
      continue;
    }
    if (quoted && c === "\\") {
      escaped = true;
      continue;
    }
    if (c === '"') {
      quoted = !quoted;
      continue;
    }
    if (quoted) continue;
    if (c === "[") depth++;
    if (c === "]" && --depth === 0) {
      try {
        const value = JSON.parse(source.slice(start, i + 1));
        return Array.isArray(value) ? value : null;
      } catch {
        return null;
      }
    }
  }
  return null;
}
function nativeText(value) {
  if (typeof value === "string") return value;
  if (!record2(value) || value._type !== "TextualDisplay" || !Array.isArray(value.textSpans))
    return null;
  if (!value.textSpans.every(
    (span) => record2(span) && typeof span.text === "string"
  ))
    return null;
  return value.textSpans.map((span) => span.text).join("");
}
function savedPropertyStarts(source, names2) {
  const eligible = /* @__PURE__ */ new Set();
  const ancestry = [];
  const excluded = /* @__PURE__ */ new Set([
    "options",
    "recommendations",
    "suggestions",
    "possibleValues"
  ]);
  let inString = false, escaped = false, stringStart = -1, token = "", pendingKey = "";
  for (let i = 0; i < source.length; i++) {
    const char = source[i];
    if (inString) {
      if (escaped) {
        escaped = false;
        continue;
      }
      if (char === "\\") {
        escaped = true;
        continue;
      }
      if (char === '"') {
        inString = false;
        try {
          token = JSON.parse(source.slice(stringStart, i + 1));
        } catch {
          token = "";
        }
      }
      continue;
    }
    if (char === '"') {
      inString = true;
      stringStart = i;
      continue;
    }
    if (char === ":") {
      pendingKey = token;
      if (names2.has(token) && !ancestry.some((key4) => excluded.has(key4))) {
        let valueStart = i + 1;
        while (valueStart < source.length && /\s/.test(source[valueStart]))
          valueStart++;
        eligible.add(valueStart);
      }
    } else if (char === "{" || char === "[") {
      ancestry.push(pendingKey);
      pendingKey = "";
    } else if (char === "}" || char === "]") {
      ancestry.pop();
      pendingKey = "";
    } else if (char === "," || char === ";") {
      pendingKey = "";
      token = "";
    }
  }
  return eligible;
}
function nativeModelFragments(html) {
  const fragments = [];
  const keys = /"(?:titleField|descriptionField|binPrice|quantity|conditionField|photosInput|countryOfOrigin|serviceContextMeta|listingDraft|draft|formData)"\s*:/g;
  for (const source of variants(html)) {
    const eligible = savedPropertyStarts(
      source,
      /* @__PURE__ */ new Set([
        "titleField",
        "descriptionField",
        "binPrice",
        "quantity",
        "conditionField",
        "photosInput",
        "countryOfOrigin",
        "serviceContextMeta",
        "listingDraft",
        "draft",
        "formData",
        "attributeList",
        "currencyCode"
      ])
    );
    for (const match of source.matchAll(
      /"currencyCode"\s*:\s*"USD"\s*,\s*"categoryId"\s*:\s*"?(\d{1,20})(?=[",}\s])/g
    )) {
      const start = source.indexOf('"USD"', match.index);
      if (!eligible.has(start)) continue;
      fragments.push({ currencyCode: "USD", categoryId: match[1] });
    }
    for (const match of source.matchAll(keys)) {
      const index = match.index + match[0].length;
      const start = index + (source.slice(index, index + 120).match(/^\s*/)?.[0].length ?? 0);
      if (!eligible.has(start)) continue;
      const object2 = objectAfter(source, index);
      if (object2) fragments.push(object2);
    }
    for (const match of source.matchAll(/"attributeList"\s*:/g)) {
      const index = match.index + match[0].length;
      const start = index + (source.slice(index, index + 120).match(/^\s*/)?.[0].length ?? 0);
      if (!eligible.has(start)) continue;
      const array2 = arrayAfter(source, index);
      if (array2) fragments.push(array2);
    }
  }
  return fragments;
}
function parseDraftAttributeModel(html) {
  const lists = [];
  for (const source of variants(html)) {
    const eligible = savedPropertyStarts(source, /* @__PURE__ */ new Set(["attributeList"]));
    for (const match of source.matchAll(/"attributeList"\s*:/g)) {
      const index = match.index + match[0].length;
      const start = index + (source.slice(index, index + 120).match(/^\s*/)?.[0].length ?? 0);
      if (!eligible.has(start)) continue;
      const list2 = arrayAfter(source, index);
      if (list2 && list2.length <= 500) lists.push(...list2);
    }
  }
  const models = /* @__PURE__ */ new Map();
  for (const field of lists) {
    if (!record2(field) || typeof field.name !== "string" || !/^attributes\.[^\r\n]{1,150}$/.test(field.name))
      continue;
    const value = Array.isArray(field.value) && field.value.every((v) => typeof v === "string") ? field.value : void 0;
    const next = {
      name: field.name,
      ...typeof field.multiSelectEnabled === "boolean" ? { multiSelectEnabled: field.multiSelectEnabled } : {},
      ...value ? { value: [...value] } : {}
    };
    if (!models.has(next.name)) models.set(next.name, next);
  }
  return [...models.values()];
}
function parseDraftCsrf(html) {
  for (const tag of html.matchAll(/<[^>]+>/g)) {
    const attrs = attributes(tag[0]);
    if (attrs.id !== "csrf-data" || !attrs["data-value"]) continue;
    try {
      const token = csrfFromBag(JSON.parse(attrs["data-value"]));
      if (token) return token;
    } catch {
    }
  }
  for (const source of variants(html)) {
    const routes = /"(\/lstng\/api\/listing_draft\/:draftId(?:\(\\{1,8}d\+\))?)"\s*:\s*"((?:\\.|[^"\\])*)"/g;
    for (const match of source.matchAll(routes)) {
      try {
        const route = JSON.parse(`"${match[1]}"`).replace(
          /\\+d\+/,
          "\\d+"
        );
        const token = JSON.parse(`"${match[2]}"`);
        if (exactDraftRoutes.includes(route) && token && token.length <= 16384)
          return token;
      } catch {
      }
    }
  }
  return null;
}
function parseDraftEpsData(html) {
  for (const source of variants(html)) {
    for (const match of source.matchAll(/"epsData"\s*:/g)) {
      const value = objectAfter(source, match.index + match[0].length);
      if (value && ["string", "number"].includes(typeof value.s) && ["string", "number"].includes(typeof value.n))
        return value;
    }
  }
  return null;
}
function observedDraftCondition(html) {
  for (const input of html.matchAll(/<input\b[^>]*>/gi)) {
    const attrs = attributes(input[0]);
    if (attrs.type !== "radio" || attrs.name !== "condition" || attrs.value !== "1500" || !attrs.id)
      continue;
    const labels = [...html.matchAll(/<label\b([^>]*)>([\s\S]*?)<\/label>/gi)].filter((m) => attributes(m[1]).for === attrs.id).map((m) => entities(m[2].replace(/<[^>]*>/g, "")).trim());
    if (labels.some((label) => /^new without tags$/i.test(label))) return 1500;
  }
  for (const field of nativeModelFragments(html)) {
    if (!record2(field) || field.name !== "condition" || !Array.isArray(field.options))
      continue;
    if (field.options.some(
      (option) => record2(option) && String(option.value) === "1500" && /^new without tags$/i.test(nativeText(option.label)?.trim() ?? "")
    ))
      return 1500;
  }
  for (const source of variants(html)) {
    const eligible = savedPropertyStarts(
      source,
      /* @__PURE__ */ new Set(["conditionOptions", "conditionList"])
    );
    for (const match of source.matchAll(
      /"(?:conditionOptions|conditionList)"\s*:\s*/g
    )) {
      const index = match.index + match[0].length;
      if (!eligible.has(index)) continue;
      const options = arrayAfter(source, index);
      if (options?.some(
        (option) => record2(option) && String(option.value ?? option.id ?? option.conditionId) === "1500" && [option.label, option.name, option.text].some(
          (label) => /^new without tags$/i.test(nativeText(label)?.trim() ?? "")
        )
      ))
        return 1500;
    }
  }
  return 1e3;
}
function parseDraftContext(html, pageUrl, options = {}) {
  const url = new URL(pageUrl);
  if (url.origin !== "https://www.ebay.com" || url.username || url.password)
    throw Error("Le contexte du brouillon doit provenir d\u2019eBay US.");
  const ids = /* @__PURE__ */ new Set();
  const urlId = url.searchParams.get("draftId") ?? url.searchParams.get("draft_id");
  if (urlId && DRAFT_ID.test(urlId)) ids.add(urlId);
  for (const source of variants(html)) {
    for (const m of source.matchAll(
      /(?:[?&]draft(?:Id|_id)=|"draftId"\s*:\s*"?)(\d{5,20})/g
    ))
      ids.add(m[1]);
  }
  const draftId = options.draftId ?? (ids.size === 1 ? [...ids][0] : "");
  if (!DRAFT_ID.test(draftId) || options.draftId && ids.size && !ids.has(draftId))
    throw Error("Identit\xE9 du brouillon eBay absente ou diff\xE9rente.");
  const categories = /* @__PURE__ */ new Set();
  const urlCategory = url.searchParams.get("categoryId");
  if (urlCategory && ID.test(urlCategory)) categories.add(urlCategory);
  for (const source of variants(html)) {
    for (const m of source.matchAll(
      /"categoryId"\s*:\s*"?(\d{1,20})(?=[",}\s])/g
    ))
      categories.add(m[1]);
  }
  const categoryId = options.categoryId ?? (categories.size === 1 ? [...categories][0] : "");
  if (!ID.test(categoryId))
    throw Error("Identifiant de cat\xE9gorie eBay absent ou ambigu.");
  const csrf = parseDraftCsrf(html);
  if (!csrf)
    throw Error("Jeton d\u2019enregistrement du brouillon eBay indisponible.");
  return {
    draftId,
    categoryId,
    csrf,
    epsData: parseDraftEpsData(html),
    conditionId: observedDraftCondition(html)
  };
}
function createDraftURL(categoryId, title, conditionId = 1e3) {
  if (!ID.test(categoryId) || !validTitle(title, 80) || ![1e3, 1500].includes(conditionId))
    throw Error("Cat\xE9gorie, titre ou \xE9tat du nouveau brouillon invalide.");
  const query = new URLSearchParams({
    mode: "AddItem",
    categoryId,
    title,
    condition: String(conditionId)
  });
  return `https://www.ebay.com/lstng?${query}`;
}
function hostedPicture(url) {
  try {
    const u = new URL(url);
    return u.protocol === "https:" && !u.username && !u.password && !u.port && /(^|\.)(ebayimg|ebaystatic)\.com$/i.test(u.hostname);
  } catch {
    return false;
  }
}
var ASPECT_VALUE_MAX = 65;
var clip = (v) => {
  const text3 = v.trim();
  if (text3.length <= ASPECT_VALUE_MAX) return text3;
  let cut = "";
  for (const ch of text3) {
    if (cut.length + ch.length > ASPECT_VALUE_MAX) break;
    cut += ch;
  }
  const space = cut.lastIndexOf(" ");
  return (space > 30 ? cut.slice(0, space) : cut).replace(/[\s,;:&-]+$/, "");
};
function fitAspectValue(value, multi) {
  const parts = value.split(/\s*[,;|•]\s*/).map((v) => v.trim()).filter(Boolean);
  if (multi) return [...new Set(parts.map(clip))].slice(0, 30);
  if (value.trim().length <= ASPECT_VALUE_MAX) return value.trim() ? [value.trim()] : [];
  return parts.length ? [clip(parts[0])] : [];
}
function buildDraftAttributes(job, model = []) {
  const attributes2 = /* @__PURE__ */ Object.create(null);
  const specs = removeVariationSpecifics(
    job.ebaySeed?.specifics ?? job.product.specifications,
    (job.supplierPlan?.rows.length ?? 0) > 1 ? job.supplierPlan.axes : []
  );
  for (const spec of specs) {
    const label = spec.label.trim(), value = spec.value.trim();
    if (!label || !value || /^condition$/i.test(label)) continue;
    if (["__proto__", "constructor", "prototype"].includes(label)) continue;
    const native = model.find(
      (field) => norm(field.name.replace(/^attributes\./, "")) === norm(label)
    );
    const name = native?.name.replace(/^attributes\./, "") ?? label;
    attributes2[name] = manufactureLabel(label) ? ["China"] : fitAspectValue(value, !!native?.multiSelectEnabled);
    if (!attributes2[name].length) delete attributes2[name];
  }
  const origin = model.find(
    (field) => manufactureLabel(field.name.replace(/^attributes\./, ""))
  );
  const originName = origin?.name.replace(/^attributes\./, "") ?? "Country of Origin";
  attributes2[originName] = ["China"];
  return attributes2;
}
function buildDraftBasicPayload(job, context, pictures, model = []) {
  if (!ID.test(context.categoryId) || ![1e3, 1500].includes(context.conditionId) || !validTitle(job.title, 80))
    throw Error("Donn\xE9es du brouillon eBay invalides.");
  if (!job.description.trim() || job.description.length > 2 * 1024 * 1024)
    throw Error("Description du brouillon eBay absente ou trop volumineuse.");
  if (!pictures.length || pictures.length > 24 || pictures.some((url) => !hostedPicture(url)) || new Set(pictures).size !== pictures.length)
    throw Error(
      "Les photos du brouillon doivent toutes \xEAtre confirm\xE9es par eBay."
    );
  const serviceContextMeta = JSON.stringify({
    siteId: 0,
    condition: context.conditionId,
    itemConditionDescription: null,
    categoryId: context.categoryId,
    secondaryCategoryId: null,
    prodRefId: null,
    itemId: null,
    sellerId: null,
    title: job.title,
    subtitle: null,
    description: job.description,
    addToDescription: "",
    descriptionEditorMode: /<[a-z][\s\S]*>/i.test(job.description) ? "html" : "standard",
    isDescriptionSecure: false,
    defaultDescription: false
  });
  return {
    serviceContextMeta,
    title: job.title,
    categoryId: context.categoryId,
    condition: context.conditionId,
    secondaryCategoryId: null,
    pictures: [...pictures],
    attributes: buildDraftAttributes(job, model),
    description: job.description,
    format: "FixedPrice",
    // Custom label (SKU) = AliExpress product id: Seller Hub listings and
    // orders show it, so AurOEBay finds the supplier again from any sale.
    ...supplierSku(job.product.supplierProductId) ? { customLabel: supplierSku(job.product.supplierProductId) } : {},
    variationsPref: !!job.supplierPlan?.axes.some(
      (axis) => axis.values.length > 1
    )
  };
}
function supplierSku(id) {
  return id && /^\d{6,20}$/.test(id) ? `AE-${id}` : null;
}
function buildDraftPricingPayload(job) {
  if (job.supplierPlan?.axes.some((axis) => axis.values.length > 1))
    return null;
  const price = job.supplierPlan?.rows[0]?.price;
  if (!price || !/^\d+(?:\.\d{1,2})?$/.test(price) || Number(price) <= 0)
    throw Error(
      "Prix fournisseur confirm\xE9 indisponible pour ce produit simple."
    );
  return { price, quantity: DEFAULT_IMPORT_QUANTITY };
}
function parseDraftWriteResponse(status, text3) {
  let body2;
  try {
    body2 = JSON.parse(text3);
  } catch {
    body2 = null;
  }
  if (status === 401 || status === 403)
    return {
      ok: false,
      error: "Session eBay expir\xE9e ou acc\xE8s au brouillon refus\xE9.",
      sessionExpired: true
    };
  if (status < 200 || status >= 300)
    return {
      ok: false,
      error: `eBay refuse l\u2019enregistrement du brouillon (HTTP ${status}).`
    };
  const mskuErrors = mskuSaveErrors(text3);
  if (mskuErrors?.length)
    return {
      ok: false,
      error: `eBay a refus\xE9 les variantes : ${mskuErrors.slice(0, 4).join(" ")}`.slice(0, 600)
    };
  if (mskuErrors && !mskuErrors.length)
    return { ok: true, responseBytes: text3.length };
  if (!record2(body2) || !Object.keys(body2).length)
    return {
      ok: false,
      error: "R\xE9ponse d\u2019enregistrement eBay vide ou non reconnue."
    };
  if (body2.reload === true)
    return {
      ok: false,
      error: "Le jeton d\u2019enregistrement eBay doit \xEAtre renouvel\xE9.",
      tokenRejected: true
    };
  if (body2.error)
    return {
      ok: false,
      error: "Session eBay expir\xE9e ou enregistrement refus\xE9.",
      sessionExpired: true
    };
  if (body2.success === false || body2.ok === false)
    return { ok: false, error: "eBay a refus\xE9 l\u2019enregistrement du brouillon." };
  if (Array.isArray(body2.errors) && body2.errors.length || typeof body2.errors === "string" && body2.errors.trim() || body2.errorMessage || record2(body2.errors) && Object.keys(body2.errors).length)
    return { ok: false, error: "eBay a rejet\xE9 des donn\xE9es du brouillon." };
  return { ok: true, responseBytes: text3.length };
}
function readDraftSnapshot(source) {
  const snapshot = legacyDraftSnapshot(source);
  if (typeof source !== "string") return snapshot;
  const saved = readSavedDraft(source);
  const prefer = (key4, conflictKey = key4) => {
    if (saved[key4] === null) return;
    snapshot[key4] = saved[key4];
    snapshot.conflicts = snapshot.conflicts.filter((c) => c !== conflictKey);
  };
  prefer("title");
  prefer("description");
  prefer("pictures");
  prefer("price");
  prefer("quantity");
  prefer("conditionId");
  if (saved.attributes) {
    snapshot.attributes = {
      ...snapshot.attributes ?? {},
      ...saved.attributes
    };
    snapshot.conflicts = snapshot.conflicts.filter(
      (c) => !c.startsWith("attributes.") || !(c.slice("attributes.".length) in saved.attributes)
    );
  }
  return snapshot;
}
function legacyDraftSnapshot(source) {
  if (typeof source === "string") {
    const text3 = source;
    try {
      source = JSON.parse(text3);
    } catch {
      source = nativeModelFragments(text3);
    }
  }
  const candidates = [];
  const namedFields = [];
  const pending2 = [[source, 0]];
  let visited = 0;
  const keys = [
    "title",
    "description",
    "categoryId",
    "pictures",
    "price",
    "quantity",
    "condition"
  ];
  while (pending2.length && visited++ < 5e4) {
    const [value, depth] = pending2.pop();
    if (!value || typeof value !== "object" || depth > 12) continue;
    if (Array.isArray(value)) {
      value.forEach((v) => pending2.push([v, depth + 1]));
      continue;
    }
    const node = value;
    if (keys.filter((key4) => key4 in node).length >= 3) candidates.push(node);
    if (node.currencyCode === "USD" && ID.test(String(node.categoryId ?? "")))
      candidates.push({ categoryId: node.categoryId });
    if (typeof node.name === "string" && Object.hasOwn(node, "value")) {
      if (["title", "description", "price", "quantity", "condition"].includes(
        node.name
      )) {
        candidates.push({ [node.name]: node.value });
      } else if (/^attributes\.[^\r\n]{1,150}$/.test(node.name))
        namedFields.push(node);
    }
    if (typeof node.serviceContextMeta === "string") {
      try {
        pending2.push([JSON.parse(node.serviceContextMeta), depth + 1]);
      } catch {
      }
    }
    Object.entries(node).forEach(([key4, v]) => {
      if ([
        "options",
        "suggestions",
        "recommendations",
        "possibleValues"
      ].includes(key4))
        return;
      if (typeof v === "object") pending2.push([v, depth + 1]);
    });
  }
  const snapshot = {
    title: null,
    description: null,
    categoryId: null,
    pictures: null,
    price: null,
    quantity: null,
    conditionId: null,
    attributes: null,
    conflicts: []
  };
  function choose(key4, values) {
    const unique2 = [
      ...new Map(values.map((v) => [JSON.stringify(v), v])).values()
    ];
    if (unique2.length > 1) snapshot.conflicts.push(key4);
    return unique2.length === 1 ? unique2[0] : null;
  }
  snapshot.title = choose(
    "title",
    candidates.flatMap((v) => typeof v.title === "string" ? [v.title] : [])
  );
  snapshot.description = choose(
    "description",
    candidates.flatMap(
      (v) => typeof v.description === "string" ? [v.description] : []
    )
  );
  snapshot.categoryId = choose(
    "categoryId",
    candidates.flatMap(
      (v) => ID.test(String(v.categoryId ?? "")) ? [String(v.categoryId)] : []
    )
  );
  snapshot.pictures = choose(
    "pictures",
    candidates.flatMap(
      (v) => Array.isArray(v.pictures) && v.pictures.every((p) => typeof p === "string" && hostedPicture(p)) ? [v.pictures] : []
    )
  );
  snapshot.price = choose(
    "price",
    candidates.flatMap(
      (v) => typeof v.price === "string" && /^\d+(?:\.\d{1,2})?$/.test(v.price) ? [v.price] : typeof v.price === "number" && Number.isFinite(v.price) && v.price >= 0 ? [String(v.price)] : []
    )
  );
  snapshot.quantity = choose(
    "quantity",
    candidates.flatMap(
      (v) => ["string", "number"].includes(typeof v.quantity) && Number.isSafeInteger(Number(v.quantity)) && v.quantity !== null && v.quantity !== "" && Number(v.quantity) >= 0 ? [Number(v.quantity)] : []
    )
  );
  snapshot.conditionId = choose(
    "conditionId",
    candidates.flatMap(
      (v) => ID.test(String(v.condition ?? "")) ? [Number(v.condition)] : []
    )
  );
  const attributeValues = /* @__PURE__ */ new Map();
  function addAttribute(name, value) {
    if (!Array.isArray(value) || !value.every((item) => typeof item === "string"))
      return;
    const known = attributeValues.get(name) ?? [];
    known.push(value);
    attributeValues.set(name, known);
  }
  for (const candidate2 of candidates)
    if (record2(candidate2.attributes))
      for (const [name, value] of Object.entries(candidate2.attributes))
        addAttribute(name, value);
  for (const field of namedFields)
    addAttribute(String(field.name).replace(/^attributes\./, ""), field.value);
  if (attributeValues.size) {
    snapshot.attributes = /* @__PURE__ */ Object.create(null);
    for (const [name, values] of attributeValues) {
      const value = choose(`attributes.${name}`, values);
      if (value) snapshot.attributes[name] = value;
    }
  }
  return snapshot;
}

// src/core/sales.ts
var round = (n) => Math.round(n * 100) / 100;
function splitCost(total2, weights) {
  const valid = weights.map((w) => Number.isFinite(w) && w > 0 ? w : 0);
  const sum = valid.reduce((t, w) => t + w, 0);
  const shares = sum > 0 ? valid.map((w) => w / sum) : valid.map(() => 1 / valid.length);
  const parts = shares.map((s) => round(total2.amount * s));
  if (parts.length) parts[parts.length - 1] = round(total2.amount - parts.slice(0, -1).reduce((t, x) => t + x, 0));
  return parts.map((amount2) => ({ amount: amount2, currency: total2.currency }));
}
var saleValue = (s) => s.subtotal?.amount ?? s.items.reduce((t, i) => t + (i.price?.amount ?? 0) * (i.quantity || 1), 0);
function purchases(sale) {
  return [...sale.supplier ? [sale.supplier] : [], ...sale.extraSuppliers ?? []];
}
function trackingCovered(sale) {
  const onEbay = new Set((sale.tracking ?? "").split(/\s*,\s*/).filter(Boolean));
  if (!onEbay.size) return false;
  if (sale.items.length > 1 && sale.trackedItems !== void 0 && sale.trackedItems >= sale.items.length) return true;
  return onEbay.size >= purchases(sale).filter((p) => p.tracking).length && (sale.items.length <= 1 || sale.trackedItems === void 0 || sale.trackedItems >= sale.items.length);
}
function trackingsToSend(sale) {
  if (sale.status === "cancelled" || trackingCovered(sale)) return [];
  return purchases(sale).filter((p) => p.tracking && !(sale.tracking ?? "").includes(p.tracking));
}
function saleRate(sale, fallback = null) {
  return sale.adjust?.rate ?? sale.rate ?? fallback;
}
function latestRate(sales) {
  return [...sales].filter((s) => s.rate).sort((a, b) => (b.soldAt ?? 0) - (a.soldAt ?? 0))[0]?.rate ?? null;
}
function toPayout(sale, money3, fallbackRate = null) {
  if (!money3) return null;
  const payout = sale.earnings?.currency ?? "USD";
  const rate = saleRate(sale, fallbackRate);
  if (money3.currency === payout) return money3.amount;
  if (money3.currency === "USD" && rate) return round(money3.amount * rate);
  if (payout === "USD" && rate && money3.currency === "EUR")
    return round(money3.amount / rate);
  return null;
}
function saleNumbers(sale, fallbackRate = null) {
  const currency = sale.earnings?.currency ?? "USD";
  const a = sale.adjust ?? {};
  let usedEstimate = false;
  const convert = (m) => {
    if (!m) return null;
    const direct = toPayout(sale, m);
    if (direct !== null) return direct;
    const estimated = toPayout(sale, m, fallbackRate);
    if (estimated !== null) usedEstimate = true;
    return estimated;
  };
  const total2 = sale.orderTotal ? convert(sale.orderTotal) : sale.subtotal ? (() => {
    const sub = convert(sale.subtotal);
    const ship = sale.shipping ? convert(sale.shipping) : 0;
    return sub === null || ship === null ? null : round(sub + ship);
  })() : null;
  const taxed = sale.orderTotal && sale.tax ? convert({ ...sale.tax, amount: Math.abs(sale.tax.amount) }) : 0;
  let gross = a.revenue ?? (total2 === null || taxed === null ? null : round(total2 - taxed));
  if (sale.refund && a.revenue === void 0 && gross !== null && gross < 0) gross = 0;
  const fees = a.fees ?? round(sale.fees.reduce((sum, f) => sum + (convert(f.amount) ?? 0), 0) * -1);
  const earnings = a.earnings ?? (a.revenue !== void 0 || a.fees !== void 0 ? gross === null ? null : round(gross - fees) : sale.earnings?.amount ?? (gross !== null ? round(gross - fees) : null));
  const linked = purchases(sale);
  let supplier;
  if (a.supplierCost) supplier = convert(a.supplierCost);
  else if (linked.length) {
    const parts = linked.map((p) => convert(p.cost));
    supplier = parts.some((x) => x === null) ? null : round(parts.reduce((t, x) => t + x, 0));
  } else supplier = sale.manualCost ? convert(sale.manualCost) : null;
  let supplierRefund = 0;
  if (!a.supplierCost && supplier !== null && sale.supplierRefunds?.length) {
    for (const r of sale.supplierRefunds) supplierRefund += convert(r.amount) ?? 0;
    supplierRefund = round(Math.min(supplierRefund, supplier));
    supplier = round(supplier - supplierRefund);
  }
  const cost = supplier === null ? null : round(supplier + (sale.otherCost || 0));
  const cancelled = sale.status === "cancelled";
  const profit = cancelled ? 0 : earnings === null || cost === null ? null : round(earnings - cost);
  return {
    currency,
    revenue: cancelled ? 0 : gross,
    fees: cancelled ? 0 : fees,
    earnings: cancelled ? 0 : earnings,
    supplier: cancelled ? 0 : supplier,
    cost: cancelled ? 0 : cost,
    profit,
    complete: cancelled || profit !== null,
    estimatedRate: usedEstimate,
    rate: saleRate(sale, usedEstimate ? fallbackRate : null),
    buyerRefund: sale.refund ? convert(sale.refund) : null,
    supplierRefund
  };
}
function mergeSale(previous, parsed, now = Date.now()) {
  return {
    ...parsed,
    // A later reading without tracking must not erase a known one.
    tracking: parsed.tracking || previous?.tracking || "",
    status: parsed.status === "to_ship" && previous?.status === "shipped" ? "shipped" : parsed.status,
    supplier: previous?.supplier ?? null,
    ...previous?.extraSuppliers?.length ? { extraSuppliers: previous.extraSuppliers } : {},
    manualCost: previous?.manualCost ?? null,
    ...previous?.adjust ? { adjust: previous.adjust } : {},
    ...previous?.supplierRefunds?.length ? { supplierRefunds: previous.supplierRefunds } : {},
    otherCost: previous?.otherCost ?? 0,
    notes: previous?.notes ?? "",
    savedAt: previous?.savedAt ?? now,
    updatedAt: now
  };
}
var plain = (s) => s.normalize("NFKD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/\b(mr|mrs|ms|miss|dr)\b\.?/g, " ").replace(/[^\p{L}\p{N}]+/gu, " ").trim();
var zipKey = (z) => z.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 5);
function receiverScore(sale, r) {
  const a = plain(r.name).split(" ").filter((t) => t.length > 1);
  const b = new Set(plain(sale.buyer).split(" ").filter((t) => t.length > 1));
  const nameHits = a.filter((t) => b.has(t)).length;
  const nameOk = a.length > 0 && nameHits >= Math.min(2, a.length);
  const zipOk = !!sale.zip && !!r.zip && zipKey(sale.zip) === zipKey(r.zip);
  return (nameOk ? 2 : nameHits ? 1 : 0) + (zipOk ? 2 : 0);
}

// src/core/profit.ts
var PROFIT_SETTINGS_KEY = "profitSettings:v1";
var DEFAULT_PROFIT_SETTINGS = { aliExtra: 10, feeRate: null, adRate: 5 };
var EBAY_ORDER_FEE = 0.4;
var EBAY_PERCENT = (0.136 + 0.0165) * 1.07;
var ebayFeeRate = (adRate) => EBAY_PERCENT + Math.max(0, Math.min(30, adRate)) / 100 * 1.07;
var DEFAULT_RATE = 0.92;
var median = (values) => {
  const v = [...values].sort((a, b) => a - b);
  const mid = Math.floor(v.length / 2);
  return v.length % 2 ? v[mid] : (v[mid - 1] + v[mid]) / 2;
};
function learnProfitModel(sales, taxes, settings = DEFAULT_PROFIT_SETTINGS) {
  const rate = latestRate(sales);
  const counts = /* @__PURE__ */ new Map();
  for (const s of sales) {
    const c = s.earnings?.currency;
    if (c) counts.set(c, (counts.get(c) ?? 0) + 1);
  }
  const currency = [...counts].sort((a, b) => b[1] - a[1])[0]?.[0] ?? "EUR";
  const ratios = [];
  for (const s of sales) {
    if (s.status === "cancelled") continue;
    const n = saleNumbers(s, rate);
    if (n.currency !== currency || !n.revenue || n.revenue <= 0 || !(n.fees > 0)) continue;
    const r = (n.fees - EBAY_ORDER_FEE * (rate ?? DEFAULT_RATE)) / n.revenue;
    if (r > 0.02 && r < 0.6) ratios.push(r);
  }
  const learnt = ratios.length >= 3 ? median(ratios) : null;
  const manual2 = settings.feeRate !== null && Number.isFinite(settings.feeRate);
  const feeRate = manual2 ? settings.feeRate / 100 : learnt ?? ebayFeeRate(Number.isFinite(settings.adRate) ? settings.adRate : 5);
  return {
    currency,
    rate: currency === "USD" ? 1 : rate ?? DEFAULT_RATE,
    rateEstimated: currency !== "USD" && !rate,
    feeRate: Math.round(feeRate * 1e4) / 1e4,
    // A typed percentage is taken as everything; otherwise 0.40 $ per order.
    feeFixed: manual2 ? 0 : EBAY_ORDER_FEE,
    feeSamples: settings.feeRate !== null ? 0 : learnt === null ? 0 : ratios.length,
    aliExtra: Math.max(0, settings.aliExtra) / 100,
    charges: Math.max(0, taxes.urssaf + taxes.impot) / 100
  };
}
var round2 = (n) => Math.round(n * 100) / 100;
function estimateProfit(priceUSD, costUSD, m, shipping2 = USUAL_SHIPPING) {
  const revenue = priceUSD * m.rate;
  const fees = revenue * m.feeRate + (m.feeFixed ?? 0) * m.rate;
  const supplier = (costUSD + shippingFor(costUSD, shipping2)) * (1 + m.aliExtra) * m.rate;
  const charges = revenue * m.charges;
  return {
    revenue: round2(revenue),
    fees: round2(fees),
    supplier: round2(supplier),
    charges: round2(charges),
    net: round2(revenue - fees - supplier - charges)
  };
}
function minimumPrice(costUSD, m, target = 0, shipping2 = USUAL_SHIPPING) {
  const keep = 1 - m.feeRate - m.charges;
  if (keep <= 0 || m.rate <= 0) return null;
  const exact = ((costUSD + shippingFor(costUSD, shipping2)) * (1 + m.aliExtra) * m.rate + (m.feeFixed ?? 0) * m.rate + target) / (m.rate * keep);
  const whole = Math.floor(exact);
  for (const candidate2 of [whole + 0.49, whole + 0.99, whole + 1.49])
    if (candidate2 >= exact - 1e-9) return round2(candidate2);
  return round2(whole + 1.99);
}
function targetRule(target, m, rounding) {
  const keep = 1 - m.feeRate - m.charges;
  if (!Number.isFinite(target) || target < 0 || target > 1e3 || keep <= 0.05 || !(m.rate > 0)) return null;
  return {
    coefficient: Math.ceil((1 + m.aliExtra) / keep * 1e4) / 1e4,
    fixed: Math.ceil((target + (m.feeFixed ?? 0) * m.rate) / (m.rate * keep) * 100) / 100,
    rounding,
    target: Math.round(target * 100) / 100
  };
}
function checkPlanProfit(rows, model, shipping2 = USUAL_SHIPPING) {
  return {
    model,
    rows: rows.map((r) => ({ values: r.values, price: Number(r.price), cost: r.cost })).filter((r) => Number.isFinite(r.price) && r.price > 0 && Number.isFinite(r.cost) && r.cost > 0).map((r) => {
      const net = estimateProfit(r.price, r.cost, model, shipping2).net;
      return { ...r, net, minPrice: net < 0 ? minimumPrice(r.cost, model, 0, shipping2) : null };
    })
  };
}

// src/core/supplierSearch.ts
var STOP = new Set(
  "a an and the for with of to in on by from at as or is new hot sale free shipping fast usa us uk lot pcs pc set piece pieces 1pc 1pcs 2pcs women men womens mens unisex".split(
    " "
  )
);
function searchKeywords(title, max = 7) {
  const words2 = title.toLowerCase().replace(/[^a-z0-9\s-]/g, " ").split(/\s+/).filter((w) => w.length > 1 && !STOP.has(w) && !/^\d+$/.test(w));
  return [...new Set(words2)].slice(0, max);
}
var searchURL = (words2) => `https://www.aliexpress.us/w/wholesale-${encodeURIComponent(words2.join("-"))}.html`;
function soldCount(text3) {
  const m = String(text3 ?? "").replace(/,/g, "").match(/(\d+(?:\.\d+)?)\s*(k)?\+?\s*sold/i);
  if (!m) return null;
  return Math.round(Number(m[1]) * (m[2] ? 1e3 : 1));
}
function parseSearchItems(items) {
  if (!Array.isArray(items)) return [];
  const out = [];
  for (const raw of items) {
    const id = String(raw?.productId ?? "");
    if (!/^\d{8,20}$/.test(id)) continue;
    const img = String(raw?.image?.imgUrl ?? "");
    const sale = raw?.prices?.salePrice ?? raw?.prices?.originalPrice;
    out.push({
      id,
      url: `https://www.aliexpress.us/item/${id}.html`,
      title: String(raw?.title?.displayTitle ?? "").slice(0, 300),
      image: img.startsWith("//") ? "https:" + img : img,
      price: typeof sale?.minPrice === "number" ? sale.minPrice : null,
      currency: typeof sale?.currencyCode === "string" ? sale.currencyCode : null,
      sold: soldCount(raw?.trade?.tradeDesc),
      rating: typeof raw?.evaluation?.starRating === "number" ? raw.evaluation.starRating : null,
      choice: JSON.stringify(raw?.sellingPoints ?? []).includes("choice")
    });
  }
  return out;
}
function titleSimilarity(ebayTitle, supplierTitle) {
  const x = new Set(searchKeywords(ebayTitle, 40));
  const y = new Set(searchKeywords(supplierTitle, 40));
  if (!x.size || !y.size) return 0;
  let common = 0;
  for (const w of x) if (y.has(w)) common++;
  return common / x.size;
}
function correlation(a, b) {
  const n = Math.min(a.length, b.length);
  if (!n) return 0;
  let ma = 0, mb = 0;
  for (let i = 0; i < n; i++) {
    ma += a[i];
    mb += b[i];
  }
  ma /= n;
  mb /= n;
  let num2 = 0, da = 0, db = 0;
  for (let i = 0; i < n; i++) {
    const x = a[i] - ma, y = b[i] - mb;
    num2 += x * y;
    da += x * x;
    db += y * y;
  }
  return da && db ? num2 / Math.sqrt(da * db) : 0;
}
function bestCorrelation(a, b) {
  let best = 0;
  for (const x of a) for (const y of b) best = Math.max(best, correlation(x, y));
  return Math.round(best * 1e3) / 1e3;
}
var SAME_PHOTO = 0.92;
function rankCandidates(candidates, ebayTitle, photos) {
  const maxSold = Math.max(1, ...candidates.map((c) => c.sold ?? 0));
  const prices = candidates.map((c) => c.price).filter((p) => p !== null && p > 0).sort((a, b) => a - b);
  const median2 = prices.length ? prices[Math.floor(prices.length / 2)] : null;
  return candidates.map((c) => {
    const photo = photos.has(c.id) ? Math.max(0, photos.get(c.id)) : null;
    const words2 = titleSimilarity(ebayTitle, c.title);
    const popularity = Math.log10(1 + (c.sold ?? 0)) / Math.log10(1 + maxSold);
    const rating = c.rating ? Math.max(0, (c.rating - 4) / 1) : 0;
    let score = (photo ?? 0.35) * 0.6 + words2 * 0.25 + popularity * 0.1 + rating * 0.05;
    if (median2 !== null && c.price !== null && c.price > median2 * 3) score *= 0.5;
    if (!c.sold) score *= 0.8;
    return { ...c, photo, words: words2, score: Math.round(score * 1e3) / 1e3 };
  }).sort((a, b) => b.score - a.score);
}

// src/core/scout.ts
async function searchCardsInPage(url) {
  const html = await fetch(url, { credentials: "same-origin", signal: AbortSignal.timeout(3e4) }).then((r) => r.text());
  const doc = new DOMParser().parseFromString(html, "text/html");
  const money3 = (t) => {
    const m = t.replace(/,/g, "").match(/\$\s?(\d+(?:\.\d{1,2})?)/);
    return m ? Number(m[1]) : null;
  };
  const sellerOf = (card, text3) => {
    const row = [...card.querySelectorAll(".s-card__attribute-row, .s-item__seller-info")].find((e) => /% positive/.test(e.textContent ?? ""));
    return (row?.textContent ?? text3).replace(/\s+/g, " ").trim().match(/(?:^|\s)([A-Za-z0-9_.-]{2,64})\s*\(?\d{1,3}(?:\.\d)?% positive/)?.[1]?.toLowerCase() ?? null;
  };
  const out = [];
  for (const card of doc.querySelectorAll(".srp-results li.s-card, .srp-results li.s-item")) {
    const href = card.querySelector("a[href*='/itm/']")?.getAttribute("href") ?? "";
    const itemId = href.match(/\/itm\/(?:[^/?#]+\/)?(\d{9,15})/)?.[1];
    if (!itemId) continue;
    const text3 = (card.textContent ?? "").replace(/\s+/g, " ");
    const title = (card.querySelector(".s-card__title, .s-item__title")?.textContent ?? "").replace(/Opens in a new window or tab|New Listing/gi, "").replace(/\s+/g, " ").trim();
    const price = money3(card.querySelector(".s-card__price, .s-item__price")?.textContent ?? text3);
    if (!title || price === null || /^shop on ebay$/i.test(title)) continue;
    const ship = text3.match(/\+\s?\$\s?(\d+(?:\.\d{1,2})?)\s*(?:delivery|shipping)/i);
    const date = text3.match(/Sold\s+([A-Z][a-z]{2} \d{1,2}, \d{4})/)?.[1];
    const soldText = [...card.querySelectorAll("span, div")].map((e) => e.childElementCount === 0 ? (e.textContent ?? "").trim() : "").find((t) => /^\d[\d,.]*K?\+? sold$/i.test(t));
    const sold = soldText?.match(/(\d[\d,.]*)(K)?\+? sold/i);
    const img = card.querySelector("img");
    out.push({
      itemId,
      title: title.slice(0, 200),
      price,
      shipping: ship ? Number(ship[1]) : /free (?:international )?(?:delivery|shipping)/i.test(text3) ? 0 : null,
      seller: sellerOf(card, text3),
      soldAt: date ? Date.parse(date) || null : null,
      located: [...card.querySelectorAll("span, div")].find((e) => e.childElementCount === 0 && /^Located in /.test((e.textContent ?? "").trim()))?.textContent?.trim().slice(11).trim() ?? text3.match(/Located in ([A-Za-z ]+?)(?=View|Free|\+|Last one|Sell one|$)/)?.[1]?.trim() ?? null,
      image: img?.getAttribute("src") || img?.getAttribute("data-defer-load") || img?.getAttribute("data-src") || "",
      sold: sold ? Math.round(Number(sold[1].replace(/,/g, "")) * (sold[2] ? 1e3 : 1)) : null
    });
  }
  return out;
}
var activeSearchURL = (words2) => `https://www.ebay.com/sch/i.html?_nkw=${encodeURIComponent(words2.join(" "))}&LH_BIN=1&LH_ItemCondition=1000&_ipg=240&_dmd=1`;
var total = (c) => Math.round((c.price + (c.shipping ?? 0)) * 100) / 100;
function groupByPhoto(cards, grids, now = Date.now(), same = 0.93, close = 0.86) {
  const order = cards.map((_, i) => i).sort((a, b) => (cards[b].soldAt ?? 0) - (cards[a].soldAt ?? 0));
  const members = [];
  for (const i of order) {
    const a = grids[i];
    let home = -1;
    if (a)
      for (let g = 0; g < members.length && home < 0; g++) {
        const refs = members[g].slice(0, 3);
        const ok = refs.every((r) => {
          const b = grids[r];
          if (!b) return false;
          const photo = bestCorrelation(a, b);
          return photo >= same || photo >= close && titleSimilarity(cards[i].title, cards[r].title) >= 0.45;
        });
        if (ok) home = g;
      }
    if (home >= 0) members[home].push(i);
    else members.push([i]);
  }
  const parent = cards.map((_, i) => i);
  for (const m of members) for (const i of m) parent[i] = m[0];
  const find = (i) => parent[i];
  const groups = /* @__PURE__ */ new Map();
  cards.forEach((c, i) => {
    const root = find(i);
    groups.set(root, [...groups.get(root) ?? [], c]);
  });
  return [...groups.values()].map((list2) => {
    const sorted2 = [...list2].sort((x, y) => (y.soldAt ?? 0) - (x.soldAt ?? 0));
    const prices = list2.map(total).sort((x, y) => x - y);
    const located = {};
    for (const c of list2) located[c.located ?? "United States"] = (located[c.located ?? "United States"] ?? 0) + 1;
    return {
      lead: sorted2[0],
      cards: sorted2,
      sellers: new Set(list2.map((c) => c.seller ?? c.itemId)).size,
      median: prices[Math.floor(prices.length / 2)],
      min: prices[0],
      lastSoldAt: sorted2[0].soldAt,
      recent: list2.filter((c) => c.soldAt !== null && now - c.soldAt < 30 * 864e5).length,
      located,
      soldShown: list2.reduce((n, c) => n + (c.sold ?? 0), 0)
    };
  });
}
function rankDropship(groups, sellerOf, minNonUS = 2) {
  return groups.map((g) => {
    const sellers = [...new Set(g.cards.map((c) => c.seller).filter((x) => !!x))];
    const info = sellers.map((s) => sellerOf(s) ?? { status: "UNKNOWN", country: null });
    const countries = {};
    for (const i of info) if (i.status === "NON_US" && i.country) countries[i.country] = (countries[i.country] ?? 0) + 1;
    return {
      ...g,
      nonUS: info.filter((i) => i.status === "NON_US").length,
      us: info.filter((i) => i.status === "US").length,
      unknown: info.filter((i) => i.status === "UNKNOWN").length,
      countries
    };
  }).filter((g) => g.nonUS >= minNonUS).sort((a, b) => b.nonUS - a.nonUS || b.soldShown - a.soldShown || b.sellers - a.sellers);
}
async function purchaseRowsInPage(itemIds) {
  const out = {};
  let next = 0;
  const one = async (id) => {
    try {
      const r = await fetch(`/bin/purchaseHistory?item=${id}`, { credentials: "same-origin", signal: AbortSignal.timeout(2e4) });
      if (!r.ok || /signin/i.test(new URL(r.url).hostname)) return out[id] = null;
      const doc = new DOMParser().parseFromString(await r.text(), "text/html");
      const table = doc.querySelector("table.app-table__table") ?? doc.querySelector("table");
      if (!table) return out[id] = [];
      const rows = [...table.querySelectorAll("tr")];
      const cells = (tr) => [...tr.children].map((c) => (c.textContent ?? "").replace(/\s+/g, " ").trim());
      const head = rows.length ? cells(rows[0]).map((h) => h.toLowerCase()) : [];
      const date = head.findIndex((h) => /date/.test(h));
      const qty = head.findIndex((h) => /quantity/.test(h));
      out[id] = date < 0 ? [] : rows.slice(1).map((tr) => {
        const c = cells(tr);
        return { date: c[date] ?? "", quantity: Math.max(1, Number(c[qty]) || 1) };
      });
    } catch {
      out[id] = null;
    }
  };
  await Promise.all(
    Array.from({ length: 4 }, async () => {
      while (next < itemIds.length) await one(itemIds[next++]);
    })
  );
  return out;
}
async function profileSnippetsInPage(usernames) {
  const out = {};
  let next = 0;
  const one = async (u) => {
    try {
      const r = await fetch(`/fdbk/feedback_profile/${encodeURIComponent(u)}`, { credentials: "same-origin", redirect: "follow", signal: AbortSignal.timeout(2e4) });
      if (!r.ok) return out[u] = null;
      const html = (await r.text()).replace(/<(script|style|noscript|template)\b[^>]*>[\s\S]*?<\/\1>/gi, "");
      if (/captcha|pardon our interruption|verify you are human|robot check/i.test(html)) return out[u] = { url: r.url, html: "captcha" };
      const parts = [];
      for (let at = html.indexOf("Member since"); at >= 0 && parts.length < 3; at = html.indexOf("Member since", at + 12))
        parts.push(html.slice(at, at + 600));
      out[u] = { url: r.url, html: parts.join(" ") };
    } catch {
      out[u] = null;
    }
  };
  await Promise.all(
    Array.from({ length: 3 }, async () => {
      while (next < usernames.length) await one(usernames[next++]);
    })
  );
  return out;
}

// src/core/purchaseHistory.ts
var MONTHS = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"];
var ZONES = { PDT: -7, PST: -8, MDT: -6, MST: -7, CDT: -5, CST: -6, EDT: -4, EST: -5, GMT: 0, UTC: 0, BST: 1, CET: 1, CEST: 2 };
function purchaseDate(text3) {
  let day, month, year, h, min, sec, zone;
  const a = text3.match(/(\d{1,2}) ([A-Za-z]{3})[a-z]* (\d{4})(?: at)? (\d{1,2}):(\d{2})(?::(\d{2}))?\s*(am|pm)?\s*([A-Z]{2,4})?/i);
  const b = text3.match(/([A-Za-z]{3})-(\d{1,2})-(\d{2,4}) (\d{1,2}):(\d{2})(?::(\d{2}))?\s*(am|pm)?\s*([A-Z]{2,4})?/i);
  if (a) [day, month, year, h, min, sec] = [+a[1], MONTHS.indexOf(a[2].toLowerCase()), +a[3], +a[4], +a[5], +(a[6] ?? 0)];
  else if (b) [day, month, year, h, min, sec] = [+b[2], MONTHS.indexOf(b[1].toLowerCase()), +b[3] < 100 ? 2e3 + +b[3] : +b[3], +b[4], +b[5], +(b[6] ?? 0)];
  else return null;
  const m = a ?? b;
  const ampm = (m[7] ?? "").toLowerCase();
  zone = (m[8] ?? "UTC").toUpperCase();
  if (month < 0) return null;
  if (ampm === "pm" && h < 12) h += 12;
  if (ampm === "am" && h === 12) h = 0;
  return Date.UTC(year, month, day, h, min, sec) - (ZONES[zone] ?? 0) * 36e5;
}

// src/core/niches.ts
var NICHES = {
  Maison: [
    "led strip lights",
    "sunset projection lamp",
    "moon lamp",
    "galaxy projector",
    "motion sensor night light",
    "magnetic spice rack",
    "under sink organizer",
    "drawer divider",
    "vacuum storage bags",
    "cable organizer box",
    "shower caddy",
    "rotating makeup organizer",
    "silicone stretch lids",
    "electric milk frother",
    "vegetable chopper",
    "garlic press",
    "reusable silicone bags",
    "door draft stopper",
    "self adhesive hooks",
    "blackout curtain clips"
  ],
  Cuisine: [
    "silicone baking mat",
    "air fryer liners",
    "coffee scale",
    "pour over kettle",
    "ice cube tray with lid",
    "knife sharpener",
    "oil sprayer bottle",
    "herb scissors",
    "fruit infuser bottle",
    "bento lunch box"
  ],
  "T\xE9l\xE9phone & tech": [
    "magnetic phone mount",
    "phone tripod",
    "ring light",
    "wireless charger stand",
    "usb c hub",
    "laptop stand",
    "webcam cover",
    "cable protector",
    "tablet holder for bed",
    "bluetooth tracker tag",
    "car vent phone holder",
    "screen cleaner spray",
    "mini projector",
    "smart plug",
    "keyboard wrist rest"
  ],
  "Montres & bijoux": [
    "watch band 44mm",
    "solo loop watch band",
    "magnetic watch strap",
    "watch screen protector",
    "stainless steel bracelet",
    "titanium ring",
    "birthstone necklace",
    "initial necklace",
    "anklet",
    "hair claw clip"
  ],
  Voiture: [
    "car seat gap filler",
    "car trash can",
    "steering wheel cover",
    "car sun shade",
    "trunk organizer",
    "tire pressure gauge",
    "car interior led lights",
    "dash cam mount",
    "seat back organizer",
    "car cup holder expander"
  ],
  "Animaux": [
    "cat water fountain",
    "slow feeder dog bowl",
    "lick mat",
    "cat scratcher",
    "dog poop bag holder",
    "pet hair remover",
    "cat tunnel",
    "dog harness no pull",
    "pet grooming glove",
    "automatic cat toy"
  ],
  "Sport & ext\xE9rieur": [
    "resistance bands",
    "jump rope",
    "yoga mat strap",
    "massage gun attachments",
    "grip strengthener",
    "camping lantern",
    "hammock straps",
    "waterproof phone pouch",
    "cooling towel",
    "bike phone mount",
    "fishing lure kit",
    "hiking trekking poles",
    "headlamp rechargeable",
    "collapsible water bottle"
  ],
  "Beaut\xE9 & soin": [
    "gua sha",
    "ice roller",
    "scalp massager",
    "facial steamer",
    "nail art stickers",
    "makeup brush cleaner",
    "eyelash curler heated",
    "hair bonnet satin",
    "heatless curling rod",
    "blackhead remover"
  ],
  "B\xE9b\xE9 & enfants": [
    "silicone teether",
    "baby food feeder",
    "busy board",
    "kids water bottle",
    "magnetic tiles",
    "sensory toys",
    "baby proof cabinet locks",
    "night light for kids",
    "drawing tablet for kids",
    "bath toys"
  ],
  "Loisirs & jouets": [
    "fidget toys",
    "speed cube",
    "diamond painting kit",
    "puzzle mat",
    "plush keychain",
    "kite for kids",
    "rc car",
    "building blocks",
    "card sleeves",
    "dice set resin"
  ],
  "Bureau & rangement": [
    "desk organizer",
    "monitor riser",
    "label maker tape",
    "acrylic display case",
    "magnetic whiteboard",
    "pen holder",
    "file organizer",
    "document bag",
    "sticky notes dispenser",
    "under desk drawer"
  ],
  "Jardin": [
    "solar garden lights",
    "plant grow light",
    "self watering planter",
    "garden kneeler",
    "bird feeder",
    "hose nozzle",
    "plant labels",
    "seed starter tray",
    "pruning shears",
    "outdoor string lights"
  ]
};
var ALL_NICHES = Object.entries(NICHES).flatMap(([category, list2]) => list2.map((niche) => ({ niche, category })));
function pickNiches(count, recent = [], random = Math.random, categories) {
  const recentSet = new Set(recent);
  const allowed = categories?.length ? ALL_NICHES.filter((n) => categories.includes(n.category)) : ALL_NICHES;
  let pool = allowed.filter((n) => !recentSet.has(n.niche));
  if (pool.length < count) pool = [...allowed];
  const out = [];
  const usedCategories = /* @__PURE__ */ new Set();
  while (out.length < count && pool.length) {
    const fresh = pool.filter((n) => !usedCategories.has(n.category));
    const from = fresh.length ? fresh : pool;
    const pick = from[Math.floor(random() * from.length)];
    out.push(pick);
    usedCategories.add(pick.category);
    pool = pool.filter((n) => n !== pick);
  }
  return out;
}

// src/seller/cache.ts
var sellerKey = (username) => `seller:v4:${username.trim().toLowerCase()}`;
function cacheValid(entry, ttlDays, now = Date.now()) {
  return !!entry && Number.isFinite(entry.timestamp) && entry.timestamp <= now && now - entry.timestamp < (entry.status === "UNKNOWN" ? 60 * 1e3 : ttlDays * 864e5);
}
async function getSellerCache(username, ttl) {
  const key4 = sellerKey(username);
  const r = await chrome.storage.local.get(key4);
  return cacheValid(r[key4], ttl) ? r[key4] : null;
}
async function getSellerCaches(usernames, ttl) {
  const r = await chrome.storage.local.get(usernames.map(sellerKey));
  const out = /* @__PURE__ */ new Map();
  for (const name of usernames) {
    const v = r[sellerKey(name)];
    if (cacheValid(v, ttl)) out.set(name, v);
  }
  return out;
}
var puts = 0;
async function putSellerCache(entry, identity2 = entry.username) {
  await chrome.storage.local.set({ [sellerKey(identity2)]: entry });
  if (++puts % 25 === 0) await pruneSellerCache();
}
async function pruneSellerCache() {
  const all3 = await chrome.storage.local.get(null);
  const entries = Object.entries(all3).filter(([k]) => k.startsWith("seller:")).sort((a, b) => b[1].timestamp - a[1].timestamp);
  await chrome.storage.local.remove(
    entries.filter(([, v], i) => i >= 1e3 || !cacheValid(v, 30)).map(([k]) => k)
  );
}

// src/seller/parser.ts
function unknownSeller(username, reason = "Seller account country not exposed") {
  return {
    username,
    country: null,
    status: "UNKNOWN",
    timestamp: Date.now(),
    source: "none",
    evidence: reason
  };
}
function parseFeedbackCountry(html, username, url) {
  let u;
  try {
    u = new URL(url);
  } catch {
    return unknownSeller(username, "Invalid feedback profile source");
  }
  const owner = decodeURIComponent(
    u.pathname.match(/^\/fdbk\/feedback_profile\/([^/]+)\/?$/)?.[1] ?? ""
  );
  if (u.protocol !== "https:" || !/(^|\.)ebay\.com$/.test(u.hostname) || owner.toLowerCase() !== username.toLowerCase())
    return unknownSeller(username, "Unexpected feedback profile");
  html = html.replace(
    /<(script|style|noscript|template)\b[^>]*>[\s\S]*?<\/\1>/gi,
    ""
  );
  if (/captcha|pardon our interruption|verify you are human|robot check/i.test(
    html
  ))
    return unknownSeller(username, "eBay verification required");
  const found = [
    ...html.matchAll(
      /Member since:?\s*(?:<[^>]+>\s*)*[A-Za-z0-9 ,.-]{3,30}?\s+in\s+(?:<[^>]+>\s*)*([^<>]{2,60}?)\s*</gi
    )
  ].map((m) => ({
    evidence: compact(m[1].replace(/&nbsp;|&#160;/g, " ")),
    value: normalizeCountry(m[1])
  }));
  const countries = [...new Set(found.map((f) => f.value).filter(Boolean))];
  if (countries.length !== 1)
    return unknownSeller(
      username,
      countries.length > 1 ? "Conflicting profile countries" : "Registration country not found"
    );
  return {
    username,
    country: countries[0],
    status: countries[0] === "United States" ? "US" : "NON_US",
    timestamp: Date.now(),
    source: u.href,
    evidence: `Member since \u2026 in ${found.find((f) => f.value).evidence}`
  };
}

// src/background/competitorPrices.ts
var CACHE = "competitorPrices:v1";
var HOURS = 24;
var wait2 = (ms) => new Promise((r) => setTimeout(r, ms));
async function marketSearchInPage(url) {
  const html = await fetch(url, { credentials: "same-origin", signal: AbortSignal.timeout(3e4) }).then((r) => r.text());
  const doc = new DOMParser().parseFromString(html, "text/html");
  const money3 = (t) => {
    const m = t.replace(/,/g, "").match(/\$\s?(\d+(?:\.\d{1,2})?)/);
    return m ? Number(m[1]) : null;
  };
  const out = [];
  for (const card of doc.querySelectorAll(".srp-results li.s-card, .srp-results li.s-item")) {
    const link = card.querySelector("a[href*='/itm/']");
    const itemId = link?.getAttribute("href")?.match(/\/itm\/(?:[^/?#]+\/)?(\d{9,15})/)?.[1];
    if (!itemId) continue;
    const text3 = (card.textContent ?? "").replace(/\s+/g, " ");
    const title = (card.querySelector(".s-card__title, .s-item__title")?.textContent ?? "").replace(/Opens in a new window or tab|New Listing/gi, "").replace(/\s+/g, " ").trim();
    const priceText = card.querySelector(".s-card__price, .s-item__price")?.textContent ?? text3;
    const price = money3(priceText);
    if (!title || price === null) continue;
    const ship = text3.match(/\+\s?\$\s?(\d+(?:\.\d{1,2})?)\s*(?:delivery|shipping)/i);
    const shipping2 = ship ? Number(ship[1]) : /free (?:delivery|shipping)/i.test(text3) ? 0 : null;
    const row = [...card.querySelectorAll(".s-card__attribute-row, .s-item__seller-info")].find((e) => /% positive/.test(e.textContent ?? ""));
    const seller = (row?.textContent ?? text3).replace(/\s+/g, " ").trim().match(/(?:^|\s)([A-Za-z0-9_.-]{2,64})\s*\(?\d{1,3}(?:\.\d)?% positive/)?.[1]?.toLowerCase() ?? null;
    const soldText = [...card.querySelectorAll("span, div")].map((e) => e.childElementCount === 0 ? (e.textContent ?? "").trim() : "").find((t) => /^\d[\d,.]*K?\+? sold$/i.test(t));
    const sold = soldText?.match(/(\d[\d,.]*)(K)?\+? sold/i);
    out.push({
      itemId,
      title: title.slice(0, 200),
      seller,
      price,
      shipping: shipping2,
      image: card.querySelector("img")?.getAttribute("src") ?? "",
      sold: sold ? Math.round(Number(sold[1].replace(/,/g, "")) * (sold[2] ? 1e3 : 1)) : null
    });
  }
  return out;
}
var jobTabs = /* @__PURE__ */ new Set();
async function ebayTab(own = false) {
  if (!own) {
    const open = await chrome.tabs.query({ url: "https://www.ebay.com/*", status: "complete" }).catch(() => []);
    const usable = open.find((t) => t.id !== void 0 && !t.discarded && !jobTabs.has(t.id));
    if (usable?.id !== void 0) return { tabId: usable.id, owned: false };
  }
  const tab = await chrome.tabs.create({ url: "https://www.ebay.com/robots.txt", active: false });
  if (tab.id === void 0) throw Error("Impossible d\u2019ouvrir eBay.");
  jobTabs.add(tab.id);
  await chrome.tabs.update(tab.id, { autoDiscardable: false }).catch(() => {
  });
  for (let i = 0; i < 30; i++) {
    await wait2(400);
    const t = await chrome.tabs.get(tab.id).catch(() => void 0);
    if (!t) throw Error("L\u2019onglet eBay a \xE9t\xE9 ferm\xE9.");
    if (t.status === "complete") return { tabId: tab.id, owned: true };
  }
  return { tabId: tab.id, owned: true };
}
async function marketSearch(input) {
  const title = typeof input.title === "string" ? input.title.slice(0, 300) : "";
  const words2 = searchKeywords(title, 8);
  if (words2.length < 2) throw Error("Titre trop court pour chercher les concurrents.");
  const key4 = typeof input.itemId === "string" && /^\d{9,15}$/.test(input.itemId) ? `item:${input.itemId}` : `t:${words2.join(" ")}`;
  const cache = (await chrome.storage.local.get(CACHE))[CACHE] ?? {};
  const hit = cache[key4];
  if (input.fresh !== true && hit && Date.now() - hit.at < HOURS * 36e5) return { ...hit, cached: true };
  const searchUrl = `https://www.ebay.com/sch/i.html?_nkw=${encodeURIComponent(words2.join(" "))}&LH_BIN=1&_ipg=60&_dmd=1`;
  const { tabId, owned } = await ebayTab();
  let cards = [];
  try {
    const [r] = await withTimeout(chrome.scripting.executeScript({ target: { tabId }, func: marketSearchInPage, args: [searchUrl] }), 6e4);
    cards = r?.result ?? [];
  } finally {
    if (owned) await chrome.tabs.remove(tabId).catch(() => {
    });
  }
  if (!cards.length) throw Error("eBay n\u2019a renvoy\xE9 aucune annonce (v\xE9rification anti-robot ?). Ouvre eBay une fois puis r\xE9essaie.");
  const result = { words: words2, searchUrl, cards, at: Date.now() };
  cache[key4] = result;
  const kept2 = Object.entries(cache).filter(([, v]) => Date.now() - v.at < HOURS * 36e5).sort((a, b) => b[1].at - a[1].at).slice(0, 80);
  await chrome.storage.local.set({ [CACHE]: Object.fromEntries(kept2) });
  return result;
}

// src/background/supplierFinder.ts
var CACHE2 = "supplierSearch:v1";
var CACHE_DAYS = 7;
var CACHE_MAX = 150;
var GALLERY_CHECK = 30;
var wait3 = (ms) => new Promise((r) => setTimeout(r, ms));
async function supplierSearchInPage(imageUrl, words2) {
  const readRegion = () => {
    const ship = document.querySelector('[class*="ship-to--menuItem"], [class*="ship-to--text"]');
    const flag = document.querySelector('[class*="ship-to--cssFlag"]');
    const account = document.querySelector('[class*="my-account--menuItem"], [class*="my-account--text"]');
    const shipText = (ship?.textContent ?? "").replace(/\s+/g, " ").trim();
    const accountText = (account?.textContent ?? "").replace(/\s+/g, " ").trim();
    return {
      host: location.hostname,
      country: [...flag?.classList ?? []].find((c) => /^[A-Z]{2}$/.test(c)) ?? null,
      currency: shipText.match(/\b([A-Z]{3})\b\s*$/)?.[1] ?? null,
      signedIn: !accountText ? null : /sign in|register|connecte|connexion|identifi|inscri|iniciar|anmelden|accedi|entrar/i.test(accountText) && !/,/.test(accountText) ? false : /,/.test(accountText) ? true : null
    };
  };
  let region = readRegion();
  for (let i = 0; i < 6 && (region.country === null || region.signedIn === null); i++) {
    await new Promise((r) => setTimeout(r, 500));
    region = readRegion();
  }
  const regionWrong = !/(^|\.)aliexpress\.us$/.test(region.host) || region.signedIn === false || region.country !== null && region.country !== "US" || region.currency !== null && region.currency !== "USD";
  if (regionWrong) return { mode: "text", items: [], blocked: false, challenge: false, cookieFull: false, imageError: "", region };
  const contentOf = (html) => {
    const j = html.indexOf('"productId"');
    if (j < 0) return null;
    const start = html.lastIndexOf('"content":[', j);
    if (start < 0) return null;
    const from = start + '"content":'.length;
    let depth = 0, inString = false, escaped = false;
    for (let p = from; p < html.length; p++) {
      const ch = html[p];
      if (inString) {
        if (escaped) escaped = false;
        else if (ch === "\\") escaped = true;
        else if (ch === '"') inString = false;
        continue;
      }
      if (ch === '"') inString = true;
      else if (ch === "[" || ch === "{") depth++;
      else if (ch === "]" || ch === "}") {
        depth--;
        if (depth === 0) {
          try {
            return JSON.parse(html.slice(from, p + 1));
          } catch {
            return null;
          }
        }
      }
    }
    return null;
  };
  let blocked = false;
  let cookieFull = false;
  const robot = (text3) => /punish|x5sec|captcha|FAIL_SYS_USER_VALIDATE|RGV587/i.test(text3);
  const read2 = (url) => fetch(url, { credentials: "include", signal: AbortSignal.timeout(15e3) }).then((r) => r.text()).then((html) => {
    if (!html.includes('"productId"') && robot(html.slice(0, 2e4))) blocked = true;
    if (!html.includes('"productId"') && /Request Header Or Cookie Too Large/i.test(html.slice(0, 5e3))) cookieFull = true;
    return html;
  });
  let challenge = false;
  const shownCheck = () => [...document.querySelectorAll('iframe[src*="punish"], iframe[src*="captcha"], iframe[src*="_____tmd_____"], .J_MIDDLEWARE_FRAME_WIDGET, .baxia-dialog, #baxia-dialog-content')].some((e) => {
    const r = e.getBoundingClientRect();
    return r.width > 100 && r.height > 100 && r.bottom > 0 && r.top < innerHeight && e.checkVisibility({ opacityProperty: true, visibilityProperty: true });
  });
  const watched2 = (p) => new Promise((resolve, reject) => {
    const started = Date.now();
    let seen = 0;
    const timer = setInterval(() => {
      seen = shownCheck() ? seen + 1 : 0;
      if (seen >= 2) {
        challenge = true;
        clearInterval(timer);
        reject({ ret: ["punish: v\xE9rification affich\xE9e"] });
      } else if (Date.now() - started > 2e4) {
        clearInterval(timer);
        reject({ ret: ["pas de r\xE9ponse en 20 s"] });
      }
    }, 400);
    p.then(
      (v) => {
        clearInterval(timer);
        resolve(v);
      },
      (e) => {
        clearInterval(timer);
        reject(e);
      }
    );
  });
  let mode = "text";
  let imageError = "";
  let items = null;
  const mtop = window.lib?.mtop;
  if (imageUrl && mtop?.request) {
    try {
      const blob = await (await fetch(imageUrl, { signal: AbortSignal.timeout(1e4) })).blob();
      const bitmap = await createImageBitmap(blob);
      let side = 800, base64 = "";
      for (let i = 0; i < 4; i++) {
        const scale = Math.min(1, side / Math.max(bitmap.width, bitmap.height));
        const canvas = document.createElement("canvas");
        canvas.width = Math.round(bitmap.width * scale);
        canvas.height = Math.round(bitmap.height * scale);
        canvas.getContext("2d").drawImage(bitmap, 0, 0, canvas.width, canvas.height);
        base64 = canvas.toDataURL("image/jpeg", 0.8).split("base64,")[1] ?? "";
        if (base64.length * 0.75 <= 200 * 1024) break;
        side = Math.round(side * 0.7);
      }
      const params = {
        platform: "pc",
        page: 1,
        pageSize: 60,
        appId: 21738,
        isNewImageSearch: true,
        osf: "pc_web_image_search",
        clientType: "pc",
        searchBizScene: "imageSearch",
        subScenario: "imageUpload",
        image_base64: base64,
        sortType: "default",
        sortOrder: "default",
        contentType: "imageUpload"
      };
      let fileId;
      for (let attempt = 0; attempt < 2 && !fileId; attempt++) {
        if (attempt) await new Promise((r) => setTimeout(r, 1500));
        try {
          const r = await watched2(mtop.request({
            api: "mtop.relationrecommend.AliexpressRecommend.recommend",
            v: "1.0",
            appKey: "24815441",
            timeout: 12e3,
            type: "POST",
            data: { appId: 21738, params: JSON.stringify(params) }
          }));
          fileId = r?.data?.fileId;
          if (!fileId) imageError = "pas de fileId";
        } catch (e) {
          const text3 = (() => {
            try {
              return JSON.stringify(e).slice(0, 300);
            } catch {
              return String(e);
            }
          })();
          imageError = text3;
          if (text3.includes("pas de r\xE9ponse")) break;
          if (robot(text3)) {
            blocked = true;
            break;
          }
        }
      }
      if (fileId) {
        items = contentOf(await read2(`/w/wholesale-.html?isNewImageSearch=y&filename=${encodeURIComponent(fileId)}`));
        if (items?.length) mode = "image";
      }
    } catch (e) {
      imageError = imageError || String(e);
    }
  }
  if (!items?.length && words2.length >= 2 && !challenge)
    items = contentOf(await read2(`/w/wholesale-${encodeURIComponent(words2.join("-"))}.html`));
  if (!items?.length && shownCheck()) challenge = true;
  return { mode, items: items ?? [], blocked: (blocked || challenge) && !items?.length, challenge: challenge && !items?.length, cookieFull: cookieFull && !items?.length, imageError, region };
}
async function galleriesInPage(ids) {
  const galleries = {};
  const queue5 = [...ids];
  const until = Date.now() + 2e4;
  await Promise.all(
    Array.from({ length: 8 }, async () => {
      while (queue5.length && Date.now() < until) {
        const id = queue5.shift();
        try {
          const html = await fetch(`/item/${id}.html`, { credentials: "include", signal: AbortSignal.timeout(8e3) }).then((r) => r.text());
          const m = html.match(/"imagePathList":\[([^\]]*)\]/);
          if (m)
            galleries[id] = JSON.parse(`[${m[1]}]`).filter((u) => typeof u === "string").slice(0, 12);
        } catch {
        }
      }
    })
  );
  return galleries;
}
var OWN_TAB = "aliSearchTab:v1";
var idleClose;
var hasMtop = async (tabId) => await probeTab(tabId) === "ready";
async function probeTab(tabId) {
  const [probe] = await chrome.scripting.executeScript({
    target: { tabId },
    world: "MAIN",
    func: () => {
      const shown = (e) => {
        const r = e.getBoundingClientRect();
        return r.width > 100 && r.height > 100 && r.bottom > 0 && r.top < innerHeight && e.checkVisibility({ opacityProperty: true, visibilityProperty: true });
      };
      const robot = /punish|captcha|_____tmd_____/i.test(location.href) || [...document.querySelectorAll('iframe[src*="punish"], iframe[src*="captcha"], iframe[src*="_____tmd_____"], .J_MIDDLEWARE_FRAME_WIDGET, .baxia-dialog, #baxia-dialog-content')].some(shown);
      if (robot) return "robot";
      return window.lib?.mtop ? "ready" : "wait";
    }
  }).catch(() => [void 0]);
  return probe?.result ?? "wait";
}
var VERIFY_TEXT = `${ALI_VERIFY}. Fais-la sur AliExpress (lien \u{1F513} ci-dessous, une seule fois), puis relance.`;
var VERIFY_KEY = "aliVerifyUntil";
var VERIFY_PAUSE = 10 * 6e4;
var isAliVerify = (e) => e instanceof Error && (e.message.startsWith(ALI_VERIFY) || e.message.startsWith(ALI_COOKIES) || e.message.startsWith(ALI_REGION));
async function verifyAsked() {
  await chrome.storage.session.set({ [VERIFY_KEY]: Date.now() + VERIFY_PAUSE }).catch(() => {
  });
  apiTrace("supplier", "verify:asked", {});
  throw Error(VERIFY_TEXT);
}
async function showChallenge() {
  const id = (await chrome.storage.session.get(OWN_TAB).catch(() => ({})))[OWN_TAB];
  if (typeof id === "number") {
    await chrome.storage.session.remove(OWN_TAB).catch(() => {
    });
    const tab = await chrome.tabs.update(id, { active: true }).catch(() => void 0);
    if (tab?.windowId !== void 0) await chrome.windows.update(tab.windowId, { focused: true }).catch(() => {
    });
  }
  await chrome.storage.session.set({ [VERIFY_KEY]: Date.now() + VERIFY_PAUSE }).catch(() => {
  });
  apiTrace("supplier", "verify:shown", {});
  throw Error(`${ALI_VERIFY} : l\u2019onglet AliExpress est devant toi, glisse le curseur puis \xAB \u21BB Relancer \xBB.`);
}
var verifyPending = async () => ((await chrome.storage.session.get(VERIFY_KEY).catch(() => ({})))[VERIFY_KEY] ?? 0) > Date.now();
async function closeOwnTab() {
  const id = (await chrome.storage.session.get(OWN_TAB).catch(() => ({})))[OWN_TAB];
  await chrome.storage.session.remove(OWN_TAB).catch(() => {
  });
  if (typeof id === "number") await chrome.tabs.remove(id).catch(() => {
  });
}
async function aliexpressTab() {
  clearTimeout(idleClose);
  const id = (await chrome.storage.session.get(OWN_TAB).catch(() => ({})))[OWN_TAB];
  if (typeof id === "number") {
    const tab2 = await chrome.tabs.get(id).catch(() => void 0);
    if (tab2 && /^https:\/\/www\.aliexpress\.(us|com)\//.test(tab2.url ?? "") && tab2.status === "complete" && await hasMtop(id)) return id;
    await closeOwnTab();
  }
  const tab = await chrome.tabs.create({ url: "https://www.aliexpress.us/", active: false });
  if (tab.id === void 0) throw Error("Impossible d\u2019ouvrir AliExpress.");
  await chrome.storage.session.set({ [OWN_TAB]: tab.id }).catch(() => {
  });
  await chrome.tabs.update(tab.id, { autoDiscardable: false }).catch(() => {
  });
  for (let i = 0; i < 30; i++) {
    await wait3(500);
    const current2 = await chrome.tabs.get(tab.id).catch(() => void 0);
    if (!current2) throw Error("L\u2019onglet AliExpress a \xE9t\xE9 ferm\xE9.");
    const state = /captcha|punish/i.test(current2.url ?? "") ? "robot" : await probeTab(tab.id);
    if (state === "robot") {
      await closeOwnTab();
      return verifyAsked();
    }
    if (/login\./i.test(current2.url ?? "")) {
      await closeOwnTab();
      throw Error("AliExpress demande de te connecter : ouvre AliExpress une fois, puis r\xE9essaie.");
    }
    if (state === "ready") return tab.id;
  }
  await closeOwnTab();
  throw Error("AliExpress ne r\xE9pond pas. Ouvre AliExpress une fois, puis r\xE9essaie.");
}
async function inAliTab(func, args, wait8, tries = 2) {
  for (let attempt = 0; ; attempt++) {
    const tabId = await aliexpressTab();
    try {
      const [r] = await withTimeout(chrome.scripting.executeScript({ target: { tabId }, world: "MAIN", func, args }), wait8);
      if (r && r.result !== void 0 && r.result !== null) return r.result;
      throw Error("Pas de r\xE9ponse de l\u2019onglet AliExpress.");
    } catch (e) {
      apiTrace("supplier", "tab:lost", { attempt, message: e instanceof Error ? e.message : String(e) });
      await closeOwnTab();
      if (attempt + 1 >= tries) throw Error("L\u2019onglet AliExpress n\u2019a pas r\xE9pondu (ferm\xE9 ou recharg\xE9 pendant la recherche). Clique \xAB \u21BB Relancer \xBB.");
    }
  }
}
var SEARCH_WAIT = 6e4;
var GALLERY_WAIT = 25e3;
var releaseAliTab = () => {
  clearTimeout(idleClose);
  idleClose = setTimeout(() => void closeOwnTab(), 2e4);
};
var thumbnail = (url) => /aliexpress-media\.com|alicdn\.com/.test(url) ? url.replace(/(\.(?:jpe?g|png|webp))(_.*)?$/i, "$1_120x120.jpg") : url.replace(/\/s-l\d+(\.\w+)/, "/s-l300$1");
var GRID = 24;
async function pictureGrids(url, crops) {
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 6e3);
    const blob = await fetch(thumbnail(url), { signal: controller.signal }).then((r) => r.ok ? r.blob() : null).finally(() => clearTimeout(timer));
    if (!blob) return null;
    const bitmap = await createImageBitmap(blob);
    const canvas = new OffscreenCanvas(GRID, GRID);
    const ctx = canvas.getContext("2d", { willReadFrequently: true });
    if (!ctx) return null;
    const read2 = () => {
      const { data } = ctx.getImageData(0, 0, GRID, GRID);
      const g = new Float32Array(GRID * GRID);
      for (let i = 0, j = 0; i < data.length; i += 4, j++) g[j] = 0.299 * data[i] + 0.587 * data[i + 1] + 0.114 * data[i + 2];
      return g;
    };
    const grids = [];
    ctx.filter = "blur(1px)";
    for (const crop of crops) {
      const w = bitmap.width * crop, h = bitmap.height * crop;
      ctx.clearRect(0, 0, GRID, GRID);
      ctx.drawImage(bitmap, (bitmap.width - w) / 2, (bitmap.height - h) / 2, w, h, 0, 0, GRID, GRID);
      grids.push(read2());
    }
    const scale = GRID / Math.max(bitmap.width, bitmap.height);
    ctx.fillStyle = "#fff";
    ctx.fillRect(0, 0, GRID, GRID);
    ctx.drawImage(bitmap, (GRID - bitmap.width * scale) / 2, (GRID - bitmap.height * scale) / 2, bitmap.width * scale, bitmap.height * scale);
    grids.push(read2());
    bitmap.close();
    return grids;
  } catch {
    return null;
  }
}
async function parallel(items, size, job) {
  const queue5 = [...items];
  await Promise.all(Array.from({ length: size }, async () => {
    while (queue5.length) await job(queue5.shift());
  }));
}
var cacheKey = (input) => typeof input.itemId === "string" && /^\d{9,15}$/.test(input.itemId) ? `item:${input.itemId}${typeof input.photo === "string" && /^[\w~-]{6,40}$/.test(input.photo) ? `#${input.photo}` : ""}` : `img:${String(input.image ?? input.title ?? "").slice(0, 300)}`;
async function remembered(key4) {
  const cache = (await chrome.storage.local.get(CACHE2))[CACHE2] ?? {};
  const hit = cache[key4];
  return hit && Date.now() - hit.at < CACHE_DAYS * 864e5 ? { ...hit, cached: true } : null;
}
async function remember(key4, result) {
  const cache = (await chrome.storage.local.get(CACHE2))[CACHE2] ?? {};
  cache[key4] = result;
  const kept2 = Object.entries(cache).filter(([, v]) => Date.now() - v.at < CACHE_DAYS * 864e5).sort((a, b) => b[1].at - a[1].at).slice(0, CACHE_MAX);
  await chrome.storage.local.set({ [CACHE2]: Object.fromEntries(kept2) });
}
var busy = Promise.resolve();
async function findSuppliers(input, notify = () => {
}, onStep = () => {
}) {
  if (input.auto && await verifyPending()) {
    const hit = input.fresh === true ? null : await remembered(cacheKey(input));
    if (hit) return hit;
    throw Error(VERIFY_TEXT);
  }
  onStep("En attente de la recherche AliExpress en cours\u2026");
  const previous = busy;
  const real = previous.then(() => search(input, notify, onStep));
  busy = Promise.race([real, delay(6e5)]).catch(() => {
  });
  return previous.then(() => withTimeout(real, 24e4));
}
async function search(input, notify, onStep = () => {
}) {
  const key4 = cacheKey(input);
  if (input.fresh !== true) {
    const hit = await remembered(key4);
    if (hit) return hit;
  }
  const title = typeof input.title === "string" ? input.title.slice(0, 300) : "";
  const image = typeof input.image === "string" && /^https:\/\//.test(input.image) ? input.image : "";
  const words2 = searchKeywords(title);
  if (!image && words2.length < 2) throw Error("Ni photo ni titre utilisable pour chercher sur AliExpress.");
  let found;
  let galleries = {};
  let candidates = [];
  try {
    onStep(image ? "Envoi de la photo \xE0 AliExpress (recherche par image)\u2026" : "Recherche par mots sur AliExpress\u2026", 0, 3);
    found = await inAliTab(supplierSearchInPage, [image, words2], SEARCH_WAIT);
    if (!found.items.length && !found.blocked && (image || words2.length >= 2)) {
      apiTrace("supplier", "empty:retry", { error: found.imageError ?? "" });
      onStep("Aucun r\xE9sultat : nouvel essai dans un onglet AliExpress neuf\u2026", 0, 3);
      await closeOwnTab();
      await delay(1500);
      found = await inAliTab(supplierSearchInPage, [image, words2], SEARCH_WAIT);
    }
    if (image && found.mode !== "image") apiTrace("supplier", "image-search:failed", { error: found.imageError ?? "", blocked: !!found.blocked });
    const wrongRegion = aliRegionText(found.region);
    if (wrongRegion) {
      apiTrace("supplier", "region:wrong", { ...found.region });
      await closeOwnTab();
      throw Error(wrongRegion);
    }
    if (found.cookieFull) {
      apiTrace("supplier", "cookies:too-large", {});
      throw Error(ALI_COOKIES_TEXT);
    }
    if (found.challenge) await showChallenge();
    if (found.blocked) await verifyAsked();
    if (found.items.length) await chrome.storage.session.remove(VERIFY_KEY).catch(() => {
    });
    candidates = parseSearchItems(found.items).filter((c) => c.price !== null);
    notify({
      mode: found.mode,
      words: words2,
      searchUrl: found.mode === "image" ? "https://www.aliexpress.us/" : searchURL(words2),
      compared: candidates.length,
      candidates: found.mode === "image" ? rankCandidates(candidates.slice(0, 12), title, /* @__PURE__ */ new Map()).sort(
        (a, b) => candidates.findIndex((c) => c.id === a.id) - candidates.findIndex((c) => c.id === b.id)
      ) : rankCandidates(candidates, title, /* @__PURE__ */ new Map()).slice(0, 12),
      at: Date.now(),
      checking: true
    });
    onStep(`${candidates.length} produits AliExpress trouv\xE9s \xB7 lecture de leurs galeries photo\u2026`, 1, 3);
    galleries = await inAliTab(galleriesInPage, [candidates.slice(0, GALLERY_CHECK).map((c) => c.id)], GALLERY_WAIT, 1).catch(() => ({}));
  } finally {
    releaseAliTab();
  }
  const photos = /* @__PURE__ */ new Map();
  const match = /* @__PURE__ */ new Map();
  const ebayGrids = image ? await pictureGrids(image, [1, 0.95, 0.9, 0.85, 0.8]) : null;
  if (ebayGrids) {
    const jobs2 = [];
    candidates.forEach((c, rank) => {
      const gallery = rank < GALLERY_CHECK && galleries[c.id]?.length ? galleries[c.id] : c.image ? [c.image] : [];
      gallery.forEach((url, index) => jobs2.push({ id: c.id, url, index, total: gallery.length }));
    });
    let compared = 0;
    onStep(`Comparaison de ta photo avec ${jobs2.length} photos AliExpress\u2026`, 0, jobs2.length);
    const until = Date.now() + 45e3;
    await parallel(jobs2, 10, async (job) => {
      if (Date.now() > until) return;
      const grids = await pictureGrids(job.url, [1, 0.95, 0.9]);
      if (++compared % 10 === 0) onStep(`Comparaison de ta photo avec ${jobs2.length} photos AliExpress\u2026`, compared, jobs2.length);
      if (!grids) return;
      const similarity = bestCorrelation(ebayGrids, grids);
      if (similarity > (photos.get(job.id) ?? -1)) {
        photos.set(job.id, similarity);
        match.set(job.id, { index: job.index + 1, total: job.total });
      }
    });
  }
  const order = new Map(candidates.map((c, i) => [c.id, i]));
  const ranked = rankCandidates(candidates, title, photos).map((c) => {
    const visual = found.mode === "image" ? 1 - (order.get(c.id) ?? 60) / 60 : 0;
    const exact = (c.photo ?? 0) >= SAME_PHOTO ? 1 : 0;
    return {
      ...c,
      photoIndex: match.get(c.id)?.index ?? null,
      photoTotal: match.get(c.id)?.total ?? null,
      score: Math.round((exact * 2 + visual * 0.8 + c.score) * 1e3) / 1e3
    };
  }).sort((a, b) => b.score - a.score).slice(0, 12);
  const result = {
    mode: found.mode,
    words: words2,
    searchUrl: found.mode === "image" ? "https://www.aliexpress.us/" : searchURL(words2),
    compared: candidates.length,
    candidates: ranked,
    at: Date.now()
  };
  if (ranked.length) await remember(key4, result);
  else if (input.fresh === true) {
    const hit = await remembered(key4);
    if (hit) return hit;
  }
  return result;
}

// src/core/address.ts
var US_STATES = {
  AL: "Alabama",
  AK: "Alaska",
  AZ: "Arizona",
  AR: "Arkansas",
  CA: "California",
  CO: "Colorado",
  CT: "Connecticut",
  DE: "Delaware",
  DC: "District of Columbia",
  FL: "Florida",
  GA: "Georgia",
  HI: "Hawaii",
  ID: "Idaho",
  IL: "Illinois",
  IN: "Indiana",
  IA: "Iowa",
  KS: "Kansas",
  KY: "Kentucky",
  LA: "Louisiana",
  ME: "Maine",
  MD: "Maryland",
  MA: "Massachusetts",
  MI: "Michigan",
  MN: "Minnesota",
  MS: "Mississippi",
  MO: "Missouri",
  MT: "Montana",
  NE: "Nebraska",
  NV: "Nevada",
  NH: "New Hampshire",
  NJ: "New Jersey",
  NM: "New Mexico",
  NY: "New York",
  NC: "North Carolina",
  ND: "North Dakota",
  OH: "Ohio",
  OK: "Oklahoma",
  OR: "Oregon",
  PA: "Pennsylvania",
  RI: "Rhode Island",
  SC: "South Carolina",
  SD: "South Dakota",
  TN: "Tennessee",
  TX: "Texas",
  UT: "Utah",
  VT: "Vermont",
  VA: "Virginia",
  WA: "Washington",
  WV: "West Virginia",
  WI: "Wisconsin",
  WY: "Wyoming",
  PR: "Puerto Rico",
  GU: "Guam",
  VI: "Virgin Islands",
  AS: "American Samoa",
  MP: "Northern Mariana Islands",
  AA: "Armed Forces Americas",
  AE: "Armed Forces Europe",
  AP: "Armed Forces Pacific"
};
var AU_STATES = {
  ACT: "Australian Capital Territory",
  NSW: "New South Wales",
  NT: "Northern Territory",
  QLD: "Queensland",
  SA: "South Australia",
  TAS: "Tasmania",
  VIC: "Victoria",
  WA: "Western Australia"
};
var CA_PROVINCES = {
  AB: "Alberta",
  BC: "British Columbia",
  MB: "Manitoba",
  NB: "New Brunswick",
  NL: "Newfoundland and Labrador",
  NS: "Nova Scotia",
  NT: "Northwest Territories",
  NU: "Nunavut",
  ON: "Ontario",
  PE: "Prince Edward Island",
  QC: "Quebec",
  SK: "Saskatchewan",
  YT: "Yukon"
};
var IT_PROVINCES = {
  AG: ["Agrigento", "Sicilia"],
  AL: ["Alessandria", "Piemonte"],
  AN: ["Ancona", "Marche"],
  AO: ["Aosta", "Valle d'Aosta"],
  AR: ["Arezzo", "Toscana"],
  AP: ["Ascoli Piceno", "Marche"],
  AT: ["Asti", "Piemonte"],
  AV: ["Avellino", "Campania"],
  BA: ["Bari", "Puglia"],
  BT: ["Barletta-Andria-Trani", "Puglia"],
  BL: ["Belluno", "Veneto"],
  BN: ["Benevento", "Campania"],
  BG: ["Bergamo", "Lombardia"],
  BI: ["Biella", "Piemonte"],
  BO: ["Bologna", "Emilia-Romagna"],
  BZ: ["Bolzano", "Trentino-Alto Adige"],
  BS: ["Brescia", "Lombardia"],
  BR: ["Brindisi", "Puglia"],
  CA: ["Cagliari", "Sardegna"],
  CL: ["Caltanissetta", "Sicilia"],
  CB: ["Campobasso", "Molise"],
  CE: ["Caserta", "Campania"],
  CT: ["Catania", "Sicilia"],
  CZ: ["Catanzaro", "Calabria"],
  CH: ["Chieti", "Abruzzo"],
  CO: ["Como", "Lombardia"],
  CS: ["Cosenza", "Calabria"],
  CR: ["Cremona", "Lombardia"],
  KR: ["Crotone", "Calabria"],
  CN: ["Cuneo", "Piemonte"],
  EN: ["Enna", "Sicilia"],
  FM: ["Fermo", "Marche"],
  FE: ["Ferrara", "Emilia-Romagna"],
  FI: ["Firenze", "Toscana"],
  FG: ["Foggia", "Puglia"],
  FC: ["Forli-Cesena", "Emilia-Romagna"],
  FR: ["Frosinone", "Lazio"],
  GE: ["Genova", "Liguria"],
  GO: ["Gorizia", "Friuli-Venezia Giulia"],
  GR: ["Grosseto", "Toscana"],
  IM: ["Imperia", "Liguria"],
  IS: ["Isernia", "Molise"],
  SP: ["La Spezia", "Liguria"],
  AQ: ["L'Aquila", "Abruzzo"],
  LT: ["Latina", "Lazio"],
  LE: ["Lecce", "Puglia"],
  LC: ["Lecco", "Lombardia"],
  LI: ["Livorno", "Toscana"],
  LO: ["Lodi", "Lombardia"],
  LU: ["Lucca", "Toscana"],
  MC: ["Macerata", "Marche"],
  MN: ["Mantova", "Lombardia"],
  MS: ["Massa-Carrara", "Toscana"],
  MT: ["Matera", "Basilicata"],
  ME: ["Messina", "Sicilia"],
  MI: ["Milano", "Lombardia"],
  MO: ["Modena", "Emilia-Romagna"],
  MB: ["Monza e Brianza", "Lombardia"],
  NA: ["Napoli", "Campania"],
  NO: ["Novara", "Piemonte"],
  NU: ["Nuoro", "Sardegna"],
  OR: ["Oristano", "Sardegna"],
  PD: ["Padova", "Veneto"],
  PA: ["Palermo", "Sicilia"],
  PR: ["Parma", "Emilia-Romagna"],
  PV: ["Pavia", "Lombardia"],
  PG: ["Perugia", "Umbria"],
  PU: ["Pesaro e Urbino", "Marche"],
  PE: ["Pescara", "Abruzzo"],
  PC: ["Piacenza", "Emilia-Romagna"],
  PI: ["Pisa", "Toscana"],
  PT: ["Pistoia", "Toscana"],
  PN: ["Pordenone", "Friuli-Venezia Giulia"],
  PZ: ["Potenza", "Basilicata"],
  PO: ["Prato", "Toscana"],
  RG: ["Ragusa", "Sicilia"],
  RA: ["Ravenna", "Emilia-Romagna"],
  RC: ["Reggio Calabria", "Calabria"],
  RE: ["Reggio Emilia", "Emilia-Romagna"],
  RI: ["Rieti", "Lazio"],
  RN: ["Rimini", "Emilia-Romagna"],
  RM: ["Roma", "Lazio"],
  RO: ["Rovigo", "Veneto"],
  SA: ["Salerno", "Campania"],
  SS: ["Sassari", "Sardegna"],
  SV: ["Savona", "Liguria"],
  SI: ["Siena", "Toscana"],
  SR: ["Siracusa", "Sicilia"],
  SO: ["Sondrio", "Lombardia"],
  SU: ["Sud Sardegna", "Sardegna"],
  TA: ["Taranto", "Puglia"],
  TE: ["Teramo", "Abruzzo"],
  TR: ["Terni", "Umbria"],
  TO: ["Torino", "Piemonte"],
  TP: ["Trapani", "Sicilia"],
  TN: ["Trento", "Trentino-Alto Adige"],
  TV: ["Treviso", "Veneto"],
  TS: ["Trieste", "Friuli-Venezia Giulia"],
  UD: ["Udine", "Friuli-Venezia Giulia"],
  VA: ["Varese", "Lombardia"],
  VE: ["Venezia", "Veneto"],
  VB: ["Verbano-Cusio-Ossola", "Piemonte"],
  VC: ["Vercelli", "Piemonte"],
  VR: ["Verona", "Veneto"],
  VV: ["Vibo Valentia", "Calabria"],
  VI: ["Vicenza", "Veneto"],
  VT: ["Viterbo", "Lazio"]
};
var IL_DISTRICTS = Object.fromEntries(
  [
    ["Tel Aviv", "tel aviv,tel aviv yafo,tel aviv jaffa,jaffa,yafo,givatayim,givataim,ramat gan,bnei brak,bene beraq,holon,bat yam,herzliya,herzliyya,ramat hasharon,kiryat ono,or yehuda,azor"],
    ["Jerusalem", "jerusalem,yerushalayim,beit shemesh,bet shemesh,mevaseret zion,mevaseret tsiyon,abu ghosh,tzur hadassah"],
    ["Haifa", "haifa,hefa,hadera,kiryat ata,kiryat bialik,kiryat motzkin,kiryat yam,nesher,tirat carmel,tirat karmel,zikhron yaakov,zichron yaakov,or akiva,pardes hanna,pardes hana karkur,binyamina,daliyat al karmel,umm al fahm"],
    ["HaDarom (South)", "beersheba,beer sheva,beer sheba,ashdod,ashkelon,eilat,elat,dimona,sderot,netivot,ofakim,kiryat gat,kiryat malakhi,arad,yeruham,mitzpe ramon,rahat"],
    ["HaMerkaz (Central)", "petah tikva,petach tikva,petah tiqwa,rishon lezion,rishon letsiyon,netanya,rehovot,kfar saba,kefar sava,raanana,modiin,modiin maccabim reut,lod,ramla,rosh haayin,hod hasharon,ness ziona,nes tsiyona,yavne,yavneh,kfar yona,even yehuda,elad,shoham,yehud,gedera,kadima,tayibe,kafr qasim,beer yaakov,gan yavne,mazkeret batya"],
    ["HaZafon (North)", "pekiin,peqiin,nazareth,nazrat,tiberias,tveria,afula,karmiel,nahariya,akko,acre,safed,tzfat,zefat,kiryat shmona,maalot tarshiha,migdal haemek,beit shean,bet shean,yokneam,yokneam illit,nof hagalil,nazareth illit,shfaram,sakhnin,katzrin,qatsrin"],
    ["Judea and Samaria", "ariel,maale adumim,modiin illit,beitar illit,efrat,maale shomron,maale shomeron,karnei shomron,kedumim,immanuel,emmanuel,kiryat arba,elkana,oranit,alfei menashe,givat zeev,beit el,ofra,shilo,maale efrayim"]
  ].flatMap(([district, cities]) => cities.split(",").map((c) => [c.replace(/[^a-z]/g, ""), district]))
);
function translitKey(t) {
  return t.normalize("NFKD").toLowerCase().replace(/\([^)]*\)/g, " ").replace(/[^a-z]/g, "").replace(/ph/g, "f").replace(/ts|tz/g, "z").replace(/ck|[cq]/g, "k").replace(/[vw]/g, "b").replace(/[aeiouyh]/g, "").replace(/(.)\1+/g, "$1");
}
var IL_BY_SOUND = /* @__PURE__ */ new Map();
for (const [city, district] of Object.entries(IL_DISTRICTS)) {
  const k = translitKey(city);
  if (k.length < 3) continue;
  const seen = IL_BY_SOUND.get(k);
  IL_BY_SOUND.set(k, seen === void 0 || seen === district ? district : null);
}
var ilDistrict = (city) => IL_DISTRICTS[city.toLowerCase().replace(/[^a-z]/g, "")] ?? IL_BY_SOUND.get(translitKey(city)) ?? null;
function ilDistrictHint(text3, zip) {
  if (/galil|golan/i.test(text3)) return "HaZafon (North)";
  if (/negev/i.test(text3)) return "HaDarom (South)";
  const z = zip.replace(/\D/g, "");
  if (z.length !== 7 && z.length !== 5) return null;
  const head = Number(z.slice(0, 2));
  if (head >= 10 && head <= 25) return "HaZafon (North)";
  if (head >= 26 && head <= 39) return "Haifa";
  if (head >= 61 && head <= 69) return "Tel Aviv";
  if (head >= 70 && head <= 76) return "HaMerkaz (Central)";
  if (head >= 77 && head <= 79 || z[0] === "8") return "HaDarom (South)";
  if (head >= 90 && head <= 97) return "Jerusalem";
  return null;
}
function noCounty(zip) {
  const z = zip.replace(/\D/g, "");
  if (z.length !== 4) return null;
  const h = Number(z.slice(0, 2));
  if (h <= 12) return "Oslo";
  if (h >= 40 && h <= 43) return "Rogaland";
  if (h >= 46 && h <= 49) return "Agder";
  if (h >= 50 && h <= 54 || h >= 67 && h <= 69) return "Vestland";
  if (h >= 60 && h <= 66) return "More og Romsdal";
  if (h >= 70 && h <= 79) return "Trondelag";
  if (h >= 80 && h <= 89) return "Nordland";
  if (h >= 90 && h <= 94) return "Troms";
  if (h >= 95) return "Finnmark";
  return null;
}
var REGIONS_EN = {
  AT: {
    wien: "Vienna",
    w: "Vienna",
    niederosterreich: "Lower Austria",
    no: "Lower Austria",
    oberosterreich: "Upper Austria",
    oo: "Upper Austria",
    karnten: "Carinthia",
    k: "Carinthia",
    steiermark: "Styria",
    st: "Styria",
    tirol: "Tyrol",
    t: "Tyrol",
    salzburg: "Salzburg",
    s: "Salzburg",
    vorarlberg: "Vorarlberg",
    v: "Vorarlberg",
    burgenland: "Burgenland",
    b: "Burgenland"
  },
  NL: {
    "noord holland": "North Holland",
    nh: "North Holland",
    "zuid holland": "South Holland",
    zh: "South Holland",
    "noord brabant": "North Brabant",
    nb: "North Brabant",
    fryslan: "Friesland",
    friesland: "Friesland",
    gelderland: "Gelderland",
    utrecht: "Utrecht",
    overijssel: "Overijssel",
    limburg: "Limburg",
    groningen: "Groningen",
    drenthe: "Drenthe",
    flevoland: "Flevoland",
    zeeland: "Zeeland"
  }
};
var COUNTRIES = [
  [/^(us|usa|united states( of america)?)$/i, "US", "1", "United States"],
  [/^(ca|canada)$/i, "CA", "1", "Canada"],
  [/^(au|australia)$/i, "AU", "61", "Australia"],
  [/^(gb|uk|united kingdom|great britain|england|scotland|wales)$/i, "GB", "44", "United Kingdom"],
  [/^(fr|france)$/i, "FR", "33", "France"],
  [/^(de|germany|deutschland)$/i, "DE", "49", "Germany"],
  [/^(it|italy|italia)$/i, "IT", "39", "Italy"],
  [/^(es|spain|españa|espana)$/i, "ES", "34", "Spain"],
  [/^(nl|netherlands|the netherlands|holland)$/i, "NL", "31", "Netherlands"],
  [/^(be|belgium)$/i, "BE", "32", "Belgium"],
  [/^(ch|switzerland)$/i, "CH", "41", "Switzerland"],
  [/^(at|austria)$/i, "AT", "43", "Austria"],
  [/^(ie|ireland)$/i, "IE", "353", "Ireland"],
  [/^(nz|new zealand)$/i, "NZ", "64", "New Zealand"],
  [/^(pt|portugal)$/i, "PT", "351", "Portugal"],
  [/^(se|sweden)$/i, "SE", "46", "Sweden"],
  [/^(no|norway)$/i, "NO", "47", "Norway"],
  [/^(dk|denmark)$/i, "DK", "45", "Denmark"],
  [/^(fi|finland)$/i, "FI", "358", "Finland"],
  [/^(pl|poland)$/i, "PL", "48", "Poland"],
  [/^(gr|greece)$/i, "GR", "30", "Greece"],
  [/^(cz|czech republic|czechia)$/i, "CZ", "420", "Czech Republic"],
  [/^(il|israel)$/i, "IL", "972", "Israel"],
  [/^(ae|united arab emirates)$/i, "AE", "971", "United Arab Emirates"],
  [/^(sa|saudi arabia)$/i, "SA", "966", "Saudi Arabia"],
  [/^(za|south africa)$/i, "ZA", "27", "South Africa"],
  [/^(jp|japan)$/i, "JP", "81", "Japan"],
  [/^(kr|south korea|korea|korea, south|republic of korea)$/i, "KR", "82", "Korea"],
  [/^(jo|jordan)$/i, "JO", "962", "Jordan"],
  [/^(co|colombia)$/i, "CO", "57", "Colombia"],
  [/^(pe|peru)$/i, "PE", "51", "Peru"],
  [/^(ph|philippines)$/i, "PH", "63", "Philippines"],
  [/^(my|malaysia)$/i, "MY", "60", "Malaysia"],
  [/^(th|thailand)$/i, "TH", "66", "Thailand"],
  [/^(tr|turkey|turkiye)$/i, "TR", "90", "Turkey"],
  [/^(ar|argentina)$/i, "AR", "54", "Argentina"],
  [/^(cr|costa rica)$/i, "CR", "506", "Costa Rica"],
  [/^(kw|kuwait)$/i, "KW", "965", "Kuwait"],
  [/^(qa|qatar)$/i, "QA", "974", "Qatar"],
  [/^(bh|bahrain)$/i, "BH", "973", "Bahrain"],
  [/^(om|oman)$/i, "OM", "968", "Oman"],
  [/^(ro|romania)$/i, "RO", "40", "Romania"],
  [/^(hu|hungary)$/i, "HU", "36", "Hungary"],
  [/^(cy|cyprus)$/i, "CY", "357", "Cyprus"],
  [/^(mt|malta)$/i, "MT", "356", "Malta"],
  [/^(is|iceland)$/i, "IS", "354", "Iceland"],
  [/^(lu|luxembourg)$/i, "LU", "352", "Luxembourg"],
  [/^(in|india)$/i, "IN", "91", "India"],
  [/^(sg|singapore)$/i, "SG", "65", "Singapore"],
  [/^(hk|hong kong)$/i, "HK", "852", "Hong Kong"],
  [/^(mx|mexico)$/i, "MX", "52", "Mexico"],
  [/^(br|brazil)$/i, "BR", "55", "Brazil"],
  [/^(cl|chile)$/i, "CL", "56", "Chile"],
  [/^(ec|ecuador)$/i, "EC", "593", "Ecuador"],
  [/^(pr|puerto rico)$/i, "PR", "1", "Puerto Rico"]
];
var NORDIC = {
  \u00E6: "ae",
  \u00C6: "Ae",
  \u0153: "oe",
  \u0152: "Oe",
  \u00F8: "o",
  \u00D8: "O",
  \u0111: "d",
  \u0110: "D",
  \u00F0: "d",
  \u00D0: "D",
  \u0142: "l",
  \u0141: "L",
  \u00FE: "th",
  \u00DE: "Th",
  \u0131: "i"
};
var ascii = (s) => s.normalize("NFKD").replace(/[̀-ͯ]/g, "").replace(/[’`´]/g, "'").replace(/[“”]/g, '"').replace(/[–—]/g, "-").replace(/ß/g, "ss").replace(/[æÆœŒøØđĐðÐłŁþÞı]/g, (c) => NORDIC[c] ?? c).replace(/\s+/g, " ").trim();
var latin = (s) => /^[\x20-\x7e]*$/.test(s);
var UNIT = /(?:\b(?:apt|apartment|suite|ste|unit|bldg|building|fl|floor|rm|room|lot|spc|space|trlr)\b\.?|#)\s*#?\s*[\w-]+.*$/i;
function splitStreet(street, max = 35) {
  if (street.length <= max) return [street, ""];
  const cut = street.lastIndexOf(" ", max);
  const at = cut > 4 ? cut : max;
  return [street.slice(0, at).trim(), street.slice(at).trim()];
}
function titleCase(s) {
  return s === s.toUpperCase() || s === s.toLowerCase() ? s.toLowerCase().replace(new RegExp("(^|[\\s'-])\\p{L}", "gu"), (m) => m.toUpperCase()) : s;
}
function countryInfo(text3) {
  const t = ascii(text3);
  const hit = COUNTRIES.find(([re]) => re.test(t));
  return hit ? { code: hit[1], calling: hit[2], label: hit[3] } : { code: "", calling: "", label: t };
}
function checkAddress(input) {
  const changes = [];
  const problems = [];
  const note = (field, before, after) => {
    if (before !== after) changes.push(`${field} : \xAB ${before} \xBB \u2192 \xAB ${after} \xBB`);
  };
  const country = countryInfo(input.country);
  const us = country.code === "US" || country.code === "PR";
  if (!country.code)
    problems.push(`Pays \xAB ${input.country} \xBB : choisis-le dans le menu Pays d\u2019AliExpress si besoin, puis v\xE9rifie chaque champ.`);
  let name = ascii(input.name.replace(/\s*(&|\band\b)\s.*$/i, "")).replace(/[^\p{L}\p{N} .'-]/gu, " ").replace(/\s+/g, " ").trim().replace(/^(mr|mrs|ms|miss|dr)\.?\s+/i, "");
  if (!latin(input.name.replace(/[^\p{L}]/gu, "")) && !latin(name))
    problems.push("Nom en \xE9criture non latine : AliExpress risque de le refuser, saisis-le en lettres latines.");
  const parts = name.split(" ").filter((p) => p && !/\d/.test(p));
  if (parts.join(" ") !== name) name = parts.join(" ");
  note("Nom", input.name, name);
  const firstName = titleCase(parts.length > 1 ? parts.slice(0, -1).join(" ") : parts[0] ?? "");
  const lastName = titleCase(parts.length > 1 ? parts[parts.length - 1] : parts[0] ?? "");
  if (!firstName) problems.push("Nom du client manquant.");
  const raw = input.phone.trim();
  let digits = raw.replace(/\D/g, "");
  const foreign = raw.startsWith("+") && country.calling && !digits.startsWith(country.calling);
  if (raw.startsWith("+") || raw.startsWith("00")) {
    digits = digits.replace(/^00/, "");
    if (country.calling && digits.startsWith(country.calling)) digits = digits.slice(country.calling.length);
  } else if (country.calling && digits.length > 10 && digits.startsWith(country.calling))
    digits = digits.slice(country.calling.length);
  if (country.code !== "IT") digits = digits.replace(/^0+/, "");
  const israelLandline = country.code === "IL" && !!digits && !/^5\d{8}$/.test(digits);
  if (country.code === "IL" && digits) digits = "0" + digits;
  if (country.code === "MX" && digits.length === 11 && digits.startsWith("1")) digits = digits.slice(1);
  if (!raw) problems.push("T\xE9l\xE9phone absent de la commande : AliExpress l\u2019exige.");
  else if (foreign)
    problems.push(`T\xE9l\xE9phone \xAB ${raw} \xBB avec un indicatif d\u2019un autre pays que ${country.label} : v\xE9rifie-le avec le client.`);
  else if (israelLandline)
    problems.push(`T\xE9l\xE9phone \xAB ${raw} \xBB : ce n\u2019est pas un portable. AliExpress exige un portable isra\xE9lien (05\u2026, 10 chiffres) : demande-le au client.`);
  else if (us && digits.length !== 10)
    problems.push(`T\xE9l\xE9phone \xAB ${raw} \xBB : il faut 10 chiffres pour les \xC9tats-Unis.`);
  else if (!us && (digits.length < 6 || digits.length > 12))
    problems.push(`T\xE9l\xE9phone \xAB ${raw} \xBB : longueur inhabituelle, v\xE9rifie-le.`);
  note("T\xE9l\xE9phone", raw, digits);
  let street = ascii(input.street1);
  let apt = ascii(input.street2);
  if (!apt) {
    const unit = street.match(UNIT);
    if (unit && unit.index > 4) {
      apt = unit[0].trim();
      street = street.slice(0, unit.index).replace(/[,\s]+$/, "");
    }
  }
  const [main, overflow] = splitStreet(street);
  if (overflow) {
    street = main;
    apt = [overflow, apt].filter(Boolean).join(" ");
  }
  street = street.replace(/[^\w .,'#/-]/g, " ").replace(/\s+/g, " ").trim();
  apt = apt.replace(/[^\w .,'#/-]/g, " ").replace(/\s+/g, " ").trim();
  const houseNumber = street.match(/\s(\d+[a-z]?(?:[-/]\d+[a-z]?)?)$/i)?.[1] ?? street.match(/^(\d+[a-z]?)\s/i)?.[1] ?? "";
  note("Rue", input.street1, street);
  if ((input.street2 || "") !== apt) note("Compl\xE9ment", input.street2 || "", apt);
  if (street.length < 5) problems.push("Rue trop courte (5 caract\xE8res minimum chez AliExpress).");
  if (!/\d/.test(street + apt) && !/po box/i.test(street))
    problems.push("L\u2019adresse n\u2019a pas de num\xE9ro : v\xE9rifie-la.");
  if (apt.length > 35) problems.push("Compl\xE9ment d\u2019adresse tr\xE8s long : v\xE9rifie-le.");
  const military = us && (/^(AA|AE|AP)$/i.test(input.state.trim()) || /^(APO|FPO|DPO)$/i.test(input.city.trim()));
  const city = military ? ascii(input.city).toUpperCase() : titleCase(ascii(input.city));
  note("Ville", input.city, city);
  if (!city) problems.push("Ville manquante.");
  if (/\d{3}/.test(city)) problems.push(`Ville \xAB ${city} \xBB contient des chiffres : v\xE9rifie-la.`);
  let state = ascii(input.state);
  const table = us ? US_STATES : country.code === "AU" ? AU_STATES : country.code === "CA" ? CA_PROVINCES : null;
  let region = "";
  if (country.code === "IT") {
    const hit = IT_PROVINCES[state.toUpperCase().replace(/\./g, "")] ?? Object.values(IT_PROVINCES).find(([n]) => n.toLowerCase() === state.toLowerCase());
    if (hit) [state, region] = hit;
  }
  const english = REGIONS_EN[country.code]?.[state.toLowerCase().replace(/[^a-z]+/g, " ").trim()];
  if (english) state = english;
  if (table) {
    const code = state.toUpperCase().replace(/\./g, "");
    const full = table[code] ?? Object.values(table).find((s) => s.toLowerCase() === state.toLowerCase());
    if (full) state = full;
    else problems.push(`\xC9tat / r\xE9gion \xAB ${input.state} \xBB non reconnu.`);
  }
  if (country.code === "NO" && !state) {
    const county = noCounty(ascii(input.zip));
    if (county) state = county;
    else problems.push("R\xE9gion norv\xE9gienne (State/Province) \xE0 taper \xE0 la main : eBay ne la donne pas.");
  }
  if (country.code === "IL") {
    const parts2 = `${city}/${state}`.split(/[/,]/).map((x) => x.trim()).filter(Boolean);
    const district = parts2.map(ilDistrict).find(Boolean) ?? ilDistrictHint(parts2.join(" "), ascii(input.zip));
    if (district) state = district;
    else problems.push(`R\xE9gion isra\xE9lienne de \xAB ${city} \xBB inconnue : choisis-la \xE0 la main dans le formulaire AliExpress.`);
  }
  note("\xC9tat / r\xE9gion", input.state, state);
  let zip = ascii(input.zip).toUpperCase();
  if (us) {
    const z = zip.replace(/[^\d]/g, "");
    if (z.length === 9) zip = `${z.slice(0, 5)}-${z.slice(5)}`;
    else if (z.length === 5) zip = z;
    else if (z.length === 4) zip = "0" + z;
    else problems.push(`Code postal \xAB ${input.zip} \xBB invalide (5 chiffres attendus).`);
  } else if (country.code === "CA") {
    const z = zip.replace(/\s/g, "");
    if (/^[A-Z]\d[A-Z]\d[A-Z]\d$/.test(z)) zip = `${z.slice(0, 3)} ${z.slice(3)}`;
    else problems.push(`Code postal canadien \xAB ${input.zip} \xBB invalide.`);
  } else if (country.code === "AU" && !/^\d{4}$/.test(zip))
    problems.push(`Code postal australien \xAB ${input.zip} \xBB invalide (4 chiffres).`);
  else if (!zip) problems.push("Code postal manquant.");
  if (country.code === "IL" && /^\d{5}$/.test(zip.replace(/\s/g, "")))
    problems.push(`Code postal \xAB ${input.zip} \xBB \xE0 5 chiffres (ancien format) : Isra\xEBl utilise 7 chiffres, AliExpress refuse l\u2019ancien. Demande-le au client.`);
  note("Code postal", input.zip, zip);
  const extra = {
    MX: "Mexique : AliExpress demande aussi le RFC/CURP du client (conseill\xE9 pour la douane), \xE0 lui demander si besoin.",
    BR: "Br\xE9sil : AliExpress exige le CPF du client (et parfois sa date de naissance) : \xE0 lui demander.",
    JP: "Japon : AliExpress exige le nom en katakana : \xE0 saisir \xE0 la main.",
    SA: "Arabie saoudite : AliExpress exige la \xAB National address \xBB (code court) du client : \xE0 lui demander.",
    ZA: "Afrique du Sud : AliExpress exige le num\xE9ro d\u2019identit\xE9 sud-africain du client (douane) : \xE0 lui demander, c\u2019est toi qui le saisis.",
    CH: "Suisse : choisis le canton \xE0 la main dans la liste AliExpress (ex. Sierre \u2192 Valais), eBay ne le donne pas. V\xE9rifie aussi que le produit est livrable en Suisse."
  };
  if (extra[country.code]) problems.push(extra[country.code]);
  if (military)
    problems.unshift(
      `Adresse militaire am\xE9ricaine (${city || "APO"}, ${input.state.trim().toUpperCase()}) : AliExpress ne livre pas ces adresses (pas d\u2019\xAB Armed Forces \xBB dans sa liste). Ne passe pas la commande : demande au client une adresse civile aux \xC9tats-Unis, sinon annule la vente.`
    );
  return {
    address: {
      firstName,
      lastName,
      phone: digits,
      street,
      apt,
      houseNumber,
      city,
      state,
      zip,
      country: country.code || input.country,
      countryLabel: country.label,
      calling: country.calling,
      ...region ? { region } : {}
    },
    changes,
    problems
  };
}

// src/background/sales.ts
var KEY2 = "sales:v1";
var CLIPBOARD = "shippingClipboard:v1";
var ORDER_ID = /^\d{2}-\d{5}-\d{5}$/;
async function all() {
  return (await chrome.storage.local.get(KEY2))[KEY2] ?? {};
}
async function write(sales) {
  await chrome.storage.local.set({ [KEY2]: sales });
}
var queue2 = Promise.resolve();
function locked(change) {
  const run6 = queue2.then(change, change);
  queue2 = run6.catch(() => {
  });
  return run6;
}
var saveSale = (...args) => locked(() => saveSaleNow(...args));
var updateSale = (...args) => locked(() => updateSaleNow(...args));
var deleteSale = (...args) => locked(() => deleteSaleNow(...args));
var linkSupplier = (...args) => locked(() => linkSupplierNow(...args));
var unlinkSupplier = (...args) => locked(() => unlinkSupplierNow(...args));
var syncAliOrders = (...args) => locked(() => syncAliOrdersNow(...args));
var noteEbayTracking = (...args) => locked(() => noteEbayTrackingNow(...args));
var noteEbayTrackings = (...args) => locked(() => noteEbayTrackingsNow(...args));
var importSales = (...args) => locked(() => importSalesNow(...args));
var shareSupplier = (...args) => locked(() => shareSupplierNow(...args));
var money = (value) => {
  if (!value || typeof value !== "object") return null;
  const v = value;
  return Number.isFinite(v.amount) && /^[A-Z]{3}$/.test(v.currency) ? { amount: Math.round(v.amount * 100) / 100, currency: v.currency } : null;
};
var text2 = (v, max = 300) => typeof v === "string" ? v.slice(0, max) : "";
function validParsed(value) {
  const s = value;
  if (!s || typeof s !== "object" || !ORDER_ID.test(s.orderId))
    throw Error("Commande eBay invalide.");
  if (!Array.isArray(s.items) || !s.items.length || s.items.length > 50)
    throw Error("Articles de la commande eBay introuvables. Recharge la page.");
  return {
    orderId: s.orderId,
    soldAt: Number.isFinite(s.soldAt) ? s.soldAt : null,
    buyer: text2(s.buyer, 120),
    country: text2(s.country, 80),
    zip: text2(s.zip, 20),
    city: text2(s.city, 100),
    items: s.items.map((i) => ({
      title: text2(i.title, 200),
      itemId: /^\d{9,15}$/.test(i.itemId ?? "") ? i.itemId : null,
      variation: text2(i.variation, 200),
      quantity: Number.isInteger(i.quantity) && i.quantity > 0 ? Math.min(i.quantity, 999) : 1,
      price: money(i.price),
      sku: i.sku ? text2(i.sku, 80) : null,
      supplierId: /^\d{6,20}$/.test(i.supplierId ?? "") ? i.supplierId : null
    })),
    subtotal: money(s.subtotal),
    shipping: money(s.shipping),
    tax: money(s.tax),
    orderTotal: money(s.orderTotal),
    fees: Array.isArray(s.fees) ? s.fees.slice(0, 10).flatMap((f) => {
      const m = money(f?.amount);
      return m ? [{ label: text2(f.label, 60), amount: m }] : [];
    }) : [],
    earnings: money(s.earnings),
    ...money(s.refund) ? { refund: { ...money(s.refund), amount: Math.abs(money(s.refund).amount) } } : {},
    rate: Number.isFinite(s.rate) && s.rate > 0 && s.rate < 10 ? s.rate : null,
    status: ["to_ship", "shipped", "cancelled"].includes(s.status) ? s.status : "to_ship",
    tracking: text2(s.tracking, 200),
    ...Number.isInteger(s.trackedItems) && s.trackedItems >= 0 ? { trackedItems: Math.min(s.trackedItems, 50) } : {}
  };
}
async function saveSaleNow(parsed) {
  const sale = validParsed(parsed);
  const sales = await all();
  const next = mergeSale(sales[sale.orderId], sale);
  sales[sale.orderId] = next;
  await write(sales);
  return next;
}
async function profitModel() {
  const local = await chrome.storage.local.get(["taxRates:v1", PROFIT_SETTINGS_KEY]);
  const taxes = local["taxRates:v1"];
  const settings = { ...DEFAULT_PROFIT_SETTINGS, ...local[PROFIT_SETTINGS_KEY] ?? {} };
  return learnProfitModel(
    Object.values(await all()),
    {
      urssaf: Number.isFinite(taxes?.urssaf) ? taxes.urssaf : 12.3,
      impot: Number.isFinite(taxes?.impot) ? taxes.impot : 1
    },
    settings
  );
}
async function listSales() {
  return Object.values(await all()).sort((a, b) => (b.soldAt ?? 0) - (a.soldAt ?? 0));
}
async function salesStatus(ids) {
  if (!Array.isArray(ids)) return {};
  const sales = await all();
  const fallback = latestRate(Object.values(sales));
  return Object.fromEntries(
    ids.filter((id) => typeof id === "string" && ORDER_ID.test(id)).slice(0, 300).map((id) => {
      const s = sales[id];
      return [
        id,
        s ? {
          saved: true,
          supplierOrderId: s.supplier?.orderId ?? null,
          supplierOrderIds: purchases(s).map((p) => p.orderId),
          // Every AliExpress tracking number of the sale (multi-item orders).
          supplierTrackings: purchases(s).filter((p) => p.tracking).map((p) => ({ tracking: p.tracking, carrier: p.carrier ?? "" })),
          itemIds: s.items.map((i) => i.itemId).filter(Boolean),
          // First AliExpress parcel whose tracking is not on eBay yet.
          supplierTracking: purchases(s).find((p) => p.tracking && p.tracking !== s.tracking)?.tracking ?? s.supplier?.tracking ?? null,
          supplierCarrier: purchases(s).find((p) => p.tracking && p.tracking !== s.tracking)?.carrier ?? s.supplier?.carrier ?? null,
          ebayTracking: s.tracking || null,
          // Every AliExpress number still to give to eBay (split orders).
          pendingTrackings: (trackingCovered(s) ? [] : purchases(s)).filter(
            (p) => p.tracking && (!(s.tracking ?? "").includes(p.tracking) || // Several items, some still without tracking on eBay.
            s.items.length > 1 && s.trackedItems !== void 0 && s.trackedItems > 0 && s.trackedItems < s.items.length)
          ).map((p) => ({ tracking: p.tracking, carrier: p.carrier ?? "" })),
          profit: saleNumbers(s, fallback).profit,
          currency: saleNumbers(s, fallback).currency
        } : { saved: false }
      ];
    })
  );
}
var amount = (v, min, max) => typeof v === "number" && Number.isFinite(v) && v >= min && v <= max ? Math.round(v * 1e5) / 1e5 : void 0;
function validAdjust(value) {
  if (!value || typeof value !== "object") return void 0;
  const v = value;
  const out = {};
  const revenue = amount(v.revenue, 0, 1e6);
  const fees = amount(v.fees, 0, 1e6);
  const earnings = amount(v.earnings, -1e6, 1e6);
  const rate = amount(v.rate, 0.01, 10);
  const cost = money(v.supplierCost);
  if (revenue !== void 0) out.revenue = Math.round(revenue * 100) / 100;
  if (fees !== void 0) out.fees = Math.round(fees * 100) / 100;
  if (earnings !== void 0) out.earnings = Math.round(earnings * 100) / 100;
  if (rate !== void 0) out.rate = rate;
  if (cost && cost.amount >= 0) out.supplierCost = cost;
  return Object.keys(out).length ? out : void 0;
}
async function updateSaleNow(orderId, patch) {
  const sales = await all();
  const sale = typeof orderId === "string" ? sales[orderId] : void 0;
  if (!sale) throw Error("Vente introuvable.");
  if ("manualCost" in patch) sale.manualCost = patch.manualCost === null ? null : money(patch.manualCost);
  if (Number.isFinite(patch.otherCost)) sale.otherCost = Math.round(patch.otherCost * 100) / 100;
  if (typeof patch.notes === "string") sale.notes = patch.notes.slice(0, 1e3);
  if (patch.status && ["to_ship", "shipped", "cancelled"].includes(patch.status)) sale.status = patch.status;
  if (typeof patch.tracking === "string") sale.tracking = patch.tracking.slice(0, 200);
  if (patch.unlinkSupplier) {
    const gone = purchases(sale).map((p) => p.orderId);
    sale.supplier = null;
    delete sale.extraSuppliers;
    for (const id of gone) reshare(sales, id);
  }
  if (Array.isArray(patch.unlinkPurchases)) {
    for (const id of patch.unlinkPurchases)
      if (typeof id === "string" && removePurchase(sale, id)) reshare(sales, id);
  }
  if ("adjust" in patch) {
    const adjust = validAdjust(patch.adjust);
    if (adjust) sale.adjust = adjust;
    else delete sale.adjust;
  }
  sale.updatedAt = Date.now();
  await write(sales);
  return sale;
}
async function deleteSaleNow(orderId) {
  const sales = await all();
  if (typeof orderId !== "string" || !sales[orderId]) throw Error("Vente introuvable.");
  const gone = purchases(sales[orderId]).map((p) => p.orderId);
  delete sales[orderId];
  for (const id of gone) reshare(sales, id);
  await write(sales);
  return true;
}
function removePurchase(sale, aliOrderId) {
  const all3 = purchases(sale);
  const found = all3.find((p) => p.orderId === aliOrderId) ?? null;
  if (!found) return null;
  const rest = all3.filter((p) => p !== found);
  sale.supplier = rest[0] ?? null;
  if (rest.length > 1) sale.extraSuppliers = rest.slice(1);
  else delete sale.extraSuppliers;
  sale.updatedAt = Date.now();
  return found;
}
var ownerOf = (sales, aliOrderId) => Object.values(sales).find((s) => purchases(s).some((p) => p.orderId === aliOrderId));
var owners = (sales, aliOrderId) => Object.values(sales).filter((s) => purchases(s).some((p) => p.orderId === aliOrderId));
function reshare(sales, aliOrderId) {
  const left = owners(sales, aliOrderId);
  const first2 = left.map((s) => purchases(s).find((p) => p.orderId === aliOrderId)).find((p) => p.share);
  if (!first2?.share) return;
  const total2 = first2.share.total;
  const ids = left.map((s) => s.orderId);
  const parts = splitCost(total2, left.map(saleValue));
  left.forEach((s, i) => {
    const p = purchases(s).find((x) => x.orderId === aliOrderId);
    p.cost = parts[i];
    if (ids.length > 1) p.share = { total: total2, sales: ids };
    else delete p.share;
    s.updatedAt = Date.now();
  });
}
async function shareSupplierNow(saleIds, purchase) {
  const sales = await all();
  const ids = [...new Set(Array.isArray(saleIds) ? saleIds.filter((x) => typeof x === "string") : [])];
  if (ids.length < 2) throw Error("Choisis au moins 2 ventes eBay.");
  if (ids.length > 6) throw Error("6 ventes eBay au maximum pour une commande AliExpress.");
  const targets2 = ids.map((id) => sales[id]);
  if (targets2.some((s) => !s)) throw Error("Vente eBay introuvable dans AurOEBay.");
  const supplierOrderId = typeof purchase?.orderId === "string" ? purchase.orderId : "";
  const total2 = money(purchase?.cost);
  if (!/^\d{8,25}$/.test(supplierOrderId) || !total2 || total2.amount <= 0)
    throw Error("Commande AliExpress illisible (num\xE9ro ou total).");
  let previous = null;
  for (const owner of owners(sales, supplierOrderId)) previous = removePurchase(owner, supplierOrderId) ?? previous;
  for (const s of targets2)
    if (purchases(s).length >= 10) throw Error(`La vente ${s.orderId} a d\xE9j\xE0 10 commandes AliExpress.`);
  const tracking = text2(purchase.tracking, 60).trim() || previous?.tracking;
  const carrier = text2(purchase.carrier, 60).trim() || previous?.carrier;
  const parts = splitCost(total2, targets2.map(saleValue));
  targets2.forEach((s, i) => {
    const list2 = [
      ...purchases(s),
      {
        orderId: supplierOrderId,
        cost: parts[i],
        status: text2(purchase.status, 40) || previous?.status || void 0,
        ...tracking ? { tracking } : {},
        ...carrier ? { carrier } : {},
        how: "manual",
        linkedAt: Date.now(),
        share: { total: total2, sales: ids }
      }
    ];
    s.supplier = list2[0];
    if (list2.length > 1) s.extraSuppliers = list2.slice(1);
    else delete s.extraSuppliers;
    s.updatedAt = Date.now();
  });
  await write(sales);
  return targets2;
}
async function linkSupplierNow(orderId, purchase) {
  const sales = await all();
  const sale = typeof orderId === "string" ? sales[orderId] : void 0;
  const supplierOrderId = typeof purchase?.orderId === "string" ? purchase.orderId : "";
  const cost = money(purchase?.cost);
  if (!sale) throw Error("Vente eBay introuvable dans AurOEBay.");
  if (!/^\d{8,25}$/.test(supplierOrderId) || !cost || cost.amount <= 0)
    throw Error("Commande AliExpress illisible (num\xE9ro ou total).");
  let previous = purchases(sale).find((p) => p.orderId === supplierOrderId) ?? null;
  const others = owners(sales, supplierOrderId).filter((s) => s.orderId !== sale.orderId);
  if (others.length) {
    if (purchase.move !== true)
      throw Error(`Cette commande AliExpress est d\xE9j\xE0 li\xE9e \xE0 la vente ${others.map((s) => s.orderId).join(", ")}.`);
    for (const owner of others) previous = removePurchase(owner, supplierOrderId) ?? previous;
  }
  const tracking = text2(purchase.tracking, 60).trim() || previous?.tracking;
  const carrier = text2(purchase.carrier, 60).trim() || previous?.carrier;
  const next = {
    orderId: supplierOrderId,
    cost,
    status: text2(purchase.status, 40) || previous?.status || void 0,
    ...tracking ? { tracking } : {},
    ...carrier ? { carrier } : {},
    how: "manual",
    linkedAt: Date.now()
  };
  const list2 = purchases(sale);
  const at = list2.findIndex((p) => p.orderId === supplierOrderId);
  if (at >= 0) list2[at] = next;
  else if (purchase.add === true) {
    if (list2.length >= 10) throw Error("10 commandes AliExpress au maximum par vente.");
    list2.push(next);
  } else list2.splice(0, list2.length, next);
  sale.supplier = list2[0] ?? null;
  if (list2.length > 1) sale.extraSuppliers = list2.slice(1);
  else delete sale.extraSuppliers;
  sale.updatedAt = Date.now();
  await write(sales);
  return sale;
}
async function supplierState(aliOrderId) {
  if (typeof aliOrderId !== "string" || !/^\d{8,25}$/.test(aliOrderId)) return null;
  const sale = ownerOf(await all(), aliOrderId);
  if (!sale) return null;
  const supplier = purchases(sale).find((p) => p.orderId === aliOrderId);
  const sales = await all();
  const shared = supplier.share ? owners(sales, aliOrderId).map((s) => ({
    ...candidate(s),
    cost: purchases(s).find((p) => p.orderId === aliOrderId).cost
  })) : void 0;
  return { ...candidate(sale), supplier, purchases: purchases(sale), how: supplier.how ?? "manual", ...shared ? { shared } : {} };
}
async function unlinkSupplierNow(aliOrderId) {
  const sales = await all();
  if (typeof aliOrderId !== "string") return false;
  const holders = owners(sales, aliOrderId);
  if (!holders.length) return false;
  for (const sale of holders) removePurchase(sale, aliOrderId);
  await write(sales);
  return true;
}
async function syncAliOrdersNow(rows) {
  if (!Array.isArray(rows)) return {};
  const sales = await all();
  const list2 = Object.values(sales);
  const bySupplier = new Map(list2.flatMap((s) => purchases(s).map((p) => [p.orderId, s])));
  const holders = (id) => list2.filter((s) => purchases(s).some((p) => p.orderId === id));
  let changed = false;
  const result = {};
  for (const raw of rows.slice(0, 100)) {
    const id = typeof raw?.orderId === "string" && /^\d{8,25}$/.test(raw.orderId) ? raw.orderId : "";
    if (!id) continue;
    const tracking = text2(raw.tracking, 60).trim();
    const carrier = text2(raw.carrier, 60).trim();
    let sale = bySupplier.get(id);
    if (!sale && raw.receiver && raw.cost) {
      const cost = money(raw.cost);
      const items = Array.isArray(raw.itemIds) ? raw.itemIds.filter((x) => typeof x === "string") : [];
      const scored = list2.filter((s) => !s.supplier && s.status !== "cancelled").map((s) => ({
        s,
        score: receiverScore(s, raw.receiver) + (s.items.some((i) => i.supplierId && items.includes(i.supplierId)) ? 1 : 0)
      })).filter((x) => x.score >= 2).sort((a, b) => b.score - a.score);
      const best = scored[0];
      const unique2 = best && (!scored[1] || scored[1].score < best.score);
      if (best && unique2 && best.score >= 4 && cost && cost.amount > 0) {
        best.s.supplier = {
          orderId: id,
          cost,
          status: text2(raw.status, 40) || void 0,
          tracking: tracking || void 0,
          carrier: carrier || void 0,
          how: "auto",
          linkedAt: Date.now()
        };
        best.s.updatedAt = Date.now();
        bySupplier.set(id, best.s);
        sale = best.s;
        changed = true;
        result[id] = { saleId: sale.orderId, auto: true, tracking: tracking || void 0 };
        continue;
      }
      result[id] = { saleId: null, suggestion: best?.s.orderId ?? null };
      continue;
    }
    if (!sale) {
      result[id] = { saleId: null, suggestion: null };
      continue;
    }
    const status = text2(raw.status, 40);
    const group = holders(id);
    for (const s of group) {
      const sup2 = purchases(s).find((p) => p.orderId === id);
      if (status && status !== sup2.status) {
        sup2.status = status;
        changed = true;
      }
      if (tracking && tracking !== sup2.tracking) {
        sup2.tracking = tracking;
        sup2.carrier = carrier || sup2.carrier;
        s.updatedAt = Date.now();
        changed = true;
      }
    }
    const sup = purchases(sale).find((p) => p.orderId === id);
    result[id] = { saleId: sale.orderId, tracking: sup.tracking, ...group.length > 1 ? { saleIds: group.map((s) => s.orderId) } : {} };
  }
  if (changed) await write(sales);
  return result;
}
var candidate = (s) => ({
  orderId: s.orderId,
  soldAt: s.soldAt,
  firstName: s.buyer.split(" ")[0] ?? "",
  country: s.country,
  items: s.items.map((i) => ({
    title: i.title.slice(0, 80),
    variation: i.variation.slice(0, 80),
    quantity: i.quantity,
    supplierId: i.supplierId
  }))
});
async function linkCandidates(receiver, includeLinked = false) {
  const r = receiver && typeof receiver === "object" ? {
    name: text2(receiver.name, 120),
    zip: text2(receiver.zip, 20),
    country: text2(receiver.country, 5)
  } : null;
  return (await listSales()).filter((s) => s.status !== "cancelled" && (includeLinked ? !!s.supplier : !s.supplier)).slice(0, 150).map((s) => ({
    ...candidate(s),
    ...r ? { score: receiverScore(s, r) } : {},
    ...includeLinked ? { linkedOrders: purchases(s).map((p) => p.orderId) } : {}
  }));
}
async function copyAddress(orderId, address) {
  const a = address;
  if (typeof orderId !== "string" || !ORDER_ID.test(orderId) || !a || typeof a !== "object")
    throw Error("Adresse de la commande illisible.");
  const clean = {
    name: text2(a.name, 120),
    street1: text2(a.street1, 200),
    street2: text2(a.street2, 200),
    city: text2(a.city, 100),
    state: text2(a.state, 100),
    zip: text2(a.zip, 20),
    country: text2(a.country, 80),
    phone: text2(a.phone, 40)
  };
  const check = checkAddress(clean);
  await chrome.storage.local.set({
    [CLIPBOARD]: { orderId, address: clean, at: Date.now() }
  });
  return { orderId, problems: check.problems, changes: check.changes.length };
}
async function pasteAddress() {
  const stored = (await chrome.storage.local.get(CLIPBOARD))[CLIPBOARD];
  if (!stored || Date.now() - stored.at > 24 * 3600 * 1e3) {
    if (stored) await chrome.storage.local.remove(CLIPBOARD);
    return null;
  }
  return { orderId: stored.orderId, ...checkAddress(stored.address) };
}
async function noteEbayTrackingNow(orderId, tracking) {
  const sales = await all();
  const sale = typeof orderId === "string" ? sales[orderId] : void 0;
  const number2 = text2(tracking, 60).trim();
  if (!sale || !/^[A-Z0-9-]{8,40}$/i.test(number2)) return false;
  const known = sale.tracking ? sale.tracking.split(/\s*,\s*/) : [];
  if (!known.includes(number2)) sale.tracking = [...known, number2].join(", ").slice(0, 200);
  if (sale.status === "to_ship") sale.status = "shipped";
  sale.updatedAt = Date.now();
  await write(sales);
  return true;
}
async function noteEbayTrackingsNow(rows) {
  if (!Array.isArray(rows)) return 0;
  const sales = await all();
  let changed = 0;
  for (const row of rows.slice(0, 200)) {
    const sale = typeof row?.orderId === "string" ? sales[row.orderId] : void 0;
    if (!sale || !Array.isArray(row.trackings)) continue;
    const numbers = row.trackings.map((t) => text2(t, 60).trim()).filter((t) => /^[A-Z0-9-]{8,40}$/i.test(t));
    if (!numbers.length) continue;
    const before = sale.tracking ?? "";
    const known = [
      ...new Set(
        before.split(/\s*,\s*/).map((t) => t.replace(/(Edit|Quantity|Tracking|Carrier|Shipped).*$/i, "")).filter(Boolean)
      )
    ];
    const missing = numbers.filter((n) => !known.includes(n));
    const tracked = sale.items.length > 1 && Number.isInteger(row.trackedItems) && row.trackedItems > (sale.trackedItems ?? -1) ? Math.min(row.trackedItems, 50) : void 0;
    if (tracked !== void 0) sale.trackedItems = tracked;
    if (!missing.length && sale.status !== "to_ship" && known.join(", ") === before && tracked === void 0) continue;
    sale.tracking = [...known, ...missing].join(", ").slice(0, 200);
    if (sale.status === "to_ship") sale.status = "shipped";
    sale.updatedAt = Date.now();
    changed++;
  }
  if (changed) await write(sales);
  return changed;
}
var validRefunds = (v) => Array.isArray(v) ? v.slice(0, 10).flatMap((r) => {
  const amount2 = money(r?.amount);
  const id = r?.aliOrderId;
  return amount2 && amount2.amount > 0 && typeof id === "string" && /^\d{8,25}$/.test(id) ? [{ aliOrderId: id, amount: amount2 }] : [];
}) : [];
async function noteSupplierRefundsNow(refunds) {
  const sales = await all();
  let changed = 0;
  for (const sale of Object.values(sales)) {
    const next = (sale.supplierRefunds ?? []).filter((r) => !refunds[r.aliOrderId]);
    for (const p of purchases(sale)) {
      const r = refunds[p.orderId];
      if (!r) continue;
      const part = p.share && p.share.total.amount > 0 && p.share.total.currency === p.cost.currency ? p.cost.amount / p.share.total.amount : 1;
      next.push({ aliOrderId: p.orderId, amount: { amount: Math.round(r.amount * part * 100) / 100, currency: r.currency } });
    }
    const before = JSON.stringify(sale.supplierRefunds ?? []);
    if (JSON.stringify(next) === before) continue;
    if (next.length) sale.supplierRefunds = next;
    else delete sale.supplierRefunds;
    sale.updatedAt = Date.now();
    changed++;
  }
  if (changed) await write(sales);
  return changed;
}
var noteSupplierRefunds = (...args) => locked(() => noteSupplierRefundsNow(...args));
async function importSalesNow(value) {
  if (!value || typeof value !== "object") return 0;
  const sales = await all();
  let added = 0;
  const purchase = (v) => {
    const p = v;
    const cost = money(p?.cost);
    if (!p || typeof p.orderId !== "string" || !/^\d{8,25}$/.test(p.orderId) || !cost) return null;
    return {
      orderId: p.orderId,
      cost,
      ...text2(p.status, 40) ? { status: text2(p.status, 40) } : {},
      ...text2(p.tracking, 60) ? { tracking: text2(p.tracking, 60) } : {},
      ...text2(p.carrier, 60) ? { carrier: text2(p.carrier, 60) } : {},
      ...p.how === "auto" || p.how === "manual" ? { how: p.how } : {},
      linkedAt: Number.isFinite(p.linkedAt) ? p.linkedAt : Date.now()
    };
  };
  for (const raw of Object.values(value).slice(0, 5e3)) {
    try {
      const s = raw;
      if (!s || typeof s.orderId !== "string" || sales[s.orderId]) continue;
      const base = validParsed(s);
      const extra = Array.isArray(s.extraSuppliers) ? s.extraSuppliers.map(purchase).filter((p) => !!p).slice(0, 9) : [];
      sales[base.orderId] = {
        ...mergeSale(void 0, base, Number.isFinite(s.savedAt) ? s.savedAt : Date.now()),
        supplier: purchase(s.supplier),
        ...extra.length ? { extraSuppliers: extra } : {},
        manualCost: money(s.manualCost),
        ...validAdjust(s.adjust) ? { adjust: validAdjust(s.adjust) } : {},
        ...validRefunds(s.supplierRefunds).length ? { supplierRefunds: validRefunds(s.supplierRefunds) } : {},
        otherCost: Number.isFinite(s.otherCost) ? Math.round(s.otherCost * 100) / 100 : 0,
        notes: text2(s.notes, 1e3)
      };
      added++;
    } catch {
    }
  }
  if (added) await write(sales);
  return added;
}

// src/background/scout.ts
var SCOUT_KEY = "productScout:v1";
var DAY4 = 864e5;
var current = null;
async function report(state) {
  current = state;
  state.beat = Date.now();
  await chrome.storage.local.set({ [SCOUT_KEY]: state }).catch(() => {
  });
}
async function recoverScout() {
  const saved = (await chrome.storage.local.get(SCOUT_KEY))[SCOUT_KEY];
  if (saved?.state === "running" && !running2) {
    saved.state = "stopped";
    delete saved.task;
    saved.step = "Recherche interrompue (extension recharg\xE9e ou mise en veille). Relance-la.";
    await chrome.storage.local.set({ [SCOUT_KEY]: saved }).catch(() => {
    });
  }
}
var running2 = null;
var stopRequested = false;
var scoutRunning = () => !!running2;
function stopScout() {
  stopRequested = true;
  return !!running2;
}
function track(job) {
  stopRequested = false;
  aliPaused = false;
  aliPausedWhy = "";
  current = null;
  const beat = setInterval(() => {
    if (current?.state === "running") void report(current);
  }, 6e4);
  running2 = job().finally(() => {
    clearInterval(beat);
    running2 = null;
  });
  return running2;
}
function runScout(input) {
  if (running2) throw Error("Une recherche de produits est d\xE9j\xE0 en cours.");
  return track(() => manual(input));
}
function runAutopilot(input) {
  if (running2) throw Error("Une recherche de produits est d\xE9j\xE0 en cours.");
  return track(() => autopilot(input));
}
async function parallel2(items, size, job) {
  let next = 0;
  await Promise.all(
    Array.from({ length: size }, async () => {
      while (next < items.length) {
        const i = next++;
        await job(items[i], i);
      }
    })
  );
}
var clamp = (v, min, max, fallback) => {
  const n = Number(v);
  return Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : fallback;
};
async function sellerCountries(sellers, tab, onProgress) {
  const out = /* @__PURE__ */ new Map();
  const s = await getSettings();
  const todo = [];
  const known = await getSellerCaches(sellers.map((seller) => `profile|${seller.toLowerCase()}`), s.sellerTtlDays);
  for (const seller of sellers) {
    const cached = known.get(`profile|${seller.toLowerCase()}`);
    if (cached && cached.status !== "UNKNOWN") out.set(seller, { status: cached.status, country: cached.country });
    else todo.push(seller);
  }
  let blocked = 0;
  for (let i = 0; i < todo.length && !stopRequested; i += 12) {
    const part = todo.slice(i, i + 12);
    const [r] = await withTimeout(chrome.scripting.executeScript({ target: { tabId: tab.tabId }, func: profileSnippetsInPage, args: [part] }), 12e4).catch(() => [void 0]);
    const pages = r?.result ?? {};
    for (const seller of part) {
      const page = pages[seller];
      if (page?.html === "captcha") blocked++;
      const info = page && page.html !== "captcha" ? parseFeedbackCountry(page.html, seller, page.url) : null;
      out.set(seller, { status: info?.status ?? "UNKNOWN", country: info?.country ?? null });
      if (info && info.status !== "UNKNOWN") await putSellerCache(info, `profile|${seller.toLowerCase()}`);
    }
    await onProgress(out.size);
  }
  if (blocked >= 5 && blocked >= todo.length / 2)
    throw Error("eBay demande une v\xE9rification anti-robot sur les profils vendeurs : ouvre un profil vendeur eBay une fois, valide-la, puis relance.");
  return out;
}
async function scanNiche(query, opts, tab, model, progress2) {
  const words2 = searchKeywords(query, 8);
  if (!words2.length) throw Error("\xC9cris quelques mots de la niche (ex. \xAB anime plush keychain \xBB).");
  const seen = /* @__PURE__ */ new Set();
  const cards = [];
  for (let page = 1; page <= opts.pages && !stopRequested; page++) {
    await progress2(`Lecture des annonces eBay en stock (page ${page}/${opts.pages})\u2026`, page - 1, opts.pages);
    const [r] = await withTimeout(
      chrome.scripting.executeScript({
        target: { tabId: tab.tabId },
        func: searchCardsInPage,
        args: [`${activeSearchURL(words2)}&_pgn=${page}`]
      }),
      9e4
    ).catch(() => [void 0]);
    const list2 = (r?.result ?? []).filter((c) => c.image && !seen.has(c.itemId));
    list2.forEach((c) => seen.add(c.itemId));
    cards.push(...list2);
    if (list2.length < 200) break;
  }
  if (!cards.length) throw Error("eBay n\u2019a renvoy\xE9 aucune annonce (v\xE9rification anti-robot ?). Ouvre eBay une fois puis r\xE9essaie.");
  const grids = new Array(cards.length).fill(null);
  let done = 0;
  await parallel2(cards, 10, async (c, i) => {
    grids[i] = await pictureGrids(c.image, [1, 0.9]);
    if (++done % 40 === 0) await progress2(`Comparaison des photos de ${cards.length} annonces\u2026`, done, cards.length);
  });
  const groups = groupByPhoto(cards, grids).filter((g) => g.sellers >= opts.minNonUS).sort((a, b) => b.sellers - a.sellers).slice(0, 40);
  const sellers = [...new Set(groups.flatMap((g) => g.cards.map((c) => c.seller).filter((x) => !!x)))].slice(0, 160);
  done = 0;
  await progress2(`Pays des ${sellers.length} vendeurs (dropshippers hors US ?)\u2026`, 0, sellers.length);
  const countries = stopRequested ? /* @__PURE__ */ new Map() : await sellerCountries(sellers, tab, (n2) => progress2(`Pays des ${sellers.length} vendeurs (dropshippers hors US ?)\u2026`, n2, sellers.length));
  const ranked = rankDropship(groups, (seller) => countries.get(seller), opts.minNonUS).slice(0, 15);
  const proven = ranked.length;
  let products = ranked.map((g) => product(g, null, model, countries));
  if (opts.keep) products = products.filter(opts.keep);
  const ids = products.flatMap((p) => p.listings.slice(0, 5).map((l) => l.itemId));
  if (ids.length && !stopRequested) {
    await progress2("Ventes des 7 et 30 derniers jours de chaque annonce\u2026", 0, 1);
    const [r] = await withTimeout(chrome.scripting.executeScript({ target: { tabId: tab.tabId }, func: purchaseRowsInPage, args: [ids] }), 18e4).catch(() => [void 0]);
    const rows = r?.result ?? {};
    products = products.map((p) => withRecentSales(p, rows));
    products.sort((a, b) => b.nonUS - a.nonUS || (b.d7 ?? -1) - (a.d7 ?? -1) || (b.d30 ?? -1) - (a.d30 ?? -1) || b.soldShown - a.soldShown);
  }
  if (opts.keepAfterSales) products = products.filter(opts.keepAfterSales);
  const n = Math.min(opts.suppliers, products.length);
  for (let i = 0; i < n && !stopRequested && !aliPaused; i++) {
    await progress2("Recherche des fournisseurs AliExpress par photo\u2026", i, n);
    products[i] = await supplierFor(products[i], model, false);
  }
  apiTrace("scout", "niche", { query, read: cards.length, groups: groups.length, sellers: sellers.length, proven: products.length });
  return { read: cards.length, products, proven };
}
function withRecentSales(p, rows, now = Date.now()) {
  const units = (list2, days) => list2.filter((x) => {
    const at = purchaseDate(x.date);
    return at !== null && now - at <= days * DAY4;
  }).reduce((n, x) => n + x.quantity, 0);
  const listings = p.listings.map((l) => {
    const list2 = rows[l.itemId];
    if (!list2) return l;
    const dates = list2.map((x) => purchaseDate(x.date)).filter((t) => t !== null);
    const capped = list2.length >= 100 && dates.length > 0 && now - Math.min(...dates) < 30 * DAY4;
    return { ...l, d7: units(list2, 7), d30: units(list2, 30), ...capped ? { capped } : {} };
  });
  const read2 = listings.filter((l) => l.d30 !== null);
  listings.sort((a, b) => (b.d7 ?? -1) - (a.d7 ?? -1) || (b.d30 ?? -1) - (a.d30 ?? -1) || (b.sold ?? 0) - (a.sold ?? 0));
  return {
    ...p,
    listings,
    itemId: listings[0]?.itemId ?? p.itemId,
    d7: read2.length ? read2.reduce((n, l) => n + (l.d7 ?? 0), 0) : null,
    d30: read2.length ? read2.reduce((n, l) => n + (l.d30 ?? 0), 0) : null,
    ...listings.some((l) => l.capped) ? { capped: true } : {}
  };
}
function photosToTry(p, max = 3) {
  const big = (url) => url.replace(/\/s-l\d+(\.\w+)/, "/s-l500$1");
  const others = p.listings.filter((l) => l.status === "NON_US").concat(p.listings.filter((l) => l.status !== "NON_US"));
  return [...new Set([p.image, ...others.map((l) => l.image ?? "")].filter((u) => /^https:\/\//.test(u)).map(big))].slice(0, max);
}
function mergeSuppliers(lists) {
  const byUrl = /* @__PURE__ */ new Map();
  for (const list2 of lists)
    for (const c of list2) {
      if (!c.price || c.currency !== "USD" && c.currency !== null || (c.photo ?? 0) < SAME_PHOTO) continue;
      const had = byUrl.get(c.url);
      if (!had || (c.photo ?? 0) > (had.photo ?? 0)) byUrl.set(c.url, c);
    }
  return [...byUrl.values()].sort((a, b) => a.price - b.price || (b.photo ?? 0) - (a.photo ?? 0));
}
var aliPaused = false;
var aliPausedWhy = "";
var ALI_PAUSED_NOTE_VERIFY = " \u26A0 AliExpress a demand\xE9 une v\xE9rification : fournisseurs pas cherch\xE9s pour la suite. Fais-la (lien \u{1F513} ci-dessous), puis \xAB \u{1F4F8} Chercher les fournisseurs par photo \xBB.";
var aliPausedNote = () => aliPausedWhy.startsWith(ALI_COOKIES) || aliPausedWhy.startsWith(ALI_REGION) ? ` \u26A0 Fournisseurs pas cherch\xE9s pour la suite. ${aliPausedWhy}` : ALI_PAUSED_NOTE_VERIFY;
async function supplierFor(p, model, fresh, auto = true) {
  if (aliPaused) return p;
  const photos = photosToTry(p);
  const lists = [];
  let tried = 0;
  const since = Date.now();
  let last = 0;
  const step = (k) => (text3, done = 0, total2 = 0) => {
    if (!current) return;
    current.sub = { text: `Photo ${k}/${photos.length} \xB7 ${text3}`, done, total: total2, since };
    if (Date.now() - last < 1e3 && done !== total2) return;
    last = Date.now();
    void report(current);
  };
  for (const [k, image] of photos.entries()) {
    if (stopRequested) break;
    try {
      const found = await findSuppliers({ title: p.title, image, fresh, auto }, () => {
      }, step(k + 1));
      if (!found.candidates.some((c) => (c.photo ?? 0) >= SAME_PHOTO) && k + 1 < photos.length)
        step(k + 1)("pas de photo exacte : essai avec la photo d\u2019un autre dropshipper\u2026");
      tried++;
      lists.push(found.candidates);
      if (found.candidates.some((c) => (c.photo ?? 0) >= SAME_PHOTO)) break;
    } catch (e) {
      apiTrace("scout", "supplier:error", { message: e instanceof Error ? e.message : String(e) });
      if (isAliVerify(e)) {
        aliPaused = true;
        aliPausedWhy = e instanceof Error ? e.message : "";
        break;
      }
    }
  }
  if (current) delete current.sub;
  if (!tried) return p;
  const merged = mergeSuppliers(lists);
  return { ...withSupplier(p, merged[0] ?? null, model), alts: merged.slice(0, 5).map(asSupplier), searchedAt: Date.now(), photosTried: tried };
}
var asSupplier = (c) => ({
  url: c.url,
  title: c.title,
  image: c.image,
  price: c.price,
  currency: c.currency,
  photo: c.photo,
  sold: c.sold,
  rating: c.rating,
  exact: (c.photo ?? 0) >= SAME_PHOTO
});
function searchScoutSuppliers(input) {
  if (running2) throw Error("Une recherche est d\xE9j\xE0 en cours : attends la fin ou arr\xEAte-la.");
  return track(() => suppliersJob(input));
}
async function suppliersJob(input) {
  const state = (await chrome.storage.local.get(SCOUT_KEY))[SCOUT_KEY];
  if (!state?.products?.length) throw Error("Aucun produit trouv\xE9 \xE0 chercher.");
  const wanted = Array.isArray(input.itemIds) ? input.itemIds.filter((x) => typeof x === "string") : [];
  const todo = state.products.filter((p) => wanted.length ? wanted.includes(p.itemId) : !p.supplier && !p.searchedAt);
  if (!todo.length) throw Error("Tous les produits ont d\xE9j\xE0 leur fournisseur.");
  const before = { state: state.state, step: state.step };
  const model = await profitModel().catch(() => null);
  Object.assign(state, { state: "running", task: "suppliers", done: 0, total: todo.length });
  let found = 0;
  try {
    for (const [i, p] of todo.entries()) {
      if (stopRequested) break;
      state.step = `\u{1F4F8} Fournisseur AliExpress par photo : \xAB ${p.title.slice(0, 50)} \xBB`;
      state.done = i;
      await report(state);
      if (aliPaused) break;
      const next = await supplierFor(p, model, input.fresh === true, false);
      if (next.supplier?.exact) found++;
      state.products = state.products.map((x) => x.itemId === p.itemId ? next : x);
    }
    state.step = `${before.step} \xB7 \u{1F4F8} ${found}/${todo.length} fournisseur(s) \xE0 photo exacte trouv\xE9(s)${stopRequested ? " (arr\xEAt\xE9)" : ""}.${aliPaused ? aliPausedNote() : ""}`;
  } finally {
    state.state = before.state === "running" ? "stopped" : before.state;
    delete state.task;
    state.done = state.total;
    await report(state);
  }
  return state;
}
async function pickScoutSupplier(itemId, url) {
  if (running2) throw Error("Attends la fin de la recherche en cours.");
  const state = (await chrome.storage.local.get(SCOUT_KEY))[SCOUT_KEY];
  const p = state?.products.find((x) => x.itemId === itemId);
  const alt = p?.alts?.find((a) => a.url === url);
  if (!state || !p || !alt) throw Error("Produit introuvable : relance la recherche.");
  const next = { ...withSupplier(p, alt, await profitModel().catch(() => null)), alts: p.alts, searchedAt: p.searchedAt, photosTried: p.photosTried };
  state.products = state.products.map((x) => x.itemId === p.itemId ? next : x);
  await report(state);
  return next;
}
function withSupplier(p, supplier, model) {
  const cost = supplier?.price ?? null;
  return {
    ...p,
    supplier: supplier ? asSupplier(supplier) : null,
    net: model && cost ? estimateProfit(p.median, cost, model).net : null,
    floor: model && cost ? minimumPrice(cost, model, 1) : null
  };
}
async function manual(input) {
  const query = typeof input.query === "string" ? input.query.trim().slice(0, 120) : "";
  const minNonUS = clamp(input.minNonUS, 1, 6, 2);
  const state = { state: "running", mode: "manual", query, step: "D\xE9marrage\u2026", done: 0, total: 1, at: Date.now(), read: 0, products: [] };
  await report(state);
  const tab = await ebayTab(true);
  try {
    const model = await profitModel().catch(() => null);
    const r = await scanNiche(
      query,
      { minNonUS, pages: clamp(input.pages, 1, 4, 3), suppliers: clamp(input.suppliers, 0, 15, 8) },
      tab,
      model,
      async (step, done, total2) => {
        Object.assign(state, { step, done, total: total2 });
        delete state.sub;
        await report(state);
      }
    );
    state.read = r.read;
    state.products = r.products;
    state.state = stopRequested ? "stopped" : "done";
    state.step = r.products.length ? `${r.products.length} produit(s) en vente chez au moins ${minNonUS} dropshipper(s) hors US.` : `Aucun produit vendu par au moins ${minNonUS} dropshipper(s) hors US dans ces ${r.read} annonces : essaie d\u2019autres mots ou baisse le minimum.`;
    if (aliPaused) state.step += aliPausedNote();
  } catch (e) {
    state.state = "error";
    state.error = e instanceof Error ? e.message : String(e);
  } finally {
    if (tab.owned) await chrome.tabs.remove(tab.tabId).catch(() => {
    });
  }
  state.at = Date.now();
  await report(state);
  return state;
}
function rejectReason(p, c, stage) {
  if (brandRisks(p.title).some((b) => b.level === "danger")) return "brand";
  if (c.priceMin !== null && p.median < c.priceMin) return "price";
  if (c.priceMax !== null && p.median > c.priceMax) return "price";
  if (stage === "price") return null;
  if (c.minD30 > 0 && p.d30 !== null && p.d30 < c.minD30) return "sales";
  if (stage === "sales") return null;
  if (c.minNet !== null && (p.net === null || p.net < c.minNet)) return "profit";
  return null;
}
async function autopilot(input) {
  const price = (v) => v === null || v === "" || v === void 0 || !Number.isFinite(Number(v)) ? null : Number(v);
  const criteria = {
    categories: Array.isArray(input.categories) ? input.categories.filter((x) => typeof x === "string") : [],
    minNonUS: clamp(input.minNonUS, 1, 6, 2),
    target: clamp(input.target, 1, 30, 10),
    priceMin: price(input.priceMin),
    priceMax: price(input.priceMax),
    minNet: price(input.minNet),
    minD30: clamp(input.minD30, 0, 1e3, 0),
    pages: clamp(input.pages, 1, 4, 2),
    photoSearch: input.photoSearch !== false
  };
  const state = {
    state: "running",
    mode: "auto",
    query: "",
    step: "D\xE9marrage de l\u2019autopilote\u2026",
    done: 0,
    total: criteria.target,
    at: Date.now(),
    read: 0,
    products: [],
    auto: { tried: [], target: criteria.target, criteria, seen: 0, refused: { brand: 0, price: 0, sales: 0, profit: 0 } }
  };
  const own = eventPlan(input);
  if (own) state.auto.event = own.event;
  await report(state);
  const tab = await ebayTab(true);
  const model = await profitModel().catch(() => null);
  const known = /* @__PURE__ */ new Set();
  try {
    const plan = own?.plan ?? pickNiches(40, [], Math.random, criteria.categories);
    for (const { niche } of plan) {
      if (stopRequested || state.products.length >= criteria.target) break;
      state.query = niche;
      state.auto.tried.push(niche);
      const nicheStart = Date.now();
      await report(state);
      try {
        const r = await scanNiche(
          niche,
          {
            minNonUS: criteria.minNonUS,
            pages: criteria.pages,
            // Profit rule: the supplier is needed to know the profit.
            suppliers: criteria.minNet !== null ? 5 : 0,
            keep: (p) => {
              const why = rejectReason(p, criteria, "price");
              if (why) state.auto.refused[why]++;
              return !why;
            },
            keepAfterSales: (p) => {
              const why = rejectReason(p, criteria, "sales");
              if (why) state.auto.refused[why]++;
              return !why;
            }
          },
          tab,
          model,
          async (step, done, total2) => {
            state.step = `Niche ${state.auto.tried.length} : \xAB ${niche} \xBB \xB7 ${step}`;
            state.sub = { text: step, done, total: total2, since: nicheStart };
            await report(state);
          }
        );
        state.read += r.read;
        state.auto.seen += r.proven;
        for (let p of r.products) {
          if (state.products.length >= criteria.target || stopRequested) break;
          if (known.has(p.itemId)) continue;
          const why = rejectReason(p, criteria, "final");
          if (why) {
            state.auto.refused[why]++;
            continue;
          }
          if (criteria.photoSearch && !p.supplier && !aliPaused) {
            state.step = `Niche ${state.auto.tried.length} : \xAB ${niche} \xBB \xB7 \u{1F4F8} fournisseur AliExpress par photo\u2026`;
            await report(state);
            p = await supplierFor(p, model, false);
          }
          if (p.supplier && known.has(p.supplier.url)) continue;
          known.add(p.itemId);
          if (p.supplier) known.add(p.supplier.url);
          state.products.push({ ...p, niche });
          state.done = state.products.length;
          await report(state);
        }
        state.done = state.products.length;
        await report(state);
      } catch (e) {
        apiTrace("scout", "auto:niche-error", { niche, message: e instanceof Error ? e.message : String(e) });
        if (/anti-robot/.test(e instanceof Error ? e.message : "")) throw e;
      }
    }
    state.state = stopRequested ? "stopped" : "done";
    state.step = state.products.length >= criteria.target ? `Objectif atteint : ${state.products.length} produit(s) trouv\xE9(s) en ${state.auto.tried.length} niche(s).` : `${state.products.length} produit(s) trouv\xE9(s) en ${state.auto.tried.length} niche(s)${stopRequested ? " (arr\xEAt\xE9)" : " : \xE9largis les crit\xE8res pour en trouver plus"}.`;
    if (aliPaused) state.step += aliPausedNote();
  } catch (e) {
    state.state = "error";
    state.error = e instanceof Error ? e.message : String(e);
  } finally {
    if (tab.owned) await chrome.tabs.remove(tab.tabId).catch(() => {
    });
  }
  state.at = Date.now();
  await report(state);
  return state;
}
function eventPlan(input, random = Math.random) {
  const strings2 = (v) => Array.isArray(v) ? v.filter((x) => typeof x === "string").map((x) => x.trim().slice(0, 80)).filter(Boolean) : [];
  const niches = [...new Set(strings2(input.niches))].slice(0, 300);
  if (!niches.length) return null;
  const event = typeof input.event === "string" && input.event.trim() ? input.event.trim().slice(0, 60) : "F\xEAte";
  for (let i = niches.length - 1; i > 0; i--) {
    const j = Math.floor(random() * (i + 1));
    [niches[i], niches[j]] = [niches[j], niches[i]];
  }
  const avoid = new Set(strings2(input.avoid));
  const order = [...niches.filter((n) => !avoid.has(n)), ...niches.filter((n) => avoid.has(n))].slice(0, 40);
  return { event, plan: order.map((niche) => ({ niche, category: event })) };
}
function product(g, supplier, model, countries) {
  const rank = { NON_US: 0, UNKNOWN: 1, US: 2 };
  const listings = g.cards.map((c) => {
    const info = c.seller && countries.get(c.seller) || { status: "UNKNOWN", country: null };
    return {
      itemId: c.itemId,
      seller: c.seller,
      status: info.status,
      country: info.country,
      total: Math.round((c.price + (c.shipping ?? 0)) * 100) / 100,
      sold: c.sold,
      d7: null,
      d30: null,
      image: c.image
    };
  }).sort((a, b) => rank[a.status] - rank[b.status] || (b.sold ?? 0) - (a.sold ?? 0));
  const theirs = listings.filter((l) => l.status === "NON_US").map((l) => l.total).sort((a, b) => a - b);
  const median2 = theirs.length ? theirs[Math.floor(theirs.length / 2)] : g.median;
  const lead = g.cards.find((c) => c.itemId === listings[0]?.itemId) ?? g.lead;
  const base = {
    title: lead.title,
    image: lead.image,
    itemId: lead.itemId,
    sellers: g.sellers,
    nonUS: g.nonUS,
    us: g.us,
    unknown: g.unknown,
    countries: g.countries,
    listingsCount: g.cards.length,
    soldShown: g.soldShown,
    d7: null,
    d30: null,
    median: median2,
    min: theirs[0] ?? g.min,
    located: g.located,
    listings: listings.slice(0, 10),
    supplier: null,
    net: null,
    floor: null,
    currency: model?.currency ?? "EUR"
  };
  return supplier ? withSupplier(base, supplier, model) : base;
}

// src/background/draftBatch.ts
var BATCH_KEY = "draftBatch:v1";
var MAX_ITEMS2 = 60;
function parseBatchLines(text3) {
  const items = [];
  const refused = [];
  const seen = /* @__PURE__ */ new Set();
  for (const raw of String(text3 ?? "").split(/\r?\n/)) {
    const line = raw.trim();
    if (!line) continue;
    const ebayId = line.match(/ebay\.[a-z.]+\/itm\/(?:[^/\s]*\/)?(\d{9,15})/i)?.[1];
    const aliId = line.match(/aliexpress\.[a-z.]+\/item\/(\d{6,25})\.html/i)?.[1];
    if (!ebayId || !aliId) {
      refused.push(line.slice(0, 120));
      continue;
    }
    if (seen.has(aliId)) continue;
    seen.add(aliId);
    items.push({ ebayId, aliId, state: "pending" });
  }
  return { items: items.slice(0, MAX_ITEMS2), refused };
}
var wait4 = (ms) => new Promise((r) => setTimeout(r, ms));
async function batchState() {
  return (await chrome.storage.local.get(BATCH_KEY))[BATCH_KEY] ?? null;
}
async function save2(b) {
  b.updatedAt = Date.now();
  await chrome.storage.local.set({ [BATCH_KEY]: b });
}
var loop = null;
async function startBatch(text3, create, getJob) {
  const current2 = await batchState();
  if (current2?.running) throw Error("Un lot de brouillons est d\xE9j\xE0 en cours : attends la fin ou arr\xEAte-le.");
  const rule = (await chrome.storage.local.get("variantPricing")).variantPricing;
  if (!rule || !Number.isFinite(rule.coefficient))
    throw Error("R\xE8gle de prix manquante : cr\xE9e d\u2019abord un brouillon depuis une annonce eBay (coefficient, montant fixe, arrondi), elle sera reprise pour tout le lot.");
  const { items, refused } = parseBatchLines(String(text3 ?? ""));
  if (!items.length) throw Error("Aucune ligne lisible : il faut un lien eBay (\u2026/itm/123\u2026) et un lien AliExpress (\u2026/item/123\u2026.html) par ligne.");
  const batch = { running: true, startedAt: Date.now(), updatedAt: Date.now(), items };
  await save2(batch);
  loop ??= run(create, getJob).finally(() => loop = null);
  return { count: items.length, refused };
}
async function stopBatch() {
  const b = await batchState();
  if (!b?.running) return b;
  b.stopRequested = true;
  await save2(b);
  return b;
}
async function resumeBatch(create, getJob) {
  const b = await batchState();
  if (!b?.running || loop) return;
  for (const it of b.items)
    if (it.state === "running") Object.assign(it, { state: "error", error: "Interrompu (extension red\xE9marr\xE9e) : v\xE9rifie tes brouillons eBay avant de le relancer.", at: Date.now() });
  await save2(b);
  loop = run(create, getJob).finally(() => loop = null);
}
async function run(create, getJob) {
  for (; ; ) {
    const b = await batchState();
    if (!b) return;
    const next = b.items.find((i) => i.state === "pending");
    if (!next || b.stopRequested) {
      for (const i of b.items) if (i.state === "pending") i.state = "skipped";
      b.running = false;
      b.stopRequested = false;
      await save2(b);
      return;
    }
    next.state = "running";
    next.at = Date.now();
    await save2(b);
    const result = await makeOne(next, create, getJob).catch((e) => ({ error: e instanceof Error ? e.message : String(e) }));
    const after = await batchState() ?? b;
    const item = after.items.find((i) => i.aliId === next.aliId && i.ebayId === next.ebayId);
    if (item) Object.assign(item, "draftId" in result ? { state: "done", draftId: result.draftId } : { state: "error", error: result.error }, { at: Date.now() });
    if ("error" in result && /anti-robot/i.test(result.error)) after.stopRequested = true;
    await save2(after);
    await wait4(4e3);
  }
}
async function waitLoaded(tabId) {
  for (let i = 0; i < 120; i++) {
    await wait4(500);
    const t = await chrome.tabs.get(tabId).catch(() => void 0);
    if (!t) throw Error("L\u2019onglet eBay a \xE9t\xE9 ferm\xE9.");
    if (/signin/i.test(t.url ?? "")) throw Error("Connecte-toi \xE0 eBay, puis relance.");
    if (t.status === "complete") {
      await wait4(1500);
      return;
    }
    if (i > 0 && i % 30 === 0)
      await chrome.scripting?.executeScript({ target: { tabId }, func: () => void (document.readyState !== "loading" && window.stop()) }).catch(() => {
      });
  }
  throw Error("La fiche eBay ne finit pas de charger : relance ce produit plus tard.");
}
async function makeOne(item, create, getJob) {
  const ref = await chrome.tabs.create({ url: `https://www.ebay.com/itm/${item.ebayId}`, active: false });
  if (ref.id === void 0) throw Error("Impossible d\u2019ouvrir l\u2019annonce eBay.");
  let workTab;
  try {
    await waitLoaded(ref.id);
    const aliUrl = `https://www.aliexpress.us/item/${item.aliId}.html`;
    let started;
    try {
      started = await withTimeout(create(ref.id, aliUrl), 6 * 6e4);
    } catch (error) {
      if (!/en cours de chargement/i.test(error instanceof Error ? error.message : String(error))) throw error;
      await chrome.tabs.reload(ref.id).catch(() => {
      });
      await waitLoaded(ref.id);
      started = await withTimeout(create(ref.id, aliUrl), 6 * 6e4);
    }
    workTab = started.tabId;
    const deadline = Date.now() + 12 * 6e4;
    let draftId;
    while (Date.now() < deadline) {
      await wait4(3e3);
      const job = await getJob(started.tabId).catch(() => null);
      if (job?.apiDraftId) draftId = job.apiDraftId;
      if (job?.stage === "error" || job?.apiPhase === "error") throw Error(job.error || "Cr\xE9ation interrompue par eBay.");
      if (job?.stage === "ready" || job?.apiPhase === "complete") {
        if (!draftId) throw Error("Brouillon termin\xE9 sans num\xE9ro : v\xE9rifie tes brouillons eBay.");
        await wait4(2500);
        return { draftId };
      }
      if (!job && draftId) return { draftId };
    }
    throw Error(draftId ? "Brouillon cr\xE9\xE9 mais pas encore v\xE9rifi\xE9 : ouvre-le pour contr\xF4ler." : "Trop long (12 min) : v\xE9rifie tes brouillons eBay.");
  } finally {
    await chrome.tabs.remove(ref.id).catch(() => {
    });
    if (workTab !== void 0) await chrome.tabs.remove(workTab).catch(() => {
    });
  }
}

// src/core/ebaySeed.ts
function ebayItemId(url) {
  try {
    const u = new URL(url);
    return u.protocol === "https:" && !u.username && !u.password && !u.port && /(^|\.)ebay\.com$/.test(u.hostname) ? u.pathname.match(/^\/itm\/(?:[^/]+\/)?(\d+)(?:\/)?$/)?.[1] ?? null : null;
  } catch {
    return null;
  }
}
function validEbaySeed(s, now = Date.now()) {
  try {
    const u = new URL(s.copyUrl);
    return ebayItemId(s.url) === s.itemId && validTitle(s.title, 80) && !u.username && !u.password && u.origin === "https://www.ebay.com" && u.pathname === "/sl/list" && ["SellLikeItem", "SellSimilarItem"].includes(
      u.searchParams.get("mode") ?? ""
    ) && u.searchParams.get("itemId") === s.itemId && typeof s.category === "string" && (s.categoryId === void 0 || /^\d{1,7}$/.test(s.categoryId)) && (!!s.category || s.categoryFromCopy === true && u.searchParams.get("mode") === "SellLikeItem") && Array.isArray(s.specifics) && s.specifics.length <= 100 && s.specifics.every(
      (x) => typeof x.label === "string" && typeof x.value === "string" && x.label.length <= 150 && x.value.length <= 1e3
    ) && Number.isFinite(s.capturedAt) && s.capturedAt <= now + 3e4 && now - s.capturedAt < 36e5 && (s.price === null || /^\d+(?:\.\d{1,2})?$/.test(s.price)) && (s.currency === null || s.currency === "USD") && typeof s.hasVariations === "boolean";
  } catch {
    return false;
  }
}
function ebayCopyURL(seed) {
  if (!validEbaySeed(seed))
    throw Error("Fiche eBay de d\xE9part invalide ou p\xE9rim\xE9e.");
  const u = new URL(seed.copyUrl);
  u.searchParams.set("mode", "SellLikeItem");
  if (!u.searchParams.has("rt")) u.searchParams.set("rt", "nc");
  return u.href;
}
function aliProductURL(value) {
  const u = new URL(value.trim());
  if (u.protocol !== "https:" || u.username || u.password || u.port || !/(^|\.)aliexpress\.(com|us)$/.test(u.hostname) || !/^\/item\/\d+\.html$/.test(u.pathname))
    throw Error(
      "Colle le lien complet d\u2019une fiche produit AliExpress (.com ou .us)."
    );
  return u.origin + u.pathname;
}
function usSupplierURL(value) {
  const u = new URL(aliProductURL(value));
  if (u.hostname === "www.aliexpress.us") return u.origin + u.pathname;
  return `https://www.aliexpress.us${u.pathname}`;
}

// src/core/description.ts
var reviewTerms = /\bdrop[\s-]?shipping\b|\bdropship(?:pers?)?\b|\bwholesale\b|\baliexpress\b|\balibaba\b|\b(?:whats\s?app|wechat|telegram)\b|[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}|\b(?:leave|give)\s+(?:us\s+)?(?:5|five)[ -]stars?\b/gi;
function descriptionMentions(text3) {
  return [...text3.matchAll(new RegExp(reviewTerms))].map((match) => ({
    text: match[0],
    start: match.index,
    end: match.index + match[0].length
  }));
}

// src/core/nativeImport.ts
var textHTML = (s) => escapeHTML(s).replace(/&#39;/g, "'").replace(/&quot;/g, '"').replace(/\u00a0/g, "&nbsp;");
function nativeDescription(p, title, removeMentions = false) {
  if (!validTitle(title, 80))
    throw Error("Titre invalide : 80 caract\xE8res maximum, sur une seule ligne.");
  const paragraphs = p.description.split(/\n+/).filter(
    (line) => line.trim() && (!removeMentions || !descriptionMentions(line).length)
  );
  const specs = p.specifications.filter(
    (s) => !removeMentions || !descriptionMentions(s.label + " " + s.value).length
  );
  return listingDescriptionHTML(
    title,
    (paragraphs.length ? `<h3>Product Overview</h3>${paragraphs.map((line) => `<p>${textHTML(line.trim())}</p>`).join("")}` : "") + (specs.length ? `<h3>Specifications</h3><ul>${specs.map((s) => `<li><strong>${textHTML(s.label)}:</strong> ${textHTML(s.value)}</li>`).join("")}</ul>` : "")
  );
}
function validateNativeChoice(p, c, seed) {
  if (c.sourceUrl !== p.sourceUrl || !validTitle(c.title, 80))
    throw Error("Source ou titre invalide.");
  if (c.ebaySeedId && (!seed || !validEbaySeed(seed) || seed.itemId !== c.ebaySeedId || c.title !== seed.title))
    throw Error(
      "Fiche eBay de d\xE9part p\xE9rim\xE9e ou diff\xE9rente. Recommence Push depuis cette fiche."
    );
  if (p.axes.some((a) => a.values.length !== 1) && !(seed && c.ebaySeedId === seed.itemId))
    throw Error(
      "Import natif limit\xE9 aux produits simples et options lues pour cette version. Pour les variantes, utilise Push to eBay depuis une fiche eBay puis colle ce lien AliExpress."
    );
  if (c.fullDescription && (p.descriptionStatus !== "loaded" || !p.descriptionHTML))
    throw Error(
      "La description AliExpress compl\xE8te doit \xEAtre charg\xE9e, photos incluses."
    );
  if (!c.fullDescription && !p.description.trim() && !p.specifications.length)
    throw Error(
      "Description et caract\xE9ristiques absentes : relis la fiche AliExpress."
    );
  if (!Array.isArray(c.images) || !c.images.length || c.images.length > 24 || new Set(c.images).size !== c.images.length || c.images.some(
    (url) => importImageURL(url) !== url || !p.images.some((i) => i.url === url)
  ))
    throw Error("Choisis entre 1 et 24 photos r\xE9ellement lues sur la fiche.");
  if (typeof c.removeMentions !== "boolean" || c.fullDescription !== void 0 && typeof c.fullDescription !== "boolean")
    throw Error("Choix de description invalide.");
}
function freshNativeJob(job, now = Date.now()) {
  return job?.schemaVersion === 1 && Number.isFinite(job.createdAt) && job.createdAt <= now + 3e4 && now - job.createdAt < 36e5;
}

// src/ebay/workingPage.ts
function workingPageScene(brandCss, mark) {
  document.title = "AurOEBay \xB7 pr\xE9paration du brouillon\u2026";
  const steps = [
    ["create", "Cr\xE9ation du brouillon eBay"],
    ["photos", "Envoi des photos"],
    ["basics", "Titre, description et prix"],
    ["variants", "Variantes et stock"],
    ["verify", "V\xE9rification finale"]
  ];
  const css = `${brandCss}
  :root{--bg:#fbf7f3;--card:rgba(255,255,255,.78);--ink:#1d1828;--mut:#75697d;--line:#ebe1d7;--ok:#1f9a6c}
  @media (prefers-color-scheme:dark){:root{--bg:#15121c;--card:rgba(30,26,39,.78);--ink:#f1ecf4;--mut:#a49bb0;--line:#373042;--ok:#3fd09a}}
  *{box-sizing:border-box}
  html,body{height:100%}
  body{margin:0;display:grid;place-items:center;background:var(--bg);color:var(--ink);font:15px/1.5 -apple-system,system-ui,sans-serif;overflow:hidden}
  .sky{position:fixed;inset:0;overflow:hidden;pointer-events:none}
  .sky i{position:absolute;border-radius:50%;filter:blur(60px);opacity:.55}
  .sky i:nth-child(1){width:520px;height:520px;left:-120px;top:-140px;background:#ff5f3a;animation:drift1 14s ease-in-out infinite alternate}
  .sky i:nth-child(2){width:460px;height:460px;right:-120px;bottom:-160px;background:#ffb347;animation:drift2 16s ease-in-out infinite alternate}
  .sky i:nth-child(3){width:300px;height:300px;left:45%;top:60%;background:#ff8a3d;opacity:.3;animation:drift1 18s ease-in-out infinite alternate-reverse}
  .card{position:relative;overflow:hidden;width:min(540px,92vw);padding:38px 36px 26px;border-radius:26px;background:var(--card);border:1px solid var(--line);box-shadow:0 30px 80px rgba(20,10,30,.18);backdrop-filter:blur(18px) saturate(1.2);-webkit-backdrop-filter:blur(18px) saturate(1.2);animation:ao-rise .7s var(--ao-ease) both}
  .card::before{content:"";position:absolute;inset:0 0 auto;height:3px;background:linear-gradient(90deg,transparent,#ff5f3a,#ffb347,#ff5f3a,transparent) 0 0/200% 100%;animation:line 5s linear infinite}
  .hero{display:grid;place-items:center;margin:0 auto 20px}
  .hero .ao-loader{--ao-size:104px}
  h1{margin:0 0 6px;font-size:22px;text-align:center;letter-spacing:-.02em}
  h1 em{font-style:normal;background:var(--ao-gradient);-webkit-background-clip:text;background-clip:text;color:transparent}
  .sub{margin:0 0 24px;text-align:center;color:var(--mut);font-size:14px}
  .ao-progress{height:8px;margin-bottom:22px}
  ol{list-style:none;margin:0;padding:0;display:grid;gap:12px}
  li{display:flex;align-items:center;gap:12px;color:var(--mut);transition:color .35s;animation:ao-rise .5s var(--ao-ease) both}
  li .dot{flex:none;position:relative;width:24px;height:24px;border-radius:50%;border:2px solid var(--line);display:grid;place-items:center;transition:border-color .35s,background .35s}
  li.active{color:var(--ink);font-weight:650}
  li.active .dot{border-color:#ff5f3a;animation:ao-pulse 1.5s ease-out infinite}
  li.active .dot::before{content:"";width:8px;height:8px;border-radius:50%;background:var(--ao-gradient)}
  li.done{color:var(--ink)}
  li.done .dot{border-color:transparent;background:var(--ao-gradient);animation:ao-pop .45s var(--ao-spring)}
  li.done .dot::before{content:"";width:9px;height:5px;border:2px solid #fff;border-top:0;border-right:0;transform:translate(0,-1px) rotate(-45deg)}
  li small{margin-left:auto;font-weight:600;color:var(--mut);font-variant-numeric:tabular-nums}
  .foot{margin:22px 0 0;text-align:center;color:var(--mut);font-size:12.5px}
  .finished .hero .ao-loader::before,.finished .hero .ao-loader::after{animation:none;opacity:0;transition:opacity .4s}
  .finished .hero .ao-mark{animation:ao-pop .6s var(--ao-spring)}
  .finished h1{animation:ao-rise .5s var(--ao-ease)}
  @keyframes drift1{to{transform:translate(120px,80px) scale(1.15)}}
  @keyframes drift2{to{transform:translate(-110px,-70px) scale(1.1)}}
  @keyframes line{to{background-position:-200% 0}}
  @media (prefers-reduced-motion:reduce){*,*::before,*::after{animation:none!important;transition:none!important}}
  `;
  document.head.replaceChildren();
  const style = document.createElement("style");
  style.textContent = css;
  const meta = document.createElement("meta");
  meta.name = "color-scheme";
  meta.content = "light dark";
  document.head.append(style, meta);
  const sky = document.createElement("div");
  sky.className = "sky";
  sky.innerHTML = "<i></i><i></i><i></i>";
  const card = document.createElement("main");
  card.className = "card";
  card.id = "auroebay-working";
  card.innerHTML = `<div class="hero"><div class="ao-loader"><span class="ao-mark"></span></div></div>
    <h1>AurOEBay <em>pr\xE9pare</em> ton brouillon</h1>
    <p class="sub">Cet onglet affichera le brouillon d\xE8s qu\u2019il sera pr\xEAt. Tu peux continuer \xE0 naviguer.</p>
    <div class="ao-progress"><i></i></div>
    <ol>${steps.map(([k, label], i) => `<li data-step="${k}" style="animation-delay:${0.25 + i * 0.08}s"><span class="dot"></span><span>${label}</span><small></small></li>`).join("")}</ol>
    <p class="foot">Rien n\u2019est publi\xE9 : tu v\xE9rifies tout avant de mettre en vente.</p>`;
  const holder = card.querySelector(".ao-mark");
  if (holder) {
    holder.innerHTML = mark;
    holder.style.background = "none";
    holder.querySelector("svg")?.setAttribute("style", "width:100%;height:100%");
  }
  document.body.replaceChildren(sky, card);
  document.body.removeAttribute("style");
  card.querySelector("li")?.classList.add("active");
  card.querySelector(".ao-progress")?.style.setProperty("--p", "6%");
}
function workingPageStep(phase, uploaded, total2) {
  const card = document.getElementById("auroebay-working");
  if (!card) return;
  const order = ["create", "photos", "basics", "variants", "verify"];
  const index = phase === "queued" || phase === "creating" ? 0 : phase === "photos" ? 1 : phase === "basics" ? 2 : phase === "variants" ? 3 : phase === "verifying" ? 4 : phase === "complete" ? 5 : -1;
  if (index < 0) return;
  card.querySelectorAll("li").forEach((li) => {
    const i = order.indexOf(li.dataset.step ?? "");
    li.classList.toggle("done", i < index);
    li.classList.toggle("active", i === index);
  });
  const photos = card.querySelector("li[data-step='photos'] small");
  if (photos && total2 > 0) photos.textContent = `${Math.min(uploaded, total2)} / ${total2}`;
  const within = index === 1 && total2 > 0 ? Math.min(uploaded, total2) / total2 : 0;
  const percent = Math.max(6, Math.min(100, (index + within) / 5 * 100));
  card.querySelector(".ao-progress")?.style.setProperty("--p", `${percent}%`);
  if (index === 5 && !card.classList.contains("finished")) {
    card.classList.add("finished");
    const title = card.querySelector("h1");
    if (title) title.innerHTML = "Brouillon <em>pr\xEAt</em> ! Ouverture\u2026";
  }
}

// src/core/brand.ts
var BRAND = {
  ember: "#ff5f3a",
  flame: "#ff8a3d",
  sun: "#ffb347",
  night: "#15121c",
  night2: "#1e1a27",
  night3: "#2a2534",
  nightLine: "#373042",
  paper: "#fbf7f3",
  paper2: "#ffffff",
  paper3: "#f4ede6",
  paperLine: "#ebe1d7",
  inkDark: "#f1ecf4",
  inkLight: "#1d1828",
  mutedDark: "#a49bb0",
  mutedLight: "#75697d",
  ok: "#22b07d",
  warn: "#f0a63a",
  danger: "#ef4f5f",
  info: "#7c8cff",
  gradient: "linear-gradient(135deg,#ff5f3a 0%,#ff8a3d 48%,#ffb347 100%)",
  ease: "cubic-bezier(.2,.8,.2,1)",
  spring: "cubic-bezier(.34,1.56,.64,1)"
};
function brandMarkSVG(size = 28, id = "ao") {
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 48 48" aria-hidden="true"><defs><linearGradient id="${id}g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${BRAND.ember}"/><stop offset=".5" stop-color="${BRAND.flame}"/><stop offset="1" stop-color="${BRAND.sun}"/></linearGradient></defs><rect x="2" y="2" width="44" height="44" rx="13" fill="url(#${id}g)"/><path d="M14.5 36 24 12.5 33.5 36" fill="none" stroke="#fff" stroke-width="4.6" stroke-linecap="round" stroke-linejoin="round"/><path d="M18.6 30.2a5.4 5.4 0 0 1 10.8 0" fill="none" stroke="#fff" stroke-width="3.4" stroke-linecap="round"/><path class="ao-spark" d="M38 6.5l1.5 3.6 3.6 1.5-3.6 1.5L38 16.7l-1.5-3.6-3.6-1.5 3.6-1.5z" fill="#fff"/></svg>`;
}
var markURL = `url("data:image/svg+xml,${encodeURIComponent(brandMarkSVG(48, "u"))}")`;
var BRAND_CSS = `
:root,:host{--ao-ember:${BRAND.ember};--ao-flame:${BRAND.flame};--ao-sun:${BRAND.sun};--ao-gradient:${BRAND.gradient};--ao-ease:${BRAND.ease};--ao-spring:${BRAND.spring};--ao-ok:${BRAND.ok};--ao-warn:${BRAND.warn};--ao-danger:${BRAND.danger};--ao-info:${BRAND.info};--ao-glow:0 10px 30px rgba(255,95,58,.35)}
.ao-mark{display:inline-block;flex:none;width:28px;height:28px;background:${markURL} center/contain no-repeat}
.ao-loader{position:relative;display:inline-grid;place-items:center;flex:none;width:var(--ao-size,64px);height:var(--ao-size,64px)}
.ao-loader::before{content:"";position:absolute;inset:0;border-radius:50%;background:conic-gradient(from 0deg,transparent 0 40%,${BRAND.sun} 70%,${BRAND.ember} 100%);-webkit-mask:radial-gradient(circle closest-side,transparent calc(100% - max(2px,calc(var(--ao-size,64px) * .05))),#000 calc(100% - max(2px,calc(var(--ao-size,64px) * .05)) + 1px));mask:radial-gradient(circle closest-side,transparent calc(100% - max(2px,calc(var(--ao-size,64px) * .05))),#000 calc(100% - max(2px,calc(var(--ao-size,64px) * .05)) + 1px));animation:ao-spin 1.15s linear infinite}
.ao-loader::after{content:"";position:absolute;top:50%;left:50%;width:max(3px,calc(var(--ao-size,64px) * .08));height:max(3px,calc(var(--ao-size,64px) * .08));margin:calc(max(3px,calc(var(--ao-size,64px) * .08)) / -2);border-radius:50%;background:#fff;box-shadow:0 0 8px 2px ${BRAND.sun};animation:ao-orbit 2.2s linear infinite}
.ao-loader>.ao-mark{width:64%;height:64%;animation:ao-breathe 2.4s var(--ao-ease) infinite;filter:drop-shadow(0 4px 10px rgba(255,95,58,.45))}
.ao-spinner{display:inline-block;flex:none;width:var(--ao-size,14px);height:var(--ao-size,14px);border-radius:50%;background:conic-gradient(from 0deg,transparent 0 35%,${BRAND.sun} 65%,${BRAND.ember});-webkit-mask:radial-gradient(circle closest-side,transparent 68%,#000 72%);mask:radial-gradient(circle closest-side,transparent 68%,#000 72%);animation:ao-spin .8s linear infinite;vertical-align:-2px}
.ao-sweep{position:relative;overflow:hidden;isolation:isolate}
.ao-sweep::after{content:"";position:absolute;inset:-20% auto -20% -60%;width:45%;background:linear-gradient(100deg,transparent,rgba(255,255,255,.28),transparent);transform:skewX(-18deg);animation:ao-sweep 4.8s var(--ao-ease) infinite;pointer-events:none;z-index:1}
.ao-rise{animation:ao-rise .5s var(--ao-ease) both}
.ao-progress{position:relative;height:6px;border-radius:99px;background:rgba(127,112,140,.18);overflow:hidden}
.ao-progress>i{position:absolute;inset:0 auto 0 0;width:var(--p,0%);border-radius:inherit;background:var(--ao-gradient);transition:width .7s var(--ao-ease)}
.ao-progress>i::after{content:"";position:absolute;inset:0;background:linear-gradient(90deg,transparent,rgba(255,255,255,.55),transparent);transform:translateX(-100%);animation:ao-shine 1.6s ease-in-out infinite}
.ao-progress.indeterminate>i{width:38%;animation:ao-slide 1.4s cubic-bezier(.65,0,.35,1) infinite}
.ao-spark{transform-box:fill-box;transform-origin:center;animation:ao-twinkle 3.2s ease-in-out infinite}
.profit-box{margin:10px 0;padding:10px 12px;border-radius:12px;border:1px solid rgba(127,112,140,.3);background:rgba(127,112,140,.08);font-size:12.5px;line-height:1.45;animation:ao-rise .4s var(--ao-ease) both}
.profit-box strong{display:block;font-size:13px;margin-bottom:2px}
.profit-box.ok{border-color:rgba(34,176,125,.45);background:rgba(34,176,125,.08)}
.profit-box.ok strong{color:${BRAND.ok}}
.profit-box.loss{border-color:rgba(255,95,58,.55);background:rgba(255,95,58,.09)}
.profit-box.loss strong{color:${BRAND.ember}}
.profit-box p{margin:4px 0}
.profit-box ul{margin:6px 0;padding-left:18px}
.profit-box li{margin:2px 0}
.profit-box small{display:block;margin-top:6px;opacity:.7;font-size:11px}
.net-pill{display:inline-block;padding:1px 7px;border-radius:99px;font-size:11.5px;font-weight:650;white-space:nowrap}
.net-pill.ok{background:rgba(34,176,125,.15);color:${BRAND.ok}}
.net-pill.loss{background:rgba(255,95,58,.16);color:${BRAND.ember}}
@keyframes ao-spin{to{transform:rotate(360deg)}}
@keyframes ao-orbit{from{transform:rotate(0) translateX(calc(var(--ao-size,64px) / 2)) rotate(0)}to{transform:rotate(360deg) translateX(calc(var(--ao-size,64px) / 2)) rotate(-360deg)}}
@keyframes ao-breathe{50%{transform:scale(.92) translateY(-1px)}}
@keyframes ao-sweep{0%,55%{left:-60%}100%{left:130%}}
@keyframes ao-rise{from{opacity:0;transform:translateY(10px) scale(.985)}to{opacity:1;transform:none}}
@keyframes ao-shine{to{transform:translateX(100%)}}
@keyframes ao-slide{from{transform:translateX(-105%)}to{transform:translateX(270%)}}
@keyframes ao-twinkle{0%,70%,100%{opacity:1;transform:scale(1) rotate(0)}80%{opacity:.35;transform:scale(.55) rotate(45deg)}90%{opacity:1;transform:scale(1.25) rotate(90deg)}}
@keyframes ao-pop{0%{transform:scale(.6);opacity:0}100%{transform:scale(1);opacity:1}}
@keyframes ao-pulse{0%{box-shadow:0 0 0 0 rgba(255,95,58,.5)}70%{box-shadow:0 0 0 10px rgba(255,95,58,0)}100%{box-shadow:0 0 0 0 rgba(255,95,58,0)}}
@media (prefers-reduced-motion:reduce){.ao-loader::before,.ao-loader::after,.ao-loader>.ao-mark,.ao-spinner,.ao-sweep::after,.ao-rise,.ao-progress>i::after,.ao-progress.indeterminate>i,.ao-spark{animation:none!important}}
`;
var WINDOW_TOKENS = `--bg:${BRAND.night2};--bg2:${BRAND.night3};--line:${BRAND.nightLine};--ink:${BRAND.inkDark};--muted:${BRAND.mutedDark};--accent:${BRAND.ember};--ok:#3fd09a;--warn:${BRAND.warn};--err:#ff6b78`;

// src/core/ebayCategory.ts
function decodeAttribute(value) {
  return value.replace(
    /&(?:amp|quot|apos|lt|gt|#\d+|#x[\da-f]+);/gi,
    (entity) => {
      const named = {
        "&amp;": "&",
        "&quot;": '"',
        "&apos;": "'",
        "&lt;": "<",
        "&gt;": ">"
      };
      if (named[entity.toLowerCase()]) return named[entity.toLowerCase()];
      const hexadecimal = /^&#x/i.test(entity);
      const point = Number.parseInt(
        entity.slice(hexadecimal ? 3 : 2, -1),
        hexadecimal ? 16 : 10
      );
      return Number.isFinite(point) && point >= 0 && point <= 1114111 ? String.fromCodePoint(point) : entity;
    }
  );
}
function attribute(tag, name) {
  const match = tag.match(
    new RegExp(
      `(?:^|\\s)${name}\\s*=\\s*(?:"([^"]*)"|'([^']*)'|([^\\s>]+))`,
      "i"
    )
  );
  return match ? decodeAttribute(match[1] ?? match[2] ?? match[3]) : null;
}
function categoryLink(value) {
  try {
    const url = new URL(value, "https://www.ebay.com");
    if (url.protocol !== "https:" || !/^(www\.)?ebay\.com$/.test(url.hostname) || url.username || url.password || url.port)
      return null;
    const hit = url.pathname.match(/^\/b\/[^/]+\/([1-9]\d{0,6})(?:\/[^/]+)?\/?$/) ?? url.pathname.match(/^\/sch\/([1-9]\d{0,6})\/i\.html$/);
    return hit?.[1] ?? null;
  } catch {
    return null;
  }
}
function uniqueLeaf(leaves) {
  const ids = new Set(leaves);
  return ids.size === 1 ? leaves[0] : null;
}
function ebayCategoryFromHTML(html) {
  if (typeof html !== "string" || html.length > 16 * 1024 * 1024) return null;
  const source = html.replace(/<!--[\s\S]*?-->/g, "").replace(
    /<(script|style|template|noscript)\b[^>]*>[\s\S]*?<\/\1\s*>/gi,
    ""
  );
  const tokens = /<\/?([a-z][\w:-]*)\b(?:"[^"]*"|'[^']*'|[^'"<>])*>/gi;
  const stack = [];
  const leaves = [];
  let match, budget = 1e5;
  while ((match = tokens.exec(source)) && budget-- > 0) {
    const token = match[0], name = match[1].toLowerCase();
    if (token.startsWith("</")) {
      let index = stack.length - 1;
      while (index >= 0 && stack[index].name !== name) index--;
      if (index < 0) continue;
      const open = stack[index];
      if (name === "nav" && open.eligibleNav) {
        const contents = source.slice(open.start, match.index);
        const anchors = /<a\b(?:"[^"]*"|'[^']*'|[^'"<>])*>/gi;
        let anchor, leaf = null;
        while (anchor = anchors.exec(contents)) {
          const href = attribute(anchor[0], "href");
          const id = href === null ? null : categoryLink(href);
          if (id) leaf = id;
        }
        if (leaf) leaves.push(leaf);
      }
      stack.splice(index);
      continue;
    }
    const classes = (attribute(token, "class") ?? "").split(/\s+/);
    const breadcrumb = classes.includes("x-breadcrumb") || attribute(token, "data-testid") === "x-breadcrumb";
    const eligibleNav = name === "nav" && (classes.includes("breadcrumbs") || breadcrumb || stack.some((scope) => scope.breadcrumb));
    if (!/\/\s*>$/.test(token) && !/^(area|base|br|col|embed|hr|img|input|link|meta|param|source|track|wbr)$/.test(
      name
    ))
      stack.push({ name, breadcrumb, eligibleNav, start: tokens.lastIndex });
  }
  return budget < 0 ? null : uniqueLeaf(leaves);
}
function searchCategoryPath(html, itemId) {
  if (typeof html !== "string" || !/^\d{9,15}$/.test(itemId)) return null;
  if (!new RegExp(`/itm/(?:[^/"'?]+/)?${itemId}\\b`).test(html)) return null;
  const filter = categoryFilter(html);
  return filter === null ? null : [...filter.matchAll(/\/sch\/([1-9]\d{0,6})\/i\.html/g)].map((m) => m[1]);
}
function searchFilterCategories(html) {
  const filter = typeof html === "string" ? categoryFilter(html) : null;
  return filter ? [...new Set([...filter.matchAll(/\/sch\/([1-9]\d{0,6})\/i\.html/g)].map((m) => m[1]))] : [];
}
function categoryFilter(html) {
  const start = html.search(/details__label["']?>\s*Category\s*</);
  if (start < 0) return null;
  const end = html.indexOf("</details>", start);
  return html.slice(start, end > start ? end : start + 2e4);
}
function searchSubcategories(html) {
  const filter = typeof html === "string" ? categoryFilter(html) : null;
  if (!filter) return [];
  const bold = filter.search(/<b\b[^>]*>/);
  if (bold < 0) return [];
  const close = filter.indexOf("</b>", bold);
  if (close < 0) return [];
  let rest = filter.slice(close + 4).replace(/^(?:\s|<!--[\s\S]*?-->)*/, "");
  if (!/^<ul\b/i.test(rest)) return [];
  const tags = /<(\/?)ul\b[^>]*>/gi;
  let depth = 0, end = rest.length, m;
  while (m = tags.exec(rest)) {
    depth += m[1] ? -1 : 1;
    if (depth === 0) {
      end = m.index;
      break;
    }
  }
  rest = rest.slice(0, end);
  return [...new Set([...rest.matchAll(/\/sch\/([1-9]\d{0,6})\/i\.html/g)].map((x) => x[1]))];
}
function trackedCategory(html) {
  if (typeof html !== "string") return null;
  const found = html.match(/(?:ui_)?tcat(?:%3D|=)([1-9]\d{2,8})\b/)?.[1];
  return found ?? null;
}

// src/core/ebayApiVerification.ts
var normalizedValue = (value) => value.normalize("NFKC").replace(/\s+/g, " ").trim().toLowerCase();
function stringSet(values) {
  if (!Array.isArray(values) || values.some((value) => typeof value !== "string" || !value.trim()))
    return null;
  const normalized = values.map((value) => normalizedValue(value));
  if (new Set(normalized).size !== normalized.length) return null;
  return normalized.sort();
}
function embeddedApiValue(source, key4) {
  if (source.length > 8 * 1024 * 1024)
    throw Error("Mod\xE8le eBay trop volumineux.");
  const values = [];
  const excluded = /* @__PURE__ */ new Set([
    "options",
    "recommendations",
    "suggestions",
    "possibleValues"
  ]);
  const sources = [
    source,
    source.replace(/&quot;|&#34;/g, '"').replace(/&amp;/g, "&")
  ];
  for (const text3 of sources) {
    const eligible = /* @__PURE__ */ new Set();
    const ancestry = [];
    let stringStart = -1, inString = false, slash = false;
    let token = "", pendingKey = "";
    for (let i = 0; i < text3.length; i++) {
      const char = text3[i];
      if (inString) {
        if (slash) {
          slash = false;
          continue;
        }
        if (char === "\\") {
          slash = true;
          continue;
        }
        if (char === '"') {
          inString = false;
          try {
            token = JSON.parse(text3.slice(stringStart, i + 1));
          } catch {
            token = "";
          }
        }
        continue;
      }
      if (char === '"') {
        inString = true;
        stringStart = i;
        continue;
      }
      if (char === ":") {
        pendingKey = token;
        if (token === key4 && !ancestry.some((name) => excluded.has(name))) {
          let valueStart = i + 1;
          while (/\s/.test(text3[valueStart] ?? "") && valueStart < text3.length)
            valueStart++;
          eligible.add(valueStart);
        }
      } else if (char === "{" || char === "[") {
        ancestry.push(pendingKey);
        pendingKey = "";
      } else if (char === "}" || char === "]") {
        ancestry.pop();
        pendingKey = "";
      } else if (char === "," || char === ";") {
        pendingKey = "";
        token = "";
      }
    }
    const pattern = new RegExp(`"${key4}"\\s*:\\s*`, "g");
    for (const match of text3.matchAll(pattern)) {
      const start = match.index + match[0].length;
      if (!eligible.has(start)) continue;
      const first2 = text3[start];
      if (first2 !== "[" && first2 !== "{") continue;
      const stack = [];
      let quoted = false, escaped = false;
      for (let i = start; i < Math.min(text3.length, start + 3 * 1024 * 1024); i++) {
        const char = text3[i];
        if (escaped) {
          escaped = false;
          continue;
        }
        if (quoted && char === "\\") {
          escaped = true;
          continue;
        }
        if (char === '"') {
          quoted = !quoted;
          continue;
        }
        if (quoted) continue;
        if (char === "[" || char === "{") stack.push(char);
        else if (char === "]" || char === "}") {
          const open = stack.pop();
          if (open !== (char === "]" ? "[" : "{")) break;
          if (!stack.length) {
            try {
              values.push(JSON.parse(text3.slice(start, i + 1)));
            } catch {
            }
            break;
          }
        }
      }
    }
  }
  const unique2 = new Map(values.map((value) => [JSON.stringify(value), value]));
  if (unique2.size > 1) throw Error(`Mod\xE8le eBay contradictoire : ${key4}.`);
  return unique2.size === 1 ? [...unique2.values()][0] : void 0;
}
function specificsObject(value) {
  if (Array.isArray(value)) {
    const out = {};
    for (const entry of value) {
      if (!entry || typeof entry !== "object") return null;
      const { name, value: v } = entry;
      const first2 = Array.isArray(v) ? v[0] : v;
      if (typeof name !== "string" || typeof first2 !== "string") return null;
      out[name] = first2;
    }
    return out;
  }
  if (value && typeof value === "object")
    return Object.fromEntries(
      Object.entries(value).filter(
        (e) => typeof e[1] === "string"
      )
    );
  return null;
}
function pictureSetObject(value) {
  const out = {};
  if (!value || typeof value !== "object") return out;
  const bag = value;
  if (typeof bag.variationSpecificName === "string") {
    const axis = {};
    for (const entry of Array.isArray(bag.variationSpecificPicture) ? bag.variationSpecificPicture : []) {
      if (!entry || typeof entry !== "object") continue;
      const e = entry;
      if (typeof e.variationSpecificValue !== "string") continue;
      axis[e.variationSpecificValue] = (Array.isArray(e.picture) ? e.picture : []).map(
        (p) => p && typeof p === "object" ? p.url : p
      ).filter((u) => typeof u === "string");
    }
    out[bag.variationSpecificName] = axis;
    return out;
  }
  for (const [axis, options] of Object.entries(bag)) {
    if (!options || typeof options !== "object") continue;
    out[axis] = {};
    for (const [option, urls] of Object.entries(options))
      if (Array.isArray(urls))
        out[axis][option] = urls.filter((u) => typeof u === "string");
  }
  return out;
}
function verifyApiVariations(html, expected) {
  const warnings = [];
  const rows = embeddedApiValue(html, "variationItem");
  if (!Array.isArray(rows) || rows.length !== expected.variationItem.length)
    throw Error(
      `eBay n\u2019a pas confirm\xE9 toutes les variantes enregistr\xE9es (${Array.isArray(rows) ? rows.length : 0}/${expected.variationItem.length}).`
    );
  const key4 = (specifics2) => JSON.stringify(
    Object.entries(specifics2).map(([k, v]) => [normalizedValue(k), normalizedValue(v)]).sort(([a], [b]) => a.localeCompare(b))
  );
  const retained = /* @__PURE__ */ new Map();
  for (const row of rows) {
    const specifics2 = row && typeof row === "object" ? specificsObject(row.variationSpecific) : null;
    if (!specifics2 || !row.listingVariation)
      throw Error("Combinaison eBay non reconnue apr\xE8s enregistrement.");
    const id = key4(specifics2);
    if (retained.has(id))
      throw Error("eBay a conserv\xE9 une variante dupliqu\xE9e.");
    retained.set(id, row);
  }
  for (const row of expected.variationItem) {
    const actual = retained.get(key4(row.variationSpecific));
    const listing = actual?.listingVariation;
    if (!listing)
      throw Error(
        `Variante absente apr\xE8s enregistrement : ${Object.values(row.variationSpecific).join(" / ")}.`
      );
    if (!/^\d+(?:\.\d{1,2})?$/.test(String(listing.price)) || Number(listing.price) !== Number(row.listingVariation.price) || Number(listing.quantity) !== row.listingVariation.quantity)
      throw Error(
        `Prix ou quantit\xE9 non conserv\xE9 pour ${Object.values(row.variationSpecific).join(" / ")}.`
      );
  }
  const metadata = embeddedApiValue(html, "variationSpecificsMetaData");
  if (Array.isArray(metadata)) {
    for (const group of expected.variationSpecificsMetaData) {
      const found = metadata.find(
        (m) => m && typeof m === "object" && typeof m.name === "string" && normalizedValue(m.name) === normalizedValue(group.name)
      );
      if (!found || JSON.stringify(stringSet(found.value)) !== JSON.stringify(stringSet(group.value)))
        warnings.push(`Options de l\u2019axe ${group.name} \xE0 v\xE9rifier dans eBay.`);
    }
  }
  const pictures = pictureSetObject(
    embeddedApiValue(html, "variationSpecificPictureSet")
  );
  let missingPictures = 0;
  for (const [axis, options] of Object.entries(
    expected.variationSpecificPictureSet
  )) {
    const actualAxis = Object.entries(pictures).find(
      ([name]) => normalizedValue(name) === normalizedValue(axis)
    )?.[1];
    for (const [option, urls] of Object.entries(options)) {
      if (!urls.length) continue;
      const actual = actualAxis ? Object.entries(actualAxis).find(
        ([name]) => normalizedValue(name) === normalizedValue(option)
      )?.[1] : void 0;
      if (!actual?.length) missingPictures++;
    }
  }
  if (missingPictures)
    warnings.push(
      `${missingPictures} photo(s) de variante non retrouv\xE9e(s) : v\xE9rifie les photos des options dans eBay.`
    );
  return warnings;
}
function verifyApiDraft(html, job, categoryId, conditionId, pictures, expectedAttributes) {
  const warnings = [];
  const snapshot = readDraftSnapshot(html);
  if (snapshot.title !== job.title)
    throw Error("Titre non confirm\xE9 apr\xE8s l\u2019enregistrement eBay.");
  if (snapshot.categoryId && snapshot.categoryId !== categoryId)
    warnings.push("Cat\xE9gorie eBay diff\xE9rente de la r\xE9f\xE9rence : \xE0 v\xE9rifier.");
  const squash = (v) => v.replace(/\s+/g, " ").trim();
  if (!snapshot.description)
    warnings.push("Description non retrouv\xE9e dans le brouillon : \xE0 v\xE9rifier.");
  else if (squash(snapshot.description) !== squash(job.description))
    warnings.push("Description l\xE9g\xE8rement modifi\xE9e par eBay : v\xE9rifie-la.");
  if (!snapshot.pictures?.length)
    throw Error("Aucune photo n\u2019a \xE9t\xE9 conserv\xE9e dans la galerie eBay.");
  const savedKeys = snapshot.pictures.map(ebayPictureKey);
  const missing = pictures.filter((url) => !savedKeys.includes(ebayPictureKey(url)));
  if (missing.length)
    warnings.push(
      `${missing.length} photo(s) de galerie non retrouv\xE9e(s) sur ${pictures.length}.`
    );
  if (snapshot.conditionId !== null && Number(snapshot.conditionId) !== conditionId)
    warnings.push(
      conditionId === 1500 ? "eBay n\u2019a pas gard\xE9 \xAB New without tags \xBB : v\xE9rifie l\u2019\xE9tat." : "\xC9tat eBay diff\xE9rent de \xAB New \xBB : v\xE9rifie l\u2019\xE9tat."
    );
  const origins = Object.entries(snapshot.attributes ?? {}).filter(
    ([name]) => /^(?:attributes\.)?(?:Country of Origin|Country\/Region of Manufacture|Country of Manufacture)$/i.test(
      name
    )
  );
  if (!origins.some(([, values]) => values.length === 1 && values[0] === "China"))
    warnings.push("Origine China non confirm\xE9e : v\xE9rifie Country of Origin.");
  const attributes2 = expectedAttributes ?? buildDraftAttributes(job, parseDraftAttributeModel(html));
  const retained = /* @__PURE__ */ new Map();
  for (const [name, values] of Object.entries(snapshot.attributes ?? {}))
    retained.set(normalizedValue(name.replace(/^attributes\./, "")), stringSet(values));
  const dropped = [];
  for (const [name, values] of Object.entries(attributes2)) {
    if (/^(?:Country of Origin|Country\/Region of Manufacture|Country of Manufacture)$/i.test(name))
      continue;
    const actual = retained.get(normalizedValue(name.replace(/^attributes\./, "")));
    if (!actual || JSON.stringify(actual) !== JSON.stringify(stringSet(values)))
      dropped.push(name);
  }
  if (dropped.length)
    warnings.push(
      `Caract\xE9ristiques non reprises par eBay : ${dropped.slice(0, 6).join(", ")}${dropped.length > 6 ? "\u2026" : ""}.`
    );
  if ((job.supplierPlan?.rows.length ?? 0) < 2) {
    if (Number(snapshot.price) !== Number(job.supplierPlan?.rows[0].price) || Number(snapshot.quantity) !== 3)
      throw Error(
        "Prix calcul\xE9 ou quantit\xE9 3 non confirm\xE9 dans le brouillon eBay."
      );
  }
  return warnings;
}

// src/ebay/draftApiRequest.ts
var EBAY_SIGNIN_PAGE = "https://www.ebay.com/sh/ovw";
var EBAY_SIGNIN_TEXT = "eBay te demande de te reconnecter : la page de connexion vient de s\u2019ouvrir. Connecte-toi, puis recommence.";
async function ebayDraftRequestFromPage(request) {
  const fail3 = (code) => ({
    ok: false,
    status: 0,
    url: "",
    text: "",
    code
  });
  if (location.href !== request.expectedPage) return fail3("CONTEXT");
  let target;
  try {
    target = new URL(request.url);
  } catch {
    return fail3("CONTEXT");
  }
  if (target.origin !== location.origin || target.username || target.password || target.port || target.hash || target.protocol !== "https:")
    return fail3("CONTEXT");
  const queryKeys = [...target.searchParams.keys()];
  if (new Set(queryKeys).size !== queryKeys.length) return fail3("CONTEXT");
  const isMain = location.origin === "https://www.ebay.com";
  const isBulk = location.origin === "https://bulkedit.ebay.com";
  const id = request.draftId;
  const draftIdOK = typeof id === "string" && /^\d{5,20}$/.test(id);
  let method = "GET";
  const headers = {
    Accept: "text/html,application/json"
  };
  let body2;
  switch (request.kind) {
    case "reference":
      if (!isMain || !/^\/itm\/(?:[^/]+\/)?\d+\/?$/.test(target.pathname))
        return fail3("CONTEXT");
      break;
    case "category-search":
      if (!isMain || target.pathname !== "/sch/i.html" || !/^[\w .,'&-]{2,100}$/.test(target.searchParams.get("_nkw") ?? "") || !/^\d{0,7}$/.test(target.searchParams.get("_sacat") ?? "") || queryKeys.some((key4) => !["_nkw", "_sacat", "LH_PrefLoc"].includes(key4)))
        return fail3("CONTEXT");
      break;
    case "create":
      if (!isMain || target.pathname !== "/lstng" || target.searchParams.get("mode") !== "AddItem" || !/^\d{1,7}$/.test(target.searchParams.get("categoryId") ?? "") || !target.searchParams.get("title") || (target.searchParams.get("title")?.length ?? 81) > 80 || !["1000", "1500"].includes(
        target.searchParams.get("condition") ?? ""
      ) || [...target.searchParams.keys()].some(
        (key4) => !["mode", "categoryId", "title", "condition"].includes(key4)
      ))
        return fail3("CONTEXT");
      break;
    case "context":
      if (!isMain || !draftIdOK || target.pathname !== "/lstng" || target.searchParams.get("draftId") !== id || target.searchParams.get("mode") !== "AddItem" || queryKeys.some((key4) => !["draftId", "mode"].includes(key4)))
        return fail3("CONTEXT");
      break;
    case "put":
      if (!isMain || !draftIdOK || target.pathname !== `/lstng/api/listing_draft/${id}` || target.searchParams.get("mode") !== "AddItem" || queryKeys.some((key4) => key4 !== "mode") || typeof request.csrf !== "string" || !request.csrf || request.csrf.length > 16384 || !request.body)
        return fail3("CONTEXT");
      method = "PUT";
      headers.srt = request.csrf;
      headers["content-type"] = "application/json";
      body2 = JSON.stringify(request.body);
      break;
    case "variants-context":
      if (!isBulk || !draftIdOK || target.pathname !== "/msku" || target.searchParams.get("draftId") !== id || target.searchParams.get("listingMode") !== "AddItem")
        return fail3("CONTEXT");
      break;
    case "variants-save":
      if (!isBulk || !draftIdOK || target.pathname !== "/msku-update" || location.pathname !== "/msku" || new URL(location.href).searchParams.get("draftId") !== id || new URL(location.href).searchParams.get("listingMode") !== "AddItem" || request.body?.draftId !== id || request.body.action !== "save" || request.body.listingMode !== "AddItem")
        return fail3("CONTEXT");
      method = "POST";
      body2 = JSON.stringify(request.body);
      break;
    default:
      return fail3("CONTEXT");
  }
  if (body2 && body2.length > 3 * 1024 * 1024) return fail3("SIZE");
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 25e3);
  try {
    const response = await fetch(target.href, {
      method,
      headers,
      credentials: "include",
      signal: controller.signal,
      ...body2 ? { body: body2 } : {},
      ...request.kind === "put" ? { referrer: `${location.origin}/lstng?draftId=${id}&mode=AddItem` } : {}
    });
    const final = new URL(response.url || target.href);
    if (location.href !== request.expectedPage) return fail3("CONTEXT");
    if (final.origin !== target.origin || /\/signin|\/login/i.test(final.pathname))
      return fail3("AUTH");
    if (!response.ok) {
      await response.body?.cancel();
      return { ok: false, status: response.status, url: final.href, text: "" };
    }
    const reader = response.body?.getReader();
    let text3 = "";
    if (reader) {
      const decoder = new TextDecoder();
      let bytes = 0;
      try {
        while (true) {
          const part = await reader.read();
          if (part.done) break;
          bytes += part.value.byteLength;
          if (bytes > 8 * 1024 * 1024) return fail3("SIZE");
          text3 += decoder.decode(part.value, { stream: true });
        }
        text3 += decoder.decode();
      } finally {
        await reader.cancel();
      }
    } else text3 = await response.text();
    if (text3.length > 8 * 1024 * 1024) return fail3("SIZE");
    if (location.href !== request.expectedPage) return fail3("CONTEXT");
    return { ok: true, status: response.status, url: final.href, text: text3 };
  } catch {
    if (controller.signal.aborted) return fail3("TIMEOUT");
    try {
      if (isMain) {
        const followed = await fetch("/sh/ovw", { credentials: "include" }).then(() => true, () => false);
        const probe = await fetch("/sh/ovw", { credentials: "include", redirect: "manual" });
        if (!followed && probe.type === "opaqueredirect") return fail3("AUTH");
      }
    } catch {
    }
    return fail3("NETWORK");
  } finally {
    clearTimeout(timeout);
  }
}

// src/ebay/epsUpload.ts
function binaryEndpoint(value) {
  if (value === void 0 || value === null || value === "")
    return "https://mach-100.ebay.com/ws/eBayISAPI.dll?EpsBasic";
  if (typeof value !== "string" || value.length > 300) return null;
  try {
    const url = new URL(value);
    if (url.protocol !== "https:" || !/^mach-\d+\.ebay\.com$/.test(url.hostname) || url.port || url.username || url.password || url.hash || url.pathname !== "/ws/eBayISAPI.dll" || url.search !== "?EpsBasic")
      return null;
    return url.href;
  } catch {
    return null;
  }
}
function extractEpsContext(source) {
  const fields = ["s", "n", "v", "uaek", "uaes", "aXRequest", "wm"];
  let remaining = 6e3;
  const normalize = (value) => {
    if (!value || typeof value !== "object" || Array.isArray(value))
      return null;
    const bag = value;
    const endpoint = binaryEndpoint(bag.endpoint);
    if (!endpoint) return null;
    const result = { endpoint };
    for (const field of fields) {
      const input = bag[field];
      if (input === void 0 || input === null) continue;
      if (!["string", "number", "boolean"].includes(typeof input)) return null;
      const text3 = String(input);
      if (!text3 && field !== "s" && field !== "n") {
        result[field] = "";
        continue;
      }
      if (!text3 || text3.length > 16e3 || /[\u0000-\u0008\u000b\u000c\u000e-\u001f]/.test(text3))
        return null;
      result[field] = text3;
    }
    return result.s && result.n ? result : null;
  };
  const readObject = (text3, start) => {
    let depth = 0, quoted = false, escaped = false;
    for (let end = start; end < text3.length && end - start < 8e4; end++) {
      const c = text3[end];
      if (escaped) {
        escaped = false;
        continue;
      }
      if (quoted && c === "\\") {
        escaped = true;
        continue;
      }
      if (c === '"') {
        quoted = !quoted;
        continue;
      }
      if (quoted) continue;
      if (c === "{") depth++;
      if (c === "}" && --depth === 0) {
        try {
          return JSON.parse(text3.slice(start, end + 1));
        } catch {
          return null;
        }
      }
    }
    return null;
  };
  const visit = (value, depth) => {
    if (--remaining < 0 || depth > 12 || value === null || value === void 0)
      return null;
    if (typeof value === "string") {
      if (value.length > 16 * 1024 * 1024) return null;
      const decoded = value.replace(/&quot;|&#34;|&#x22;/gi, '"').replace(/&apos;|&#39;|&#x27;/gi, "'").replace(/&amp;/gi, "&");
      try {
        const found = visit(JSON.parse(decoded), depth + 1);
        if (found) return found;
      } catch {
      }
      const versions = decoded.includes('\\"epsData\\"') ? [decoded, decoded.replace(/\\(["\\/])/g, "$1")] : [decoded];
      for (const text3 of versions) {
        const marker = /"epsData"\s*:\s*(\{)/g;
        let hit;
        while ((hit = marker.exec(text3)) && remaining-- > 0) {
          const candidate2 = normalize(
            readObject(text3, hit.index + hit[0].length - 1)
          );
          if (candidate2) return candidate2;
        }
      }
      return null;
    }
    if (typeof value !== "object") return null;
    const bag = value;
    const named = normalize(bag.epsData);
    if (named) return named;
    if (depth === 0) {
      const direct = normalize(value);
      if (direct) return direct;
    }
    for (const child of Object.values(bag).slice(0, 512)) {
      const found = visit(child, depth + 1);
      if (found) return found;
    }
    return null;
  };
  return visit(source, 0);
}
async function uploadEpsFileFromPage(payload) {
  const failure = (code, error, status) => ({
    ok: false,
    code,
    error,
    ...status === void 0 ? {} : { status }
  });
  if (location.protocol !== "https:" || !/^(www\.)?ebay\.com$/.test(location.hostname))
    return failure(
      "PAGE",
      "L\u2019envoi des photos doit \xEAtre ex\xE9cut\xE9 depuis eBay US."
    );
  const context = payload?.context;
  if (!context || typeof context !== "object")
    return failure("CONTEXT", "Informations de l\u2019uploader eBay indisponibles.");
  const fields = ["s", "n", "v", "uaek", "uaes", "aXRequest", "wm"];
  for (const key4 of fields) {
    const value = context[key4];
    if (value === void 0 && key4 !== "s" && key4 !== "n") continue;
    if (value === "" && key4 !== "s" && key4 !== "n") continue;
    if (typeof value !== "string" || !value || value.length > 16e3 || /[\u0000-\u0008\u000b\u000c\u000e-\u001f]/.test(value))
      return failure("CONTEXT", "Informations de l\u2019uploader eBay invalides.");
  }
  let endpoint;
  try {
    const url = new URL(context.endpoint);
    if (url.protocol !== "https:" || !/^mach-\d+\.ebay\.com$/.test(url.hostname) || url.port || url.username || url.password || url.hash || url.pathname !== "/ws/eBayISAPI.dll" || url.search !== "?EpsBasic")
      return failure("CONTEXT", "Adresse de l\u2019uploader eBay non reconnue.");
    endpoint = url.href;
  } catch {
    return failure("CONTEXT", "Adresse de l\u2019uploader eBay non reconnue.");
  }
  const image = payload?.image;
  const maximum = 8 * 1024 * 1024;
  if (!image || !["image/jpeg", "image/png", "image/webp", "image/gif", "image/avif", "image/bmp"].includes(image.mime) || typeof image.data !== "string" || !image.data || image.data.length > Math.ceil(maximum / 3) * 4 || image.data.length % 4 !== 0 || !/^[A-Za-z0-9+/]+={0,2}$/.test(image.data))
    return failure(
      "IMAGE",
      "Photo invalide ou trop volumineuse (8 Mo maximum)."
    );
  const fileId = payload.fileId ?? 0;
  if (!Number.isSafeInteger(fileId) || fileId < 0 || fileId > 1e5 || payload.requestId !== void 0 && !/^\d{1,20}$/.test(payload.requestId))
    return failure("IMAGE", "Identifiant d\u2019envoi de la photo invalide.");
  let blob;
  try {
    const binary = atob(image.data);
    if (!binary.length || binary.length > maximum || image.size !== void 0 && image.size !== binary.length)
      return failure(
        "IMAGE",
        "La taille de la photo ne correspond pas au fichier re\xE7u."
      );
    const bytes = Uint8Array.from(
      binary,
      (character) => character.charCodeAt(0)
    );
    const isJPEG = bytes[0] === 255 && bytes[1] === 216 && bytes[2] === 255;
    const isPNG = [137, 80, 78, 71, 13, 10, 26, 10].every(
      (value, index) => bytes[index] === value
    );
    const isWEBP = String.fromCharCode(...bytes.subarray(0, 4)) === "RIFF" && String.fromCharCode(...bytes.subarray(8, 12)) === "WEBP";
    const head = String.fromCharCode(...bytes.subarray(0, 12));
    const isGIF = head.startsWith("GIF8");
    const isAVIF = head.slice(4, 8) === "ftyp" && /^(avif|avis|mif1|msf1)$/.test(head.slice(8, 12));
    const isBMP = head.startsWith("BM");
    if (!(image.mime === "image/jpeg" ? isJPEG : image.mime === "image/png" ? isPNG : image.mime === "image/webp" ? isWEBP : image.mime === "image/gif" ? isGIF : image.mime === "image/avif" ? isAVIF : isBMP))
      return failure(
        "IMAGE",
        "Le contenu de la photo ne correspond pas \xE0 son format."
      );
    blob = new Blob([bytes], { type: image.mime });
    const convert = image.mime !== "image/jpeg" && image.mime !== "image/png";
    let bitmap = null;
    try {
      bitmap = await createImageBitmap(blob);
    } catch {
      if (convert) throw Error("decode");
    }
    if (bitmap) {
      try {
        if (!bitmap.width || !bitmap.height || bitmap.width * bitmap.height > 4e7)
          return failure(
            "IMAGE",
            "Les dimensions de la photo ne sont pas exploitables."
          );
        const longest = Math.max(bitmap.width, bitmap.height);
        const scale = longest < 500 ? 1e3 / longest : 1;
        if (convert || scale > 1) {
          const canvas = document.createElement("canvas");
          canvas.width = Math.round(bitmap.width * scale);
          canvas.height = Math.round(bitmap.height * scale);
          const drawing = canvas.getContext("2d");
          if (!drawing)
            return failure("IMAGE", "Conversion de la photo indisponible.");
          drawing.imageSmoothingQuality = "high";
          drawing.fillStyle = "#ffffff";
          drawing.fillRect(0, 0, canvas.width, canvas.height);
          drawing.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
          const converted = await new Promise(
            (resolve) => canvas.toBlob(resolve, "image/jpeg", 0.92)
          );
          if (!converted || !converted.size || converted.size > maximum)
            return failure(
              "IMAGE",
              "La photo convertie d\xE9passe la taille autoris\xE9e."
            );
          blob = converted;
        }
      } finally {
        bitmap.close();
      }
    }
  } catch {
    return failure("IMAGE", "La photo fournisseur n\u2019a pas pu \xEAtre d\xE9cod\xE9e.");
  }
  const hostedURL = (input) => {
    if (typeof input !== "string" || input.length > 4e3) return null;
    try {
      const url = new URL(input.trim().replace(/&amp;/g, "&"));
      if (url.protocol !== "https:" || url.port || url.username || url.password || url.hash || !/(^|\.)ebay(?:img|static)\.com$/.test(url.hostname) || !/\.(?:jpe?g|png|webp)$/i.test(url.pathname))
        return null;
      return url.href.replace(/\/\$_1\./, "/$_57.");
    } catch {
      return null;
    }
  };
  const responseURL = (text3) => {
    if (text3.length > 256 * 1024) return null;
    const trimmed = text3.trim();
    if (trimmed.startsWith("{") || trimmed.startsWith("[")) {
      try {
        const parsed = JSON.parse(trimmed);
        let budget = 300;
        const denied = (value, depth) => {
          if (!value || typeof value !== "object") return false;
          if (depth > 10 || --budget < 0) return true;
          if (Array.isArray(value))
            return value.some((entry) => denied(entry, depth + 1));
          return Object.entries(value).some(
            ([key4, child]) => /^(ack|status)$/i.test(key4) && typeof child === "string" && /^(failure|error|failed)$/i.test(child) || /^(ok|success)$/i.test(key4) && child === false || /^(error|errors)$/i.test(key4) && !!child && (!Array.isArray(child) || child.length > 0) || denied(child, depth + 1)
          );
        };
        if (denied(parsed, 0)) return null;
        const find = (value, depth, field) => {
          if (!value || typeof value !== "object" || depth > 10 || --budget < 0)
            return null;
          for (const [key4, child] of Object.entries(value)) {
            if (key4.toLowerCase() === field) {
              const hit = hostedURL(child);
              if (hit) return hit;
            }
          }
          for (const child of Object.values(value)) {
            const hit = find(child, depth + 1, field);
            if (hit) return hit;
          }
          return null;
        };
        for (const field of [
          "fullurl",
          "sitehostedpictureurl",
          "pictureurl",
          "imageurl",
          "url"
        ]) {
          budget = 300;
          const hit = find(parsed, 0, field);
          if (hit) return hit;
        }
        return null;
      } catch {
        return null;
      }
    }
    if (trimmed.startsWith("<")) {
      const xml = new DOMParser().parseFromString(trimmed, "application/xml");
      if (xml.querySelector("parsererror") || !/^(?:UploadSiteHostedPicturesResponse|EpsBasicResponse|Response)$/i.test(
        xml.documentElement.localName
      ))
        return null;
      const ack = [
        ...xml.getElementsByTagNameNS("*", "Ack")
      ][0]?.textContent?.trim();
      if (ack && !/^(success|warning)$/i.test(ack)) return null;
      if ([...xml.getElementsByTagNameNS("*", "SeverityCode")].some(
        (node) => /^error$/i.test(node.textContent?.trim() ?? "")
      ))
        return null;
      for (const tag of ["FullURL", "PictureURL", "ImageURL"]) {
        for (const node of xml.getElementsByTagNameNS("*", tag)) {
          const hit = hostedURL(node.textContent);
          if (hit) return hit;
        }
      }
      return null;
    }
    const direct = hostedURL(trimmed);
    if (direct) return direct;
    const parts = trimmed.split(";");
    if (!/^(?:0|ok|success|version:\d+)$/i.test(parts[0]?.trim() ?? "")) return null;
    for (const part of parts.slice(1)) {
      const hit = hostedURL(part);
      if (hit) return hit;
    }
    return null;
  };
  const form = new FormData();
  for (const key4 of fields) {
    const value = context[key4];
    if (value !== void 0) form.append(key4, value);
  }
  const name = (image.name ?? "auro-photo").replace(/[^a-zA-Z0-9_.-]/g, "_").slice(0, 90).replace(/\.[^.]*$/, "") || "auro-photo";
  form.append(
    "Filedata",
    blob,
    `${name}.${blob.type === "image/png" ? "png" : "jpg"}`
  );
  endpoint += "&" + new URLSearchParams({
    fileId: String(fileId),
    fId: payload.requestId ?? String(Math.floor(1e11 + Math.random() * 9e11)),
    fileSize: String(blob.size),
    ar: "/lstng"
  }).toString();
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 3e4);
  try {
    const response = await fetch(endpoint, {
      method: "POST",
      body: form,
      credentials: "omit",
      signal: controller.signal
    });
    if (!response.ok)
      return failure(
        response.status === 401 || response.status === 403 ? "AUTH" : "HTTP",
        "eBay a refus\xE9 l\u2019envoi de cette photo.",
        response.status
      );
    const url = responseURL(await response.text());
    if (!url)
      return failure(
        "RESPONSE",
        "eBay n\u2019a pas confirm\xE9 une photo h\xE9berg\xE9e valide.",
        response.status
      );
    return { ok: true, url, size: blob.size, mime: blob.type };
  } catch {
    return controller.signal.aborted ? failure(
      "TIMEOUT",
      "L\u2019envoi de la photo eBay a d\xE9pass\xE9 le d\xE9lai autoris\xE9."
    ) : failure("NETWORK", "La photo n\u2019a pas pu \xEAtre envoy\xE9e \xE0 eBay.");
  } finally {
    clearTimeout(timer);
  }
}

// src/ebay/saleBanner.ts
async function saleBannerFromPage(image, style) {
  try {
    const look = {
      stops: ["#ff5f3a", "#ff8a3d", "#ffb347"],
      ink: "#ffffff",
      shadow: "rgba(150,30,10,.25)",
      main: "SALE",
      title: "HOT DEALS",
      sub: "SHOP NOW",
      position: "top",
      ...style ?? {}
    };
    if (!image || typeof image.data !== "string" || !/^image\//.test(image.mime))
      return { ok: false, error: "Photo invalide." };
    const binary = atob(image.data);
    const bytes = Uint8Array.from(binary, (c) => c.charCodeAt(0));
    const bitmap = await createImageBitmap(new Blob([bytes], { type: image.mime }));
    try {
      if (!bitmap.width || !bitmap.height || bitmap.width * bitmap.height > 4e7)
        return { ok: false, error: "Dimensions de la photo inexploitables." };
      const S = 1600;
      const k = S / 1200;
      const band = Math.round(150 * k);
      const canvas = document.createElement("canvas");
      canvas.width = S;
      canvas.height = S;
      const g = canvas.getContext("2d");
      if (!g) return { ok: false, error: "Dessin indisponible." };
      g.fillStyle = "#ffffff";
      g.fillRect(0, 0, S, S);
      const room = S - band;
      const top = look.position === "bottom" ? 0 : band;
      const bandY = look.position === "bottom" ? S - band : 0;
      const cover = Math.max(S / bitmap.width, room / bitmap.height);
      const cw = bitmap.width * cover;
      const ch = bitmap.height * cover;
      const kept2 = Math.min(S / cw, room / ch);
      g.imageSmoothingQuality = "high";
      g.save();
      g.beginPath();
      g.rect(0, top, S, room);
      g.clip();
      if (kept2 >= 0.85) g.drawImage(bitmap, (S - cw) / 2, top + (room - ch) / 2, cw, ch);
      else {
        g.save();
        g.filter = `blur(${Math.round(30 * k)}px) brightness(0.9)`;
        g.drawImage(bitmap, (S - cw * 1.1) / 2, top + (room - ch * 1.1) / 2, cw * 1.1, ch * 1.1);
        g.restore();
        const fit = Math.min(S / bitmap.width, room / bitmap.height);
        const w = bitmap.width * fit;
        const h = bitmap.height * fit;
        g.drawImage(bitmap, (S - w) / 2, top + (room - h) / 2, w, h);
      }
      g.restore();
      const gradient = g.createLinearGradient(0, bandY, S, bandY + band * 2);
      look.stops.forEach((c, i) => gradient.addColorStop(i / Math.max(1, look.stops.length - 1), c));
      g.fillStyle = gradient;
      g.fillRect(0, bandY, S, band);
      g.save();
      g.translate(0, bandY);
      const family = 'system-ui, -apple-system, "Helvetica Neue", Arial, sans-serif';
      const font = (weight, size) => `${weight} ${Math.round(size * k)}px ${family}`;
      const spaced = (px) => {
        g.letterSpacing = `${px * k}px`;
      };
      g.textBaseline = "alphabetic";
      let z = 1;
      const sizes = () => {
        spaced(-2 * z);
        g.font = font(900, 108 * z);
        const a = look.main ? g.measureText(look.main).width : 0;
        spaced(-1 * z);
        g.font = font(800, 52 * z);
        const b = look.title ? g.measureText(look.title).width : 0;
        spaced(2 * z);
        g.font = font(600, 24 * z);
        const c = look.sub ? g.measureText(look.sub).width : 0;
        return { a, b, c };
      };
      let m = sizes();
      const gap = 28 * k;
      const bar = 4 * k;
      const width = () => m.a + (m.a && (m.b || m.c) ? gap + bar + gap : 0) + Math.max(m.b, m.c);
      while (width() > S - 80 * k && z > 0.4) {
        z -= 0.05;
        m = sizes();
      }
      const sale = m.a;
      const total2 = width();
      let x = (S - total2) / 2;
      const middle = band / 2;
      if (look.main) {
        spaced(-2 * z);
        g.font = font(900, 108 * z);
        g.fillStyle = look.shadow;
        g.fillText(look.main, x, middle + 38 * k * z + 4 * k);
        g.fillStyle = look.ink;
        g.fillText(look.main, x, middle + 38 * k * z);
        x += sale;
        if (m.b || m.c) {
          x += gap;
          g.fillStyle = look.ink;
          g.globalAlpha = 0.7;
          const barHeight = 86 * k * z;
          g.beginPath();
          g.roundRect(x, middle - barHeight / 2, bar, barHeight, bar / 2);
          g.fill();
          g.globalAlpha = 1;
          x += bar + gap;
        }
      }
      g.fillStyle = look.ink;
      const both = !!(m.b && m.c);
      if (m.b) {
        spaced(-1 * z);
        g.font = font(800, 52 * z);
        g.fillText(look.title, x, both ? middle + 4 * k * z : middle + 18 * k * z);
      }
      if (m.c) {
        spaced(2 * z);
        g.font = font(600, 24 * z);
        g.globalAlpha = 0.95;
        g.fillText(look.sub, x, both ? middle + 40 * k * z : middle + 9 * k * z);
        g.globalAlpha = 1;
      }
      spaced(0);
      g.restore();
      const blob = await new Promise((resolve) => canvas.toBlob(resolve, "image/jpeg", 0.92));
      if (!blob || !blob.size || blob.size > 8 * 1024 * 1024)
        return { ok: false, error: "Photo avec bandeau trop volumineuse." };
      const out = new Uint8Array(await blob.arrayBuffer());
      let text3 = "";
      for (let i = 0; i < out.length; i += 32768)
        text3 += String.fromCharCode(...out.subarray(i, i + 32768));
      return { ok: true, data: btoa(text3), mime: "image/jpeg", size: out.length };
    } finally {
      bitmap.close();
    }
  } catch (error) {
    return { ok: false, error: error instanceof Error ? error.message : String(error) };
  }
}

// src/background/tabOperations.ts
var TAB_DRAG_ERROR = "Tabs cannot be edited right now (user may be dragging a tab).";
async function retryTabOperation(operation, valid, attempts = 10) {
  if (!Number.isSafeInteger(attempts) || attempts < 1)
    throw Error("Nombre de tentatives d\u2019onglet invalide.");
  const limit = Math.min(attempts, 10);
  for (let attempt = 0; attempt < limit; attempt++) {
    if (!await valid())
      throw Error(
        "Op\xE9ration onglet annul\xE9e : extension en pause ou contexte modifi\xE9."
      );
    try {
      return await operation();
    } catch (error) {
      const message2 = error instanceof Error ? error.message : typeof error === "string" ? error : error && typeof error === "object" && "message" in error ? error.message : null;
      if (typeof message2 !== "string" || message2.trim() !== TAB_DRAG_ERROR || attempt + 1 === limit)
        throw error;
      await new Promise(
        (resolve) => setTimeout(resolve, Math.min(1e3, 300 * (attempt + 1)))
      );
    }
  }
  throw Error("Op\xE9ration onglet interrompue.");
}

// src/ebay/detection.ts
function draftIdentity(url) {
  const u = new URL(url);
  const keys = [
    "draftId",
    "draftid",
    "draft_id",
    "itemId",
    "itemid",
    "item_id",
    "listingId",
    "mode"
  ];
  return `${u.origin}${u.pathname}?${keys.filter((k) => u.searchParams.has(k)).map((k) => `${k}=${u.searchParams.get(k)}`).join("&")}${u.hash}`;
}

// src/core/sizes.ts
function ebaySize(value) {
  const m = value.trim().match(/^(X{2,7})(L|S)$/i);
  return m ? `${m[1].length}X${m[2].toUpperCase()}` : value;
}
var isSizeAxis = (name) => /\b(size|sizes|taille|tailles|talla)\b/i.test(name);
var STANDARD = /^(XS|S|M|L|XL|X{2,7}[LS]|\d{1,2}X[LS])$/i;
function standardSize(value) {
  const m = value.trim().match(/^([0-9]{0,2}X{0,7}[A-Z]{1,2})\s*[([（【]\s*(.+?)\s*[)\]）】]$/i);
  const base = (m ? m[1] : value.trim()).toUpperCase();
  if (!STANDARD.test(base)) return null;
  return { size: ebaySize(base), note: m ? m[2] : "" };
}
function ebaySizePlan(plan, images) {
  const notes = [];
  const maps = plan.axes.map((axis) => {
    if (!isSizeAxis(axis.name)) return null;
    const parsed = axis.values.map(standardSize);
    if (parsed.every(Boolean)) {
      const sizes = parsed.map((p) => p.size);
      if (new Set(sizes).size === sizes.length) {
        parsed.forEach((p) => p.note && notes.push({ axis: axis.name, size: p.size, note: p.note }));
        return new Map(axis.values.map((v, i) => [v, sizes[i]]));
      }
    }
    const prefixed = axis.values.map(
      (v) => v.replace(/^\s*(X{2,7})(L|S)(?=\b|\s*[([（【]|$)/i, (_, x, l) => `${x.length}X${l.toUpperCase()}`)
    );
    if (new Set(prefixed.map((v) => v.toUpperCase())).size !== prefixed.length) return null;
    return new Map(axis.values.map((v, i) => [v, prefixed[i]]));
  });
  if (!maps.some((m) => m && [...m].some(([a, b]) => a !== b))) return { plan, images, notes: [] };
  const map2 = (i, v) => maps[i]?.get(v) ?? v;
  return {
    plan: {
      ...plan,
      axes: plan.axes.map((a, i) => ({ ...a, values: a.values.map((v) => map2(i, v)) })),
      rows: plan.rows.map((r) => ({ ...r, values: r.values.map((v, i) => map2(i, v)) }))
    },
    images: images.map((img) => {
      const i = plan.axes.findIndex((a) => norm(a.name) === norm(img.axis));
      return i >= 0 ? { ...img, value: map2(i, img.value) } : img;
    }),
    notes
  };
}
function sizeGuideHTML(notes) {
  if (!notes.length) return "";
  return `<div style="margin-top:16px"><p><strong>Size guide</strong></p><ul>${notes.map((n) => `<li><strong>${escapeHTML(n.size)}</strong>: ${escapeHTML(n.note)}</li>`).join("")}</ul></div>`;
}
function ebayAxisName(name, others = []) {
  if (!/\bcolou?rs?\b/i.test(name) || /^colou?rs?$/i.test(name.trim())) return name;
  return others.some((o) => o !== name && /^colou?rs?$/i.test(o.trim())) ? name : "Color";
}
function ebayAxisPlan(plan, images) {
  const names2 = plan.axes.map((a) => a.name);
  const renamed = [];
  const axes = plan.axes.map((a, i) => {
    const to = ebayAxisName(a.name, names2);
    if (to !== a.name && !renamed.some((r) => r.to === to) && !names2.slice(0, i).some((n) => ebayAxisName(n, names2) === to)) {
      renamed.push({ from: a.name, to });
      return { ...a, name: to };
    }
    return a;
  });
  if (!renamed.length) return { plan, images, renamed };
  return {
    plan: { ...plan, axes },
    images: images.map((img) => {
      const r = renamed.find((x) => norm(x.from) === norm(img.axis));
      return r ? { ...img, axis: r.to } : img;
    }),
    renamed
  };
}

// src/background/nativeImport.ts
var key = (tabId) => `nativeImport:v1:${tabId}`;
var starting = false;
async function getNativeJob(tabId, includeSource = false) {
  let job = (await chrome.storage.session.get(key(tabId)))[key(tabId)];
  if (!job && includeSource) {
    const target = (await chrome.storage.session.get(`nativeImportSource:v1:${tabId}`))[`nativeImportSource:v1:${tabId}`];
    if (typeof target === "number" && Number.isInteger(target)) {
      const candidate2 = (await chrome.storage.session.get(key(target)))[key(target)];
      const tab = await chrome.tabs.get(tabId);
      if (candidate2?.transport === "api" && candidate2.ebaySeed?.tabId === tabId && ebayItemId(tab.url ?? "") === candidate2.ebaySeed.itemId)
        job = candidate2;
    }
  }
  return job && freshNativeJob(job) ? job : null;
}
async function startNativeImport(choice, prepared) {
  if (starting) throw Error("Un import est d\xE9j\xE0 en pr\xE9paration.");
  starting = true;
  let tabId;
  try {
    const s = await getSettings();
    if (!s.enabled || !prepared?.plan && !s.captureEnabled)
      throw Error("Active AurOEBay et la capture AliExpress.");
    const { sources = [] } = await chrome.storage.session.get("sources");
    const source = prepared?.source ?? sources.find((p) => p.url === choice?.sourceUrl);
    if (!source || Date.now() - source.capturedAt > s.sourceExpiryMinutes * 6e4)
      throw Error("Relis la fiche AliExpress avant l\u2019import.");
    const product2 = normalizeProduct(source);
    const stored = (await chrome.storage.session.get("ebaySeed:v1"))["ebaySeed:v1"];
    const seed = choice.ebaySeedId ? prepared?.seed ?? stored : void 0;
    validateNativeChoice(product2, choice, seed);
    const rawPlan = prepared?.plan ? prepared.plan : seed ? supplierImportPlan(
      source,
      prepared?.rule ?? (await chrome.storage.local.get("variantPricing")).variantPricing,
      { keepOutOfStock: true }
    ) : void 0;
    const sizedOnly = rawPlan ? ebaySizePlan(rawPlan, product2.variantImages) : null;
    const named = sizedOnly ? ebayAxisPlan(sizedOnly.plan, sizedOnly.images) : null;
    const sized = sizedOnly && named ? { ...sizedOnly, plan: named.plan, images: named.images } : null;
    const supplierPlan = sized?.plan;
    if (sized) product2.variantImages = sized.images;
    const tab = await retryTabOperation(
      () => chrome.tabs.create({ url: "about:blank", active: false }),
      async () => (await getSettings()).enabled
    );
    if (tab.id === void 0) throw Error("Impossible d\u2019ouvrir eBay.");
    tabId = tab.id;
    const job = {
      schemaVersion: 1,
      id: crypto.randomUUID(),
      tabId,
      product: product2,
      supplierPlan,
      ebaySeed: seed,
      ...prepared?.libraryProductId ? { libraryProductId: prepared.libraryProductId } : {},
      title: choice.title,
      description: (prepared?.keepDescription ? product2.descriptionHTML : choice.fullDescription ? listingDescriptionHTML(choice.title, product2.descriptionHTML) : nativeDescription(product2, choice.title, choice.removeMentions)) + // Weight ranges removed from the size options stay visible here.
      sizeGuideHTML(sized?.notes ?? []),
      images: choice.images,
      stage: "opening",
      ...seed ? { transport: "api", apiPhase: "queued" } : {},
      createdAt: Date.now(),
      updatedAt: Date.now()
    };
    await chrome.storage.session.set({ [key(tabId)]: job });
    if (!(await getSettings()).enabled)
      throw Error("Import interrompu : AurOEBay en pause.");
    if (seed) {
      await initializeApiImport(job);
      queueApiImport(job);
      return job;
    }
    await retryTabOperation(
      () => chrome.tabs.update(tabId, {
        url: "https://www.ebay.com/sl/sell",
        active: true
      }),
      async () => (await getSettings()).enabled
    );
    return job;
  } catch (e) {
    if (tabId !== void 0) {
      await chrome.storage.session.remove(key(tabId));
      await chrome.tabs.remove(tabId).catch(() => {
      });
    }
    throw e;
  } finally {
    starting = false;
  }
}
var recovering = /* @__PURE__ */ new Set();
async function recoverNativeCopy(tabId, id, url) {
  if (recovering.has(tabId)) throw Error("Reprise eBay d\xE9j\xE0 en cours.");
  recovering.add(tabId);
  try {
    const job = await getNativeJob(tabId);
    const u = new URL(url);
    const current2 = await chrome.tabs.get(tabId);
    if (!(await getSettings()).enabled || !job?.supplierPlan || !job.ebaySeed || job.id !== id || job.stage !== "category" || job.identity || current2.url !== url || u.origin !== "https://www.ebay.com" || !["/sh/lst/active", "/sh/lst/drafts"].includes(u.pathname))
      throw Error("Reprise non autoris\xE9e pour cet import.");
    if (job.copyRouteRetried)
      throw Error(
        "eBay renvoie encore au Seller Hub au lieu d\u2019ouvrir la copie. Aucun brouillon rempli. R\xE9essaie depuis le bouton Sell one like this de la fiche eBay."
      );
    job.copyRouteRetried = true;
    job.updatedAt = Date.now();
    await chrome.storage.session.set({ [key(tabId)]: job });
    await chrome.tabs.update(tabId, {
      url: ebayCopyURL(job.ebaySeed),
      active: true
    });
    return true;
  } finally {
    recovering.delete(tabId);
  }
}
async function updateNativeJob(tabId, id, url, patch) {
  const job = await getNativeJob(tabId);
  if (!job || job.id !== id)
    throw Error("Import expir\xE9 ou associ\xE9 \xE0 un autre onglet.");
  if (job.transport === "api")
    throw Error("Ce brouillon est g\xE9r\xE9 par le transport en arri\xE8re-plan.");
  if (!(await getSettings()).enabled) throw Error("AurOEBay en pause.");
  const u = new URL(url);
  if (u.protocol !== "https:" || !/(^|\.)ebay\.com$/.test(u.hostname))
    throw Error("Page eBay invalide.");
  if (!["category", "filling", "ready", "error"].includes(patch.stage ?? ""))
    throw Error("\xC9tat d\u2019import invalide.");
  if (patch.stage === "filling" && job.stage !== "category" || patch.stage === "ready" && job.stage !== "filling" && job.stage !== "ready" || patch.stage === "category" && job.stage !== "opening")
    throw Error("Transition d\u2019import invalide.");
  if (["filling", "ready"].includes(patch.stage) && (!patch.identity || u.pathname !== "/lstng"))
    throw Error("Identit\xE9 du nouveau brouillon requise.");
  if (patch.retainedPhotos !== void 0 && (!job.ebaySeed || patch.stage !== "filling" || !Number.isInteger(patch.retainedPhotos) || patch.retainedPhotos < 0 || job.supplierPlan && patch.retainedPhotos !== 0 || patch.retainedPhotos > 25))
    throw Error("Photos h\xE9rit\xE9es invalides.");
  if (patch.stage === "ready" && patch.uploaded !== (job.retainedPhotos || job.images.length))
    throw Error("Toutes les photos doivent \xEAtre confirm\xE9es.");
  if (patch.identity) {
    if (patch.identity !== draftIdentity(url) || !u.searchParams.has("draftId") && !u.searchParams.has("draft_id") || u.searchParams.get("mode") !== (job.supplierPlan ? "SellLikeItem" : job.ebaySeed ? "SellSimilarItem" : "AddItem") || ["itemId", "itemid", "item_id", "listingId"].some(
      (k) => u.searchParams.has(k)
    ) || job.identity && job.identity !== patch.identity)
      throw Error(
        "Seul le nouveau brouillon li\xE9 \xE0 cet import peut \xEAtre rempli."
      );
  }
  if (job.stage === "ready") return job;
  job.stage = patch.stage;
  job.updatedAt = Date.now();
  if (patch.identity) job.identity = patch.identity;
  if (patch.retainedPhotos !== void 0)
    job.retainedPhotos = patch.retainedPhotos;
  if (patch.error) job.error = String(patch.error).slice(0, 800);
  if (patch.stage === "ready" && typeof patch.conditionStatus === "string")
    job.conditionStatus = patch.conditionStatus.trim().slice(0, 400);
  if (Number.isInteger(patch.uploaded) && patch.uploaded >= 0 && patch.uploaded <= Math.max(job.images.length, job.retainedPhotos ?? 0))
    job.uploaded = patch.uploaded;
  await chrome.storage.session.set({ [key(tabId)]: job });
  return job;
}
async function nativeImage(tabId, id, url) {
  const job = await getNativeJob(tabId);
  if (!(await getSettings()).enabled || !job || job.id !== id || job.stage !== "filling" || !(job.images.includes(url) || job.product.variantImages.some((i) => i.url === url)) || importImageURL(url) !== url)
    throw Error("Photo non autoris\xE9e pour cet import.");
  const response = await fetch(url, {
    credentials: "omit",
    referrerPolicy: "no-referrer",
    signal: AbortSignal.timeout(2e4)
  });
  if (!response.ok || importImageURL(response.url) === null)
    throw Error("Photo fournisseur inaccessible.");
  const declared = response.headers.get("content-type")?.split(";")[0]?.trim().toLowerCase() ?? "";
  if (declared && !declared.startsWith("image/") && declared !== "application/octet-stream")
    throw Error(`Format photo non reconnu (${declared}).`);
  const reader = response.body?.getReader();
  if (!reader) throw Error("Photo vide.");
  const chunks = [];
  let size = 0;
  try {
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      size += value.length;
      if (size > 8 * 1024 * 1024)
        throw Error("Photo trop volumineuse (8 Mo maximum).");
      chunks.push(value);
    }
  } finally {
    await reader.cancel();
  }
  if (!size) throw Error("Photo vide.");
  const bytes = new Uint8Array(size);
  let offset = 0;
  for (const c of chunks) {
    bytes.set(c, offset);
    offset += c.length;
  }
  const mime = imageFormat(bytes) ?? (["image/jpeg", "image/png", "image/webp"].includes(declared) ? declared : null);
  if (!mime) throw Error(`Format photo non reconnu (${declared || "inconnu"}).`);
  let binary = "";
  for (let i = 0; i < bytes.length; i += 8192)
    binary += String.fromCharCode(...bytes.subarray(i, i + 8192));
  return { data: btoa(binary), mime, size };
}
function imageFormat(bytes) {
  const text3 = (a, b) => String.fromCharCode(...bytes.subarray(a, b));
  if (bytes[0] === 255 && bytes[1] === 216 && bytes[2] === 255) return "image/jpeg";
  if ([137, 80, 78, 71, 13, 10, 26, 10].every((v, i) => bytes[i] === v)) return "image/png";
  if (text3(0, 4) === "RIFF" && text3(8, 12) === "WEBP") return "image/webp";
  if (text3(0, 4) === "GIF8") return "image/gif";
  if (text3(4, 8) === "ftyp" && /^(avif|avis|mif1|msf1)$/.test(text3(8, 12))) return "image/avif";
  if (text3(0, 2) === "BM") return "image/bmp";
  return null;
}

// src/background/ebayApiImport.ts
var API_BASE_PAGE = "https://www.ebay.com/robots.txt";
var running3 = /* @__PURE__ */ new Set();
async function showWorkingPage(tabId) {
  await chrome.scripting.executeScript({ target: { tabId }, func: workingPageScene, args: [BRAND_CSS, brandMarkSVG(64, "w")] }).catch(() => {
  });
}
function showWorkingStep(tabId, job) {
  void chrome.tabs.get(tabId).then(
    (tab) => tab.url === API_BASE_PAGE ? chrome.scripting.executeScript({
      target: { tabId },
      func: workingPageStep,
      args: [job.apiPhase ?? "", job.apiImagesUploaded ?? 0, job.apiImagesTotal ?? 0]
    }) : void 0
  ).catch(() => {
  });
}
var completed = async () => {
};
var jobKey = (tabId) => `nativeImport:v1:${tabId}`;
var stateKey = (id) => `apiImport:v1:${id}`;
function setApiImportCompletion(handler) {
  completed = handler;
}
async function initializeApiImport(job) {
  await chrome.storage.session.set({
    [stateKey(job.id)]: {
      version: 1,
      phase: "queued",
      bootstrapIssuedAt: Date.now(),
      hosted: {},
      bytes: 0
    },
    ...job.ebaySeed?.tabId !== void 0 ? { [`nativeImportSource:v1:${job.ebaySeed.tabId}`]: job.tabId } : {}
  });
}
var apiImportsRunning = () => running3.size;
function queueApiImport(job) {
  if (job.transport !== "api" || ["ready", "error"].includes(job.stage) || running3.has(job.id))
    return;
  running3.add(job.id);
  void executeApiImport(job).finally(() => running3.delete(job.id));
}
async function resumeApiImports() {
  const records = await chrome.storage.session.get(null);
  for (const [key4, value] of Object.entries(records)) {
    const job = value;
    if (key4.startsWith("nativeImport:v1:") && job?.transport === "api" && freshNativeJob(job))
      queueApiImport(job);
  }
}
async function executeApiImport(initial) {
  let job = initial;
  let state = (await chrome.storage.session.get(stateKey(job.id)))[stateKey(job.id)];
  const owned = async () => {
    const current2 = (await chrome.storage.session.get(jobKey(job.tabId)))[jobKey(job.tabId)];
    if (!(await getSettings()).enabled || !current2 || current2.id !== job.id || current2.transport !== "api" || !freshNativeJob(current2))
      throw Error(
        "Import en arri\xE8re-plan interrompu : pause, expiration ou autre op\xE9ration."
      );
    const tab = await chrome.tabs.get(job.tabId);
    if (state?.expectedPage && tab.url !== state.expectedPage)
      throw Error("L\u2019onglet de pr\xE9paration a \xE9t\xE9 modifi\xE9. Import arr\xEAt\xE9.");
    return tab;
  };
  const persist = async (phase, patch = {}) => {
    await owned();
    apiTrace(job.id, `phase:${phase}`, patch);
    state.phase = phase;
    job = { ...job, ...patch, apiPhase: phase, updatedAt: Date.now() };
    await chrome.storage.session.set({
      [jobKey(job.tabId)]: job,
      [stateKey(job.id)]: state
    });
    showWorkingStep(job.tabId, job);
  };
  const navigate = async (url) => {
    const before = await owned();
    apiTrace(job.id, "navigate", { to: url, from: before.url ?? "(masqu\xE9)" });
    const requested = new URL(url);
    if (requested.href === API_BASE_PAGE && before.url === API_BASE_PAGE) {
      state.expectedPage = API_BASE_PAGE;
      await chrome.storage.session.set({ [stateKey(job.id)]: state });
      return;
    }
    const bootstrap = requested.href === API_BASE_PAGE && !state.expectedPage;
    const untouchedInitialTab = (tab) => tab.url === "about:blank" || !tab.url && (!tab.pendingUrl || tab.pendingUrl === "about:blank") && Date.now() - (state.bootstrapIssuedAt ?? job.createdAt) <= 1e4;
    if (bootstrap && (state.phase !== "queued" || state.draftId || state.expectedPage || !untouchedInitialTab(before)))
      throw Error(
        "L\u2019onglet initial de pr\xE9paration a \xE9t\xE9 modifi\xE9. Import arr\xEAt\xE9."
      );
    await retryTabOperation(
      () => chrome.tabs.update(job.tabId, { url, active: false }),
      async () => {
        const current2 = await owned();
        return !bootstrap || untouchedInitialTab(current2);
      }
    );
    for (let attempt = 0; attempt < 100; attempt++) {
      if (!(await getSettings()).enabled)
        throw Error("Import arr\xEAt\xE9 : AurOEBay en pause.");
      const tab = await chrome.tabs.get(job.tabId);
      if (tab.status === "complete" && tab.url) {
        if (tab.url === "about:blank" || tab.url === before.url && tab.url !== requested.href) {
          await new Promise((resolve) => setTimeout(resolve, 200));
          continue;
        }
        const target = new URL(tab.url);
        if (target.origin !== requested.origin || target.username || target.password || target.port || requested.href === API_BASE_PAGE && target.href !== API_BASE_PAGE || requested.searchParams.has("draftId") && (target.searchParams.get("draftId") !== requested.searchParams.get("draftId") || target.pathname !== requested.pathname))
          throw Error("eBay a ouvert une autre page que le brouillon demand\xE9.");
        apiTrace(job.id, "navigate:ok", { at: tab.url });
        state.expectedPage = tab.url;
        await chrome.storage.session.set({ [stateKey(job.id)]: state });
        if (tab.url === API_BASE_PAGE) await showWorkingPage(job.tabId);
        return;
      }
      await new Promise((resolve) => setTimeout(resolve, 200));
    }
    throw Error("La page de pr\xE9paration eBay n\u2019a pas termin\xE9 son chargement.");
  };
  const request = async (input) => {
    const tab = await owned();
    const results = await chrome.scripting.executeScript({
      target: { tabId: job.tabId },
      world: "MAIN",
      func: ebayDraftRequestFromPage,
      args: [{ ...input, expectedPage: tab.url }]
    });
    const response = results[0]?.result;
    apiTrace(job.id, `request:${input.kind}`, {
      status: response?.status,
      code: response?.code,
      bytes: response?.text?.length,
      head: input.kind === "variants-save" || input.kind === "put" ? response?.text?.slice(0, 600) : void 0
    });
    await owned();
    if (!response || response.code)
      throw Error(
        response?.code === "AUTH" ? EBAY_SIGNIN_TEXT : "La requ\xEAte de brouillon eBay n\u2019a pas pu \xEAtre confirm\xE9e."
      );
    return response;
  };
  const categoryFromSearch = async (url, title, referenceHtml = "") => {
    const itemId = url.match(/\/itm\/(?:[^/]+\/)?(\d{9,15})/)?.[1];
    if (!itemId) return null;
    const search2 = async (words3, category) => {
      const u = new URL("https://www.ebay.com/sch/i.html");
      u.searchParams.set("_nkw", words3);
      if (category) u.searchParams.set("_sacat", category);
      u.searchParams.set("LH_PrefLoc", "99");
      const r = await request({ kind: "category-search", url: u.href });
      if (/Pardon Our Interruption|splashui\/challenge/i.test(r.text.slice(0, 2e4)))
        throw Error("eBay demande une v\xE9rification anti-robot : ouvre eBay, fais-la toi-m\xEAme, attends quelques minutes puis relance ce produit.");
      return r.ok ? r.text : "";
    };
    const path = [];
    const tracked = trackedCategory(referenceHtml);
    if (tracked && new RegExp(`/itm/(?:[^/"'?]+/)?${itemId}\\b`).test(await search2(itemId, tracked))) {
      path.push(tracked);
      apiTrace(job.id, "category:tracked", { category: tracked });
    }
    for (let depth = 0; depth < 6; depth++) {
      const found = searchCategoryPath(await search2(itemId, path.at(-1) ?? null), itemId);
      apiTrace(job.id, "category:search", { depth, path: found });
      const deeper = (found ?? []).filter((id) => !path.includes(id));
      if (!deeper.length) break;
      path.push(...deeper);
    }
    if (!path.length) {
      const words3 = title.replace(/[^\w .,'&/-]/g, " ").replace(/\s+/g, " ").trim().slice(0, 80);
      for (let depth = 0; depth < 5 && words3.length >= 3; depth++) {
        const page = await search2(words3, path.at(-1) ?? null);
        if (!new RegExp(`/itm/(?:[^/"'?]+/)?${itemId}\\b`).test(page)) break;
        const candidates = (depth ? searchSubcategories(page) : searchFilterCategories(page)).filter((id) => !path.includes(id)).slice(0, 4);
        let holder = null;
        for (const id of candidates) {
          if (new RegExp(`/itm/(?:[^/"'?]+/)?${itemId}\\b`).test(await search2(words3, id))) {
            holder = id;
            break;
          }
        }
        apiTrace(job.id, "category:title", { depth, candidates, holder });
        if (!holder) break;
        path.push(holder);
      }
    }
    if (!path.length) return null;
    const words2 = title.replace(/[^\w .,'&-]/g, " ").split(/\s+/).filter(Boolean).slice(0, 5).join(" ");
    for (let depth = 0; depth < 5 && words2.length >= 2; depth++) {
      const current2 = path[path.length - 1];
      const children = searchSubcategories(await search2(words2, current2)).filter((id) => !path.includes(id));
      if (!children.length) break;
      path.push(children[0]);
      apiTrace(job.id, "category:down", { from: current2, to: children[0], children: children.slice(0, 8) });
    }
    return path[path.length - 1];
  };
  const contextURL = () => `https://www.ebay.com/lstng?draftId=${state.draftId}&mode=AddItem`;
  const refresh = async () => {
    const response = await request({
      kind: "context",
      draftId: state.draftId,
      url: contextURL()
    });
    if (!response.ok)
      throw Error(
        `Lecture du brouillon eBay refus\xE9e (HTTP ${response.status}).`
      );
    return {
      html: response.text,
      context: parseDraftContext(response.text, response.url, {
        draftId: state.draftId,
        categoryId: state.categoryId
      })
    };
  };
  let draftHtml = "";
  let context;
  let variantsVerified = false;
  const originalRows = initial.supplierPlan?.rows.length ?? 0;
  const importWarnings = [];
  const put = async (body2) => {
    for (let attempt = 0; attempt < 2; attempt++) {
      const response = await request({
        kind: "put",
        draftId: context.draftId,
        url: `https://www.ebay.com/lstng/api/listing_draft/${context.draftId}?mode=AddItem`,
        csrf: context.csrf,
        body: body2
      });
      const result = parseDraftWriteResponse(response.status, response.text);
      if (result.ok) return;
      if (!result.tokenRejected || attempt === 1) throw Error(result.error);
      const fresh = await refresh();
      context = fresh.context;
      draftHtml = fresh.html;
    }
  };
  try {
    if (!state || state.version !== 1 || !job.ebaySeed || !job.supplierPlan)
      throw Error("Pr\xE9paration d\u2019import en arri\xE8re-plan absente.");
    if (state.phase === "creating" && !state.draftId)
      throw Error(
        "La cr\xE9ation pr\xE9c\xE9dente n\u2019a pas re\xE7u de confirmation. V\xE9rifie les brouillons eBay avant de recommencer ; aucune seconde cr\xE9ation automatique."
      );
    if (!state.expectedPage)
      await navigate(API_BASE_PAGE);
    if (!state.draftId) {
      let category = job.ebaySeed.categoryId;
      if (!category) {
        const reference = await request({
          kind: "reference",
          url: job.ebaySeed.url
        });
        if (!reference.ok)
          throw Error("Cat\xE9gorie de la r\xE9f\xE9rence eBay inaccessible.");
        category = ebayCategoryFromHTML(reference.text) ?? void 0;
        if (!category) category = await categoryFromSearch(job.ebaySeed.url, job.ebaySeed.title, reference.text) ?? void 0;
      }
      if (!category)
        throw Error(
          "Cat\xE9gorie eBay introuvable pour cette annonce d\u2019exemple (elle n\u2019en affiche aucune) : choisis une autre annonce eBay du m\xEAme produit, qui montre sa cat\xE9gorie en haut de page."
        );
      state.categoryId = category;
      await persist("creating", { stage: "opening" });
      const response = await request({
        kind: "create",
        url: createDraftURL(category, job.title)
      });
      if (!response.ok)
        throw Error(`Cr\xE9ation du brouillon refus\xE9e (HTTP ${response.status}).`);
      context = parseDraftContext(response.text, response.url, {
        categoryId: category
      });
      draftHtml = response.text;
      state.draftId = context.draftId;
      state.conditionId = context.conditionId;
      await persist("photos", {
        stage: "filling",
        apiDraftId: context.draftId,
        identity: contextURL()
      });
    } else {
      if (state.expectedPage !== API_BASE_PAGE) await navigate(API_BASE_PAGE);
      const fresh = await refresh();
      context = fresh.context;
      draftHtml = fresh.html;
    }
    const sources = [...job.images];
    for (const image of job.product.variantImages) {
      if (job.supplierPlan.axes.some(
        (axis) => norm(axis.name) === norm(image.axis) && axis.values.includes(image.value)
      ))
        sources.push(image.url);
    }
    const unique2 = /* @__PURE__ */ new Map();
    for (const source of sources) {
      const key4 = ebayVariationImageKey(source);
      if (!key4) throw Error("Source d\u2019image fournisseur invalide.");
      if (!unique2.has(key4)) unique2.set(key4, source);
    }
    if (unique2.size > 12 + 250)
      throw Error("Trop de photos diff\xE9rentes pour cet import.");
    const hostedByKey = new Map(
      Object.entries(state.hosted).map(([source, url]) => [
        ebayVariationImageKey(source),
        url
      ])
    );
    if (state.phase === "photos") {
      const eps = extractEpsContext(context.epsData ?? draftHtml);
      if (!eps)
        throw Error(
          "Uploader eBay indisponible : aucun transfert de galerie effectu\xE9."
        );
      await persist("photos", {
        apiImagesTotal: unique2.size,
        apiImagesUploaded: hostedByKey.size
      });
      const pending2 = [...unique2].filter(([key4]) => !hostedByKey.has(key4));
      let nextFileId = hostedByKey.size;
      const uploadOne = async ([key4, source]) => {
        await owned();
        let url;
        try {
          const file = await nativeImage(job.tabId, job.id, source);
          if (state.bytes + file.size > 192 * 1024 * 1024)
            throw Error("Photos trop volumineuses : maximum 192 Mo pour cet import.");
          state.bytes += file.size;
          await owned();
          const results = await chrome.scripting.executeScript({
            target: { tabId: job.tabId },
            world: "MAIN",
            func: uploadEpsFileFromPage,
            args: [{ context: eps, image: file, fileId: nextFileId++ }]
          });
          const result = results[0]?.result;
          if (!result?.ok)
            throw Error(result?.error ?? "Envoi de photo eBay non confirm\xE9.");
          url = result.url;
        } catch (error) {
          await owned();
          apiTrace(job.id, "photo:skipped", {
            message: error instanceof Error ? error.message : String(error)
          });
          state.skippedImages = (state.skippedImages ?? 0) + 1;
          return;
        }
        state.hosted[source] = url;
        hostedByKey.set(key4, url);
        await persist("photos", { apiImagesUploaded: hostedByKey.size });
      };
      for (let i = 0; i < pending2.length; i += 4)
        await Promise.all(pending2.slice(i, i + 4).map(uploadOne));
      const first2 = job.images[0];
      if (first2 && !state.bannerUrl && !state.bannerFailed && hostedByKey.has(ebayVariationImageKey(first2)) && (await getSettings()).saleBanner) {
        try {
          const look = bannerStyle(await getSettings());
          const file = await nativeImage(job.tabId, job.id, first2);
          await owned();
          const [drawn] = await chrome.scripting.executeScript({
            target: { tabId: job.tabId },
            world: "MAIN",
            func: saleBannerFromPage,
            args: [{ data: file.data, mime: file.mime }, look]
          });
          const banner = drawn?.result;
          if (!banner?.ok) throw Error(banner?.error ?? "Bandeau non dessin\xE9.");
          await owned();
          const [sent] = await chrome.scripting.executeScript({
            target: { tabId: job.tabId },
            world: "MAIN",
            func: uploadEpsFileFromPage,
            args: [{ context: eps, image: { data: banner.data, mime: banner.mime, size: banner.size }, fileId: nextFileId++ }]
          });
          const result = sent?.result;
          if (!result?.ok) throw Error(result?.error ?? "Envoi du bandeau non confirm\xE9.");
          state.bannerUrl = result.url;
        } catch (error) {
          await owned();
          state.bannerFailed = error instanceof Error ? error.message : String(error);
          apiTrace(job.id, "photo:banner-skipped", { message: state.bannerFailed });
        }
      }
      await persist("basics");
    }
    const imageMap = Object.fromEntries(
      sources.flatMap((source) => {
        const hosted = hostedByKey.get(ebayVariationImageKey(source));
        return hosted ? [[source, hosted]] : [];
      })
    );
    const pictures = [
      ...new Set(job.images.map((source) => imageMap[source]).filter((url) => !!url))
    ];
    if (!pictures.length)
      throw Error("Aucune photo du fournisseur n\u2019a pu \xEAtre envoy\xE9e \xE0 eBay : import arr\xEAt\xE9.");
    if (state.bannerUrl && job.images[0] && pictures[0] === imageMap[job.images[0]])
      pictures[0] = state.bannerUrl;
    if (state.bannerFailed && !importWarnings.some((w) => w.startsWith("Bandeau")))
      importWarnings.push(`Bandeau \xAB SALE \xBB non ajout\xE9 sur la 1re photo (${state.bannerFailed}).`);
    if (state.axisRenames && job.supplierPlan) {
      const renamed = renameAxes(job.supplierPlan, job.product.variantImages, state.axisRenames);
      job.supplierPlan = renamed.plan;
      job.product.variantImages = renamed.images;
    }
    let variantImages = job.product.variantImages.filter((image) => imageMap[image.url]);
    if (state.skippedImages && !importWarnings.some((w) => w.startsWith("Photo")))
      importWarnings.push(
        `Photos : ${state.skippedImages} photo(s) AliExpress illisible(s) laiss\xE9e(s) de c\xF4t\xE9 \u2014 v\xE9rifie la galerie et les photos des variantes.`
      );
    if (state.phase === "basics" && job.supplierPlan.rows.length > 1 && !categoryAllowsVariations(draftHtml)) {
      state.singleRow = 0;
      job = singleRowJob(job, 0);
      if (!job.supplierPlan) throw Error("Plan fournisseur indisponible.");
      importWarnings.push(singleRowWarning(job, originalRows));
    }
    if (state.phase === "basics") {
      const body2 = buildDraftBasicPayload(
        job,
        { ...context, conditionId: state.conditionId },
        pictures,
        parseDraftAttributeModel(draftHtml)
      );
      state.expectedAttributes = body2.attributes;
      await chrome.storage.session.set({ [stateKey(job.id)]: state });
      await put({ ...body2 });
      const pricing = buildDraftPricingPayload(job);
      if (pricing) await put({ ...pricing });
      await persist(
        job.supplierPlan.rows.length > 1 ? "variants" : "verifying"
      );
    }
    if (state.phase === "variants") {
      const msku = `https://bulkedit.ebay.com/msku?draftId=${state.draftId}&listingMode=AddItem&categoryId=${state.categoryId}&decimalSymbol=.&maxPics=24&loadDraft=true`;
      await navigate(msku);
      const model = await request({
        kind: "variants-context",
        draftId: state.draftId,
        url: msku
      });
      if (!model.ok)
        throw Error("Le mod\xE8le de variantes eBay est indisponible.");
      const upi = model.text.match(
        /"upiFieldName"\s*:\s*"(upc|ean|isbn)"/
      )?.[1];
      state.upiFieldName = upi;
      let payload = buildEbayApiVariations({
        draftId: state.draftId,
        plan: job.supplierPlan,
        variantImages,
        uploadedImages: imageMap,
        ...upi ? { upiFieldName: upi } : {}
      });
      let response = await request({
        kind: "variants-save",
        draftId: state.draftId,
        url: "https://bulkedit.ebay.com/msku-update",
        body: { ...payload }
      });
      let saved = parseDraftWriteResponse(response.status, response.text);
      const missing = response.text.match(/\b(UPC|EAN|ISBN) field is missing/i)?.[1];
      if (!saved.ok && missing) {
        const field = upi ?? missing.toLowerCase();
        state.upiFieldName = field;
        payload = buildEbayApiVariations({
          draftId: state.draftId,
          plan: job.supplierPlan,
          variantImages,
          uploadedImages: imageMap,
          upiFieldName: field,
          identifierExempt: true
        });
        state.identifierExempt = true;
        response = await request({
          kind: "variants-save",
          draftId: state.draftId,
          url: "https://bulkedit.ebay.com/msku-update",
          body: { ...payload }
        });
        saved = parseDraftWriteResponse(response.status, response.text);
        if (saved.ok)
          importWarnings.push(
            `Cette cat\xE9gorie exige un ${field.toUpperCase()} : \xAB Does not apply \xBB mis sur chaque variante.`
          );
      }
      const rename = !saved.ok ? missingSpecificRename(response.text, job.supplierPlan.axes) : null;
      if (rename) {
        state.axisRenames = { ...state.axisRenames, [rename.from]: rename.to };
        const renamed = renameAxes(job.supplierPlan, job.product.variantImages, { [rename.from]: rename.to });
        job.supplierPlan = renamed.plan;
        job.product.variantImages = renamed.images;
        variantImages = job.product.variantImages.filter((image) => imageMap[image.url]);
        payload = buildEbayApiVariations({
          draftId: state.draftId,
          plan: job.supplierPlan,
          variantImages,
          uploadedImages: imageMap,
          ...state.upiFieldName ? { upiFieldName: state.upiFieldName } : {},
          ...state.identifierExempt ? { identifierExempt: true } : {}
        });
        response = await request({
          kind: "variants-save",
          draftId: state.draftId,
          url: "https://bulkedit.ebay.com/msku-update",
          body: { ...payload }
        });
        saved = parseDraftWriteResponse(response.status, response.text);
        if (saved.ok)
          importWarnings.push(`eBay exige \xAB ${rename.to} \xBB dans cette cat\xE9gorie : l\u2019option \xAB ${rename.from} \xBB a \xE9t\xE9 renomm\xE9e.`);
      }
      if (!saved.ok && categoryRefusesVariations(response.text))
        throw Error(
          "Cette cat\xE9gorie eBay n\u2019accepte pas les variantes. Choisis une annonce eBay de r\xE9f\xE9rence dans une autre cat\xE9gorie, ou fais une annonce par variante."
        );
      if (!saved.ok) throw Error(saved.error);
      {
        const retained = await request({
          kind: "variants-context",
          draftId: state.draftId,
          url: msku
        });
        if (!retained.ok)
          throw Error("La relecture des variantes eBay a \xE9chou\xE9.");
        importWarnings.push(...verifyApiVariations(retained.text, payload));
        variantsVerified = true;
        await persist("verifying");
      }
    }
    if (state.phase === "verifying") {
      if (state.singleRow !== void 0 && job.supplierPlan.rows.length > 1)
        job = singleRowJob(job, state.singleRow);
      if (!job.supplierPlan) throw Error("Plan fournisseur indisponible.");
      if (job.supplierPlan.rows.length > 1 && !variantsVerified) {
        const msku = `https://bulkedit.ebay.com/msku?draftId=${state.draftId}&listingMode=AddItem&categoryId=${state.categoryId}&decimalSymbol=.&maxPics=24&loadDraft=true`;
        await navigate(msku);
        const retained2 = await request({
          kind: "variants-context",
          draftId: state.draftId,
          url: msku
        });
        if (!retained2.ok)
          throw Error(
            "La relecture des variantes eBay a \xE9chou\xE9 apr\xE8s reprise."
          );
        importWarnings.push(...verifyApiVariations(
          retained2.text,
          buildEbayApiVariations({
            draftId: state.draftId,
            plan: job.supplierPlan,
            variantImages,
            uploadedImages: imageMap,
            ...state.upiFieldName ? { upiFieldName: state.upiFieldName } : {},
            ...state.identifierExempt ? { identifierExempt: true } : {}
          })
        ));
      }
      await navigate(API_BASE_PAGE);
      const retained = await refresh();
      importWarnings.push(...verifyApiDraft(
        retained.html,
        job,
        state.categoryId,
        state.conditionId,
        pictures,
        state.expectedAttributes
      ));
      const condition = `Item condition : ${state.conditionId === 1500 ? "New without tags" : "New"}.`;
      await persist("complete", {
        stage: "ready",
        apiDraftId: state.draftId,
        identity: contextURL(),
        uploaded: pictures.length,
        conditionStatus: importWarnings.length ? `${condition} \xC0 v\xE9rifier : ${importWarnings.join(" ")}`.slice(0, 900) : `${condition} Tout a \xE9t\xE9 relu dans eBay.`
      });
      await completed(job);
      await chrome.storage.session.remove(stateKey(job.id));
      const batch = (await chrome.storage.local.get(BATCH_KEY))[BATCH_KEY];
      if (!batch?.running)
        await openApiImport(job.tabId, job.id).catch(
          (error) => apiTrace(job.id, "open:error", String(error))
        );
    }
  } catch (error) {
    apiTrace(job.id, "error", {
      message: error instanceof Error ? error.message : String(error),
      stack: error instanceof Error ? error.stack?.slice(0, 800) : void 0,
      phase: state?.phase,
      draftId: state?.draftId
    });
    const existing = (await chrome.storage.session.get(jobKey(job.tabId)))[jobKey(job.tabId)];
    if (existing?.id === job.id && existing.stage !== "ready") {
      const text3 = error instanceof Error ? error.message : "Pr\xE9paration eBay non confirm\xE9e.";
      job = {
        ...existing,
        stage: "error",
        apiPhase: "error",
        updatedAt: Date.now(),
        ...state?.draftId ? { apiDraftId: state.draftId, identity: contextURL() } : {},
        error: text3.slice(0, 600) + (state?.draftId ? " Le nouveau brouillon reste disponible pour v\xE9rification ; aucune annonce n\u2019a \xE9t\xE9 publi\xE9e." : text3 === EBAY_SIGNIN_TEXT ? " Aucun brouillon n\u2019a \xE9t\xE9 cr\xE9\xE9." : " Aucune seconde cr\xE9ation n\u2019a \xE9t\xE9 relanc\xE9e automatiquement.")
      };
      await chrome.storage.session.set({ [jobKey(job.tabId)]: job });
      if (text3 === EBAY_SIGNIN_TEXT) {
        const tab = await chrome.tabs.update(job.tabId, { url: EBAY_SIGNIN_PAGE, active: true }).catch(() => void 0);
        if (tab?.windowId !== void 0) await chrome.windows.update(tab.windowId, { focused: true }).catch(() => {
        });
      }
      if (state?.draftId) await completed(job).catch(() => {
      });
      if (state?.draftId)
        await openApiImport(job.tabId, job.id).catch(
          (e) => apiTrace(job.id, "open:error", String(e))
        );
    }
  }
}
async function openApiImport(tabId, id) {
  const owned = async () => {
    const job2 = (await chrome.storage.session.get(jobKey(tabId)))[jobKey(tabId)];
    if (!job2 || job2.id !== id || job2.transport !== "api" || !freshNativeJob(job2) || !job2.apiDraftId || !["ready", "error"].includes(job2.stage) || !(await getSettings()).enabled)
      throw Error("Brouillon pr\xE9par\xE9 indisponible.");
    const identity2 = new URL(job2.identity ?? "");
    if (identity2.origin !== "https://www.ebay.com" || identity2.pathname !== "/lstng" || identity2.searchParams.get("draftId") !== job2.apiDraftId || identity2.searchParams.get("mode") !== "AddItem")
      throw Error("Identit\xE9 du brouillon pr\xE9par\xE9 invalide.");
    return job2;
  };
  const job = await owned();
  return retryTabOperation(
    () => chrome.tabs.update(tabId, { url: job.identity, active: true }),
    async () => {
      const current2 = await owned();
      return current2.apiDraftId === job.apiDraftId && current2.identity === job.identity;
    }
  );
}
function categoryAllowsVariations(html) {
  return !/Variations are for selling[^"\\<]{0,120}Not supported for this category/i.test(html);
}
function categoryRefusesVariations(text3) {
  return /121916564|does not support multi-variation/i.test(text3);
}
function singleRowJob(job, index) {
  const plan = job.supplierPlan;
  const row = (plan.rows[index]?.quantity !== 0 ? plan.rows[index] : void 0) ?? plan.rows.find((r) => r.quantity > 0) ?? plan.rows[0];
  return {
    ...job,
    supplierPlan: {
      ...plan,
      omitted: plan.omitted ?? 0,
      axes: plan.axes.map((axis, i) => ({ name: axis.name, values: [row.values[i]] })),
      rows: [row]
    }
  };
}
function singleRowWarning(job, total2) {
  const plan = job.supplierPlan;
  const chosen = plan.axes.map((a) => `${a.name} ${a.values[0]}`).join(", ");
  return `Cette cat\xE9gorie eBay n\u2019accepte pas les variantes : brouillon fait avec une seule variante (${chosen}, ${plan.rows[0].price} $)${total2 > 1 ? ` sur ${total2}` : ""}. Les autres ne sont pas dans l\u2019annonce.`;
}

// src/background/sources.ts
var queue3 = Promise.resolve();
function writeSource(p, keep) {
  const run6 = queue3.catch(() => {
  }).then(async () => {
    const { sources = [] } = await chrome.storage.session.get("sources");
    const list2 = [p, ...sources.filter(keep)].slice(0, 20);
    while (JSON.stringify(list2).length > 2e6 && list2.length > 1) list2.pop();
    await chrome.storage.session.set({ sources: list2 });
  });
  queue3 = run6;
  return run6;
}

// src/aliexpress/pageData.ts
async function readPdpSkuData() {
  const w = window;
  if (typeof w.__INIT_DATA_CALLBACK__ !== "function") return null;
  let raw;
  try {
    raw = await new Promise((resolve, reject) => {
      w.__INIT_DATA_CALLBACK__(resolve, reject);
      setTimeout(() => reject(Error("timeout")), 8e3);
    });
  } catch {
    return null;
  }
  const result = raw?.data?.result;
  const sku = result?.SKU, price = result?.PRICE;
  if (!sku && !price) return null;
  const props = Array.isArray(sku?.skuProperties) ? sku.skuProperties : [];
  const axes = props.map((p) => ({
    id: String(p.skuPropertyId),
    name: String(p.skuPropertyName ?? "").trim(),
    values: (Array.isArray(p.skuPropertyValues) ? p.skuPropertyValues : []).map(
      (v) => ({
        id: String(v.propertyValueIdLong ?? v.propertyValueId ?? ""),
        name: String(
          v.propertyValueDisplayName ?? v.propertyValueDefinitionName ?? v.propertyValueName ?? ""
        ).trim(),
        image: typeof v.skuPropertyImagePath === "string" ? v.skuPropertyImagePath : null
      })
    )
  }));
  for (const axis of axes) {
    const count = /* @__PURE__ */ new Map();
    for (const v of axis.values) {
      const key4 = v.name.normalize("NFKC").toLowerCase().replace(/[\s\W_]+/g, " ").trim();
      const n = (count.get(key4) ?? 0) + 1;
      count.set(key4, n);
      if (n > 1 && v.name) v.name = `${v.name} (${n})`;
    }
  }
  const priceMap = price?.skuPriceInfoMap ?? {};
  const parse = (text3) => {
    const m = String(text3 ?? "").replace(/,/g, "").match(/(\d+(?:\.\d+)?)/);
    return m ? Number(m[1]) : null;
  };
  const paths = Array.isArray(sku?.skuPaths) && sku.skuPaths.length ? sku.skuPaths : [
    {
      path: "",
      skuIdStr: String(price?.selectedSkuId ?? sku?.selectedSkuIdStr ?? ""),
      salable: sku?.selectedSkuSaleable !== false,
      skuStock: void 0,
      __target: price?.targetSkuPriceInfo
    }
  ];
  const rows = paths.map((path) => {
    const parts = String(path.path ?? "").split(";").filter(Boolean).map((pair) => pair.split(":"));
    const values = axes.map((axis) => {
      const hit = parts.find(([pid]) => pid === axis.id);
      return hit ? axis.values.find((v) => v.id === hit[1])?.name ?? "" : "";
    });
    const info = priceMap[String(path.skuIdStr ?? path.skuId)] ?? path.__target ?? (paths.length === 1 ? price?.targetSkuPriceInfo : void 0) ?? {};
    const amount2 = typeof info.salePrice?.value === "number" ? info.salePrice.value : parse(info.salePriceString);
    const currency = info.salePrice?.currency ?? info.originalPrice?.currency ?? (/^\$\s?\d/.test(String(info.salePriceString ?? "")) && /(^|\.)aliexpress\.us$/.test(location.hostname) ? "USD" : null);
    return {
      values,
      price: amount2,
      currency: typeof currency === "string" ? currency : null,
      stock: typeof path.skuStock === "number" ? path.skuStock : null,
      salable: path.salable !== false
    };
  });
  const descUrl = result?.DESC?.pcDescUrl;
  return {
    ...typeof descUrl === "string" ? { descUrl } : {},
    productId: String(price?.productId ?? ""),
    axes: axes.map((a) => ({
      name: a.name,
      values: a.values.map((v) => v.name),
      images: a.values.map((v) => v.image)
    })),
    rows
  };
}

// src/background/supplierLink.ts
async function selectEbaySeed(seed, tabId, tabURL) {
  if (!(await getSettings()).enabled || !validEbaySeed(seed) || new URL(tabURL).origin + new URL(tabURL).pathname !== seed.url)
    throw Error("Fiche eBay invalide ou AurOEBay en pause.");
  await chrome.storage.session.set({
    "ebaySeed:v1": { ...seed, tabId, capturedAt: Date.now() }
  });
  return seed;
}
var supplierReads = /* @__PURE__ */ new Set();
var supplierCostTabs = /* @__PURE__ */ new Map();
var COST_CAPTURE_GRACE_MS = 5e3;
function isSupplierCostReadTab(tabId) {
  const now = Date.now();
  for (const [id, expires] of supplierCostTabs)
    if (expires <= now) supplierCostTabs.delete(id);
  return tabId !== void 0 && supplierCostTabs.has(tabId);
}
async function readSupplierLink(value, prices = true, background = false, onRetry) {
  return withSupplierRead(
    background ? usSupplierURL(value) : value,
    prices,
    background,
    true,
    onRetry
  );
}
async function readSupplierCosts(value) {
  return (await readSupplierScan(value)).scan;
}
async function readSupplierScan(value) {
  const source = await withSupplierRead(usSupplierURL(value), true, true, false);
  return { scan: source.variantScan, shipping: source.shippingDetails ?? null, images: source.variantImages ?? [] };
}
var READ_TIMEOUT = "La lecture AliExpress en arri\xE8re-plan n\u2019a pas r\xE9pondu dans le d\xE9lai pr\xE9vu.";
async function withSupplierRead(value, prices, background, fullDescription, onRetry) {
  const url = aliProductURL(value);
  const key4 = new URL(url).pathname;
  if (supplierReads.has(key4))
    throw Error("Une lecture de ce fournisseur AliExpress est d\xE9j\xE0 en cours.");
  supplierReads.add(key4);
  let temporaryTabId;
  let temporaryWindowId;
  const release = async () => {
    if (temporaryTabId !== void 0) {
      await chrome.tabs.remove(temporaryTabId).catch(() => {
      });
      supplierCostTabs.set(temporaryTabId, Date.now() + COST_CAPTURE_GRACE_MS);
      if (temporaryWindowId !== void 0 && chrome.windows?.get) {
        const window2 = await chrome.windows.get(temporaryWindowId, { populate: true }).catch(() => void 0);
        if (window2?.id === temporaryWindowId && window2.tabs?.length === 0)
          await chrome.windows.remove(temporaryWindowId).catch(() => {
          });
      }
    }
    temporaryTabId = temporaryWindowId = void 0;
  };
  try {
    for (let attempt = 0; ; attempt++) {
      try {
        return await readSupplier(
          url,
          prices,
          background,
          fullDescription,
          (id) => {
            temporaryTabId = id;
            supplierCostTabs.set(id, Infinity);
          },
          (id) => {
            temporaryWindowId = id;
          }
        );
      } catch (error) {
        const message2 = error instanceof Error ? error.message : String(error);
        if (!background || attempt > 0 || !message2.includes(READ_TIMEOUT)) {
          if (attempt > 0 && message2.includes(READ_TIMEOUT))
            throw Error(`${READ_TIMEOUT} Deux essais faits : AliExpress est tr\xE8s lent en ce moment, r\xE9essaie dans quelques minutes.`);
          throw error;
        }
        apiTrace("lecture", "aliexpress:retry", { reason: "timeout" });
        await release();
        await onRetry?.();
      }
    }
  } finally {
    supplierReads.delete(key4);
    await release();
  }
}
async function readSupplier(url, prices, background, fullDescription, ownTemporaryTab, ownTemporaryWindow) {
  let expectedPath = new URL(url).pathname;
  let adapted = false;
  const settings = await getSettings();
  if (!settings.enabled || !settings.captureEnabled)
    throw Error("Active AurOEBay et la capture AliExpress.");
  const existing = background && !fullDescription ? [] : (await chrome.tabs.query({
    url: ["https://*.aliexpress.com/*", "https://*.aliexpress.us/*"]
  })).filter((t) => {
    try {
      return !!t.url && (background ? new URL(aliProductURL(t.url)).pathname === new URL(url).pathname : aliProductURL(t.url) === url);
    } catch {
      return false;
    }
  });
  let candidates = background ? [] : existing;
  const isolated = background || candidates.length > 1;
  if (isolated) candidates = [];
  const snapshotTabs = isolated && fullDescription ? existing : [];
  if (snapshotTabs.length > 20)
    throw Error(
      "Plus de 20 onglets correspondent \xE0 cette fiche AliExpress : la lecture a \xE9t\xE9 arr\xEAt\xE9e sans modifier tes onglets."
    );
  let snapshots = await readLoadedSnapshots(snapshotTabs, url);
  const tab = candidates[0] ?? await chrome.tabs.create({ url, active: !isolated });
  if (tab.id === void 0 || !Number.isSafeInteger(tab.id) || tab.id < 0)
    throw Error("Impossible d\u2019ouvrir la fiche AliExpress.");
  if (isolated) ownTemporaryTab(tab.id);
  if (candidates.length) await chrome.tabs.update(tab.id, { active: true });
  let until = Date.now() + 45e3;
  let lastError = "La fiche n\u2019est pas encore charg\xE9e.";
  let popupAttempted = false;
  let reloads = 0;
  while (Date.now() < until) {
    const configuration = await getSettings();
    if (!configuration.enabled || !configuration.captureEnabled)
      throw Error("Lecture interrompue : AurOEBay en pause.");
    let current2;
    try {
      current2 = await chrome.tabs.get(tab.id);
    } catch {
      throw Error("Lecture AliExpress interrompue : l\u2019onglet a \xE9t\xE9 ferm\xE9.");
    }
    if (current2.id !== tab.id)
      throw Error("Lecture AliExpress interrompue : onglet non confirm\xE9.");
    if (candidates.length && current2.url && aliProductURL(current2.url) !== url)
      throw Error("La fiche AliExpress a chang\xE9 pendant la lecture.");
    if (current2.status === "complete") {
      const resolvedURL = aliProductURL(current2.url ?? "");
      if (background && !adapted && new URL(resolvedURL).pathname !== expectedPath && /\/item\/1005\d+\.html$/.test(expectedPath) && new URL(resolvedURL).hostname === "www.aliexpress.us" && /[?&]gatewayAdapt=/.test(current2.url ?? "")) {
        adapted = true;
        expectedPath = new URL(resolvedURL).pathname;
      }
      if (background && new URL(resolvedURL).pathname !== expectedPath)
        throw Error(
          "La fiche AliExpress a redirig\xE9 vers un autre produit. La lecture du fournisseur a \xE9t\xE9 annul\xE9e."
        );
      try {
        let pdp = null;
        if ((prices || fullDescription) && typeof chrome.scripting?.executeScript === "function")
          for (let attempt = 0; attempt < 2 && !pdp; attempt++) {
            if (attempt) await new Promise((r) => setTimeout(r, 1500));
            try {
              const r = await chrome.scripting.executeScript({
                target: { tabId: tab.id },
                world: "MAIN",
                func: readPdpSkuData
              });
              pdp = r?.[0]?.result ?? null;
            } catch {
              pdp = null;
            }
          }
        const requestFor = (complete) => ({
          type: prices ? "SOURCE_READ_IMPORT" : complete ? "SOURCE_READ_FULL" : "SOURCE_READ",
          url: resolvedURL,
          ...!complete && prices ? { fullDescription: false } : {},
          ...pdp ? { pdp } : {}
        });
        let snapshotMode = fullDescription && snapshots.length > 0;
        let response = await supplierMessage(
          tab.id,
          requestFor(fullDescription && !snapshotMode),
          isolated
        );
        if (!response?.ok && isolated && fullDescription && !snapshotMode && /description.*(?:pas fini|non charg|indisponible|non confirmée)/i.test(
          String(response?.error ?? "")
        )) {
          snapshots = await readLoadedSnapshots(
            await currentDescriptionTabs(url),
            url
          );
          const fullScreen = (await chrome.windows?.getLastFocused?.().catch(() => void 0))?.state === "fullscreen";
          if (background && !snapshots.length && !popupAttempted && !fullScreen && typeof chrome.windows?.create === "function") {
            popupAttempted = true;
            await openUnfocusedReadWindow(
              tab.id,
              resolvedURL,
              ownTemporaryWindow
            );
            response = await supplierMessage(tab.id, requestFor(true), true);
          }
          if (!response?.ok && /description.*(?:pas fini|non charg|indisponible|non confirmée)/i.test(
            String(response?.error ?? "")
          ) && (snapshots.length || prices)) {
            snapshotMode = true;
            response = await supplierMessage(tab.id, requestFor(false), true);
          }
        }
        if (!response?.ok)
          throw Error(
            response?.error ?? (fullDescription ? "Description compl\xE8te indisponible." : "Lecture des co\xFBts AliExpress indisponible.")
          );
        const p = response.data;
        if (!p || p.url !== resolvedURL || background && p.id !== expectedPath.match(/\/(\d+)\.html$/)?.[1] || fullDescription && !snapshotMode && (p.descriptionStatus !== "loaded" || !p.descriptionHTML))
          throw Error(
            fullDescription ? "Description compl\xE8te non confirm\xE9e." : "Le produit AliExpress ne correspond pas \xE0 la fiche demand\xE9e."
          );
        if (!fullDescription || snapshotMode && prices) {
          p.variantScan = validatePriceScan(p);
          p.variantCosts = p.variantScan.costs;
        }
        const nextSettings = await getSettings();
        if (!nextSettings.enabled || !nextSettings.captureEnabled)
          throw Error("Lecture fournisseur interrompue : capture d\xE9sactiv\xE9e.");
        const verified = await chrome.tabs.get(tab.id).catch(() => void 0);
        if (!verified || verified.id !== tab.id)
          throw Error(
            "Lecture fournisseur interrompue : l\u2019onglet a \xE9t\xE9 ferm\xE9."
          );
        if (aliProductURL(verified.url ?? "") !== resolvedURL)
          throw Error("La fiche AliExpress a chang\xE9 pendant la lecture.");
        if (snapshotMode) {
          let after = await readLoadedSnapshots(
            await currentDescriptionTabs(url),
            url
          );
          if (!snapshots.length && after.length) {
            snapshots = after;
            after = await readLoadedSnapshots(
              await currentDescriptionTabs(url),
              url
            );
          }
          if (snapshots.length) {
            const description = verifiedDescription(snapshots, after, p);
            p.descriptionHTML = description.descriptionHTML;
            p.description = description.description;
            p.descriptionStatus = "loaded";
            p.descriptionImageCount = description.descriptionImageCount;
          } else if (p.descriptionStatus !== "loaded" || !p.descriptionHTML) {
            throw Error(
              "La description compl\xE8te AliExpress n\u2019a pas pu \xEAtre charg\xE9e. Ouvre Description dans ta fiche AliExpress puis relance la lecture. La fiche eBay reste conserv\xE9e."
            );
          }
          const settingsAfterSnapshot = await getSettings();
          if (!settingsAfterSnapshot.enabled || !settingsAfterSnapshot.captureEnabled)
            throw Error(
              "Lecture fournisseur interrompue : capture d\xE9sactiv\xE9e."
            );
          const finalTab = await chrome.tabs.get(tab.id).catch(() => void 0);
          if (!finalTab || finalTab.id !== tab.id)
            throw Error(
              "Lecture fournisseur interrompue : l\u2019onglet a \xE9t\xE9 ferm\xE9."
            );
          if (aliProductURL(finalTab.url ?? "") !== resolvedURL)
            throw Error("La fiche AliExpress a chang\xE9 pendant la lecture.");
        }
        const scanKey = "variantCosts:" + p.url;
        if (prices && p.variantScan)
          await chrome.storage.session.set({
            [scanKey]: p.variantScan,
            ...!fullDescription ? { ["variantCosts:" + url]: p.variantScan } : {}
          });
        if (!prices) {
          const scan = (await chrome.storage.session.get(scanKey))[scanKey];
          if (scan && Date.now() - scan.at < 15 * 6e4) {
            p.variantScan = scan;
            p.variantCosts = scan.costs;
          }
        }
        if (fullDescription) {
          await writeSource(p, (x) => x.url !== p.url);
        }
        return p;
      } catch (e) {
        lastError = e instanceof Error ? e.message : String(e);
        const reloaded = /message (channel|port) closed|back\/forward cache|frame was removed|page.*(unload|navigat)/i.test(lastError);
        if (reloaded && reloads < 2) {
          reloads++;
          until = Math.max(until, Date.now() + 45e3);
          lastError = "La fiche AliExpress s\u2019est recharg\xE9e pendant la lecture.";
        } else if (!/receiving end|connection|not exist/i.test(lastError))
          throw Error(lastError);
      }
    }
    await new Promise((r) => setTimeout(r, 500));
  }
  throw Error(
    fullDescription ? `Lecture AliExpress indisponible : ${lastError} Ouvre la rubrique Description puis r\xE9essaie.` : `Lecture des co\xFBts AliExpress indisponible : ${lastError} R\xE9essaie la lecture du fournisseur.`
  );
}
async function openUnfocusedReadWindow(tabId, expectedURL, ownWindow) {
  const verify = async () => {
    const settings = await getSettings();
    if (!settings.enabled || !settings.captureEnabled)
      throw Error("Lecture fournisseur interrompue : capture d\xE9sactiv\xE9e.");
    const tab = await chrome.tabs.get(tabId).catch(() => void 0);
    if (!tab || tab.id !== tabId || !isSupplierCostReadTab(tabId) || aliProductURL(tab.url ?? "") !== expectedURL)
      throw Error("La fiche AliExpress a chang\xE9 pendant la lecture.");
  };
  await verify();
  const focusedBefore = await chrome.windows.getLastFocused();
  if (!Number.isSafeInteger(focusedBefore.id))
    throw Error(
      "La fen\xEAtre active n\u2019a pas pu \xEAtre confirm\xE9e avant la lecture AliExpress."
    );
  const window2 = await chrome.windows.create({
    tabId,
    type: "popup",
    focused: false,
    width: 1080,
    height: 800
  });
  if (!window2 || window2.id === void 0 || !Number.isSafeInteger(window2.id) || window2.id < 0 || window2.focused !== false || window2.tabs?.length !== 1 || window2.tabs[0].id !== tabId)
    throw Error("La fen\xEAtre de lecture AliExpress n\u2019a pas \xE9t\xE9 confirm\xE9e.");
  ownWindow(window2.id);
  await verify();
  const focusedAfter = await chrome.windows.getLastFocused();
  if (focusedBefore.id !== focusedAfter.id)
    throw Error(
      "La fen\xEAtre active a chang\xE9 pendant l\u2019ouverture de la lecture AliExpress. R\xE9essaie la capture."
    );
}
async function currentDescriptionTabs(requested) {
  const tabs = (await chrome.tabs.query({
    url: ["https://*.aliexpress.com/*", "https://*.aliexpress.us/*"]
  })).filter((tab) => {
    if (tab.id === void 0 || isSupplierCostReadTab(tab.id)) return false;
    try {
      return new URL(aliProductURL(tab.url ?? "")).pathname === new URL(requested).pathname;
    } catch {
      return false;
    }
  });
  if (tabs.length > 20)
    throw Error(
      "Plus de 20 onglets correspondent \xE0 cette fiche AliExpress : la lecture a \xE9t\xE9 arr\xEAt\xE9e sans modifier tes onglets."
    );
  return tabs;
}
async function readLoadedSnapshots(tabs, requested) {
  const reads = await Promise.all(
    tabs.map(async (tab) => {
      if (tab.id === void 0 || isSupplierCostReadTab(tab.id)) return null;
      if (!Number.isSafeInteger(tab.id) || tab.id < 0)
        throw Error(
          "L\u2019onglet AliExpress contenant la description est invalide."
        );
      let response;
      const before = await chrome.tabs.get(tab.id).catch(() => void 0);
      if (!before || before.id !== tab.id)
        throw Error(
          "L\u2019onglet contenant la description AliExpress a \xE9t\xE9 ferm\xE9."
        );
      const url = aliProductURL(before.url ?? "");
      if (new URL(url).pathname !== new URL(requested).pathname)
        throw Error(
          "La fiche AliExpress a chang\xE9 pendant la lecture de sa description."
        );
      if (before.status !== "complete") return null;
      try {
        response = await supplierMessage(
          tab.id,
          { type: "SOURCE_READ_SNAPSHOT", url },
          true,
          5e3
        );
      } catch (error) {
        if (/receiving end|connection|not exist/i.test(String(error)))
          return null;
        throw error;
      }
      if (!response?.ok)
        throw Error(
          response?.error ?? "Lecture de la description AliExpress non confirm\xE9e."
        );
      if (!response.data || !["loaded", "unavailable", "unsupported", "too-large"].includes(
        response.data.descriptionStatus
      ))
        throw Error("Description AliExpress invalide ou non confirm\xE9e.");
      const after = await chrome.tabs.get(tab.id).catch(() => void 0);
      if (!after || after.id !== tab.id || after.status !== "complete" || aliProductURL(after.url ?? "") !== url || response.data.url !== url || response.data.id !== new URL(url).pathname.match(/\/(\d+)\.html$/)?.[1])
        throw Error(
          "La fiche AliExpress a chang\xE9 pendant la lecture de sa description."
        );
      if (response.data.descriptionStatus !== "loaded") return null;
      const source = validateLibrarySource(response.data);
      if (!source.descriptionHTML?.trim() || source.descriptionImageCount === void 0)
        throw Error(
          "Description compl\xE8te AliExpress invalide ou non confirm\xE9e."
        );
      if (source.capturedAt < Date.now() - 3e4 || source.capturedAt > Date.now() + 3e4)
        throw Error(
          "La lecture de la description AliExpress est trop ancienne ou expir\xE9e."
        );
      source.url = url;
      return { tabId: tab.id, source };
    })
  );
  return reads.filter((read2) => read2 !== null);
}
function sourceSignature(source) {
  const axes = source.variants.map((axis) => ({
    name: norm(axis.name),
    values: axis.values.map(norm).sort()
  }));
  if (new Set(axes.map((axis) => axis.name)).size !== axes.length || axes.some(
    (axis) => !axis.name || !axis.values.length || axis.values.some((value) => !value) || new Set(axis.values).size !== axis.values.length
  ))
    throw Error("Les variantes AliExpress de la description sont ambigu\xEBs.");
  return JSON.stringify([
    source.id,
    norm(source.title),
    axes.sort((a, b) => a.name.localeCompare(b.name))
  ]);
}
function descriptionSignature(source) {
  return JSON.stringify([
    source.descriptionHTML,
    source.description,
    source.descriptionImageCount
  ]);
}
function verifiedDescription(before, after, owned) {
  const current2 = validateLibrarySource(owned);
  if (current2.capturedAt < Date.now() - 15 * 6e4 || current2.capturedAt > Date.now() + 3e4)
    throw Error(
      "La lecture du produit AliExpress est trop ancienne ou expir\xE9e."
    );
  const signature = sourceSignature(current2);
  if (!before.length || !after.length || [...before, ...after].some(
    (snapshot) => sourceSignature(snapshot.source) !== signature
  ))
    throw Error(
      "La description charg\xE9e dans tes onglets ne correspond plus au produit, au titre ou aux variantes AliExpress relus. Aucun contenu diff\xE9rent n\u2019a \xE9t\xE9 fusionn\xE9."
    );
  const descriptions = new Set(
    [...before, ...after].map(
      (snapshot) => descriptionSignature(snapshot.source)
    )
  );
  if (descriptions.size !== 1)
    throw Error(
      "Les descriptions AliExpress diff\xE8rent entre les lectures de cette fiche. Actualise la fiche fournisseur puis r\xE9essaie ; aucun contenu ambigu n\u2019a \xE9t\xE9 copi\xE9."
    );
  if (before.some(
    (initial) => !after.some((entry) => initial.tabId === entry.tabId)
  ))
    throw Error(
      "L\u2019onglet contenant la description compl\xE8te a chang\xE9 pendant la lecture. R\xE9essaie sans modifier cette fiche."
    );
  return after[0].source;
}
function validatePriceScan(source) {
  const validated = validateLibrarySource(source);
  const scan = validated.variantScan;
  const now = Date.now();
  if (!scan || scan.at < now - 15 * 6e4 || scan.at > now + 3e4 || source.capturedAt < now - 15 * 6e4 || source.capturedAt > now + 3e4 || !scan.costs.length && !scan.unavailable.length || scan.costs.length + scan.unavailable.length > 1e3)
    throw Error(
      "Lecture des co\xFBts et des stocks absente, incompl\xE8te ou trop ancienne. Relis le fournisseur."
    );
  const axes = validated.variants.filter((axis) => axis.values.length);
  if (new Set(axes.map((axis) => norm(axis.name))).size !== axes.length || axes.some(
    (axis) => new Set(axis.values.map(norm)).size !== axis.values.length
  ))
    throw Error(
      "Les options AliExpress sont ambigu\xEBs. V\xE9rifie les variantes avant de relire les co\xFBts."
    );
  const seen = /* @__PURE__ */ new Set();
  for (const row of [...scan.costs, ...scan.unavailable]) {
    const key4 = JSON.stringify(row.values.map(norm));
    if (row.values.length !== axes.length || row.values.some((value, i) => !axes[i].values.includes(value)) || seen.has(key4))
      throw Error(
        "Les co\xFBts ou ruptures AliExpress ne correspondent pas aux variantes de cette fiche. Relis le fournisseur."
      );
    seen.add(key4);
  }
  if (scan.costs.some((cost) => cost.currency !== "USD" || cost.cost <= 0))
    throw Error(
      "Les co\xFBts AliExpress doivent \xEAtre confirm\xE9s en USD. Aucune conversion ou estimation automatique."
    );
  return scan;
}
async function supplierMessage(tabId, request, background, timeoutMs = 12e4) {
  const result = chrome.tabs.sendMessage(tabId, request);
  let timer;
  if (!background)
    return Promise.race([
      result,
      new Promise((_, reject) => {
        timer = setTimeout(() => reject(Error("La fiche AliExpress n\u2019a pas r\xE9pondu. Recharge-la puis r\xE9essaie.")), Math.max(timeoutMs, 3e5));
      })
    ]).finally(() => clearTimeout(timer));
  try {
    return await Promise.race([
      result,
      new Promise((_, reject) => {
        timer = setTimeout(
          () => reject(
            Error(
              `${READ_TIMEOUT} R\xE9essaie la lecture du fournisseur.`
            )
          ),
          timeoutMs
        );
      })
    ]);
  } finally {
    clearTimeout(timer);
  }
}

// src/background/ebayRead.ts
var RESPONSE_TIMEOUT_MS = 15e3;
var LOADING_RETRY_MS = 300;
var EbayPageReadError = class extends Error {
  diagnostics;
  constructor(message2, operation, reconnected, attempts, code) {
    super(message2);
    this.name = "EbayPageReadError";
    this.diagnostics = {
      operation,
      reconnexion: reconnected,
      tentatives: attempts,
      code
    };
  }
};
function identity(url) {
  const canonical = canonicalEbayLibraryURL(url);
  const parsed = new URL(canonical.url);
  return canonical.kind === "item" ? `item:${parsed.pathname.split("/").at(-1)}` : `draft:${parsed.searchParams.get("draftId")}`;
}
function noReceiver(error) {
  const text3 = error instanceof Error ? error.message : typeof error === "string" ? error : "";
  return /receiving end does not exist/i.test(text3);
}
async function transport(tabId, type) {
  let timeout;
  try {
    return await Promise.race([
      chrome.tabs.sendMessage(tabId, { type }),
      new Promise((_, reject) => {
        timeout = setTimeout(
          () => reject(new Error("EBAY_READ_TIMEOUT")),
          RESPONSE_TIMEOUT_MS
        );
      })
    ]);
  } finally {
    clearTimeout(timeout);
  }
}
function validData(value, type, expectedIdentity) {
  if (type === "EBAY_LIBRARY_READ") {
    const snapshot = validateEbayLibrarySnapshot(value);
    if (identity(snapshot.url) !== expectedIdentity)
      throw Error("Capture d\u2019une autre annonce.");
    return snapshot;
  }
  if (!value || typeof value !== "object" || !validEbaySeed(value))
    throw Error("R\xE9f\xE9rence eBay invalide.");
  const seed = value;
  if (identity(seed.url) !== expectedIdentity)
    throw Error("R\xE9f\xE9rence d\u2019une autre annonce.");
  return {
    itemId: seed.itemId,
    url: seed.url,
    copyUrl: seed.copyUrl,
    title: seed.title,
    category: seed.category,
    ...seed.categoryId ? { categoryId: seed.categoryId } : {},
    specifics: seed.specifics.map(({ label, value: value2 }) => ({ label, value: value2 })),
    price: seed.price,
    currency: seed.currency,
    hasVariations: seed.hasVariations,
    capturedAt: seed.capturedAt,
    ...seed.categoryFromCopy === true ? { categoryFromCopy: true } : {}
  };
}
async function readEbayPage(tabId, expectedUrl, type) {
  let attempts = 0, reconnected = false;
  const fail3 = (text3, code) => {
    throw new EbayPageReadError(text3, type, reconnected, attempts, code);
  };
  if (!Number.isSafeInteger(tabId) || tabId < 0 || !["EBAY_LIBRARY_READ", "EBAY_SEED_READ"].includes(type))
    fail3(
      "L\u2019onglet ou le type de lecture eBay n\u2019est pas valide.",
      "CIBLE_INVALIDE"
    );
  let expectedIdentity;
  try {
    const canonical = canonicalEbayLibraryURL(expectedUrl);
    if (type === "EBAY_SEED_READ" && canonical.kind !== "item")
      fail3(
        "La r\xE9f\xE9rence d\u2019import doit \xEAtre une annonce eBay publique.",
        "CIBLE_INVALIDE"
      );
    expectedIdentity = identity(canonical.url);
  } catch (error) {
    if (error instanceof EbayPageReadError) throw error;
    fail3(
      "Ouvre une fiche produit ou un brouillon eBay US valide.",
      "CIBLE_INVALIDE"
    );
  }
  const guard = async (waitForLoad = false) => {
    for (let retry = 0; ; retry++) {
      if (!(await getSettings()).enabled)
        fail3(
          "AurOEBay est en pause. Active l\u2019extension pour lire cette annonce.",
          "EN_PAUSE"
        );
      let tab;
      try {
        tab = await chrome.tabs.get(tabId);
      } catch {
        fail3(
          "L\u2019onglet eBay n\u2019est plus accessible. R\xE9ouvre sa fiche puis r\xE9essaie.",
          "ONGLET_INACCESSIBLE"
        );
      }
      if (tab.id !== tabId)
        fail3(
          "L\u2019onglet eBay ne correspond plus \xE0 la fiche demand\xE9e.",
          "ONGLET_CHANGE"
        );
      try {
        if (tab.pendingUrl && identity(tab.pendingUrl) !== expectedIdentity)
          throw Error();
        if (tab.url && tab.url !== "about:blank" && identity(tab.url) !== expectedIdentity)
          throw Error();
      } catch {
        fail3(
          "La fiche eBay a chang\xE9 pendant la lecture. Aucun autre onglet n\u2019a \xE9t\xE9 modifi\xE9.",
          "ONGLET_CHANGE"
        );
      }
      if (tab.status === "complete") {
        try {
          if (!tab.url || identity(tab.url) !== expectedIdentity)
            throw Error();
        } catch {
          fail3(
            "La fiche eBay demand\xE9e n\u2019est pas ouverte dans cet onglet.",
            "ONGLET_CHANGE"
          );
        }
        return;
      }
      if (!waitForLoad || retry >= 2)
        fail3(
          "La fiche eBay est encore en cours de chargement. R\xE9essaie apr\xE8s son chargement.",
          "CHARGEMENT"
        );
      await new Promise((resolve) => setTimeout(resolve, LOADING_RETRY_MS));
    }
  };
  await guard(true);
  for (let retry = 0; retry < 4; retry++) {
    if (retry) await guard(true);
    attempts++;
    let response;
    try {
      response = await transport(tabId, type);
    } catch (error) {
      if (!noReceiver(error)) {
        fail3(
          error instanceof Error && error.message === "EBAY_READ_TIMEOUT" ? "La lecture eBay n\u2019a pas r\xE9pondu dans le d\xE9lai pr\xE9vu. Aucun traitement n\u2019a \xE9t\xE9 relanc\xE9." : "La r\xE9ponse eBay a \xE9t\xE9 perdue ou la lecture n\u2019a pas pu \xEAtre d\xE9livr\xE9e. Aucun traitement n\u2019a \xE9t\xE9 relanc\xE9.",
          "LECTURE_INTERROMPUE"
        );
      }
      if (!reconnected && retry === 0) {
        await new Promise((resolve) => setTimeout(resolve, LOADING_RETRY_MS));
        continue;
      }
      if (!reconnected) {
        await guard(true);
        if (!chrome.scripting?.executeScript)
          fail3(
            "Cette version ne peut pas reconnecter la lecture eBay. Recharge l\u2019extension mise \xE0 jour puis r\xE9essaie.",
            "RECONNEXION_INDISPONIBLE"
          );
        try {
          await chrome.scripting.executeScript({
            target: { tabId, frameIds: [0] },
            func: () => {
              globalThis.__auroebayReadReconnect = true;
            }
          });
          await guard(true);
          await chrome.scripting.executeScript({
            target: { tabId, frameIds: [0] },
            files: ["ebay.js"]
          });
          reconnected = true;
        } catch (error2) {
          if (error2 instanceof EbayPageReadError) throw error2;
          fail3(
            "Chrome n\u2019a pas autoris\xE9 la reconnexion de cette fiche eBay. V\xE9rifie l\u2019acc\xE8s de l\u2019extension \xE0 eBay puis r\xE9essaie.",
            "RECONNEXION_REFUSEE"
          );
        }
      }
      if (retry >= 3)
        fail3(
          "La lecture eBay reste indisponible apr\xE8s reconnexion. R\xE9essaie sur cette fiche une fois son chargement termin\xE9.",
          "RECEPTION_INDISPONIBLE"
        );
      await new Promise((resolve) => setTimeout(resolve, LOADING_RETRY_MS));
      continue;
    }
    await guard();
    if (!response || response.ok !== true) {
      const text3 = response && response.ok === false && typeof response.error === "string" ? response.error : "La fiche eBay n\u2019a pas fourni de capture exploitable.";
      return fail3(text3, "CAPTURE_REFUSEE");
    }
    try {
      return validData(response.data, type, expectedIdentity);
    } catch {
      fail3(
        "La r\xE9ponse eBay ne correspond pas \xE0 une capture valide de cette fiche. Aucun contenu n\u2019a \xE9t\xE9 enregistr\xE9.",
        "CAPTURE_INVALIDE"
      );
    }
  }
  return fail3("La lecture eBay reste indisponible.", "RECEPTION_INDISPONIBLE");
}

// src/aliexpress/descriptionResource.ts
var DESCRIPTION_RESOURCE_LIMIT = 4e5;
function descriptionResourceURL(value) {
  if (typeof value !== "string" || value.length > 2e3)
    throw Error("Ressource de description AliExpress invalide.");
  const url = new URL(value);
  if (url.protocol !== "https:" || url.username || url.password || url.port || url.hash || !/(^|\.)(alicdn\.com|aliexpress-media\.com)$/.test(url.hostname) || // The public description CDN (DESC.pcDescUrl) carries a cache "token"/"key"
  // that is not a credential; it is fetched without cookies.
  !/^\/product\/description\//.test(url.pathname) && [...url.searchParams.keys()].some(
    (key4) => /token|secret|auth|session|cookie|password|credential|signature|api.?key/i.test(
      key4
    )
  ))
    throw Error("Ressource de description AliExpress non autoris\xE9e.");
  return url.href;
}

// src/background/supplierDescriptionResource.ts
async function readSupplierDescriptionResource(sender, pageValue, resourceValue) {
  const tabId = sender.tab?.id;
  if (sender.frameId !== 0 || tabId === void 0 || !Number.isSafeInteger(tabId) || !isSupplierCostReadTab(tabId) || typeof pageValue !== "string")
    throw Error("Lecture de ressource AliExpress non autoris\xE9e.");
  const pageURL = aliProductURL(pageValue);
  if (pageValue !== pageURL || aliProductURL(sender.url ?? "") !== pageURL)
    throw Error("La fiche AliExpress a chang\xE9 pendant la lecture.");
  const resourceURL = descriptionResourceURL(resourceValue);
  const verify = async () => {
    const settings = await getSettings();
    if (!settings.enabled || !settings.captureEnabled)
      throw Error("Lecture fournisseur interrompue : capture d\xE9sactiv\xE9e.");
    const tab = await chrome.tabs.get(tabId).catch(() => void 0);
    if (!tab || tab.id !== tabId || tab.status !== "complete" || aliProductURL(tab.url ?? "") !== pageURL || !isSupplierCostReadTab(tabId))
      throw Error("La fiche AliExpress a chang\xE9 pendant la lecture.");
  };
  await verify();
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 5e3);
  try {
    const response = await fetch(resourceURL, {
      credentials: "omit",
      redirect: "error",
      referrerPolicy: "no-referrer",
      cache: "no-store",
      signal: controller.signal
    });
    if (!response.ok || response.redirected || response.url !== resourceURL || !/^(text\/html|application\/xhtml\+xml)(?:\s*;|$)/i.test(
      response.headers.get("content-type") ?? ""
    ) || Number(response.headers.get("content-length")) > DESCRIPTION_RESOURCE_LIMIT || !response.body)
      throw Error("Ressource de description AliExpress indisponible.");
    const reader = response.body.getReader();
    const parts = [];
    let bytes = 0;
    try {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        bytes += value.length;
        if (bytes > DESCRIPTION_RESOURCE_LIMIT) {
          controller.abort();
          throw Error("La description AliExpress d\xE9passe la taille maximale.");
        }
        parts.push(value);
      }
    } finally {
      reader.releaseLock();
    }
    const joined = new Uint8Array(bytes);
    let position = 0;
    for (const part of parts) {
      joined.set(part, position);
      position += part.length;
    }
    const html = new TextDecoder("utf-8", { fatal: true }).decode(joined);
    await verify();
    return { html, url: resourceURL };
  } finally {
    clearTimeout(timeout);
  }
}

// src/background/tabPanel.ts
function supportsTabPanel(value) {
  try {
    const url = new URL(value ?? "");
    return url.protocol === "https:" && /(^|\.)(?:ebay\.com|aliexpress\.(?:com|us))$/i.test(url.hostname);
  } catch {
    return false;
  }
}
function setupTabPanels() {
  const configure = (tabId, url) => chrome.sidePanel.setOptions(
    supportsTabPanel(url) ? { tabId, path: `panel.html?tabId=${tabId}`, enabled: true } : { tabId, enabled: false }
  );
  chrome.tabs.onUpdated.addListener((tabId, change, tab) => {
    if (!change.url && change.status !== "complete") return;
    void configure(tabId, change.url ?? tab.url).catch(() => {
    });
  });
  void chrome.sidePanel.setOptions({ enabled: false }).then(async () => {
    const tabs = await chrome.tabs.query({});
    await Promise.allSettled(
      tabs.flatMap(
        (tab) => tab.id === void 0 ? [] : [configure(tab.id, tab.url)]
      )
    );
    await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: false });
  }).catch(() => {
  });
  chrome.action.onClicked.addListener((tab) => {
    if (tab.id !== void 0 && supportsTabPanel(tab.url)) {
      void chrome.sidePanel.open({ tabId: tab.id }).catch(() => openHome());
      return;
    }
    void openHome();
  });
}
async function openHome() {
  const url = chrome.runtime.getURL("routine.html");
  const [open] = await chrome.tabs.query({ url: url + "*" }).catch(() => []);
  if (open?.id !== void 0) {
    await chrome.tabs.update(open.id, { active: true });
    if (open.windowId !== void 0) await chrome.windows.update(open.windowId, { focused: true }).catch(() => {
    });
    return;
  }
  await chrome.tabs.create({ url });
}

// src/core/variantMatch.ts
function variantValue(value) {
  return value.normalize("NFKC").toLowerCase().replace(/(\d),(\d)/g, "$1.$2").replace(/[\s\u00a0_-]+/g, "").trim();
}
function compact2(value) {
  return variantValue(value).replace(/(mm|cm|inch|in|ml|kg|g|pcs|pc)(?=\b|\d|$)/g, "").replace(/[^\p{L}\p{N}]+/gu, "");
}
function distance(a, b) {
  const d = Array.from({ length: b.length + 1 }, (_, i) => i);
  for (let i = 1; i <= a.length; i++) {
    let prev = d[0];
    d[0] = i;
    for (let j = 1; j <= b.length; j++) {
      const tmp = d[j];
      d[j] = Math.min(d[j] + 1, d[j - 1] + 1, prev + (a[i - 1] === b[j - 1] ? 0 : 1));
      prev = tmp;
    }
  }
  return d[b.length];
}
function supplierValueFor(value, supplierValues) {
  const exact = supplierValues.filter((v) => variantValue(v) === variantValue(value));
  if (exact.length) return exact[0];
  const wanted = standardSize(value)?.size;
  const sized = wanted ? supplierValues.filter((v) => standardSize(v)?.size === wanted) : [];
  if (sized.length === 1) return sized[0];
  const c = compact2(value);
  const same = [...new Set(supplierValues.filter((v) => c && compact2(v) === c))];
  if (same.length === 1) return same[0];
  if (c.length >= 4) {
    const close = [
      ...new Set(
        supplierValues.filter((v) => {
          const k = compact2(v);
          if (k.length < 4 || /^\d+$/.test(k) || /^\d+$/.test(c)) return false;
          return k.startsWith(c) || c.startsWith(k) || Math.min(k.length, c.length) >= 5 && distance(k, c) <= 2;
        })
      )
    ];
    if (close.length === 1) return close[0];
  }
  return value;
}

// src/core/listingSync.ts
var key2 = (values) => JSON.stringify(values.map(variantValue).sort());
var ebayRowKey = (values) => JSON.stringify(values);
function typedPrice(value) {
  if (typeof value !== "string" && typeof value !== "number") return null;
  const t = String(value).trim().replace(",", ".");
  if (!/^\d{1,5}(\.\d{1,2})?$/.test(t)) return null;
  const n = Number(t);
  return n >= 0.99 && n <= 99999 ? n.toFixed(2) : null;
}
function planListingSync(rows, scan, rule, options) {
  const supplierValues = [...new Set([...scan.costs ?? [], ...scan.unavailable ?? []].flatMap((c) => c.values))];
  const ebayKey = (values) => key2(values.map((v) => supplierValueFor(v, supplierValues)));
  const costs2 = (scan.costs ?? []).filter(
    (c) => c.currency === "USD" && Number.isFinite(c.cost) && c.cost > 0
  );
  const out = new Set((scan.unavailable ?? []).map((u) => key2(u.values)));
  const simple = rows.length === 1 && rows[0].values.length === 0;
  return rows.map((row, index) => {
    let cost = null;
    let supplier = "unknown";
    const chosen = simple ? options.links?.[ebayRowKey(row.values)] : void 0;
    if (chosen?.length) {
      const hits = costs2.filter((c) => key2(c.values) === key2(chosen));
      if (hits.length === 1) {
        cost = hits[0].cost;
        supplier = "in_stock";
      } else if (out.has(key2(chosen))) supplier = "out_of_stock";
    } else if (simple) {
      if (costs2.length === 1) {
        cost = costs2[0].cost;
        supplier = "in_stock";
      } else if (!costs2.length && out.size) supplier = "out_of_stock";
    } else {
      const link = options.links?.[ebayRowKey(row.values)];
      const k = link?.length ? key2(link) : ebayKey(row.values);
      const hits = costs2.filter((c) => key2(c.values) === k);
      if (hits.length === 1) {
        cost = hits[0].cost;
        supplier = "in_stock";
      } else if (out.has(k)) supplier = "out_of_stock";
    }
    const ruled = cost !== null && rule ? ruledPrice(cost, rule) : null;
    const typed = options.quantities?.[index];
    return {
      ...row,
      supplier,
      cost,
      newPrice: typedPrice(options.prices_?.[index]) ?? (options.prices && ruled ? ruled : row.price),
      newQuantity: typeof typed === "number" && Number.isInteger(typed) && typed >= 0 && typed <= 999 ? typed : !options.stock ? row.quantity : supplier === "in_stock" ? DEFAULT_IMPORT_QUANTITY : supplier === "out_of_stock" || options.zeroUnknown ? 0 : row.quantity
    };
  });
}
function mskuRows(model) {
  return model.variationItem.map((r) => ({
    values: r.variationSpecific.map((s) => s.value[0] ?? ""),
    price: String(r.listingVariation.price),
    quantity: Number(r.listingVariation.quantity) || 0
  }));
}
function mskuRowPhotos(model) {
  const set = model.variationSpecificPictureSet;
  const byValue = new Map((set?.variationSpecificPicture ?? []).map((p) => [p.variationSpecificValue, p.picture?.[0]?.url]));
  return model.variationItem.map((item) => {
    const value = item.variationSpecific.find((s) => s.name === set?.variationSpecificName)?.value[0];
    const url = value === void 0 ? void 0 : byValue.get(value);
    return url && /^https:\/\//.test(url) ? url : null;
  });
}
function optionPhoto(values, images) {
  for (const value of values) {
    const url = images?.find((i) => i.value === value)?.url;
    if (url && /^https:\/\//.test(url)) return url;
  }
  return null;
}
function mskuSavePayload(model, rows, draftId, listingMode, upiFieldName) {
  if (rows.length !== model.variationItem.length) throw Error("Variantes eBay modifi\xE9es entre-temps.");
  const set = model.variationSpecificPictureSet;
  return {
    action: "save",
    draftId,
    listingMode,
    restricted: false,
    upiFieldName,
    variationItem: model.variationItem.map((item, index) => ({
      variationSpecific: Object.fromEntries(item.variationSpecific.map((s) => [s.name, s.value[0]])),
      listingVariation: { price: rows[index].newPrice, quantity: rows[index].newQuantity },
      sku: item.sku ?? "",
      state: "enabled",
      productInfo: item.productInfo ?? {},
      edited: true,
      index
    })),
    variationSpecificPictureSet: set?.variationSpecificName && set.variationSpecificPicture ? {
      [set.variationSpecificName]: Object.fromEntries(
        set.variationSpecificPicture.map((p) => [p.variationSpecificValue, p.picture.map((x) => x.url)])
      )
    } : {},
    variationSpecificsMetaData: model.variationSpecificsMetaData.map((m) => ({ name: m.name, value: [...m.value] }))
  };
}

// src/background/listingSync.ts
var BASE = "https://www.ebay.com/robots.txt";
var KEY3 = (t) => "listingSync:" + t;
var LINKS = "variantLinks:v1";
async function productLinks(productId2) {
  const all3 = (await chrome.storage.local.get(LINKS))[LINKS] ?? {};
  return all3[productId2] ?? {};
}
var LISTING_PRICES = "listingPrices:v1";
async function saveListingPrices(productId2, rows) {
  const all3 = (await chrome.storage.local.get(LISTING_PRICES))[LISTING_PRICES] ?? {};
  const kept2 = rows.filter((r) => Number.isFinite(r.price) && r.price > 0);
  const pairs2 = kept2.flatMap((r) => r.cost ? [{ price: r.price, cost: r.cost }] : []);
  if (kept2.length) all3[productId2] = { prices: kept2.map((r) => r.price), pairs: pairs2, at: Date.now() };
  await chrome.storage.local.set({ [LISTING_PRICES]: all3 });
}
var PRODUCT_SHIPPING = "productShipping:v1";
async function saveProductShipping(productId2, shipping2) {
  if (!shipping2) return;
  const charge = shippingCharge(shipping2);
  if (charge.usual && charge.freeOver === USUAL_SHIPPING.freeOver) return;
  const all3 = (await chrome.storage.local.get(PRODUCT_SHIPPING))[PRODUCT_SHIPPING] ?? {};
  all3[productId2] = { ...charge, at: Date.now() };
  await chrome.storage.local.set({ [PRODUCT_SHIPPING]: all3 });
}
async function saveProductLinks(productId2, links) {
  const all3 = (await chrome.storage.local.get(LINKS))[LINKS] ?? {};
  if (Object.keys(links).length) all3[productId2] = links;
  else delete all3[productId2];
  await chrome.storage.local.set({ [LINKS]: all3 });
}
async function pageOpenListing(input) {
  const url = input.itemId ? `/lstng?mode=ReviseItem&itemId=${input.itemId}` : `/lstng?draftId=${input.draftId}&mode=AddItem`;
  const r = await fetch(url, { credentials: "include" }).catch(() => null);
  if (!r) {
    const probe = await fetch(url, { credentials: "include", redirect: "manual" }).catch(() => null);
    return { error: probe?.type === "opaqueredirect" ? "SIGNIN" : "eBay ne r\xE9pond pas. V\xE9rifie ta connexion, puis recommence." };
  }
  if (/signin/i.test(new URL(r.url).hostname + new URL(r.url).pathname)) return { error: "SIGNIN" };
  if (!r.ok) return { error: `eBay a refus\xE9 l\u2019ouverture de l\u2019annonce (HTTP ${r.status}).` };
  const html = await r.text();
  const u = html.replace(/\\"/g, '"');
  const draftId = input.draftId ?? u.match(/"draftId"\s*:\s*"?(\d{8,20})/)?.[1];
  const value = (name) => u.match(new RegExp(`"name":"${name}","value":("[^"]*"|[\\d.]+|null)`))?.[1]?.replace(/"/g, "") ?? null;
  return {
    draftId: draftId ?? null,
    categoryId: u.match(/"categoryId"\s*:\s*"?(\d{2,10})/)?.[1] ?? null,
    msku: /"isMsku"\s*:\s*"true"/.test(u),
    price: value("price"),
    quantity: value("quantity"),
    title: value("title")
  };
}
function pageReadMsku() {
  const h = document.documentElement.innerHTML;
  const at = h.indexOf('"variationItem"');
  if (at < 0) return null;
  for (let s = h.lastIndexOf("{", at); s > 0 && at - s < 3e5; s = h.lastIndexOf("{", s - 1)) {
    let depth = 0, quoted = false, escaped = false, end = -1;
    for (let i = s; i < h.length; i++) {
      const c = h[i];
      if (quoted) {
        if (escaped) escaped = false;
        else if (c === "\\") escaped = true;
        else if (c === '"') quoted = false;
        continue;
      }
      if (c === '"') quoted = true;
      else if (c === "{") depth++;
      else if (c === "}" && --depth === 0) {
        end = i;
        break;
      }
    }
    if (end < at) continue;
    try {
      const model = JSON.parse(h.slice(s, end + 1));
      if (Array.isArray(model.variationItem))
        return { model, upi: h.match(/"upiFieldName"\s*:\s*"(\w+)"/)?.[1] ?? "upc" };
    } catch {
    }
  }
  return null;
}
async function pageSaveMsku(body2) {
  const r = await fetch("/msku-update", {
    method: "POST",
    credentials: "include",
    headers: { Accept: "text/html,application/json" },
    body: JSON.stringify(body2)
  });
  return { status: r.status, text: (await r.text()).slice(0, 4e3) };
}
async function pagePutSimple(input) {
  const page = `/lstng?draftId=${input.draftId}&mode=${input.mode}`;
  const html = await (await fetch(page, { credentials: "include" })).text();
  let token = null;
  for (const s of [html, html.replace(/\\"/g, '"').replace(/\\\\/g, "\\")]) {
    const m = s.match(/"\/lstng\/api\/listing_draft\/:draftId\(\\+d\+\)"\s*:\s*"([^"]+)"/);
    if (m) {
      token = m[1];
      break;
    }
  }
  if (!token) return { status: 0, error: "Jeton eBay introuvable." };
  const r = await fetch(`/lstng/api/listing_draft/${input.draftId}?mode=${input.mode}`, {
    method: "PUT",
    credentials: "include",
    referrer: location.origin + page,
    headers: { "content-type": "application/json", srt: token },
    body: JSON.stringify({ price: input.price, quantity: input.quantity })
  });
  const text3 = await r.text();
  return { status: r.status, error: /"errors"\s*:\s*\[\s*\{/.test(text3) ? "eBay a refus\xE9 le prix ou la quantit\xE9." : null };
}
async function waitTab(tabId, prefix) {
  for (let i = 0; i < 100; i++) {
    const tab = await chrome.tabs.get(tabId);
    if (tab.status === "complete" && tab.url?.startsWith(prefix)) return;
    await new Promise((r) => setTimeout(r, 200));
  }
  throw Error("La page eBay ne se charge pas.");
}
async function run2(tabId, func, ...args) {
  const [result] = await chrome.scripting.executeScript({
    target: { tabId },
    world: "MAIN",
    func,
    args
  });
  return result?.result;
}
var mskuURL = (s) => `https://bulkedit.ebay.com/msku?draftId=${s.draftId}&listingMode=${s.mode}&categoryId=${s.categoryId}&decimalSymbol=.&maxPics=24&loadDraft=true`;
async function previewListingSync(productId2) {
  const p = await executeLibrary({ action: "get-product", productId: String(productId2) });
  const supplier = p.suppliers.find((s) => s.id === p.primarySupplierId) ?? p.suppliers[0];
  if (!supplier) throw Error("Ce produit n\u2019a pas de fournisseur AliExpress.");
  const item = p.ownListings.find((l) => l.kind === "item");
  const draft = p.ownListings.find((l) => l.kind === "draft");
  const itemId = item ? new URL(item.url).pathname.match(/(\d{9,15})$/)?.[1] : void 0;
  const draftId = !itemId && draft ? new URL(draft.url).searchParams.get("draftId") ?? void 0 : void 0;
  if (!itemId && !draftId) throw Error("Aucune annonce ni brouillon eBay reli\xE9 \xE0 ce produit.");
  const rule = (await chrome.storage.local.get("variantPricing")).variantPricing ?? null;
  const scanning = readSupplierScan(supplier.url);
  scanning.catch(() => {
  });
  const tab = await chrome.tabs.create({ url: BASE, active: false });
  const tabId = tab.id;
  try {
    await waitTab(tabId, BASE);
    const info = await run2(tabId, pageOpenListing, { itemId, draftId });
    if (info && "error" in info && info.error === "SIGNIN") {
      await chrome.tabs.update(tabId, { url: EBAY_SIGNIN_PAGE, active: true });
      throw Object.assign(Error(EBAY_SIGNIN_TEXT), { keepTab: true });
    }
    if (!info || "error" in info) throw Error(info?.error ?? "Annonce eBay illisible.");
    if (!info.draftId || !info.categoryId) throw Error("R\xE9vision eBay non ouverte (identifiant manquant).");
    const state = {
      token: crypto.randomUUID(),
      productId: p.id,
      tabId,
      mode: itemId ? "ReviseItem" : "AddItem",
      draftId: info.draftId,
      categoryId: info.categoryId,
      msku: info.msku,
      upi: "upc",
      rows: [],
      scan: { at: 0, costs: [], unavailable: [] },
      rule,
      at: Date.now()
    };
    if (state.msku) {
      await chrome.tabs.update(tabId, { url: mskuURL(state) });
      await waitTab(tabId, "https://bulkedit.ebay.com/msku");
      const read3 = await run2(tabId, pageReadMsku);
      if (!read3) throw Error("Variantes eBay illisibles.");
      state.model = read3.model;
      state.upi = read3.upi;
      state.rows = mskuRows(state.model);
    } else {
      if (!info.price || !/^\d+(\.\d{1,2})?$/.test(info.price)) throw Error("Prix eBay actuel illisible.");
      state.rows = [{ values: [], price: info.price, quantity: Number(info.quantity) || 0 }];
    }
    const read2 = await scanning;
    state.scan = read2.scan;
    const shipping2 = shippingCharge(read2.shipping ?? supplier.source.shippingDetails);
    if (state.rule) state.rule = { ...state.rule, shipping: shipping2 };
    await saveProductShipping(p.id, read2.shipping);
    await chrome.storage.session.set({ [KEY3(state.token)]: state });
    apiTrace("sync", "preview", { mode: state.mode, variants: state.rows.length, msku: state.msku });
    const links = await productLinks(p.id);
    const both = planListingSync(state.rows, state.scan, state.rule, { stock: true, prices: true });
    const linked = planListingSync(state.rows, state.scan, state.rule, { stock: true, prices: true, links });
    await saveListingPrices(p.id, linked.map((r) => ({ price: Number(r.price), cost: r.cost })));
    const images = read2.images.length ? read2.images : supplier.source.variantImages;
    const photos = state.model ? mskuRowPhotos(state.model) : [];
    const choices = [
      ...state.scan.costs.filter((c) => c.currency === "USD" && c.cost > 0).map((c) => ({
        values: c.values,
        cost: c.cost,
        inStock: true,
        rulePrice: state.rule ? ruledPrice(c.cost, state.rule) : null,
        photo: optionPhoto(c.values, images)
      })),
      ...state.scan.unavailable.map((u) => ({ values: u.values, cost: null, inStock: false, rulePrice: null, photo: optionPhoto(u.values, images) }))
    ];
    return {
      token: state.token,
      live: state.mode === "ReviseItem",
      hasRule: !!rule,
      shipping: shipping2,
      choices,
      links: both.map((r) => links[ebayRowKey(r.values)] ?? null),
      rows: both.map((r, i) => ({
        photo: photos[i] ?? null,
        values: r.values,
        price: r.price,
        quantity: r.quantity,
        supplier: r.supplier,
        cost: r.cost,
        rulePrice: r.newPrice,
        stockQuantity: r.newQuantity
      }))
    };
  } catch (e) {
    if (!e.keepTab) await chrome.tabs.remove(tabId).catch(() => {
    });
    throw e;
  }
}
async function applyListingSync(token, options) {
  const state = (await chrome.storage.session.get(KEY3(String(token))))[KEY3(String(token))];
  if (!state || Date.now() - state.at > 30 * 60 * 1e3) {
    if (state) {
      await chrome.tabs.remove(state.tabId).catch(() => {
      });
      await chrome.storage.session.remove(KEY3(String(token))).catch(() => {
      });
    }
    throw Error("Relis l\u2019annonce avant de l\u2019envoyer (plus de 30 min).");
  }
  const known = new Set([...state.scan.costs, ...state.scan.unavailable].map((c) => JSON.stringify(c.values)));
  const links = await productLinks(state.productId);
  if (Array.isArray(options.links))
    state.rows.forEach((row, i) => {
      const chosen = options.links[i];
      const k = ebayRowKey(row.values);
      if (Array.isArray(chosen) && known.has(JSON.stringify(chosen))) links[k] = chosen;
      else if (chosen === null) delete links[k];
    });
  const quantities = Array.isArray(options.quantities) ? state.rows.map((_, i) => {
    const q = options.quantities[i];
    return typeof q === "number" && Number.isInteger(q) && q >= 0 && q <= 999 ? q : null;
  }) : void 0;
  const quiet = options.quiet === true;
  const planned = planListingSync(state.rows, state.scan, state.rule, {
    stock: options.stock !== false,
    prices: options.prices === true,
    zeroUnknown: options.zeroUnknown === true,
    links,
    quantities,
    prices_: Array.isArray(options.typedPrices) ? state.rows.map((_, i) => typedPrice(options.typedPrices[i])) : void 0
  });
  const rows = quiet && options.lower !== true ? planned.map((r) => Number(r.newPrice) < Number(r.price) ? { ...r, newPrice: r.price } : r) : planned;
  const changedRows = rows.filter((r) => Number(r.newPrice) !== Number(r.price) || r.newQuantity !== r.quantity);
  await chrome.tabs.get(state.tabId).catch(() => {
    throw Error("L\u2019onglet eBay de pr\xE9paration a \xE9t\xE9 ferm\xE9. Relance la mise \xE0 jour.");
  });
  if (changedRows.length) {
    if (state.msku) {
      const tab2 = await chrome.tabs.get(state.tabId);
      if (!tab2.url?.startsWith("https://bulkedit.ebay.com/msku")) {
        await chrome.tabs.update(state.tabId, { url: mskuURL(state) });
        await waitTab(state.tabId, "https://bulkedit.ebay.com/msku");
      }
      const body2 = mskuSavePayload(state.model, rows, state.draftId, state.mode, state.upi);
      const res = await run2(state.tabId, pageSaveMsku, body2);
      const errors = mskuSaveErrors(res?.text ?? "");
      if (!res || res.status !== 200 || errors?.length || !/"ack"\s*:\s*"success"/.test(res.text))
        throw Error(`eBay a refus\xE9 les variantes : ${(errors ?? []).slice(0, 3).join(" ") || "r\xE9ponse inattendue"}`);
    } else {
      const tab2 = await chrome.tabs.get(state.tabId);
      if (!tab2.url?.startsWith("https://www.ebay.com/")) {
        await chrome.tabs.update(state.tabId, { url: BASE });
        await waitTab(state.tabId, BASE);
      }
      const res = await run2(state.tabId, pagePutSimple, {
        draftId: state.draftId,
        mode: state.mode,
        price: rows[0].newPrice,
        quantity: rows[0].newQuantity
      });
      if (!res || res.status !== 200 || res.error) throw Error(res?.error ?? "eBay a refus\xE9 la mise \xE0 jour.");
    }
  }
  await saveProductLinks(state.productId, links);
  await saveListingPrices(state.productId, rows.map((r) => ({ price: Number(r.newPrice), cost: r.cost })));
  apiTrace("sync", "applied", { changed: changedRows.length, mode: state.mode, links: Object.keys(links).length, quiet });
  const result = {
    changed: changedRows.length,
    zero: changedRows.filter((r) => r.newQuantity === 0 && r.quantity > 0).length,
    restocked: changedRows.filter((r) => r.newQuantity > 0 && r.quantity === 0).length,
    live: state.mode === "ReviseItem"
  };
  if (quiet) {
    await chrome.storage.session.remove(KEY3(state.token));
    if (!changedRows.length) await chrome.tabs.remove(state.tabId).catch(() => {
    });
    else await chrome.tabs.update(state.tabId, { url: `https://www.ebay.com/lstng?draftId=${state.draftId}&mode=${state.mode}` });
    return result;
  }
  const tab = await chrome.tabs.update(state.tabId, {
    url: `https://www.ebay.com/lstng?draftId=${state.draftId}&mode=${state.mode}`,
    active: true
  });
  if (tab?.windowId !== void 0) await chrome.windows.update(tab.windowId, { focused: true }).catch(() => {
  });
  await chrome.storage.session.remove(KEY3(state.token));
  return result;
}
async function cancelListingSync(token) {
  const state = (await chrome.storage.session.get(KEY3(String(token))))[KEY3(String(token))];
  if (!state) return false;
  await chrome.tabs.remove(state.tabId).catch(() => {
  });
  await chrome.storage.session.remove(KEY3(state.token));
  return true;
}

// src/aliexpress/orderInfo.ts
async function aliOrderInfoInPage(ids, details) {
  const SYMBOL = { "\u20AC": "EUR", $: "USD", "US $": "USD", "\xA3": "GBP" };
  const moneyText = (v) => {
    const m = v.match(/^\s*(US \$|€|\$|£)\s?(\d[\d.,\s]*)\s*$/) ?? v.match(/^\s*(\d[\d.,\s]*)\s?(€|\$|£)\s*$/);
    if (!m) return null;
    const [sym, num2] = /\d/.test(m[1][0]) ? [m[2], m[1]] : [m[1], m[2]];
    const t = num2.replace(/\s/g, "");
    const amount2 = Number(/,\d{1,2}$/.test(t) ? t.replace(/\./g, "").replace(",", ".") : t.replace(/,/g, ""));
    return Number.isFinite(amount2) && amount2 > 0 ? { amount: amount2, currency: SYMBOL[sym] ?? "USD" } : null;
  };
  const moneyObject = (o) => {
    const currency = String(o.currency ?? o.currencyCode ?? "");
    const raw = o.amount ?? o.value ?? (typeof o.cent === "number" ? o.cent / 100 : void 0);
    const amount2 = typeof raw === "string" ? Number(raw) : raw;
    return /^[A-Z]{3}$/.test(currency) && Number.isFinite(amount2) && amount2 > 0 ? { amount: amount2, currency } : null;
  };
  const findTotal = (root) => {
    const found = [];
    const walk = (node, depth) => {
      if (!node || typeof node !== "object" || depth > 14) return;
      const o = node;
      const strings2 = Object.values(o).filter((v) => typeof v === "string");
      if (strings2.some((v) => /^\s*(Order total|Total|Total payé|Montant total|Total price)\s*:?\s*$/i.test(v)))
        for (const v of strings2) {
          const m = moneyText(v);
          if (m) found.push({ ...m, rank: 3 });
        }
      for (const [key4, value] of Object.entries(o)) {
        if (/^(actual|order|total|pay)\w*(amount|price|fee)$|^total\w*/i.test(key4)) {
          const m = typeof value === "string" ? moneyText(value) : value && typeof value === "object" ? moneyObject(value) : null;
          if (m) found.push({ ...m, rank: /actual|pay/i.test(key4) ? 2 : 1 });
        }
        walk(value, depth + 1);
      }
    };
    walk(root, 0);
    found.sort((a, b) => b.rank - a.rank);
    return found[0] ? { amount: Math.round(found[0].amount * 100) / 100, currency: found[0].currency } : null;
  };
  const mtop = window.lib?.mtop;
  if (!mtop?.request) return [];
  const call2 = (api, data, type = "POST") => mtop.request({ api, v: "1.0", data, type, dataType: "json", needLogin: true, timeout: 15e3 }).then((r) => r.data).catch(() => null);
  const out = [];
  for (const id of ids) {
    let receiver = null;
    let total2 = null;
    if (details) {
      const d = await call2("mtop.aliexpress.trade.buyer.order.detail", { tradeOrderId: id });
      const a = Object.values(d?.data ?? {}).find((m) => m?.fields?.addressVO)?.fields?.addressVO;
      if (a) receiver = { name: a.contactName ?? "", zip: a.postCode ?? "", country: a.countryCode ?? "" };
      total2 = findTotal(d);
    }
    const t = JSON.stringify(await call2("mtop.ae.ld.querydetail", { tradeOrderId: id, terminalType: "PC" }, "GET") ?? {});
    const tracking = t.match(/"mailNo"\s*:\s*"([A-Za-z0-9-]{6,40})"/)?.[1] ?? "";
    const carrier = t.match(/"logisticsCarrierName"\s*:\s*"([^"]{2,40})"/)?.[1] ?? "";
    out.push({ orderId: id, receiver, tracking, carrier: carrier === "-" ? "" : carrier, ...details ? { total: total2 } : {} });
    await new Promise((r) => setTimeout(r, 150));
  }
  return out;
}
async function aliParcelsInPage(ids) {
  const mtop = window.lib?.mtop;
  if (!mtop?.request) return [];
  const call2 = (api, data, type = "POST") => mtop.request({ api, v: "1.0", data, type, dataType: "json", needLogin: true, timeout: 15e3 }).then((r) => r.data).catch(() => null);
  const str = (v, max = 300) => typeof v === "string" ? v.slice(0, max) : "";
  const num2 = (v) => typeof v === "number" && Number.isFinite(v) ? v : null;
  const out = [];
  const aliLink = (v) => {
    if (typeof v !== "string" || v.length > 600) return "";
    try {
      const u = new URL(v, location.href);
      return /(^|\.)aliexpress\.(com|us)$/.test(u.hostname) && u.protocol === "https:" && u.pathname.startsWith("/p/") ? u.href : "";
    } catch {
      return "";
    }
  };
  const disputeLinks = (fields) => {
    const lines = Array.isArray(fields.productVOList) ? fields.productVOList : [];
    const b = lines.flatMap((l) => Array.isArray(l?.buttonVOS) ? l.buttonVOS : []).find((x) => x?.type === "OPEN_DISPUTE");
    if (!b) return null;
    const received = aliLink(b.extMap?.okButton?.href) || aliLink(b.href);
    const notReceived = aliLink(b.extMap?.cancelButton?.href) || aliLink(b.href);
    return received && notReceived ? { received, notReceived } : null;
  };
  const one = async (id) => {
    const [d, t] = await Promise.all([
      call2("mtop.aliexpress.trade.buyer.order.detail", { tradeOrderId: id }),
      call2("mtop.ae.ld.querydetail", { tradeOrderId: id, terminalType: "PC" }, "GET")
    ]);
    const blocks = Object.entries(d?.data ?? {});
    const block = (name) => blocks.find(([k]) => k.startsWith(name))?.[1]?.fields ?? {};
    const status = block("detail_order_status_block");
    const info = block("detail_simple_order_info_component");
    const lines = Array.isArray(t?.module?.trackingDetailLineList) ? t.module.trackingDetailLineList : [];
    const events = lines.flatMap((l) => Array.isArray(l?.detailList) ? l.detailList.slice(0, 3) : []).map((e) => ({ time: num2(e?.time) ?? 0, text: str(e?.trackingDetailDesc, 200), code: str(e?.trackingSecondCode ?? e?.trackingPrimaryCode, 60) })).filter((e) => e.time > 0).sort((a, b) => b.time - a.time).slice(0, 3);
    const eta = lines.map((l) => num2(l?.etaInfo?.endEtaTime)).filter((x) => x !== null);
    const promises = (Array.isArray(t?.module?.fastDeliveryInfoDTO?.fdContentList) ? t.module.fastDeliveryInfoDTO.fdContentList : []).map((x) => str(x, 200)).filter(Boolean).slice(0, 6);
    out.push({
      orderId: id,
      ok: !!d && blocks.length > 0,
      status: str(status.title, 80),
      placed: str(info.orderCreatTime, 40),
      autoConfirmAt: num2(status.gmtTrigger),
      reminder: str(status.reminder, 400),
      events,
      etaEnd: eta.length ? Math.max(...eta) : null,
      promises,
      disputeLinks: disputeLinks(block("detail_product_block"))
    });
  };
  const queue5 = [...ids];
  await Promise.all(Array.from({ length: Math.min(4, queue5.length) }, async () => {
    for (let id = queue5.shift(); id; id = queue5.shift()) await one(id);
  }));
  return out;
}

// src/core/libraryNavigation.ts
function sellerHubListingsURL(value) {
  try {
    const url = new URL(value);
    return url.protocol === "https:" && /(^|\.)ebay\.com$/.test(url.hostname) && !url.username && !url.password && !url.port && /^\/sh\/lst\/(?:active|drafts|inactive|scheduled)\/?$/.test(url.pathname);
  } catch {
    return false;
  }
}
function libraryLinkIdentity(value) {
  const link = canonicalLibraryEbayURL(value);
  const url = new URL(link.url);
  return link.kind === "item" ? "item:" + url.pathname.split("/").at(-1) : "draft:" + (url.searchParams.get("draftId") ?? url.searchParams.get("draft_id"));
}

// src/core/listingCost.ts
var symbol = (currency) => !currency || /^USD$/i.test(currency) ? "$" : ` ${currency.toUpperCase()}`;
var money2 = (n) => n.toFixed(2);
function supplierCostLabel(source) {
  if (!source) return null;
  const costs2 = (source.variantCosts ?? []).filter((v) => Number.isFinite(v.cost) && v.cost > 0);
  if (costs2.length) {
    const currency2 = costs2[0].currency;
    const same = costs2.filter((v) => v.currency === currency2).map((v) => v.cost);
    const low2 = Math.min(...same);
    const high2 = Math.max(...same);
    return `${money2(low2)}${high2 - low2 >= 0.01 ? `\u2013${money2(high2)}` : ""}${symbol(currency2)}`;
  }
  const text3 = String(source.price ?? "").replace(/,(?=\d{3}(\D|$))/g, "").replace(/,/g, ".");
  const numbers = [...text3.matchAll(/\d+(?:\.\d+)?/g)].map((m) => Number(m[0])).filter((n) => n > 0 && n < 1e5);
  if (!numbers.length) return null;
  const currency = /€|EUR/i.test(text3) ? "EUR" : /£|GBP/i.test(text3) ? "GBP" : "USD";
  const low = Math.min(...numbers.slice(0, 2));
  const high = Math.max(...numbers.slice(0, 2));
  return `${money2(low)}${high - low >= 0.01 ? `\u2013${money2(high)}` : ""}${symbol(currency)}`;
}

// src/background/libraryLinks.ts
var SUPPLIER_MAP = "listingSuppliers:v1";
var normTitle = (t) => t.toLowerCase().replace(/\s+/g, " ").trim();
function cleanSupplierUrl(value) {
  if (typeof value !== "string") return null;
  try {
    const url = new URL(value);
    const id = url.pathname.match(/^\/item\/(\d{6,20})\.html$/)?.[1];
    if (url.protocol !== "https:" || !/(^|\.)aliexpress\.(com|us)$/.test(url.hostname) || !id)
      return null;
    return `https://${url.hostname}/item/${id}.html`;
  } catch {
    return null;
  }
}
async function listingLibraryLinks(values, hints = []) {
  if (!Array.isArray(values) || values.length > 200 || values.some((v) => typeof v !== "string"))
    throw Error("Liste d\u2019annonces eBay invalide.");
  const urls = [
    ...new Set(values.map((value) => canonicalLibraryEbayURL(value).url))
  ];
  const products = await executeLibrary({
    action: "list"
  });
  const hintFor = (url) => hints.find(
    (h) => typeof h?.url === "string" && (() => {
      try {
        return libraryLinkIdentity(h.url) === libraryLinkIdentity(url);
      } catch {
        return false;
      }
    })()
  );
  const store = globalThis.chrome?.storage?.local;
  const map2 = (store ? (await store.get(SUPPLIER_MAP))[SUPPLIER_MAP] : null) ?? {};
  let mapChanged = false;
  const result = [];
  for (const url of urls) {
    const identity2 = libraryLinkIdentity(url);
    const hint = hintFor(url);
    let matched = products.filter(
      (p) => p.ownListings.some((link) => libraryLinkIdentity(link.url) === identity2)
    );
    if (!matched.length && identity2.startsWith("item:") && hint?.title) {
      const title = normTitle(hint.title);
      let byTitle = products.filter(
        (p) => !p.archived && p.ownListings.some(
          (link) => link.kind === "draft" && normTitle(link.title) === title
        )
      );
      if (!byTitle.length)
        byTitle = products.filter(
          (p) => !p.archived && [p.name, p.ebayReference?.title ?? ""].some((x) => x && normTitle(x) === title)
        );
      if (byTitle.length === 1) {
        matched = byTitle;
        await executeLibrary({
          action: "link-ebay",
          productId: byTitle[0].id,
          role: "own",
          url,
          title: hint.title.slice(0, 200)
        }).catch(() => {
        });
      }
    }
    if (!matched.length && identity2.startsWith("item:") && typeof hint?.supplierId === "string" && /^\d{6,20}$/.test(hint.supplierId)) {
      const bySku = products.filter(
        (p) => !p.archived && p.suppliers.some((s) => s.source.id === hint.supplierId)
      );
      if (bySku.length === 1) {
        matched = bySku;
        await executeLibrary({
          action: "link-ebay",
          productId: bySku[0].id,
          role: "own",
          url,
          title: (hint.title || bySku[0].name).slice(0, 200)
        }).catch(() => {
        });
      }
    }
    const shown = cleanSupplierUrl(hint?.supplierUrl);
    if (shown && map2[identity2] !== shown) {
      map2[identity2] = shown;
      mapChanged = true;
    }
    result.push({
      url,
      supplierUrl: map2[identity2] ?? null,
      products: matched.map((p) => {
        const supplier = p.suppliers.find((s) => s.id === p.primarySupplierId);
        return {
          id: p.id,
          name: p.name,
          supplierUrl: supplier?.url ?? null,
          supplierName: supplier?.source.supplierNames.join(" \xB7 ") || "Fournisseur AliExpress",
          cost: supplierCostLabel(supplier?.source)
        };
      })
    });
  }
  if (mapChanged && store) await store.set({ [SUPPLIER_MAP]: map2 });
  return result;
}
async function orderSuppliers(items) {
  if (!Array.isArray(items) || items.length > 50) throw Error("Articles invalides.");
  const products = await executeLibrary({ action: "list" });
  const store = globalThis.chrome?.storage?.local;
  const map2 = (store ? (await store.get(SUPPLIER_MAP))[SUPPLIER_MAP] : null) ?? {};
  return items.map((raw) => {
    const item = raw ?? {};
    const itemId = typeof item.itemId === "string" && /^\d{9,15}$/.test(item.itemId) ? item.itemId : null;
    if (typeof item.supplierId === "string" && /^\d{6,20}$/.test(item.supplierId))
      return { itemId, url: `https://www.aliexpress.us/item/${item.supplierId}.html` };
    if (!itemId) return { itemId, url: null };
    const identity2 = `item:${itemId}`;
    const linked = products.filter(
      (p) => p.ownListings.some((link) => {
        try {
          return libraryLinkIdentity(link.url) === identity2;
        } catch {
          return false;
        }
      })
    );
    const supplier = linked.length === 1 ? linked[0].suppliers.find((s) => s.id === linked[0].primarySupplierId) : void 0;
    return { itemId, url: cleanSupplierUrl(supplier?.url) ?? map2[identity2] ?? null };
  });
}
async function pageLibraryProducts(pageUrl) {
  let identity2;
  try {
    identity2 = libraryLinkIdentity(canonicalLibraryEbayURL(pageUrl).url);
  } catch {
    return [];
  }
  const same = (url) => {
    try {
      return libraryLinkIdentity(url) === identity2;
    } catch {
      return false;
    }
  };
  const products = await executeLibrary({ action: "list" });
  const own = products.filter((p) => p.ownListings.some((l) => same(l.url)));
  const reference = products.filter(
    (p) => !own.includes(p) && p.ebayReference && same(p.ebayReference.url)
  );
  return [
    ...own.map((p) => ({ id: p.id, name: p.name, role: "own" })),
    ...reference.map((p) => ({ id: p.id, name: p.name, role: "reference" }))
  ].slice(0, 5);
}

// src/background/library.ts
var PREPARED_KEY = "libraryPrepared:v1";
var preparedWrite = Promise.resolve();
async function changePrepared(change) {
  const result = preparedWrite.catch(() => {
  }).then(async () => {
    const tokens = (await chrome.storage.session.get(PREPARED_KEY))[PREPARED_KEY] ?? {};
    const value = change(tokens);
    await chrome.storage.session.set({ [PREPARED_KEY]: tokens });
    return value;
  });
  preparedWrite = result;
  return result;
}
async function notifyLibraryChanged() {
  await chrome.storage.local.set({ libraryRevision: crypto.randomUUID() }).catch(() => {
  });
  try {
    const tabs = await chrome.tabs.query({
      url: "https://*.ebay.com/sh/lst/*"
    });
    await Promise.allSettled(
      tabs.filter(
        (tab) => tab.id !== void 0 && sellerHubListingsURL(tab.url ?? "")
      ).map(
        (tab) => chrome.tabs.sendMessage(tab.id, { type: "LIBRARY_LINKS_CHANGED" })
      )
    );
  } catch {
  }
}
async function libraryCommand(command) {
  const result = await executeLibrary(command);
  if (!["list", "get-product", "export"].includes(command.action))
    await notifyLibraryChanged();
  return result;
}
async function readLibraryReference(value) {
  const canonical = canonicalLibraryEbayURL(value);
  if (canonical.kind !== "item")
    throw Error("La fiche eBay de r\xE9f\xE9rence doit \xEAtre une annonce produit.");
  if (!(await getSettings()).enabled)
    throw Error("Active AurOEBay pour relire la r\xE9f\xE9rence eBay.");
  const tab = await chrome.tabs.create({ url: canonical.url, active: false });
  if (tab.id === void 0)
    throw Error("Impossible de lire la r\xE9f\xE9rence eBay en arri\xE8re-plan.");
  try {
    const until = Date.now() + 45e3;
    while (Date.now() < until) {
      if (!(await getSettings()).enabled)
        throw Error("Lecture interrompue : AurOEBay en pause.");
      const current2 = await chrome.tabs.get(tab.id);
      const pending2 = current2.pendingUrl ?? current2.url;
      if (current2.status !== "complete" && (!pending2 || pending2 === "about:blank")) {
        await new Promise((r) => setTimeout(r, 300));
        continue;
      }
      if (!pending2 || ebayItemId(pending2) !== ebayItemId(canonical.url))
        throw Error(
          "La r\xE9f\xE9rence eBay a chang\xE9 ou demande une connexion. Ouvre sa fiche puis r\xE9essaie."
        );
      if (current2.status === "complete") {
        try {
          let timer;
          const response = await Promise.race([
            chrome.tabs.sendMessage(tab.id, { type: "EBAY_SEED_READ" }),
            new Promise(
              (_, reject) => timer = setTimeout(
                () => reject(
                  Error("La lecture de la fiche eBay a d\xE9pass\xE9 le d\xE9lai.")
                ),
                15e3
              )
            )
          ]).finally(() => clearTimeout(timer));
          if (!response?.ok)
            throw Error(response?.error ?? "Fiche eBay non reconnue.");
          const seed = response.data;
          const after = await chrome.tabs.get(tab.id);
          if (!validEbaySeed(seed) || seed.itemId !== ebayItemId(canonical.url) || ebayItemId(after.url ?? "") !== seed.itemId || !(await getSettings()).enabled)
            throw Error(
              "La r\xE9f\xE9rence eBay ne correspond plus \xE0 la fiche demand\xE9e."
            );
          return seed;
        } catch (e) {
          if (!/receiving end|connection|not exist/i.test(String(e))) throw e;
        }
      }
      await new Promise((r) => setTimeout(r, 300));
    }
    throw Error(
      "R\xE9f\xE9rence eBay inaccessible en arri\xE8re-plan. Ouvre la fiche puis r\xE9essaie."
    );
  } finally {
    await chrome.tabs.remove(tab.id).catch(() => {
    });
  }
}
async function prepareLibraryDraft(productId2, supplierId) {
  const product2 = await executeLibrary({
    action: "get-product",
    productId: productId2
  });
  const supplier = product2.suppliers.find((s) => s.id === supplierId);
  if (product2.archived || !supplier || !product2.ebayReference)
    throw Error(
      "Choisis un fournisseur et relie une annonce eBay de r\xE9f\xE9rence \xE0 ce produit actif."
    );
  const settings = await getSettings();
  if (!settings.enabled || !settings.captureEnabled)
    throw Error("Active AurOEBay et la capture AliExpress.");
  const candidateRule = product2.pricing ?? (await chrome.storage.local.get("variantPricing")).variantPricing;
  if (!candidateRule)
    throw Error(
      "Enregistre ta r\xE8gle de prix dans les r\xE9glages du produit ou dans Prix des variantes avant de pr\xE9parer le brouillon."
    );
  const rule = validateLibraryPricing(candidateRule);
  const reads = await Promise.allSettled([
    readSupplierLink(supplier.url, true, true),
    readLibraryReference(product2.ebayReference.url)
  ]);
  for (const read2 of reads) if (read2.status === "rejected") throw read2.reason;
  const source = reads[0].value;
  const seed = reads[1].value;
  if (source.id !== supplier.id)
    throw Error(
      "AliExpress a redirig\xE9 vers un autre produit. V\xE9rifie le lien du fournisseur avant de continuer."
    );
  const plan = supplierImportPlan(source, rule, { keepOutOfStock: true });
  const gallery = (source.images ?? []).filter((i) => i.role === "gallery");
  if (!gallery.length)
    throw Error(
      "Aucune photo de galerie AliExpress lisible pour ce brouillon."
    );
  const saved = await libraryCommand({
    action: "save-source",
    productId: productId2,
    source,
    ebaySeed: seed,
    expectedRevision: product2.revision
  });
  const storedSource = saved.suppliers.find((s) => s.id === source.id);
  const token = crypto.randomUUID();
  const prepared = {
    token,
    productId: productId2,
    supplierId: source.id,
    revision: saved.revision,
    capturedAt: storedSource.source.capturedAt,
    rule: plan.rule,
    createdAt: Date.now()
  };
  await changePrepared((tokens) => {
    const recent = Object.values(tokens).filter((p) => Date.now() - p.createdAt < 10 * 6e4).slice(-9);
    for (const key4 of Object.keys(tokens)) delete tokens[key4];
    for (const p of [...recent, prepared]) tokens[p.token] = p;
  });
  return {
    token,
    productId: productId2,
    supplierId: source.id,
    title: seed.title,
    category: seed.category,
    sourceUrl: storedSource.url,
    descriptionImageCount: source.descriptionImageCount ?? 0,
    galleryCount: Math.min(12, gallery.length),
    rule: plan.rule,
    rows: plan.rows,
    omitted: plan.omitted
  };
}
var creating = false;
async function createLibraryDraft(token, reviewed) {
  if (reviewed !== true)
    throw Error("V\xE9rifie la proposition avant de cr\xE9er le brouillon.");
  if (creating)
    throw Error("Un brouillon de la biblioth\xE8que est d\xE9j\xE0 en pr\xE9paration.");
  creating = true;
  try {
    const values = (await chrome.storage.session.get(PREPARED_KEY))[PREPARED_KEY];
    const prepared = values?.[token];
    if (!prepared || Date.now() - prepared.createdAt > 10 * 6e4)
      throw Error(
        "Cet aper\xE7u a expir\xE9. Relis les sources pour pr\xE9parer un nouvel aper\xE7u."
      );
    const product2 = await executeLibrary({
      action: "get-product",
      productId: prepared.productId
    });
    const supplier = product2.suppliers.find(
      (s) => s.id === prepared.supplierId
    );
    const seed = product2.ebayReference?.seed;
    const currentRule = product2.pricing ?? (await chrome.storage.local.get("variantPricing")).variantPricing;
    if (product2.archived || product2.revision !== prepared.revision || !supplier || supplier.source.capturedAt !== prepared.capturedAt || !seed || !validEbaySeed(seed) || currentRule?.coefficient !== prepared.rule.coefficient || currentRule?.fixed !== prepared.rule.fixed || currentRule?.rounding !== prepared.rule.rounding)
      throw Error(
        "Le produit ou sa r\xE8gle de prix a chang\xE9. Pr\xE9pare un nouvel aper\xE7u."
      );
    const latest = await executeLibrary({
      action: "get-product",
      productId: product2.id
    });
    if (latest.revision !== prepared.revision)
      throw Error(
        "Le produit a chang\xE9 pendant la validation. Pr\xE9pare un nouvel aper\xE7u."
      );
    await changePrepared((tokens) => {
      if (!tokens[token]) throw Error("Aper\xE7u d\xE9j\xE0 utilis\xE9.");
      delete tokens[token];
    });
    const job = await startNativeImport(
      {
        sourceUrl: supplier.source.url,
        title: seed.title,
        images: (supplier.source.images ?? []).filter((i) => i.role === "gallery").slice(0, 12).map((i) => i.url),
        removeMentions: false,
        fullDescription: true,
        ebaySeedId: seed.itemId
      },
      {
        source: supplier.source,
        seed,
        rule: prepared.rule,
        libraryProductId: product2.id
      }
    );
    return { jobId: job.id, tabId: job.tabId, productId: product2.id };
  } finally {
    creating = false;
  }
}
async function saveNativeLibrary(job) {
  try {
    let productId2 = job.libraryProductId;
    if (!productId2) {
      const remembered2 = (await chrome.storage.session.get("nativeLibrary:" + job.id))["nativeLibrary:" + job.id];
      productId2 = remembered2;
    }
    if (!productId2) {
      const { sources = [] } = await chrome.storage.session.get("sources");
      const source = sources.find(
        (p) => p.id === job.product.supplierProductId
      );
      if (!source) return;
      const product2 = await executeLibrary({
        action: "save-source",
        source,
        ...job.ebaySeed ? { ebaySeed: job.ebaySeed } : {}
      });
      productId2 = product2.id;
      await chrome.storage.session.set({
        ["nativeLibrary:" + job.id]: productId2
      });
    }
    if (job.identity && (job.stage === "ready" || job.stage === "error" && job.apiDraftId))
      await executeLibrary({
        action: "link-ebay",
        productId: productId2,
        role: "own",
        url: job.identity,
        title: job.title
      });
    await notifyLibraryChanged();
  } catch (e) {
    console.warn(
      "AurOEBay : sauvegarde biblioth\xE8que indisponible.",
      e instanceof Error ? e.message : "Stockage indisponible"
    );
  }
}

// src/seller/queue.ts
var RequestQueue = class {
  constructor(limit = 2, spacing = 700) {
    this.limit = limit;
    this.spacing = spacing;
  }
  active = 0;
  waiting = [];
  async run(task) {
    if (this.active >= this.limit)
      await new Promise((r) => this.waiting.push(r));
    else this.active++;
    try {
      return await task();
    } finally {
      await delay(this.spacing);
      const next = this.waiting.shift();
      if (next) next();
      else this.active--;
    }
  }
};

// src/seller/service.ts
var queue4 = new RequestQueue(2);
var pending = /* @__PURE__ */ new Map();
async function resolveSeller(username, ttl, storePath, read2, force = false) {
  if (username !== null && !/^[A-Za-z0-9_.-]{1,80}$/.test(username))
    throw Error("Nom de vendeur eBay invalide.");
  if (storePath !== null && !/^\/str\/[a-zA-Z0-9_.-]+$/.test(storePath))
    throw Error("Adresse de boutique eBay invalide.");
  if (!username && !storePath) throw Error("Vendeur eBay introuvable sur la page.");
  const identity2 = `${storePath ?? "profile"}|${username?.toLowerCase() ?? ""}`;
  if (!force) {
    const cached = await getSellerCache(identity2, ttl);
    if (cached) return cached;
  }
  if (pending.has(identity2)) return pending.get(identity2);
  const task = queue4.run(async () => {
    const s = await getSettings();
    if (!s.enabled || !s.sellerEnabled)
      throw Error("Seller detector disabled");
    const info = await read2();
    if (!(await getSettings()).enabled) throw Error("AurOEBay is paused.");
    await putSellerCache(info, identity2);
    return info;
  }).finally(() => pending.delete(identity2));
  pending.set(identity2, task);
  return task;
}
async function cachedSeller(username, ttl) {
  if (typeof username !== "string" || !/^[A-Za-z0-9_.-]{1,80}$/.test(username)) return null;
  return getSellerCache(`profile|${username.toLowerCase()}`, ttl);
}

// src/background/ebayCopy.ts
async function fetchListingDescription(itemId) {
  if (!/^\d{9,15}$/.test(itemId)) throw Error("Annonce eBay invalide.");
  const response = await fetch(`https://itm.ebaydesc.com/itmdesc/${itemId}`, {
    credentials: "omit",
    referrerPolicy: "no-referrer",
    redirect: "error",
    signal: AbortSignal.timeout(15e3)
  });
  if (!response.ok)
    throw Error(`Description eBay inaccessible (HTTP ${response.status}).`);
  const text3 = await response.text();
  if (text3.length > 3e6) throw Error("Description eBay trop volumineuse.");
  return text3;
}
async function createFromEbayCopy(tabId) {
  const started = Date.now();
  const tab = await chrome.tabs.get(tabId);
  const itemId = ebayItemId(tab.url ?? "");
  if (!itemId) throw Error("Ouvre l\u2019annonce eBay \xE0 copier.");
  const description = await fetchListingDescription(itemId);
  const reply = await chrome.tabs.sendMessage(
    tabId,
    { type: "EBAY_COPY_READ", description },
    { frameId: 0 }
  );
  if (!reply?.ok)
    throw Error(reply?.error ?? "Lecture de l\u2019annonce eBay impossible.");
  const copy = reply.data;
  if (copy.seed.itemId !== itemId || !validEbaySeed(copy.seed))
    throw Error("Annonce eBay chang\xE9e pendant la lecture. R\xE9essaie.");
  const seed = { ...copy.seed, tabId };
  apiTrace("copie", "ebay:ok", {
    ms: Date.now() - started,
    rows: copy.plan.rows.length,
    photos: copy.gallery.length,
    outOfStock: copy.outOfStock
  });
  const choice = {
    sourceUrl: copy.source.url,
    title: seed.title,
    images: copy.gallery,
    removeMentions: false,
    fullDescription: true,
    ebaySeedId: seed.itemId
  };
  const job = await startNativeImport(choice, {
    source: copy.source,
    seed,
    rule: copy.plan.rule,
    plan: copy.plan,
    keepDescription: true
  });
  return {
    jobId: job.id,
    tabId: job.tabId,
    rows: copy.plan.rows.map((r) => ({ values: r.values, price: r.price, quantity: r.quantity })),
    omitted: copy.outOfStock,
    photos: copy.gallery.length
  };
}

// src/background/targetPricing.ts
var ROUNDINGS = ["none", "49", "99", "49-or-99"];
var read = async () => (await chrome.storage.local.get("variantPricing")).variantPricing ?? null;
async function setPriceTarget(target, rounding) {
  const current2 = await read();
  const round3 = ROUNDINGS.includes(rounding) ? rounding : current2?.rounding ?? "49-or-99";
  if (target === null) {
    if (!current2) return null;
    const { target: _, ...rule2 } = current2;
    await chrome.storage.local.set({ variantPricing: { ...rule2, rounding: round3 } });
    return { ...rule2, rounding: round3 };
  }
  const n = Number(target);
  const rule = targetRule(n, await profitModel(), round3);
  if (!rule || typeof target !== "number") throw Error("B\xE9n\xE9fice voulu invalide (de 0 \xE0 1000 \u20AC).");
  await chrome.storage.local.set({ variantPricing: rule });
  return rule;
}
async function refreshPriceTarget() {
  const current2 = await read();
  if (typeof current2?.target !== "number") return;
  const rule = targetRule(current2.target, await profitModel(), current2.rounding);
  if (rule && (rule.coefficient !== current2.coefficient || rule.fixed !== current2.fixed))
    await chrome.storage.local.set({ variantPricing: rule });
}

// src/background/ebayTrackingSync.ts
var STATE = "ebayTrackingSync:v1";
async function trackingsInPage(orderIds) {
  const out = [];
  const queue5 = [...orderIds];
  await Promise.all(
    Array.from({ length: 3 }, async () => {
      while (queue5.length) {
        const id = queue5.shift();
        try {
          const html = await fetch(`/mesh/ord/details?mode=SH&orderid=${encodeURIComponent(id)}`, { credentials: "same-origin" }).then((r) => r.text());
          const doc = new DOMParser().parseFromString(html, "text/html");
          const own = (e) => (e.textContent ?? "").replace(/\s+/g, " ").trim();
          const numbers = new Set(
            [...doc.querySelectorAll(".tracking-info .value .fake-link:not(.edit-link), .tracking-info .value a, .tracking-number")].map(own).filter((t) => /^[A-Z0-9-]{8,40}$/i.test(t) && /\d/.test(t))
          );
          let trackedItems = 0;
          for (const card of doc.querySelectorAll(".lineItemCardInfo__content")) {
            const found = own(card.parentElement ?? card).match(/Tracking\s*:?\s*([A-Z0-9]{8,40})/i)?.[1]?.replace(/(Edit|Quantity|Tracking|Carrier|Shipped).*$/i, "");
            if (found && /\d/.test(found)) {
              numbers.add(found);
              trackedItems++;
            }
          }
          out.push({ orderId: id, trackings: [...numbers], trackedItems });
        } catch {
        }
      }
    })
  );
  return out;
}
var pendingOnEbay = (sales) => sales.filter((s) => trackingsToSend(s).length).map((s) => s.orderId);
var running4 = null;
function syncEbayTrackings(force = false) {
  running4 ??= (async () => {
    const last = (await chrome.storage.session.get(STATE))[STATE] ?? 0;
    const ids = pendingOnEbay(await listSales()).slice(0, 40);
    if (!ids.length || !force && Date.now() - last < 20 * 6e4) return { checked: 0, updated: 0 };
    await chrome.storage.session.set({ [STATE]: Date.now() });
    const { tabId, owned } = await ebayTab();
    try {
      const [r] = await withTimeout(chrome.scripting.executeScript({ target: { tabId }, func: trackingsInPage, args: [ids] }), 12e4);
      const rows = r?.result ?? [];
      return { checked: ids.length, updated: await noteEbayTrackings(rows.filter((x) => x.trackings.length)) };
    } finally {
      if (owned) await chrome.tabs.remove(tabId).catch(() => {
      });
    }
  })().finally(() => running4 = null);
  return running4;
}

// src/background/aliTrackings.ts
var ORDERS_PAGE = "https://www.aliexpress.com/p/order/index.html";
var MAX_AGE_DAYS = 90;
var STATE2 = "aliTrackingRun:v1";
function ordersWithoutTracking(sales, now = Date.now()) {
  const ids = /* @__PURE__ */ new Set();
  for (const s of sales) {
    if (s.status === "cancelled") continue;
    for (const p of purchases(s)) {
      const since = p.linkedAt || s.soldAt || 0;
      if (!p.tracking && /^\d{8,25}$/.test(p.orderId) && now - since < MAX_AGE_DAYS * 864e5) ids.add(p.orderId);
    }
  }
  return [...ids];
}
function ordersToSend(sales) {
  return sales.filter((s) => trackingsToSend(s).length).map((s) => s.orderId);
}
var wait5 = (ms) => new Promise((r) => setTimeout(r, ms));
var running5 = null;
function refreshAliTrackings() {
  running5 ??= run3().finally(() => running5 = null);
  return running5;
}
async function report2(run6) {
  await chrome.storage.session.set({ [STATE2]: run6 }).catch(() => {
  });
  return run6;
}
async function run3() {
  const sales = await listSales();
  const ids = ordersWithoutTracking(sales);
  const result = { state: "running", at: Date.now(), checked: 0, total: ids.length, found: 0, toSend: [] };
  if (!ids.length) {
    await syncEbayTrackings(true).catch(() => {
    });
    return report2({ ...result, state: "done", toSend: ordersToSend(await listSales()) });
  }
  await report2(result);
  let tabId;
  try {
    const tab = await chrome.tabs.create({ url: ORDERS_PAGE, active: false });
    tabId = tab.id;
    if (tabId === void 0) throw Error("Impossible d\u2019ouvrir AliExpress.");
    let ready2 = false;
    for (let i = 0; i < 40 && !ready2; i++) {
      await wait5(750);
      const current2 = await chrome.tabs.get(tabId).catch(() => void 0);
      if (!current2) throw Error("L\u2019onglet AliExpress a \xE9t\xE9 ferm\xE9.");
      const host = current2.url ? new URL(current2.url).hostname : "";
      if (/(^|\.)login\.|passport|signin/i.test(current2.url ?? ""))
        throw Error("Connecte-toi \xE0 AliExpress dans Chrome, puis r\xE9essaie.");
      if (current2.status !== "complete" || !/(^|\.)aliexpress\.(com|us)$/.test(host)) continue;
      const [probe] = await chrome.scripting.executeScript({
        target: { tabId },
        world: "MAIN",
        func: () => !!window.lib?.mtop?.request
      }).catch(() => [void 0]);
      ready2 = probe?.result === true;
    }
    if (!ready2) throw Error("La page des commandes AliExpress ne r\xE9pond pas. Ouvre-la une fois (connect\xE9), puis r\xE9essaie.");
    for (let i = 0; i < ids.length; i += 20) {
      const part = ids.slice(i, i + 20);
      const [r] = await withTimeout(
        chrome.scripting.executeScript({
          target: { tabId },
          world: "MAIN",
          func: aliOrderInfoInPage,
          args: [part, false]
        }),
        12e4
      );
      const rows = (r?.result ?? []).filter(
        (x) => x && part.includes(x.orderId)
      );
      const withNumber = rows.filter((x) => x.tracking);
      if (withNumber.length)
        await syncAliOrders(withNumber.map((x) => ({ orderId: x.orderId, tracking: x.tracking, carrier: x.carrier })));
      result.checked += part.length;
      result.found += withNumber.length;
      await report2({ ...result });
    }
    await syncEbayTrackings(true).catch(() => {
    });
    return report2({ ...result, state: "done", at: Date.now(), toSend: ordersToSend(await listSales()) });
  } catch (e) {
    return report2({ ...result, state: "error", error: e instanceof Error ? e.message : String(e) });
  } finally {
    if (tabId !== void 0) await chrome.tabs.remove(tabId).catch(() => {
    });
  }
}

// src/core/disputes.ts
var DISPUTES_KEY = "disputes:v1";
var ORDER_ID2 = /\b\d{2}-\d{5}-\d{5}\b/;
var deliveredMissing = (d) => d.source === "aliexpress" && d.open && /delivered but not received/i.test(d.reason ?? "");
var RETURN_AUTO = /buyer started a return|approved automatically/i;
var returnToHold = (d) => d.source === "ebay" && d.kind === "return" && d.open && !d.held && !d.photos && RETURN_AUTO.test(`${d.status} ${d.detail ?? ""}`);
function ebayModules(html) {
  const out = {};
  let i = -1;
  while ((i = html.indexOf('"modules":', i + 1)) >= 0) {
    const start = html.indexOf("{", i);
    if (start < 0) break;
    const end = jsonEnd(html, start);
    if (end < 0) continue;
    try {
      Object.assign(out, JSON.parse(html.slice(start, end)));
    } catch {
    }
  }
  return out;
}
function jsonEnd(text3, start) {
  let depth = 0;
  let inString = false;
  let escaped = false;
  for (let k = start; k < text3.length && k - start < 2e6; k++) {
    const c = text3[k];
    if (inString) {
      if (escaped) escaped = false;
      else if (c === "\\") escaped = true;
      else if (c === '"') inString = false;
      continue;
    }
    if (c === '"') inString = true;
    else if (c === "{") depth++;
    else if (c === "}" && --depth === 0) return k + 1;
  }
  return -1;
}
var spans = (o) => {
  const t = o;
  return Array.isArray(t?.textSpans) ? t.textSpans.map((s) => typeof s?.text === "string" ? s.text : "").join("").trim() : null;
};
function moduleTexts(o, out = []) {
  if (Array.isArray(o)) for (const x of o) moduleTexts(x, out);
  else if (o && typeof o === "object") {
    const own = spans(o);
    if (own !== null) {
      if (own) out.push(own);
    } else for (const [k, v] of Object.entries(o)) if (k !== "accessibilityText" && k !== "trackingList") moduleTexts(v, out);
  }
  return out;
}
function labelValues(mods) {
  const map2 = /* @__PURE__ */ new Map();
  const walk = (o) => {
    if (Array.isArray(o)) o.forEach(walk);
    else if (o && typeof o === "object") {
      const d = o;
      const label = Array.isArray(d.labels) ? d.labels.map((l) => spans(l) ?? "").join(" ").trim() : spans(d.label);
      const values = Array.isArray(d.values) ? d.values.map((v) => moduleTexts(v).join(" ").trim()) : d.value !== void 0 ? [moduleTexts(d.value).join(" ").trim()] : null;
      if (label && values?.length && !map2.has(label)) map2.set(label, values.filter(Boolean));
      for (const [k, v] of Object.entries(o)) if (k !== "labels" && k !== "values" && k !== "accessibilityText") walk(v);
    }
  };
  walk(mods);
  return map2;
}
var first = (map2, ...labels) => {
  for (const l of labels) {
    const v = map2.get(l)?.[0];
    if (v) return v;
  }
  return void 0;
};
function parseAmount(text3) {
  if (!text3) return null;
  const t = text3.replace(/(\d),(?=\d{3}\b)/g, "$1");
  const symbol2 = { $: "USD", "\u20AC": "EUR", "\xA3": "GBP" };
  let currency;
  let value;
  const code = t.match(/\b([A-Z]{3})\s*\$?\s*(\d+(?:\.\d+)?)/);
  const before = t.match(/([$€£])\s*(\d+(?:\.\d+)?)/);
  const after = t.match(/(\d+(?:\.\d+)?)\s*([$€£])/);
  if (code && (!before || code.index <= before.index)) [currency, value] = [code[1], code[2]];
  else if (before) [currency, value] = [symbol2[before[1]], before[2]];
  else if (after) [currency, value] = [symbol2[after[2]], after[1]];
  const amount2 = Number(value);
  return currency && /^[A-Z]{3}$/.test(currency) && Number.isFinite(amount2) ? { amount: Math.round(amount2 * 100) / 100, currency } : null;
}
function ebayHistory(mods) {
  const out = [];
  const walk = (o) => {
    if (Array.isArray(o)) o.forEach(walk);
    else if (o && typeof o === "object") {
      const a = o;
      if (a.date && a.historyDetail) {
        const date = spans(a.date);
        const text3 = spans(a.historyDetail.title) ?? moduleTexts(a.historyDetail)[0];
        if (date && text3) out.push({ date, text: text3 });
        return;
      }
      for (const v of Object.values(o)) walk(v);
    }
  };
  walk(mods.HISTORY ?? null);
  const hm = mods.HistoryModule;
  for (const section of hm?.sections ?? [])
    for (const d of section.dataItems ?? []) {
      const date = (d.labels ?? []).map((l) => spans(l) ?? "").join(" ").trim();
      const text3 = spans(d.values?.[0]) ?? "";
      if (date && text3) out.push({ date, text: text3 });
    }
  return out.filter((e) => !/^["“]/.test(e.text)).map((e) => ({ date: e.date.slice(0, 30), text: e.text.slice(0, 120) })).slice(0, 20);
}
var CLOSED = /\b(closed|resolved|outcome|you refunded|refund (?:was )?(?:sent|issued)|refunded the buyer|request is closed|return (?:is )?complete)\b/i;
function parseEbayDispute(html, url, now = Date.now()) {
  const u = new URL(url, "https://www.ebay.com");
  const returnId = u.searchParams.get("returnId");
  const requestId = u.pathname.match(/\/ItemNotReceived\/(\d{6,20})/)?.[1];
  const id = returnId && /^\d{6,20}$/.test(returnId) ? returnId : requestId;
  if (!id) return null;
  const mods = ebayModules(html);
  if (!Object.keys(mods).length) return null;
  const pairs2 = labelValues(mods);
  const all3 = moduleTexts(mods);
  const kind = returnId ? "return" : pairs2.has("Case ID") || /case details/i.test(moduleTexts(mods.BreadcrumbModule).join(" ")) ? "case" : "inr";
  const orderId = (first(pairs2, "Order", "Order number") ?? all3.find((t) => ORDER_ID2.test(t)))?.match(ORDER_ID2)?.[0] ?? null;
  const head = moduleTexts(mods.CONTENT ?? mods.TitleModule ?? null);
  const statusModule = moduleTexts(mods.StatusMessageModule ?? null).join(" ");
  const progress2 = mods.PROGRESS?.wizardStepper?.steps ?? [];
  const lastStepDone = progress2.length > 0 && progress2[progress2.length - 1]?.stepStatus === "COMPLETED";
  const status = head[0] || statusModule || "";
  const summary = moduleTexts(mods.SummaryModule ?? mods.RefundReimbursementSummaryModule ?? null);
  const after = (label) => summary.includes(label) ? summary[summary.indexOf(label) + 1] : void 0;
  const outcome = after("Outcome");
  const refundedText = after("Total refund");
  const image = html.match(/"itemImage":\{[^{}]*?"URL":"(https:[^"]*ebayimg[^"]*)"/)?.[1] ?? html.match(/"URL":"(https:[^"]*ebayimg[^"]*)"/)?.[1];
  const itemId = html.match(/"itemId":"?(\d{9,15})/)?.[1];
  return {
    ...image ? { image } : {},
    ...itemId ? { itemId } : {},
    key: `ebay:${id}`,
    source: "ebay",
    kind,
    id,
    url: kind === "return" ? `https://www.ebay.com/rtn/Return/ReturnsDetail?returnId=${id}` : `https://www.ebay.com/ItemNotReceived/${id}`,
    orderId,
    open: !(lastStepDone || CLOSED.test(statusModule) || CLOSED.test(status) || !!outcome),
    status: status.slice(0, 160),
    ...head[1] ? { detail: head[1].slice(0, 300) } : {},
    reason: (first(pairs2, "Return Reason", "Case reason", "Reason") ?? (kind === "return" ? void 0 : "Item not received"))?.slice(0, 120),
    amount: parseAmount(first(pairs2, "Request amount", "Case amount")),
    ...summary.includes("Total refund") ? { refunded: parseAmount(refundedText) } : {},
    ...outcome ? { outcome: outcome.slice(0, 200) } : {},
    history: ebayHistory(mods),
    updatedAt: now
  };
}
var ebayDisputeBuyer = (html) => first(labelValues(ebayModules(html)), "Buyer") ?? null;
function applyConversation(d, talk, now = Date.now()) {
  return { ...d, photos: talk.photos, ...talk.hold || talk.photos ? { held: d.held ?? now } : {} };
}
function ebayDisputeLinks(html) {
  const out = /* @__PURE__ */ new Map();
  const rows = html.split(/<tr\b/i).slice(1);
  const scan = (chunk, row) => {
    const text3 = row ? chunk.replace(/<[^>]+>/g, " ").replace(/&amp;/g, "&").replace(/&#39;|&rsquo;/g, "\u2019").replace(/\s+/g, " ") : "";
    const deadline = text3.match(/Respond by:?\s*([A-Z][a-z]{2} \d{1,2}(?:, \d{4})?)/)?.[1];
    const status = (text3.match(/(Closed on [A-Z][a-z]{2} \d{1,2}, \d{4})/)?.[1] ?? "").trim();
    for (const m of chunk.matchAll(/(?:https?:)?(?:\\?\/\\?\/www\.ebay\.com)?\\?\/(rtn\\?\/Return\\?\/ReturnsDetail\?returnId=(\d{6,20})|ItemNotReceived\\?\/(\d{6,20}))/g)) {
      const url = m[2] ? `https://www.ebay.com/rtn/Return/ReturnsDetail?returnId=${m[2]}` : `https://www.ebay.com/ItemNotReceived/${m[3]}`;
      const known = out.get(url);
      if (!known || !known.deadline && deadline) out.set(url, { url, status: status || known?.status || "", ...deadline ? { deadline } : {} });
    }
  };
  for (const r of rows) scan(r.split(/<\/tr>/i)[0], true);
  scan(html, false);
  return [...out.values()].slice(0, 40);
}
var aliMoney = (m) => m && Number.isFinite(m.cent) && /^[A-Z]{3}$/.test(m.currency ?? "") ? { amount: Math.round(m.cent) / 100, currency: m.currency } : null;
function aliStatus(r) {
  if (r.step) return r.step;
  if (r.refundStatus === "FINISHED") return "Refunded";
  return Number(r.reverseStatus) === 4 ? "Closed" : "In progress";
}
function aliDispute(r, orderId, now = Date.now()) {
  if (!/^\d{6,30}$/.test(r.reverseOrderLineId ?? "") || !/^\d{6,30}$/.test(r.tradeOrderId ?? "")) return null;
  const finished = r.refundStatus === "FINISHED" || Number(r.reverseStatus) === 4;
  const until = r.responseUntil && r.responseUntil > now ? new Date(r.responseUntil).toLocaleString("fr-FR", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" }) : null;
  const refunded = aliMoney(r.solution) ?? aliMoney(r.refund);
  return {
    key: `aliexpress:${r.reverseOrderLineId}`,
    source: "aliexpress",
    kind: r.reverseType === "RETURN" ? "return" : "refund",
    id: r.reverseOrderLineId,
    url: `https://www.aliexpress.us/p/reverse-pages/detail.html?tradeOrderLineId=${encodeURIComponent(r.tradeOrderLineId)}&reverseOrderLineId=${encodeURIComponent(r.reverseOrderLineId)}`,
    orderId,
    aliOrderId: r.tradeOrderId,
    open: !finished,
    status: aliStatus(r).slice(0, 160),
    ...r.reminder ? { detail: r.reminder.slice(0, 300) } : {},
    ...r.reason ? { reason: r.reason.slice(0, 120) } : {},
    amount: aliMoney(r.solution),
    ...refunded && finished ? { refunded } : {},
    ...!finished && (until || r.timeoutText) ? { deadline: (until ?? r.timeoutText).slice(0, 40) } : {},
    // Only the « Provide additional information(s) » button says it: AliExpress keeps
    // « wait_response_in_arbitration » once the proof is sent (seen live 11/2026).
    awaitingProof: !finished && r.uploadAsked === true,
    awaitingReturn: !finished && /RETURN_ITEM/i.test(r.responseType ?? ""),
    ...r.createdAt ? { openedAt: r.createdAt.slice(0, 20) } : {},
    updatedAt: now
  };
}
function disputeAdvice(list2, hasAliOrder) {
  const ebay = list2.filter((d) => d.source === "ebay");
  const ali = list2.filter((d) => d.source === "aliexpress");
  const ebayOpen = ebay.filter((d) => d.open);
  const aliOpen = ali.filter((d) => d.open);
  if (!ebay.length && !ali.length) return null;
  if (!ali.length && ebay.some(returnToHold))
    return { level: "urgent", text: "eBay a accept\xE9 ce retour tout seul : dis tout de suite au client de ne rien renvoyer, et demande-lui ses photos." };
  const proof = aliOpen.find((d) => d.awaitingProof);
  if (proof)
    return {
      level: "urgent",
      text: `AliExpress attend ta r\xE9ponse${proof.deadline ? ` avant le ${proof.deadline}` : ""} : ajoute une preuve et un message, sinon le litige peut se fermer sans remboursement.`
    };
  const photos = ebayOpen.find((d) => d.photos);
  const due = ebayOpen.find((d) => d.deadline);
  if (due) return { level: "urgent", text: `R\xE9ponds sur eBay avant le ${due.deadline} : \xAB ${due.status} \xBB.` };
  if (ebayOpen.some((d) => d.kind === "case"))
    return { level: "urgent", text: "eBay examine un litige (case) : envoie tes preuves (suivi, photos) depuis la page eBay." };
  if (photos && hasAliOrder && !ali.length)
    return { level: "todo", text: `Le client a envoy\xE9 ${photos.photos} photo(s) : ouvre le litige AliExpress avec elles pour obtenir un remboursement ou une \xE9tiquette de retour.` };
  if (ebayOpen.length && hasAliOrder && !ali.length)
    return {
      level: "todo",
      text: ebayOpen.some((d) => d.held) ? "D\xE8s que le client a envoy\xE9 ses photos, ouvre le litige AliExpress avec elles pour obtenir un remboursement ou une \xE9tiquette de retour." : ebayOpen[0].kind === "inr" ? "Le client dit ne pas avoir re\xE7u le colis : v\xE9rifie le suivi, et ouvre un litige \xAB colis non re\xE7u \xBB sur la commande AliExpress si besoin." : "Le client a un souci avec l\u2019article : ouvre un litige sur la commande AliExpress pour te faire rembourser par le fournisseur."
    };
  const missing = ali.find(deliveredMissing);
  if (missing)
    return {
      level: "info",
      text: `Litige \xAB livr\xE9 mais pas re\xE7u \xBB en cours${missing.deadline ? `, r\xE9ponse du vendeur attendue avant le ${missing.deadline}` : ""}. Si le client retrouve le colis, annule le litige. Si le vendeur envoie une preuve, transmets-la au client. Si rien ne se d\xE9bloque, envisage de le rembourser.`
    };
  const back = aliOpen.find((d) => d.awaitingReturn);
  if (back)
    return {
      level: "todo",
      text: `AliExpress attend le retour de l\u2019article${back.deadline ? ` avant le ${back.deadline}` : ""} : regarde sur la page AliExpress comment le renvoyer (adresse ou \xE9tiquette) et transmets-le au client.`
    };
  if (ebayOpen.length && aliOpen.length) return { level: "info", text: "Litiges en cours des deux c\xF4t\xE9s : suis-les jusqu\u2019au remboursement." };
  if (ebayOpen.length) return { level: "todo", text: `Litige eBay en cours : \xAB ${ebayOpen[0].status} \xBB.` };
  if (aliOpen.length) return { level: "info", text: "Litige eBay termin\xE9 : attends la d\xE9cision AliExpress pour r\xE9cup\xE9rer ton co\xFBt." };
  if (ebay.some((d) => d.refunded) && hasAliOrder && !ali.length)
    return { level: "todo", text: "Le client a \xE9t\xE9 rembours\xE9 sur eBay : demande aussi un remboursement au fournisseur AliExpress si l\u2019article posait probl\xE8me." };
  return { level: "done", text: "Litige termin\xE9 des deux c\xF4t\xE9s." };
}
function saleOfAliOrder(sales) {
  const map2 = /* @__PURE__ */ new Map();
  for (const s of sales) for (const p of [s.supplier, ...s.extraSuppliers ?? []]) if (p?.orderId) map2.set(p.orderId, s.orderId);
  return map2;
}
function closeUnlisted(items, listed, now = Date.now()) {
  if (!listed || !listed.size) return items;
  const out = {};
  for (const [k, d] of Object.entries(items))
    out[k] = d.source === "aliexpress" && d.open && !listed.has(d.id) ? { ...d, open: false, status: "Termin\xE9 (remplac\xE9 chez AliExpress)", awaitingProof: false, awaitingReturn: false, deadline: void 0, updatedAt: now } : d;
  return out;
}
function mergeDisputes(previous, fresh, now = Date.now()) {
  const out = {};
  for (const [k, d] of Object.entries(previous)) if (d.open || now - d.updatedAt < 180 * 864e5) out[k] = d;
  for (const d of fresh) out[d.key] = { ...out[d.key], ...d };
  return out;
}

// src/background/disputes.ts
var STATE3 = "disputeSync:v1";
async function disputeStore() {
  const saved = (await chrome.storage.local.get(DISPUTES_KEY))[DISPUTES_KEY];
  return saved && typeof saved === "object" && saved.items ? saved : { items: {}, at: 0 };
}
async function ebayDisputePagesInPage(lists, skip, max, known = []) {
  const get = async (url) => {
    const r = await fetch(url, { credentials: "same-origin", signal: AbortSignal.timeout(3e4) });
    if (/signin|\/login/i.test(r.url)) throw Error("signin");
    return r.text();
  };
  const listHtml = [];
  for (const url of lists) {
    try {
      listHtml.push(await get(url));
    } catch (e) {
      if (String(e).includes("signin")) return { signin: true, lists: [], pages: [] };
    }
  }
  const links = new Set(known);
  for (const h of listHtml)
    for (const m of h.matchAll(/(rtn\\?\/Return\\?\/ReturnsDetail\?returnId=\d{6,20}|ItemNotReceived\\?\/\d{6,20})/g))
      links.add("https://www.ebay.com/" + m[1].replace(/\\\//g, "/"));
  const pages = [];
  for (const url of [...links].filter((u) => !skip.includes(u)).slice(0, max)) {
    try {
      const html = await get(url);
      const at = html.indexOf('"modules":');
      pages.push({ url, html: at < 0 ? "" : html.slice(Math.max(0, at - 20)) });
    } catch {
    }
  }
  const rows = listHtml.map((h) => (h.match(/<tr\b[\s\S]*?<\/tr>/gi) ?? []).join("\n"));
  return { signin: false, lists: rows, pages };
}
async function ebayConversationsInPage(list2) {
  const out = {};
  for (const t of list2) {
    try {
      const q = new URLSearchParams({ reference_id: t.itemId, reference_type: "LISTING", other_user_id: t.buyer, group_type: "CORE" });
      const r = await fetch(`/cnt/ViewMessage/getConversation?${q}`, { credentials: "same-origin", signal: AbortSignal.timeout(2e4) });
      if (!r.ok) continue;
      const doc = new DOMParser().parseFromString(await r.text(), "text/html");
      const bubbles = [...doc.querySelectorAll(".app-conversation__message-bubble")];
      if (!bubbles.length) continue;
      const buyer = (b) => b.classList.contains("app-conversation__message-bubble__grey");
      out[t.key] = {
        photos: bubbles.filter(buyer).reduce((n, b) => n + b.querySelectorAll("[class*='attachment-stack-item'] img").length, 0),
        hold: bubbles.some((b) => !buyer(b) && /do not (return|send)/i.test(b.textContent ?? ""))
      };
    } catch {
    }
  }
  return out;
}
async function aliDisputesInPage(orderIds) {
  const mtop = window.lib?.mtop;
  if (!mtop?.request) return { rows: [], error: "nomtop" };
  const call2 = (api, data) => mtop.request({ api, v: "1.0", type: "POST", dataType: "originaljson", needLogin: true, timeout: 15e3, data: JSON.stringify({ _lang: "en_US", shipTo: "US", ...data }) });
  const lines = /* @__PURE__ */ new Map();
  let complete = true;
  for (const status of [2, 3, 1])
    for (let page = 1; page <= 10; page++) {
      try {
        const res = await call2("mtop.aliexpress.buyer.reverse.queryReverseOrderPageListForBuyer", { pageNo: page, shopName: "", tradeOrderId: "", size: 20, sortOrder: "DESC", reverseStatus: status });
        const module = res.data?.module;
        if (!module) {
          complete = false;
          break;
        }
        for (const item of module.items ?? []) for (const l of item.reverseOrderLines ?? []) if (l.reverseOrderLineId) lines.set(String(l.reverseOrderLineId), l);
        const pages = Math.max(Number(module.pages) || 0, Math.ceil((Number(module.total) || 0) / 20), 1);
        if (page >= pages || !(module.items ?? []).length) break;
        if (page === 10) complete = false;
      } catch {
        complete = false;
        break;
      }
    }
  const wanted = new Set(orderIds);
  const rows = [];
  for (const l of [...lines.values()].filter((x) => wanted.has(String(x.tradeOrderId))).slice(0, 25)) {
    const item = l.aeItemDTO;
    const row = {
      reverseOrderLineId: String(l.reverseOrderLineId),
      tradeOrderId: String(l.tradeOrderId),
      tradeOrderLineId: String(l.tradeOrderLineId ?? ""),
      reverseStatus: l.reverseStatus,
      reverseType: l.reverseType,
      title: item?.itemTitle,
      createdAt: l.gmtCreateFormat,
      modifiedAt: l.gmtModifiedFormat,
      timeoutText: l.timeoutTriggerText
    };
    try {
      const res = await call2("mtop.aliexpress.buyer.reverse.batch.reverseLineRenderForBuyer", {
        tradeOrderLineId: row.tradeOrderLineId,
        reverseOrderLineId: row.reverseOrderLineId,
        terminalType: "PC"
      });
      const m = res.data?.module;
      if (m) {
        const bars = Array.isArray(m.progressNodeBars) ? m.progressNodeBars : [];
        const active = bars.filter((b) => b?.active).pop();
        Object.assign(row, {
          reason: m.applyReason?.reasonName,
          refundStatus: m.refundStatus,
          step: active?.progressText,
          reminder: m.topRefundReminder?.desc,
          responseType: m.timeOut?.type,
          responseUntil: Number(m.timeOut?.timeoutTrigger) || void 0,
          uploadAsked: Array.isArray(m.arbitrationInfoVO?.actions) && m.arbitrationInfoVO.actions.some((a) => a?.actionType === "open_upload"),
          refund: m.reverseRefundInfo?.estimatedRefundAmount ? { cent: m.reverseRefundInfo.estimatedRefundAmount.cent, currency: m.reverseRefundInfo.estimatedRefundAmount.currency } : null,
          solution: m.reachSolution?.refundMoney ? { cent: m.reachSolution.refundMoney.cent, currency: m.reachSolution.refundMoney.currency } : null
        });
      }
    } catch {
    }
    rows.push(row);
  }
  return { rows, listed: [...lines.keys()], complete };
}
var wait6 = (ms) => new Promise((r) => setTimeout(r, ms));
async function aliApiTab() {
  const tab = await chrome.tabs.create({ url: "https://www.aliexpress.com/p/order/index.html", active: false });
  const tabId = tab.id;
  if (tabId === void 0) throw Error("Impossible d\u2019ouvrir AliExpress.");
  for (let i = 0; i < 40; i++) {
    await wait6(750);
    const current2 = await chrome.tabs.get(tabId).catch(() => void 0);
    if (!current2) throw Error("L\u2019onglet AliExpress a \xE9t\xE9 ferm\xE9.");
    if (/(^|\.)login\.|passport|signin/i.test(current2.url ?? "")) {
      await chrome.tabs.remove(tabId).catch(() => {
      });
      throw Error("Connecte-toi \xE0 AliExpress dans Chrome, puis r\xE9essaie.");
    }
    const host = current2.url ? new URL(current2.url).hostname : "";
    if (current2.status !== "complete" || !/(^|\.)aliexpress\.(com|us)$/.test(host)) continue;
    const [probe] = await chrome.scripting.executeScript({ target: { tabId }, world: "MAIN", func: () => !!window.lib?.mtop?.request }).catch(() => [void 0]);
    if (probe?.result === true) return tabId;
  }
  await chrome.tabs.remove(tabId).catch(() => {
  });
  throw Error("La page AliExpress ne r\xE9pond pas : ouvre-la une fois (connect\xE9), puis r\xE9essaie.");
}
async function readOrdersAgain(ids) {
  const tab = await chrome.tabs.create({ url: `https://www.ebay.com/mesh/ord/details?mode=SH&orderid=${ids[0]}`, active: false });
  const tabId = tab.id;
  if (tabId === void 0) throw Error("onglet eBay");
  try {
    for (let i = 0; i < 40; i++) {
      await wait6(750);
      const t = await chrome.tabs.get(tabId).catch(() => void 0);
      if (!t) throw Error("onglet eBay ferm\xE9");
      if (/signin/i.test(t.url ?? "")) throw Error("connecte-toi \xE0 eBay");
      if (t.status !== "complete") continue;
      const r = await withTimeout(chrome.tabs.sendMessage(tabId, { type: "SALES_REFRESH_ORDERS", orderIds: ids }), 12e4).catch((e) => {
        if (e instanceof Error && e.message === "Pas de r\xE9ponse \xE0 temps.") throw Error("page eBay sans r\xE9ponse");
        return void 0;
      });
      if (r?.ok) return r.data ?? 0;
    }
    throw Error("page eBay sans r\xE9ponse");
  } finally {
    await chrome.tabs.remove(tabId).catch(() => {
    });
  }
}
var running6 = null;
function syncDisputes() {
  running6 ??= run4().finally(() => running6 = null);
  return running6;
}
async function run4() {
  await chrome.storage.session.set({ [STATE3]: { state: "running", at: Date.now() } }).catch(() => {
  });
  const before = await disputeStore();
  const errors = [];
  const fresh = [];
  const now = Date.now();
  try {
    const skip = Object.values(before.items).filter((d) => d.source === "ebay" && !d.open && now - d.updatedAt < 30 * 864e5).map((d) => d.url);
    const known = Object.values(before.items).filter((d) => d.source === "ebay" && d.open).map((d) => d.url);
    const { tabId, owned } = await ebayTab(true);
    try {
      const [r] = await withTimeout(
        chrome.scripting.executeScript({
          target: { tabId },
          func: ebayDisputePagesInPage,
          args: [["/sh/ord/return", "/sh/ord/return?filter=status%3ACLOSED", "/sh/resolutions?filter=ISSUE_STATE%3AALL_ISSUES"], skip, 40, known]
        }),
        18e4
      );
      const got = r?.result;
      if (!got || got.signin) errors.push("eBay : connecte-toi \xE0 eBay dans Chrome, puis r\xE9essaie.");
      else {
        const meta = new Map(got.lists.flatMap((h) => ebayDisputeLinks(h)).map((l) => [l.url, l]));
        const talks = [];
        for (const p of got.pages) {
          const d = parseEbayDispute(p.html, p.url, now);
          if (!d) continue;
          const row = meta.get(d.url);
          if (row?.deadline && d.open) d.deadline = row.deadline;
          fresh.push(d);
          const buyer = d.kind === "return" && d.open && d.itemId ? ebayDisputeBuyer(p.html) : null;
          if (buyer) talks.push({ key: d.key, itemId: d.itemId, buyer });
        }
        const [c] = talks.length ? await withTimeout(chrome.scripting.executeScript({ target: { tabId }, func: ebayConversationsInPage, args: [talks] }), 12e4) : [];
        const read2 = c?.result ?? {};
        fresh.forEach((d, i) => {
          const talk = read2[d.key];
          if (talk) fresh[i] = applyConversation({ ...d, held: d.held ?? before.items[d.key]?.held }, talk, now);
        });
      }
    } finally {
      if (owned) await chrome.tabs.remove(tabId).catch(() => {
      });
    }
  } catch (e) {
    errors.push("eBay : " + (e instanceof Error ? e.message : String(e)));
  }
  let listed = null;
  const sales = await listSales();
  const saleOf = saleOfAliOrder(sales);
  if (saleOf.size) {
    let tabId;
    try {
      tabId = await aliApiTab();
      const [r] = await withTimeout(
        chrome.scripting.executeScript({ target: { tabId }, world: "MAIN", func: aliDisputesInPage, args: [[...saleOf.keys()]] }),
        18e4
      );
      const got = r?.result;
      if (!got || got.error) errors.push("AliExpress : lecture des litiges impossible, r\xE9essaie plus tard.");
      for (const row of got?.rows ?? []) {
        const d = aliDispute(row, saleOf.get(row.tradeOrderId) ?? null, now);
        if (d) fresh.push(d);
      }
      if (got && !got.error && got.complete && Array.isArray(got.listed)) listed = new Set(got.listed);
    } catch (e) {
      errors.push("AliExpress : " + (e instanceof Error ? e.message : String(e)));
    } finally {
      if (tabId !== void 0) await chrome.tabs.remove(tabId).catch(() => {
      });
    }
  }
  const items = closeUnlisted(mergeDisputes(before.items, fresh, now), listed, now);
  const refunds = {};
  for (const d of Object.values(items))
    if (d.source === "aliexpress" && !d.open && d.refunded && d.aliOrderId) {
      const known = refunds[d.aliOrderId];
      refunds[d.aliOrderId] = known && known.currency === d.refunded.currency ? { ...known, amount: Math.round((known.amount + d.refunded.amount) * 100) / 100 } : known ?? d.refunded;
    }
  if (Object.keys(refunds).length) await noteSupplierRefunds(refunds).catch(() => {
  });
  const refreshed = new Set(before.refreshed ?? []);
  const saved = new Set(sales.map((x) => x.orderId));
  const toRead = Object.values(items).filter((d) => d.source === "ebay" && !d.open && d.orderId && saved.has(d.orderId) && !refreshed.has(d.key));
  if (toRead.length) {
    try {
      const ids = [...new Set(toRead.map((d) => d.orderId))];
      if (await readOrdersAgain(ids) > 0) for (const d of toRead) refreshed.add(d.key);
    } catch (e) {
      errors.push("eBay : relecture des commandes rembours\xE9es impossible (" + (e instanceof Error ? e.message : String(e)) + ").");
    }
  }
  const store = {
    items,
    at: now,
    ...errors.length ? { errors } : {},
    ...refreshed.size ? { refreshed: [...refreshed].filter((k) => items[k]) } : {}
  };
  await chrome.storage.local.set({ [DISPUTES_KEY]: store });
  await chrome.storage.session.set({ [STATE3]: { state: errors.length ? "error" : "done", at: Date.now(), found: fresh.length } }).catch(() => {
  });
  return store;
}
async function holdReturn(key4) {
  if (typeof key4 !== "string" || !/^ebay:\d{6,20}$/.test(key4)) return false;
  const store = await disputeStore();
  if (!store.items[key4]) return false;
  store.items[key4] = { ...store.items[key4], held: Date.now() };
  await chrome.storage.local.set({ [DISPUTES_KEY]: store });
  return true;
}
async function orderDisputes(orderId) {
  if (typeof orderId !== "string" || !/^\d{2}-\d{5}-\d{5}$/.test(orderId)) return { list: [], advice: null, at: 0 };
  const store = await disputeStore();
  const list2 = Object.values(store.items).filter((d) => d.orderId === orderId).sort((a, b) => Number(b.open) - Number(a.open) || Number(a.source !== "ebay") - Number(b.source !== "ebay") || b.updatedAt - a.updatedAt);
  const sale = (await listSales()).find((x) => x.orderId === orderId);
  return { list: list2, advice: disputeAdvice(list2, !!sale && purchases(sale).length > 0), at: store.at };
}

// src/core/protection.ts
var PARCELS_KEY = "aliParcels:v1";
var DAY5 = 864e5;
var DEFAULT_DISPUTE_DAYS = 90;
var MAX_AGE_DAYS2 = 120;
var FRESH_HOURS = 6;
var PARCEL_VERSION = 2;
function aliDate(text3) {
  const m = text3.match(/\b(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\.?\s+(\d{1,2}),?\s+(\d{4})\b/i);
  if (!m) return null;
  const month = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"].indexOf(m[1].slice(0, 3).toLowerCase());
  const t = new Date(Number(m[3]), month, Number(m[2])).getTime();
  return Number.isFinite(t) ? t : null;
}
var DELIVERED = /\bdelivered\b|\bsigned\b|picked up by (the )?(recipient|customer)/i;
var NOT_DELIVERED = /out for delivery|attempt|fail|unable|not delivered|could not|returned to sender|on its way/i;
function parcelInfo(raw, now = Date.now()) {
  const placedAt = aliDate(raw.placed);
  const afterOrder = raw.reminder.match(/within\s+(\d{1,3})\s+days\s+after\s+(?:the\s+)?order/i);
  const fromReceipt = /days\s+(?:of|after)\s+(?:the\s+)?receipt/i.test(raw.reminder);
  const days = afterOrder ? Number(afterOrder[1]) : fromReceipt ? null : DEFAULT_DISPUTE_DAYS;
  const last = raw.events[0];
  const lastText = last?.text ?? "";
  const refundLine = raw.promises.find((p) => /refund if no delivery/i.test(p));
  return {
    v: PARCEL_VERSION,
    orderId: raw.orderId,
    status: raw.status,
    placedAt,
    disputeUntil: placedAt !== null && days !== null ? placedAt + days * DAY5 : null,
    autoConfirmAt: raw.autoConfirmAt && raw.autoConfirmAt > 0 ? raw.autoConfirmAt : null,
    etaEnd: raw.etaEnd && raw.etaEnd > 0 ? raw.etaEnd : null,
    refundIfNotBy: refundLine ? aliDate(refundLine) : null,
    lastEventAt: last?.time || null,
    lastEvent: lastText,
    delivered: DELIVERED.test(lastText) && !NOT_DELIVERED.test(lastText) || /_DELIVERED$|DELIVERY_SUCCESS|_SIGN_SUCCESS$|_SIGNED$/i.test(last?.code ?? "") && !/^AE_SC_/i.test(last?.code ?? ""),
    closed: /complete|closed|finished|cancel/i.test(raw.status),
    checkedAt: now,
    ...raw.disputeLinks ? { disputeLinks: raw.disputeLinks } : {}
  };
}
function watched(sales, now) {
  const out = [];
  for (const s of sales) {
    if (s.status === "cancelled") continue;
    if (now - (s.soldAt ?? now) > MAX_AGE_DAYS2 * DAY5) continue;
    for (const p of purchases(s)) if (/^\d{8,25}$/.test(p.orderId)) out.push({ sale: s, p });
  }
  return out;
}
function parcelsToCheck(sales, store, now = Date.now(), force = false) {
  const ids = /* @__PURE__ */ new Set();
  for (const { p } of watched(sales, now)) {
    if (!p.tracking) continue;
    const known = store.items[p.orderId];
    const current2 = known?.v === PARCEL_VERSION;
    if (current2 && (known.delivered || known.closed)) continue;
    if (!force && current2 && now - known.checkedAt < FRESH_HOURS * 36e5) continue;
    ids.add(p.orderId);
  }
  return [...ids].slice(0, 80);
}

// src/background/parcels.ts
var DAY6 = 864e5;
async function parcelStore() {
  const saved = (await chrome.storage.local.get(PARCELS_KEY).catch(() => ({})))[PARCELS_KEY];
  return saved?.items && typeof saved.items === "object" ? saved : { items: {}, at: 0 };
}
var running7 = null;
function refreshParcels(force = false) {
  running7 ??= run5(force).finally(() => running7 = null);
  return running7;
}
var PARCEL_RUN = "parcelRun:v1";
var progress = (done, total2, state = "running") => chrome.storage.session.set({ [PARCEL_RUN]: { state, done, total: total2, at: Date.now() } }).catch(() => {
});
var BATCH = 8;
var BATCH_WAIT = 45e3;
async function run5(force) {
  const now = Date.now();
  const store = await parcelStore();
  for (const [id, p] of Object.entries(store.items)) if (now - p.checkedAt > 150 * DAY6) delete store.items[id];
  const ids = parcelsToCheck(await listSales(), store, now, force);
  const save4 = (extra = {}) => chrome.storage.local.set({ [PARCELS_KEY]: { ...store, at: Date.now(), ...extra } });
  if (!ids.length) {
    await save4({ error: void 0 });
    await progress(0, 0, "done");
    return { ...store, at: Date.now() };
  }
  let tabId;
  let done = 0;
  const failed = [];
  await progress(0, ids.length);
  const read2 = async (part) => {
    tabId ??= await aliApiTab();
    try {
      const [r] = await withTimeout(
        chrome.scripting.executeScript({ target: { tabId }, world: "MAIN", func: aliParcelsInPage, args: [part] }),
        BATCH_WAIT
      );
      const got = /* @__PURE__ */ new Set();
      for (const raw of r?.result ?? []) {
        if (!raw || !part.includes(raw.orderId) || !raw.ok) continue;
        store.items[raw.orderId] = parcelInfo(raw, Date.now());
        got.add(raw.orderId);
      }
      return part.filter((id) => !got.has(id));
    } catch {
      await chrome.tabs.remove(tabId).catch(() => {
      });
      tabId = void 0;
      return part;
    }
  };
  try {
    for (let i = 0; i < ids.length; i += BATCH) {
      const part = ids.slice(i, i + BATCH);
      failed.push(...await read2(part));
      done += part.length;
      await save4();
      await progress(done, ids.length);
    }
    const again = failed.splice(0);
    for (let i = 0; i < again.length; i += 4) failed.push(...await read2(again.slice(i, i + 4)));
    const error = failed.length ? `${failed.length} colis pas lus (AliExpress n\u2019a pas r\xE9pondu) : r\xE9essaie plus tard.` : void 0;
    await save4({ error });
    return { ...store, at: Date.now(), error };
  } catch (e) {
    const error = e instanceof Error ? e.message : String(e);
    await save4({ at: store.at, error }).catch(() => {
    });
    throw e;
  } finally {
    await progress(done, ids.length, "done");
    if (tabId !== void 0) await chrome.tabs.remove(tabId).catch(() => {
    });
  }
}

// src/core/claudeBridge.ts
var BRIDGE_KEY = "claudeBridgeOn:v1";
var BRIDGE_COMMANDS = ["status", "create", "job", "trace", "batch", "batchStop", "batchState", "reload", "disputes", "disputesSync"];
var bridgeOpen = (value) => value === true;

// src/core/ebayPhotoCheck.ts
var visualSearchURL = (guid, sold) => `https://www.ebay.com/sch/i.html?visualSearchGuid=${encodeURIComponent(guid)}${sold ? "&LH_Sold=1&LH_Complete=1" : "&LH_BIN=1&LH_ItemCondition=1000&_ipg=240&_dmd=1"}`;
async function visualGuidInPage(base64) {
  try {
    const form = new FormData();
    form.append("isVisualSearch", "true");
    form.append("imageData", base64);
    const r = await fetch("/sch/ajax/post/image", { method: "POST", body: form, credentials: "include", signal: AbortSignal.timeout(3e4) });
    if (!r.ok) return null;
    const j = await r.json();
    return typeof j.zoom_guid === "string" && j.zoom_guid ? j.zoom_guid : null;
  } catch {
    return null;
  }
}
function mergeCards(lists) {
  const out = /* @__PURE__ */ new Map();
  for (const { cards, photo } of lists)
    cards.forEach((c, rank) => {
      const had = out.get(c.itemId);
      const p = photo ? photo(c) : null;
      if (!had) return void out.set(c.itemId, { ...c, photo: p, rank });
      out.set(c.itemId, {
        ...had,
        soldAt: Math.max(had.soldAt ?? 0, c.soldAt ?? 0) || null,
        sold: Math.max(had.sold ?? 0, c.sold ?? 0) || had.sold || c.sold,
        seller: had.seller ?? c.seller,
        located: had.located ?? c.located,
        shipping: had.shipping ?? c.shipping,
        photo: Math.max(had.photo ?? -1, p ?? -1) >= 0 ? Math.max(had.photo ?? -1, p ?? -1) : null,
        rank: Math.min(had.rank, rank)
      });
    });
  return [...out.values()];
}
function sameProduct(c, words2, top = 24, minWords = 0.15, samePhoto = 0.92) {
  if (c.photo !== null && c.photo >= samePhoto) return true;
  if (c.rank >= top) return false;
  return words2 >= minWords && (c.photo === null || c.photo >= 0.55);
}
function rankListings(list2) {
  return [...list2].sort(
    (a, b) => (b.d7 ?? -1) - (a.d7 ?? -1) || (b.d30 ?? -1) - (a.d30 ?? -1) || (b.sold ?? 0) - (a.sold ?? 0) || (b.soldAt ?? 0) - (a.soldAt ?? 0) || (b.photo ?? 0) - (a.photo ?? 0)
  );
}

// src/background/ebayPhotoCheck.ts
var DAY7 = 864e5;
var jobs = /* @__PURE__ */ new Map();
var photoCheckStatus = (productId2) => typeof productId2 === "string" ? jobs.get(productId2) ?? null : null;
async function jpegBase64(url) {
  try {
    const clean = url.replace(/(\.(?:jpe?g|png|webp))_.*$/i, "$1");
    const blob = await fetch(clean, { signal: AbortSignal.timeout(2e4) }).then((r) => r.ok ? r.blob() : null);
    if (!blob) return null;
    const bitmap = await createImageBitmap(blob);
    const s = Math.min(1, 800 / Math.max(bitmap.width, bitmap.height));
    const canvas = new OffscreenCanvas(Math.max(1, Math.round(bitmap.width * s)), Math.max(1, Math.round(bitmap.height * s)));
    canvas.getContext("2d").drawImage(bitmap, 0, 0, canvas.width, canvas.height);
    bitmap.close();
    const bytes = new Uint8Array(await (await canvas.convertToBlob({ type: "image/jpeg", quality: 0.8 })).arrayBuffer());
    let text3 = "";
    for (let i = 0; i < bytes.length; i += 32768) text3 += String.fromCharCode(...bytes.subarray(i, i + 32768));
    return btoa(text3);
  } catch {
    return null;
  }
}
async function inTab(tabId, func, args, wait8) {
  const [r] = await withTimeout(
    chrome.scripting.executeScript({ target: { tabId }, func, args }),
    wait8
  ).catch(() => [void 0]);
  return r?.result ?? null;
}
async function runPhotoCheck(input) {
  const aliTitle = typeof input.title === "string" ? input.title.slice(0, 300) : "";
  const id = typeof input.productId === "string" ? input.productId : "";
  const images = (Array.isArray(input.images) ? input.images : []).filter((u) => typeof u === "string" && /^https:\/\//.test(u)).slice(0, 4);
  if (!id || !images.length) throw Error("Photos du produit introuvables : recharge la page AliExpress.");
  const running9 = jobs.get(id);
  if (running9?.state === "running") return running9;
  const r = {
    state: "running",
    step: "Ouverture d\u2019eBay\u2026",
    guid: null,
    photosSearched: 0,
    found: 0,
    sellers: 0,
    nonUS: 0,
    us: 0,
    unknown: 0,
    soldRecent: 0,
    d7: null,
    d30: null,
    median: null,
    listings: [],
    net: null,
    currency: "EUR",
    at: Date.now()
  };
  jobs.set(id, r);
  const model = await profitModel().catch(() => null);
  if (model) r.currency = model.currency;
  const step = (text3) => {
    r.step = text3;
    r.at = Date.now();
  };
  const tab = await ebayTab(true).catch(() => null);
  try {
    if (!tab) throw Error("Impossible d\u2019ouvrir eBay.");
    const aliGrids = (await Promise.all(images.map((u) => pictureGrids(u, [1, 0.9])))).filter((g) => !!g);
    const lists = [];
    for (const [i, url] of images.entries()) {
      step(`Photo ${i + 1}/${images.length} : recherche sur eBay\u2026`);
      const b64 = await jpegBase64(url);
      const guid = b64 ? await inTab(tab.tabId, visualGuidInPage, [b64], 4e4) : null;
      if (!guid) continue;
      r.photosSearched++;
      r.guid ??= guid;
      for (const sold of [true, false]) {
        const cards = await inTab(tab.tabId, searchCardsInPage, [visualSearchURL(guid, sold)], 6e4);
        if (cards?.length) lists.push({ cards: cards.slice(0, 40) });
      }
    }
    if (!r.photosSearched) throw Error("eBay n\u2019a pas accept\xE9 la recherche par photo (connexion eBay ? v\xE9rification anti-robot ?). Ouvre eBay une fois puis r\xE9essaie.");
    const merged = mergeCards(lists);
    step(`Comparaison des photos de ${merged.length} annonce(s)\u2026`);
    let next = 0;
    await Promise.all(
      Array.from({ length: 8 }, async () => {
        while (next < merged.length) {
          const c = merged[next++];
          const grid = c.image ? await pictureGrids(c.image, [1, 0.9]) : null;
          c.photo = grid && aliGrids.length ? Math.max(...aliGrids.map((a) => bestCorrelation(grid, a))) : null;
        }
      })
    );
    const kept2 = merged.filter((c) => sameProduct(c, aliTitle ? titleSimilarity(c.title, aliTitle) : 1)).sort((a, b) => (b.sold ?? 0) - (a.sold ?? 0) || (b.soldAt ?? 0) - (a.soldAt ?? 0));
    r.found = kept2.length;
    r.soldRecent = kept2.filter((c) => c.soldAt !== null && Date.now() - c.soldAt < 30 * DAY7).length;
    if (kept2.length) {
      const sellers = [...new Set(kept2.map((c) => c.seller).filter((s) => !!s))].slice(0, 40);
      step(`Pays des ${sellers.length} vendeur(s)\u2026`);
      const countries = await sellerCountries(sellers, tab, async (n) => step(`Pays des vendeurs : ${n}/${sellers.length}\u2026`));
      const info = sellers.map((s) => countries.get(s));
      r.sellers = sellers.length;
      r.nonUS = info.filter((i) => i?.status === "NON_US").length;
      r.us = info.filter((i) => i?.status === "US").length;
      r.unknown = sellers.length - r.nonUS - r.us;
      let listings = kept2.map((c) => {
        const who = c.seller && countries.get(c.seller) || { status: "UNKNOWN", country: null };
        return {
          itemId: c.itemId,
          title: c.title,
          image: c.image,
          seller: c.seller,
          status: who.status,
          country: who.country,
          total: Math.round((c.price + (c.shipping ?? 0)) * 100) / 100,
          located: c.located,
          sold: c.sold,
          soldAt: c.soldAt,
          photo: c.photo,
          d7: null,
          d30: null
        };
      });
      const prices = listings.map((l) => l.total).sort((a, b) => a - b);
      r.median = prices[Math.floor(prices.length / 2)];
      const top = listings.slice(0, 12).map((l) => l.itemId);
      step("Ventes des 7 et 30 derniers jours\u2026");
      const rows = await inTab(tab.tabId, purchaseRowsInPage, [top], 18e4) ?? {};
      const units = (list2, days) => list2.filter((x) => {
        const at = purchaseDate(x.date);
        return at !== null && Date.now() - at <= days * DAY7;
      }).reduce((n, x) => n + x.quantity, 0);
      listings = listings.map((l) => {
        const list2 = rows[l.itemId];
        return list2 ? { ...l, d7: units(list2, 7), d30: units(list2, 30) } : l;
      });
      const read2 = listings.filter((l) => l.d30 !== null);
      r.d7 = read2.length ? read2.reduce((n, l) => n + (l.d7 ?? 0), 0) : null;
      r.d30 = read2.length ? read2.reduce((n, l) => n + (l.d30 ?? 0), 0) : null;
      r.listings = rankListings(listings).slice(0, 8);
      const cost = Number(input.price);
      if (model && r.listings[0] && input.currency === "USD" && cost > 0) r.net = estimateProfit(r.listings[0].total, cost, model).net;
    }
    r.state = "done";
    step("Termin\xE9.");
    apiTrace("photoCheck", "done", { photos: r.photosSearched, read: merged.length, found: r.found, sellers: r.sellers, nonUS: r.nonUS });
  } catch (e) {
    r.state = "error";
    r.error = e instanceof Error ? e.message : String(e);
  } finally {
    if (tab?.owned) await chrome.tabs.remove(tab.tabId).catch(() => {
    });
  }
  r.at = Date.now();
  return r;
}

// src/background/competitors.ts
var KEY4 = "competitors:v1";
var MAX_SELLERS = 300;
var MAX_SEEN = 200;
var SELLER = /^[a-z0-9_.*-]{2,64}$/;
async function all2() {
  return (await chrome.storage.local.get(KEY4))[KEY4] ?? {};
}
async function write2(store) {
  await chrome.storage.local.set({ [KEY4]: store });
}
function sellerFrom(value) {
  if (typeof value !== "string") return null;
  const text3 = value.trim();
  try {
    const url = new URL(text3);
    if (!/(^|\.)ebay\.com$/.test(url.hostname)) return null;
    const name = url.searchParams.get("_ssn") ?? url.pathname.match(/^\/(?:usr|str)\/([A-Za-z0-9_.-]{2,64})\/?$/)?.[1] ?? url.pathname.match(/^\/fdbk\/feedback_profile\/([A-Za-z0-9_.-]{2,64})\/?$/)?.[1] ?? null;
    return name && SELLER.test(name.toLowerCase()) ? name.toLowerCase() : null;
  } catch {
    const name = text3.toLowerCase();
    return SELLER.test(name) ? name : null;
  }
}
async function listCompetitors() {
  return Object.values(await all2()).sort((a, b) => b.addedAt - a.addedAt).map(({ seen: _seen, ...rest }) => ({ ...rest, seenCount: Object.keys(_seen).length }));
}
async function addCompetitor(value) {
  const seller = sellerFrom(value);
  if (!seller) throw Error("Nom de vendeur eBay non reconnu.");
  const store = await all2();
  if (!store[seller]) {
    if (Object.keys(store).length >= MAX_SELLERS) throw Error(`${MAX_SELLERS} concurrents au maximum.`);
    store[seller] = { seller, addedAt: Date.now(), lastCheck: null, seen: {}, lastNew: 0 };
    await write2(store);
  }
  return seller;
}
async function addCompetitors(value) {
  const parts = typeof value === "string" ? value.split(/[\s,;]+/).filter(Boolean) : [];
  const store = await all2();
  const added = [];
  const already = [];
  const refused = [];
  for (const part of parts.slice(0, 200)) {
    const seller = sellerFrom(part);
    if (!seller) refused.push(part.slice(0, 60));
    else if (store[seller]) already.includes(seller) || already.push(seller);
    else if (Object.keys(store).length >= MAX_SELLERS) refused.push(`${seller} (${MAX_SELLERS} au maximum)`);
    else {
      store[seller] = { seller, addedAt: Date.now(), lastCheck: null, seen: {}, lastNew: 0 };
      added.push(seller);
    }
  }
  if (added.length) await write2(store);
  return { added, already, refused };
}
async function removeCompetitor(value) {
  const seller = sellerFrom(value);
  const store = await all2();
  if (seller && store[seller]) {
    delete store[seller];
    await write2(store);
  }
  return true;
}
async function markSeen(value, itemIds, now = Date.now()) {
  const seller = sellerFrom(value);
  if (!seller || !Array.isArray(itemIds)) throw Error("Concurrent inconnu.");
  const ids = itemIds.filter((x) => typeof x === "string" && /^\d{9,15}$/.test(x)).slice(0, 200);
  const store = await all2();
  const c = store[seller];
  if (!c) throw Error("Ce vendeur n\u2019est pas dans tes concurrents.");
  const baseline = c.lastCheck !== null;
  const fresh = ids.filter((id) => !(id in c.seen));
  for (const id of fresh) c.seen[id] = now;
  const entries = Object.entries(c.seen);
  if (entries.length > MAX_SEEN)
    c.seen = Object.fromEntries(entries.sort((a, b) => b[1] - a[1]).slice(0, MAX_SEEN));
  c.lastCheck = now;
  c.lastNew = baseline ? fresh.length : 0;
  await write2(store);
  return {
    newIds: baseline ? fresh : [],
    firstSeen: Object.fromEntries(ids.map((id) => [id, c.seen[id] ?? now])),
    baseline
  };
}

// src/core/floating.ts
var FLOAT_CSS = `${BRAND_CSS}
  :host{${WINDOW_TOKENS}}
  .card{position:relative;width:316px;max-height:75vh;overflow:auto;background:var(--bg);color:var(--ink);border:1px solid var(--line);border-radius:16px;box-shadow:0 18px 44px rgba(10,6,16,.45),0 0 0 1px rgba(255,255,255,.02) inset;font:13px/1.45 -apple-system,system-ui,sans-serif;animation:ao-rise .38s var(--ao-ease)}
  .card::before{content:"";position:sticky;top:0;display:block;height:2px;margin-bottom:-2px;background:linear-gradient(90deg,var(--ao-ember),var(--ao-sun),var(--ao-ember)) 0 0/200% 100%;animation:fline 6s linear infinite;z-index:2}
  .head{display:flex;justify-content:space-between;align-items:center;gap:8px;font-weight:700;padding:10px 12px;cursor:grab;user-select:none;border-bottom:1px solid var(--line)}
  .head>span{display:flex;align-items:center;gap:8px}
  .head:active{cursor:grabbing}
  .logo{width:22px;height:22px;transition:transform .45s var(--ao-spring)}
  .head:hover .logo{transform:rotate(-8deg) scale(1.08)}
  .body{padding:8px 12px 12px}
  .mini .body,.mini .t,.mini .x{display:none}
  .mini .card{width:auto;border-radius:16px;overflow:visible;background:transparent;border-color:transparent;box-shadow:none;animation:fpop .5s var(--ao-spring)}
  .mini .card::before{display:none}
  .mini .head{padding:0;border:0;cursor:pointer}
  .mini .logo{width:44px;height:44px;border-radius:13px;filter:drop-shadow(0 8px 18px rgba(255,95,58,.45));animation:fhalo 3.6s ease-out 1s infinite}
  .mini .head:hover .logo{transform:scale(1.12) rotate(-6deg)}
  button{font:600 13px system-ui;border-radius:10px;border:1px solid var(--line);background:var(--bg2);color:var(--ink);padding:8px 10px;cursor:pointer;width:100%;margin-top:6px;text-align:left;transition:background-position .4s var(--ao-ease),border-color .2s,transform .12s,box-shadow .2s}
  button:hover{border-color:color-mix(in srgb,var(--accent) 45%,var(--line))}
  button:active{transform:translateY(1px) scale(.99)}
  button.primary{background:var(--ao-gradient);background-size:170% 100%;border-color:transparent;color:#fff;box-shadow:0 6px 16px rgba(255,95,58,.3)}
  button.primary:hover{background-position:100% 0;box-shadow:0 8px 22px rgba(255,95,58,.42)}
  button.track{background:linear-gradient(135deg,#f0a63a,#ffcf6b);border-color:transparent;color:#2a1a05}
  button:disabled{opacity:.75;cursor:wait;position:relative;overflow:hidden}
  button:disabled::after{content:"";position:absolute;inset:0;background:linear-gradient(100deg,transparent 30%,rgba(255,255,255,.22) 50%,transparent 70%);transform:translateX(-100%);animation:ao-shine 1.4s ease-in-out infinite}
  button.primary:disabled::before{content:"";display:inline-block;width:12px;height:12px;margin-right:7px;vertical-align:-2px;border-radius:50%;background:conic-gradient(transparent 0 40%,#fff);-webkit-mask:radial-gradient(circle closest-side,transparent 62%,#000 70%);mask:radial-gradient(circle closest-side,transparent 62%,#000 70%);animation:ao-spin .8s linear infinite}
  @keyframes fline{to{background-position:-200% 0}}
  @keyframes fpop{0%{opacity:0;transform:scale(.4) rotate(-20deg)}100%{opacity:1;transform:none}}
  @keyframes fhalo{0%,60%,100%{filter:drop-shadow(0 8px 18px rgba(255,95,58,.45))}75%{filter:drop-shadow(0 0 22px rgba(255,179,71,.85))}}
  @media (prefers-reduced-motion:reduce){*,*::before,*::after{animation:none!important;transition:none!important}}
  .x{background:none;border:0;width:auto;margin:0;padding:0 4px;color:var(--muted);font-size:15px;transition:color .2s}.x:hover{color:var(--ink)}
  .status{margin:4px 0;color:var(--muted)}.ok{color:var(--ok)}.warn{color:var(--warn)}.err{color:var(--err)}
  ul{margin:6px 0 0;padding-left:18px}.small,.s{font-size:12px;color:var(--muted)}
  .label{margin:10px 0 4px;font:700 11px system-ui;letter-spacing:.06em;color:var(--muted)}
  label.row{display:flex;align-items:center;justify-content:space-between;gap:8px;margin:5px 0}
  input,select{font:13px system-ui;background:#15121c;color:var(--ink);border:1px solid var(--line);border-radius:9px;padding:6px 8px;transition:border-color .2s,box-shadow .2s}input:focus,select:focus{outline:0;border-color:var(--accent);box-shadow:0 0 0 3px rgba(255,95,58,.2)}
  label.row input,label.row select{width:150px;text-align:right}
  label.row.check{justify-content:flex-start;margin:8px 0;cursor:pointer}
  label.row.check input{width:auto;margin:0}
  input[type=search]{width:100%;box-sizing:border-box;margin-top:6px}
  .il-zip{margin-top:8px;padding:8px;border:1px solid var(--line);border-radius:12px}.il-zip-row{display:flex;gap:6px;margin-top:6px}.il-zip-row input{flex:1;min-width:0}.il-zip-row button{width:auto;margin:0;white-space:nowrap}
  .sale{margin-top:8px;padding:8px;border:1px solid var(--line);border-radius:12px;background:var(--bg2);animation:ao-rise .35s var(--ao-ease) both}
`;

// src/ebay/trackingPage.ts
var trackingPageURL = (orders, returnUrl = location.href, transactions = {}) => `https://www.ebay.com/ship/tr/update?source=1&flow=&returnUrl=${encodeURIComponent(returnUrl.split("#")[0])}&orders=${orders.join(",")}#auroebay-fill=${encodeURIComponent(JSON.stringify(transactions))}`;

// src/core/pageModule.ts
function pageModule(text3, key4, accept = () => true) {
  const marker = `"${key4}":{`;
  for (let at = text3.indexOf(marker); at >= 0; at = text3.indexOf(marker, at + 1)) {
    const start = at + marker.length - 1;
    let depth = 0, inString = false, escaped = false;
    for (let i = start; i < text3.length; i++) {
      const c = text3[i];
      if (inString) {
        if (escaped) escaped = false;
        else if (c === "\\") escaped = true;
        else if (c === '"') inString = false;
        continue;
      }
      if (c === '"') inString = true;
      else if (c === "{") depth++;
      else if (c === "}" && --depth === 0) {
        try {
          const value = JSON.parse(text3.slice(start, i + 1));
          if (accept(value)) return value;
        } catch {
        }
        break;
      }
    }
  }
  return null;
}

// src/core/watch.ts
var usd = (model) => {
  const v = model?.binModel?.price?.value ?? model?.price?.value;
  return v?.currency === "USD" && Number(v.value) > 0 ? Number(v.value).toFixed(2) : null;
};
function liveListing(html) {
  const ended = /This listing (was|has) ended|The seller has ended this listing/i.test(html);
  const msku = pageModule(html, "MSKU", (m) => Array.isArray(m?.selectMenus) && !!m.variationsMap);
  if (msku?.selectMenus?.length) {
    const menus = msku.selectMenus;
    const name = (id) => String(msku.menuItemMap?.[id]?.valueName ?? "").replace(/\s+/g, " ").trim();
    const rows = [];
    for (const [key4, vid] of Object.entries(msku.variationCombinations ?? {})) {
      const ids = key4.split("_").map(Number);
      if (ids.length !== menus.length) continue;
      const model = msku.variationsMap?.[String(vid)];
      const price2 = usd(model);
      if (!price2) continue;
      rows.push({ values: ids.map(name), price: price2, quantity: model?.quantity?.outOfStock ? 0 : 1 });
    }
    if (rows.length) return { ended, rows };
  }
  const price = html.match(/"binModel":\{"price":\{[^{}]*"value":\{"value":([\d.]+),"currency":"USD"\}/)?.[1] ?? html.match(/class="x-price-primary"[^>]*>(?:<[^>]+>)*US \$([\d,]+\.\d{2})/)?.[1]?.replace(/,/g, "");
  if (!price) throw Error("Prix de l\u2019annonce eBay illisible.");
  const out = /"outOfStock":true/.test(html) && !/"outOfStock":false/.test(html);
  return { ended, rows: [{ values: [], price: Number(price).toFixed(2), quantity: out ? 0 : 1 }] };
}
function watchIssues(live, scan, rule, links) {
  const plan = planListingSync(live.rows, scan, rule, { stock: true, prices: !!rule, links });
  const issues = [];
  for (const r of plan) {
    if (r.supplier === "out_of_stock" && r.quantity > 0) issues.push({ values: r.values, kind: "out" });
    else if (r.supplier === "in_stock" && r.quantity === 0) issues.push({ values: r.values, kind: "back" });
    else if (r.supplier === "unknown") issues.push({ values: r.values, kind: "unknown" });
    if (r.supplier === "in_stock" && rule && Math.abs(Number(r.newPrice) - Number(r.price)) >= 0.01)
      issues.push({
        values: r.values,
        kind: Number(r.newPrice) > Number(r.price) ? "price_up" : "price_down",
        price: r.price,
        newPrice: r.newPrice
      });
  }
  return issues;
}
var supplierProblems = (issues) => issues.filter((i) => i.kind === "out" || i.kind === "unknown" || i.kind === "price_up").length;
function pickBackup(primary, candidates) {
  const primaryProblems = supplierProblems(primary);
  const scored = candidates.map((c) => {
    const costs2 = c.scan.costs.filter((x) => x.cost > 0);
    const min = costs2.length ? costs2.reduce((a, b) => b.cost < a.cost ? b : a) : null;
    return { c, problems: supplierProblems(c.issues), minCost: min?.cost ?? null, currency: min?.currency ?? null, buyable: costs2.length };
  }).filter((x) => x.buyable > 0 && x.problems < primaryProblems).sort((a, b) => a.problems - b.problems || (a.minCost ?? Infinity) - (b.minCost ?? Infinity));
  const best = scored[0];
  return best ? { supplierId: best.c.supplierId, url: best.c.url, title: best.c.title, problems: best.problems, primaryProblems, minCost: best.minCost, currency: best.currency, at: best.c.at } : null;
}
var urgentIssues = (r) => r.issues.filter((i) => i.kind === "out" || i.kind === "price_up").length;

// src/background/watch.ts
var KEY5 = "watch:v1";
var empty = () => ({ running: false, at: null, results: {} });
async function watchState() {
  return { ...empty(), ...(await chrome.storage.local.get(KEY5))[KEY5] ?? {} };
}
async function save3(state) {
  await chrome.storage.local.set({ [KEY5]: state });
}
async function saveRun(state) {
  const stored = await watchState();
  for (const [id, r] of Object.entries(state.results)) {
    const was = stored.results[id];
    if (was && was.at === r.at) {
      r.dismissed = was.dismissed;
      r.sent = was.sent;
    }
  }
  await save3(state);
}
async function showBadge(state) {
  const urgent = Object.values(state.results).reduce(
    (n, r) => n + (urgentIssues(r) && !r.dismissed && !r.sent ? 1 : 0),
    0
  );
  const update = urgent ? null : await pendingUpdate().catch(() => null);
  if (update) return showUpdateBadge(update);
  await chrome.action.setBadgeText({ text: urgent ? String(urgent) : "" }).catch(() => {
  });
  await chrome.action.setBadgeBackgroundColor({ color: "#dc2626" }).catch(() => {
  });
}
function targets(products) {
  return products.flatMap((p) => {
    if (p.archived) return [];
    const supplier = p.suppliers.find((s) => s.id === p.primarySupplierId) ?? p.suppliers[0];
    const item = [...p.ownListings].reverse().find((l) => l.kind === "item");
    const itemId = item?.url.match(/\/itm\/(\d{9,15})/)?.[1];
    const others = p.suppliers.filter((s) => s !== supplier).sort((a, b) => b.updatedAt - a.updatedAt).slice(0, 3);
    return supplier && itemId ? [{ product: p, supplierUrl: supplier.url, itemId, others }] : [];
  });
}
var BLOCKED = /HTTP (403|429)\)/;
async function wait7(ms) {
  for (let left = ms; left > 0; left -= 5e3) {
    await new Promise((r) => setTimeout(r, Math.min(left, 5e3)));
    await chrome.storage.local.get(KEY5).catch(() => {
    });
  }
}
var running8 = false;
async function runWatch(only) {
  if (running8) return watchState();
  running8 = true;
  let state = await watchState();
  try {
    if (!(await getSettings()).enabled) throw Error("AurOEBay est en pause.");
    const products = await executeLibrary({ action: "list" });
    const ids = only === void 0 ? null : new Set(Array.isArray(only) ? only : [only]);
    const list2 = targets(products).filter((t) => !ids || ids.has(t.product.id));
    const rule = (await chrome.storage.local.get("variantPricing")).variantPricing ?? null;
    state = { ...state, running: true, progress: { done: 0, total: list2.length } };
    if (!only) {
      for (const id of Object.keys(state.results))
        if (!list2.some((t) => t.product.id === id)) delete state.results[id];
    }
    await saveRun(state);
    const refused = [];
    let pause = 1500;
    const check = async (t, retry) => {
      const result = {
        productId: t.product.id,
        name: t.product.name,
        itemId: t.itemId,
        supplierUrl: t.supplierUrl,
        at: Date.now(),
        variants: 0,
        issues: []
      };
      try {
        const response = await fetch(`https://www.ebay.com/itm/${t.itemId}`, {
          credentials: "include",
          signal: AbortSignal.timeout(2e4)
        });
        if (!response.ok) throw Error(`Annonce eBay inaccessible (HTTP ${response.status}).`);
        const live = liveListing(await response.text());
        result.variants = live.rows.length;
        if (live.ended) result.ended = true;
        else {
          const read2 = await readSupplierScan(t.supplierUrl);
          const links = await productLinks(t.product.id);
          result.issues = watchIssues(live, read2.scan, rule && { ...rule, shipping: shippingCharge(read2.shipping) }, links);
          const plan = planListingSync(live.rows, read2.scan, null, { stock: false, prices: false, links });
          await saveListingPrices(t.product.id, plan.map((r) => ({ price: Number(r.price), cost: r.cost })));
          await saveProductShipping(t.product.id, read2.shipping);
          if (urgentIssues(result) && t.others.length) {
            const candidates = [];
            for (const s of t.others) {
              if (!(await getSettings()).enabled) break;
              try {
                const other = await readSupplierScan(s.url);
                candidates.push({
                  supplierId: s.id,
                  url: s.url,
                  title: s.source.title,
                  issues: watchIssues(live, other.scan, rule && { ...rule, shipping: shippingCharge(other.shipping) }),
                  scan: other.scan,
                  at: Date.now()
                });
              } catch {
              }
            }
            const backup = pickBackup(result.issues, candidates);
            if (backup) result.backup = backup;
          }
        }
      } catch (e) {
        const text3 = (e instanceof Error ? e.message : String(e)).slice(0, 200);
        if (!retry && BLOCKED.test(text3)) {
          refused.push(t);
          pause = Math.min(pause * 2, 15e3);
          return false;
        }
        result.error = BLOCKED.test(text3) ? "eBay a limit\xE9 les v\xE9rifications (trop de pages lues d\u2019affil\xE9e). Clique \xAB Rev\xE9rifier les erreurs \xBB dans une heure." : text3;
      }
      state.results[t.product.id] = result;
      return true;
    };
    for (const [index, t] of list2.entries()) {
      if (!(await getSettings()).enabled) break;
      const done = await check(t, false);
      if (done) pause = Math.max(1500, pause - 500);
      state.progress = { done: index + 1, total: list2.length };
      await saveRun(state);
      await showBadge(state);
      await wait7(pause);
    }
    if (refused.length && (await getSettings()).enabled) {
      await wait7(6e4);
      for (const t of refused) {
        if (!(await getSettings()).enabled) break;
        await check(t, true);
        await saveRun(state);
        await showBadge(state);
        await wait7(5e3);
      }
    }
    if (!ids) state.at = Date.now();
    apiTrace("watch", "done", { products: list2.length });
  } finally {
    running8 = false;
    state.running = false;
    delete state.progress;
    await saveRun(state);
    await showBadge(state);
  }
  return state;
}
async function markWatchSent(productId2) {
  const state = await watchState();
  const r = state.results[String(productId2)];
  if (!r) return state;
  r.sent = Date.now();
  await save3(state);
  await showBadge(state);
  return state;
}
async function dismissWatch(productId2, hidden = true) {
  const state = await watchState();
  for (const r of Object.values(state.results))
    if (productId2 === "all" || r.productId === productId2) r.dismissed = hidden;
  await save3(state);
  await showBadge(state);
  return state;
}
function setupWatch() {
  void watchState().then(async (state) => {
    if (state.running && !running8) {
      state.running = false;
      delete state.progress;
      await save3(state);
    }
    await showBadge(state);
  }).catch(() => {
  });
}

// src/background/publishLink.ts
var key3 = (tabId) => `publishPending:v1:${tabId}`;
var WINDOW_MS = 20 * 6e4;
async function rememberPublishClick(tabId, draftId, clues = {}) {
  if (typeof draftId !== "string" || !/^\d{6,20}$/.test(draftId)) return false;
  const pending2 = { draftId, at: Date.now() };
  if (typeof clues.supplierId === "string" && /^\d{6,20}$/.test(clues.supplierId))
    pending2.supplierId = clues.supplierId;
  if (typeof clues.title === "string" && clues.title.trim()) pending2.title = clues.title.trim().slice(0, 200);
  await chrome.storage.session.set({ [key3(tabId)]: pending2 });
  return true;
}
var normTitle2 = (t) => t.toLowerCase().replace(/\s+/g, " ").trim();
function publishedProduct(products, clue) {
  const live = products.filter((p) => !p.archived);
  const byDraft = products.filter(
    (p) => p.ownListings.some((link) => {
      try {
        return libraryLinkIdentity(link.url) === `draft:${clue.draftId}`;
      } catch {
        return false;
      }
    })
  );
  if (byDraft.length === 1) return byDraft[0];
  if (clue.supplierId) {
    const bySku = live.filter(
      (p) => p.suppliers.some((s) => s.id === clue.supplierId || s.source?.id === clue.supplierId)
    );
    if (bySku.length === 1) return bySku[0];
  }
  if (clue.title) {
    const t = normTitle2(clue.title);
    const byTitle = live.filter(
      (p) => [p.name, p.ebayReference?.title ?? "", ...p.ownListings.map((l) => l.title)].some(
        (x) => x && normTitle2(x) === t
      )
    );
    if (byTitle.length === 1) return byTitle[0];
  }
  return null;
}
async function linkPublishedDraft(clue, itemId) {
  const products = await executeLibrary({ action: "list" });
  const product2 = publishedProduct(products, clue);
  if (!product2) return null;
  const title = (clue.title || product2.ownListings.find((l) => l.kind === "draft")?.title || product2.name).slice(0, 200);
  for (const url of [
    `https://www.ebay.com/lstng?draftId=${clue.draftId}&mode=AddItem`,
    `https://www.ebay.com/itm/${itemId}`
  ])
    await executeLibrary({ action: "link-ebay", productId: product2.id, role: "own", url, title });
  await notifyLibraryChanged().catch(() => {
  });
  return { linked: product2.name };
}
async function publishedPage(tabId, itemIds) {
  const pending2 = (await chrome.storage.session.get(key3(tabId)))[key3(tabId)];
  if (!pending2 || Date.now() - pending2.at > WINDOW_MS) return null;
  const ids = Array.isArray(itemIds) ? [...new Set(itemIds.filter((id) => typeof id === "string" && /^\d{9,15}$/.test(id)))] : [];
  if (ids.length !== 1) return null;
  const result = await linkPublishedDraft(pending2, ids[0]);
  await chrome.storage.session.remove(key3(tabId));
  return result;
}
function watchPublishedTabs() {
  chrome.tabs.onUpdated.addListener((tabId, change) => {
    if (!change.url) return;
    let id = null;
    try {
      const u = new URL(change.url);
      if (u.protocol !== "https:" || !/(^|\.)ebay\.com$/.test(u.hostname)) return;
      id = u.pathname.match(/^\/itm\/(?:[^/]+\/)?(\d{9,15})\/?$/)?.[1] ?? u.searchParams.get("itemId") ?? u.searchParams.get("itemid");
      if (u.pathname.startsWith("/lstng")) id = null;
    } catch {
      return;
    }
    if (!id || !/^\d{9,15}$/.test(id)) return;
    void (async () => {
      const pending2 = (await chrome.storage.session.get(key3(tabId)))[key3(tabId)];
      if (!pending2 || Date.now() - pending2.at > 2 * 6e4) return;
      await publishedPage(tabId, [id]);
    })().catch(() => {
    });
  });
}

// src/ebay/variantPhotoInput.ts
function variantPhotoValue(inputId, values) {
  const matches = [...new Set(values)].filter(
    (value) => value.replaceAll(" ", "_") === inputId
  );
  return matches.length === 1 ? matches[0] : null;
}

// src/background/worker.ts
async function updateBusy() {
  if ((await batchState())?.running) return "un lot de brouillons est en cours";
  if (apiImportsRunning()) return "un brouillon eBay est en cours de cr\xE9ation";
  if (scoutRunning()) return "une recherche de produits est en cours";
  return null;
}
async function recordPanelError(step, error) {
  const text3 = `${step} : ${error instanceof Error ? error.message : String(error)}`;
  apiTrace("lecture", "error", { message: text3 });
  await chrome.storage.session.set({ "lastPanelError:v1": { text: text3, at: Date.now() } }).catch(() => {
  });
}
var licenseTouched = Date.now();
var ready = Promise.all([
  chrome.storage.local.setAccessLevel({ accessLevel: "TRUSTED_CONTEXTS" }),
  chrome.storage.session.setAccessLevel({ accessLevel: "TRUSTED_CONTEXTS" })
]);
setupTabPanels();
watchPublishedTabs();
setupWatch();
setApiImportCompletion(saveNativeLibrary);
void ready.then(() => resumeApiImports());
void ready.then(() => resumeBatch(createFromReference, (id) => getNativeJob(id))).catch(() => {
});
chrome.runtime.onInstalled.addListener((details) => {
  void ready.then(() => pruneSellerCache());
  void chrome.storage.local.remove("radar:v1");
  if (details.reason === "update" && versionBelow(details.previousVersion, "0.61.0"))
    void chrome.storage.local.get(LICENSE_KEY).then(async (v) => {
      if (!v[LICENSE_KEY]?.key) await chrome.storage.local.set({ [LICENSE_KEY]: { owner: true } });
    });
  if (details.reason === "update" && details.previousVersion && details.previousVersion !== chrome.runtime.getManifest().version) {
    const now = chrome.runtime.getManifest().version;
    void chrome.storage.local.set({ [WHATS_NEW_KEY]: now }).catch(() => {
    });
    void chrome.storage.local.get(REOPEN_KEY).then(async (v) => {
      if (v[REOPEN_KEY] !== now) return;
      await chrome.storage.local.remove(REOPEN_KEY);
      await chrome.tabs.create({ url: chrome.runtime.getURL("dashboard.html") });
    }).catch(() => {
    });
  }
  if (details.reason === "install") void chrome.tabs.create({ url: chrome.runtime.getURL("welcome.html") }).catch(() => {
  });
  if (details.reason === "update" && versionBelow(details.previousVersion, "0.59.0"))
    void chrome.storage.local.get("settings").then(async ({ settings }) => {
      const saved = settings && typeof settings === "object" ? settings : {};
      if (!("storeName" in saved)) await chrome.storage.local.set({ settings: { ...saved, storeName: "Impression Minute" } });
    });
});
async function claudeBridge(cmd, args, tabId) {
  if (!ownerInstall() || !bridgeOpen((await chrome.storage.local.get(BRIDGE_KEY))[BRIDGE_KEY]))
    throw Error("Assistance Claude d\xE9sactiv\xE9e : Param\xE8tres \u2192 \xAB Activer l\u2019assistance Claude \xBB.");
  if (!BRIDGE_COMMANDS.includes(cmd)) throw Error("Commande refus\xE9e.");
  const a = args && typeof args === "object" ? args : {};
  switch (cmd) {
    case "status":
      return { on: true, tabId, version: chrome.runtime.getManifest().version };
    case "create":
      if (typeof a.aliUrl !== "string") throw Error("aliUrl manquant.");
      return createFromReference(tabId, a.aliUrl);
    case "job":
      return getNativeJob(Number(a.tabId));
    case "trace": {
      const all3 = await chrome.storage.session.get(null);
      return { trace: (all3["apiTrace:v1"] ?? []).slice(-80), lastError: all3["lastPanelError:v1"] ?? null };
    }
    case "batch":
      return startBatch(a.text, createFromReference, (id) => getNativeJob(id));
    case "batchStop":
      return stopBatch();
    case "batchState":
      return batchState();
    case "disputesSync":
      return syncDisputes();
    case "disputes": {
      const store = (await chrome.storage.local.get(DISPUTES_KEY))[DISPUTES_KEY];
      return {
        at: store?.at ?? null,
        errors: store?.errors ?? [],
        items: Object.values(store?.items ?? {}).map((d) => ({
          source: d.source,
          kind: d.kind,
          open: d.open,
          orderId: d.orderId,
          aliOrderId: d.aliOrderId,
          status: d.status,
          reason: d.reason,
          deadline: d.deadline,
          awaitingProof: d.awaitingProof,
          awaitingReturn: d.awaitingReturn,
          held: d.held,
          photos: d.photos
        }))
      };
    }
    case "reload":
      setTimeout(() => chrome.runtime.reload(), 300);
      return true;
  }
}
async function createFromReference(tabId, aliUrl) {
  const started = Date.now();
  await markPanelWork(tabId, "Cr\xE9ation du brouillon : lecture eBay et AliExpress\u2026");
  try {
    const tab = await chrome.tabs.get(tabId);
    const seed = await readEbayPage(tabId, tab.url ?? "", "EBAY_SEED_READ");
    await selectEbaySeed(seed, tabId, tab.url ?? "");
    apiTrace("lecture", "ebay:ok", { ms: Date.now() - started });
    const p = await readSupplierLink(
      aliUrl,
      true,
      true,
      () => markPanelWork(tabId, "AliExpress r\xE9pond lentement : 2e essai de lecture en cours\u2026")
    );
    apiTrace("lecture", "aliexpress:ok", {
      ms: Date.now() - started,
      scanMs: p.variantScan?.durationMs,
      description: p.descriptionStatus,
      variants: p.variantScan?.costs.length
    });
    const stored = (await chrome.storage.session.get("ebaySeed:v1"))["ebaySeed:v1"];
    const choice = {
      sourceUrl: p.url,
      title: stored.title,
      images: (p.images ?? []).filter((i) => i.role === "gallery").slice(0, 12).map((i) => i.url),
      removeMentions: false,
      fullDescription: true,
      ebaySeedId: stored.itemId
    };
    validateNativeChoice(normalizeProduct(p), choice, stored);
    const rule = (await chrome.storage.local.get("variantPricing")).variantPricing;
    const plan = supplierImportPlan(p, rule, { keepOutOfStock: true });
    const job = await startNativeImport(choice);
    await saveNativeLibrary(job).catch(() => {
    });
    apiTrace("lecture", "import:started", { ms: Date.now() - started });
    const profit = await profitModel().then((model) => {
      const ship = shippingCharge(p.shippingDetails);
      return checkPlanProfit(plan.rows, model, ship);
    }).catch(() => null);
    return {
      jobId: job.id,
      tabId: job.tabId,
      profit,
      rows: plan.rows.map((r) => ({ values: r.values, price: r.price, quantity: r.quantity })),
      omitted: plan.omitted,
      sourceId: p.id,
      descriptionImages: p.descriptionImageCount ?? 0
    };
  } catch (error) {
    await recordPanelError("Cr\xE9ation du brouillon", error);
    throw error;
  } finally {
    await markPanelWork(null);
  }
}
async function markPanelWork(tabId, label = "") {
  if (tabId === null) await chrome.storage.session.remove("panelWork:v1").catch(() => {
  });
  else await chrome.storage.session.set({ "panelWork:v1": { tabId, label, at: Date.now() } }).catch(() => {
  });
}
var lockWrite = Promise.resolve();
chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (sender.id !== chrome.runtime.id) return;
  if ((msg?.type === "EBAY_SEED_CAPTURE" || msg?.type === "DRAFT_FROM_SUPPLIER" || msg?.type === "EBAY_LIBRARY_CAPTURE" || msg?.type === "OPEN_PANEL") && sender.tab?.id !== void 0 && sender.frameId === 0 && /^https:\/\/([a-z0-9-]+\.)*(ebay\.com|aliexpress\.(com|us))\//.test(sender.url ?? ""))
    chrome.sidePanel.open({ tabId: sender.tab.id }).catch(() => {
    });
  const run6 = async () => {
    await ready;
    if (Date.now() - licenseTouched > 36e5) {
      licenseTouched = Date.now();
      void refreshLicense().catch(() => {
      });
      void checkUpdate().catch(() => {
      });
    }
    const url = new URL(sender.url ?? "https://invalid.local");
    const isExtension = url.protocol === "chrome-extension:" && url.host === chrome.runtime.id;
    const isEbay = /(^|\.)ebay\.com$/.test(url.hostname) && url.protocol === "https:";
    const isAli = /(^|\.)aliexpress\.(com|us)$/.test(url.hostname) && url.protocol === "https:";
    if (msg?.type === "LICENSE_STATE" && isExtension) return licenseState();
    if (msg?.type === "HEALTH_CHECK" && isExtension) return healthCheck(licenseActive(await licenseState()));
    if (msg?.type === "LICENSE_ACTIVATE" && isExtension) return activateLicense(msg.key);
    if (msg?.type === "LICENSE_REFRESH" && isExtension) return refreshLicense(true);
    if (msg?.type === "LICENSE_RELEASE" && isExtension) return releaseLicense();
    if (!licenseActive(await licenseState()) && !allowedWithoutLicense(msg))
      throw Error("Abonnement AurOEBay inactif : entre ta cl\xE9 de licence (Param\xE8tres \u2192 Abonnement) ou abonne-toi pour r\xE9activer cette fonction.");
    if (msg?.type === "OPEN_PANEL" && (isAli || isEbay)) return true;
    if (msg?.type === "STATUS_NOTE" && (isEbay || isAli) && sender.frameId === 0) return statusNote(isEbay ? "ebay" : "ali", msg);
    if (msg?.type === "PAGE_PREF" && (isEbay || isExtension)) return pagePref(msg.key, msg.value);
    if (msg?.type === "UPDATE_CHECK" && (isExtension || isEbay)) {
      void checkUpdate(false, UPDATE_RECHECK_MS).catch(() => {
      });
      void checkDiskUpdate(updateBusy).catch(() => {
      });
      return true;
    }
    if (msg?.type === "UPDATE_DISK" && isExtension) return checkDiskUpdate(updateBusy);
    if (msg?.type === "UPDATE_RELOAD_NOW" && isExtension) return checkDiskUpdate(updateBusy, true);
    if (msg?.type === "BRIDGE" && isEbay && sender.frameId === 0 && sender.tab?.id !== void 0)
      return claudeBridge(msg.cmd, msg.args, sender.tab.id);
    const ebayOrders = isEbay && /^\/(mesh\/ord|sh\/ord|ship\/tr\/update)/.test(url.pathname);
    if ((msg?.type?.startsWith?.("SALE") || msg?.type?.startsWith?.("ADDRESS_")) && msg?.type !== "SALES_LIST") {
      if (!(await getSettings()).enabled) throw Error("AurOEBay en pause.");
    }
    if (msg?.type === "SALE_SAVE" && (ebayOrders || isExtension))
      return saveSale(msg.sale);
    if (msg?.type === "SALES_STATUS" && (ebayOrders || isAli))
      return salesStatus(msg.ids);
    if (msg?.type === "SALES_LIST" && isExtension) return listSales();
    if (msg?.type === "PROFIT_MODEL" && (isExtension || isEbay || isAli)) return profitModel();
    if (msg?.type === "ALI_PRODUCT_INFO" && isAli && sender.tab?.id !== void 0) return aliProductInfo(sender.tab.id, sender.frameId ?? 0);
    if (msg?.type === "EBAY_PHOTO_CHECK" && isAli) {
      void runPhotoCheck(msg).catch((e) => apiTrace("photoCheck", "error", { message: e instanceof Error ? e.message : String(e) }));
      return delay(300).then(() => photoCheckStatus(msg.productId));
    }
    if (msg?.type === "EBAY_PHOTO_STATUS" && isAli) return photoCheckStatus(msg.productId);
    if (msg?.type === "MARKET_SEARCH" && isExtension)
      return marketSearch({ title: msg.title, itemId: msg.itemId, fresh: msg.fresh === true });
    if (msg?.type === "OPEN_ALI_COOKIES" && (isEbay || isExtension || isAli)) {
      await chrome.tabs.create({ url: ALI_COOKIES_URL });
      return true;
    }
    if (msg?.type === "FIND_SUPPLIERS" && (isEbay || isExtension || isAli))
      return findSuppliers(
        { title: msg.title, image: msg.image, itemId: msg.itemId, photo: msg.photo, fresh: msg.fresh === true },
        // First results shown at once in the eBay page that asked.
        (partial) => {
          if (sender.tab?.id !== void 0)
            void chrome.tabs.sendMessage(sender.tab.id, { type: "FIND_SUPPLIERS_PARTIAL", request: msg.request, data: partial }, { frameId: sender.frameId ?? 0 }).catch(() => {
            });
        },
        // Where the search is (the « 🃏 Joker » shows it).
        (text3, done, total2) => {
          if (sender.tab?.id !== void 0)
            void chrome.tabs.sendMessage(sender.tab.id, { type: "FIND_SUPPLIERS_STEP", request: msg.request, text: text3, done, total: total2 }, { frameId: sender.frameId ?? 0 }).catch(() => {
            });
        }
      );
    if (msg?.type === "COMPETITOR_LIST" && (isExtension || isEbay)) return listCompetitors();
    if (msg?.type === "COMPETITOR_ADD" && (isExtension || isEbay)) return addCompetitor(msg.seller);
    if (msg?.type === "COMPETITOR_ADD_MANY" && isExtension) return addCompetitors(msg.text);
    if (msg?.type === "COMPETITOR_REMOVE" && isExtension) return removeCompetitor(msg.seller);
    if (msg?.type === "COMPETITOR_SEEN" && isEbay) return markSeen(msg.seller, msg.itemIds);
    if (msg?.type === "SCOUT_RUN" && isExtension) {
      void runScout({ query: msg.query, minNonUS: msg.minNonUS, suppliers: msg.suppliers, pages: msg.pages }).catch(
        (e) => apiTrace("scout", "error", { message: e instanceof Error ? e.message : String(e) })
      );
      return true;
    }
    if (msg?.type === "SCOUT_AUTO" && isExtension) {
      void runAutopilot(msg.criteria ?? {}).catch(
        (e) => apiTrace("scout", "error", { message: e instanceof Error ? e.message : String(e) })
      );
      return true;
    }
    if (msg?.type === "SCOUT_STOP" && isExtension) return stopScout();
    if (msg?.type === "SCOUT_SUPPLIERS" && isExtension) {
      void searchScoutSuppliers({ itemIds: msg.itemIds, fresh: msg.fresh }).catch(
        (e) => apiTrace("scout", "error", { message: e instanceof Error ? e.message : String(e) })
      );
      return true;
    }
    if (msg?.type === "SCOUT_PICK" && isExtension) return pickScoutSupplier(msg.itemId, msg.url);
    if (msg?.type === "COMPETITOR_OPEN" && isExtension) {
      const list2 = await listCompetitors();
      if (!list2.length) throw Error("Ajoute d\u2019abord un concurrent.");
      const first2 = encodeURIComponent(list2[0].seller);
      await chrome.tabs.create({
        url: `https://www.ebay.com/sch/i.html?_ssn=${first2}&_sop=10&LH_PrefLoc=99#auroebay-competitors`
      });
      return true;
    }
    if (msg?.type === "EBAY_TRACKINGS_SYNC" && isExtension) return syncEbayTrackings(msg.force === true);
    if (msg?.type === "ALI_TRACKINGS_REFRESH" && (isExtension || ebayOrders)) return refreshAliTrackings();
    if (msg?.type === "DISPUTES_SYNC" && (isExtension || ebayOrders)) return syncDisputes();
    if (msg?.type === "DISPUTES_FOR_ORDER" && (isExtension || ebayOrders)) return orderDisputes(msg.orderId);
    if (msg?.type === "DISPUTE_HELD" && (isExtension || ebayOrders)) return holdReturn(msg.key);
    if (msg?.type === "PARCELS_REFRESH" && isExtension) return refreshParcels(msg.force === true);
    if (msg?.type === "OPEN_EBAY_TRACKING" && isExtension && Array.isArray(msg.orderIds)) {
      const ids = msg.orderIds.filter((x) => typeof x === "string" && /^\d{2}-\d{5}-\d{5}$/.test(x)).slice(0, 30);
      if (!ids.length) throw Error("Aucune commande \xE0 suivre.");
      await chrome.tabs.create({ url: trackingPageURL(ids, "https://www.ebay.com/sh/ord", {}) });
      return ids.length;
    }
    if (msg?.type === "LISTING_SYNC_PREVIEW" && isExtension) {
      if (!(await getSettings()).enabled) throw Error("AurOEBay en pause.");
      return previewListingSync(msg.productId);
    }
    if (msg?.type === "PRICE_TARGET" && isExtension) return setPriceTarget(msg.target, msg.rounding);
    if (msg?.type === "LISTING_SYNC_APPLY" && isExtension)
      return applyListingSync(msg.token, {
        stock: msg.stock,
        prices: msg.prices,
        zeroUnknown: msg.zeroUnknown,
        links: msg.links,
        quantities: msg.quantities,
        typedPrices: msg.typedPrices,
        quiet: msg.quiet,
        lower: msg.lower
      });
    if (msg?.type === "LISTING_SYNC_CANCEL" && isExtension)
      return cancelListingSync(msg.token);
    if (msg?.type === "SALE_UPDATE" && isExtension)
      return updateSale(msg.orderId, msg.patch ?? {});
    if (msg?.type === "SALE_DELETE" && isExtension) return deleteSale(msg.orderId);
    if (msg?.type === "SALES_IMPORT" && isExtension) return importSales(msg.sales);
    if (msg?.type === "SALE_EBAY_TRACKINGS" && ebayOrders) return noteEbayTrackings(msg.rows);
    if (msg?.type === "SALE_EBAY_TRACKING" && ebayOrders)
      return noteEbayTracking(msg.orderId, msg.tracking);
    if (msg?.type === "SALE_CANDIDATES" && isAli) return linkCandidates(msg.receiver, msg.includeLinked === true);
    if (msg?.type === "SALE_SUPPLIER_STATE" && isAli) return supplierState(msg.aliOrderId);
    if (msg?.type === "SALE_UNLINK_SUPPLIER" && isAli) return unlinkSupplier(msg.aliOrderId);
    if (msg?.type === "SALE_LINK_SUPPLIER" && isAli)
      return linkSupplier(msg.orderId, msg.purchase);
    if (msg?.type === "SALE_SHARE_SUPPLIER" && isAli) return shareSupplier(msg.saleIds, msg.purchase);
    if (msg?.type === "SALE_SUPPLIER_ROWS" && isAli) return syncAliOrders(msg.rows);
    if (msg?.type === "ALI_ORDER_INFO" && isAli && sender.tab?.id !== void 0) {
      const ids = Array.isArray(msg.orderIds) ? msg.orderIds.filter((x) => typeof x === "string" && /^\d{8,25}$/.test(x)).slice(0, 30) : [];
      const [r] = await chrome.scripting.executeScript({
        target: { tabId: sender.tab.id, frameIds: [sender.frameId ?? 0] },
        world: "MAIN",
        func: aliOrderInfoInPage,
        args: [ids, !!msg.details]
      });
      return r?.result ?? [];
    }
    if (msg?.type === "ADDRESS_COPY" && ebayOrders)
      return copyAddress(msg.orderId, msg.address);
    if (msg?.type === "ADDRESS_PASTE" && isAli) return pasteAddress();
    if (msg?.type === "OPEN_SALES" && (ebayOrders || isAli || isExtension))
      return chrome.tabs.create({
        url: chrome.runtime.getURL("sales.html") + (typeof msg.orderId === "string" && /^\d{2}-\d{5}-\d{5}$/.test(msg.orderId) ? "?order=" + msg.orderId : "")
      });
    if (msg?.type === "PUBLIC_SETTINGS" && (isAli || isEbay || isExtension))
      return getSettings();
    if (msg?.type === "SOURCE_DESCRIPTION_RESOURCE_READ" && isAli)
      return readSupplierDescriptionResource(
        sender,
        msg.pageURL,
        msg.resourceURL
      );
    if (msg?.type === "READ_EBAY_PAGE" && isExtension && Number.isInteger(msg.tabId) && ["EBAY_LIBRARY_READ", "EBAY_SEED_READ"].includes(msg.read))
      return readEbayPage(msg.tabId, msg.url, msg.read);
    if (msg?.type === "LIBRARY" && isExtension)
      return libraryCommand(msg.command);
    if (msg?.type === "LIBRARY_LINKS" && isEbay && sender.frameId === 0 && sellerHubListingsURL(sender.url ?? "")) {
      if (!(await getSettings()).enabled) return [];
      return listingLibraryLinks(
        msg.urls,
        Array.isArray(msg.hints) ? msg.hints.slice(0, 200) : []
      );
    }
    if (msg?.type === "PAGE_LIBRARY_PRODUCTS" && isEbay && sender.frameId === 0) {
      if (!(await getSettings()).enabled) return [];
      return pageLibraryProducts(sender.url ?? "");
    }
    if (msg?.type === "OPEN_PAGE_PRODUCT" && isEbay && sender.frameId === 0 && typeof msg.productId === "string") {
      if (!(await getSettings()).enabled) throw Error("AurOEBay en pause.");
      if (!(await pageLibraryProducts(sender.url ?? "")).some((p) => p.id === msg.productId))
        throw Error("Cette annonce n\u2019est plus reli\xE9e \xE0 ce produit.");
      return chrome.tabs.create({
        url: chrome.runtime.getURL("dashboard.html") + "?product=" + encodeURIComponent(msg.productId),
        active: msg.active !== false
      });
    }
    if (msg?.type === "OPEN_LIBRARY_PRODUCT" && isEbay && sender.frameId === 0 && sellerHubListingsURL(sender.url ?? "") && typeof msg.productId === "string") {
      if (!(await getSettings()).enabled) throw Error("AurOEBay en pause.");
      const matches = await listingLibraryLinks([msg.listingUrl]);
      if (!matches[0]?.products.some((product2) => product2.id === msg.productId))
        throw Error("Cette annonce n\u2019est plus reli\xE9e \xE0 ce produit.");
      return chrome.tabs.create({
        url: chrome.runtime.getURL("dashboard.html") + "?product=" + encodeURIComponent(msg.productId),
        active: msg.active !== false
      });
    }
    if (msg?.type === "EBAY_LIBRARY_CAPTURE" && isEbay && sender.frameId === 0 && sender.tab?.id !== void 0) {
      if (!(await getSettings()).enabled) throw Error("AurOEBay en pause.");
      const snapshot = validateEbayLibrarySnapshot(msg.snapshot);
      const tab = await chrome.tabs.get(sender.tab.id);
      if (snapshot.url !== canonicalLibraryEbayURL(sender.url).url || snapshot.url !== canonicalLibraryEbayURL(tab.url ?? "").url || Math.abs(Date.now() - snapshot.capturedAt) > 6e4)
        throw Error("La fiche eBay a chang\xE9. Relis-la avant de continuer.");
      await chrome.storage.session.set({
        "ebayLibrarySnapshot:v1": snapshot,
        "ebayPanelIntent:v1": {
          kind: "library",
          tabId: sender.tab.id,
          at: Date.now()
        }
      });
      await chrome.sidePanel.open({ tabId: sender.tab.id }).catch(() => {
      });
      return snapshot;
    }
    if (msg?.type === "LIBRARY_PREPARE_DRAFT" && isExtension && typeof msg.productId === "string" && typeof msg.supplierId === "string")
      return prepareLibraryDraft(msg.productId, msg.supplierId);
    if (msg?.type === "LIBRARY_CREATE_DRAFT" && isExtension && typeof msg.token === "string")
      return createLibraryDraft(msg.token, msg.reviewed === true);
    if (msg?.type === "DRAFT_FROM_SUPPLIER" && isEbay && sender.tab?.id !== void 0 && typeof msg.aliUrl === "string") {
      const itemId = ebayItemId(sender.url ?? "");
      if (!itemId) throw Error("Ouvre l\u2019annonce eBay de r\xE9f\xE9rence.");
      const aliUrl = aliProductURL(msg.aliUrl);
      await chrome.storage.session.set({
        "ebayPushUrl:v1": { itemId, url: aliUrl },
        "ebayPanelIntent:v1": { kind: "draft", tabId: sender.tab.id, at: Date.now() }
      });
      return createFromReference(sender.tab.id, aliUrl);
    }
    if (msg?.type === "EBAY_SEED_CAPTURE" && isEbay && sender.tab?.id !== void 0) {
      const result = await selectEbaySeed(msg.seed, sender.tab.id, sender.url);
      await chrome.storage.session.set({
        "ebayPanelIntent:v1": {
          kind: "draft",
          tabId: sender.tab.id,
          at: Date.now()
        }
      });
      await chrome.sidePanel.open({ tabId: sender.tab.id }).catch(() => {
      });
      return result;
    }
    if (msg?.type === "SELECT_EBAY_SEED" && isExtension && Number.isInteger(msg.tabId)) {
      const tab = await chrome.tabs.get(msg.tabId);
      return selectEbaySeed(msg.seed, msg.tabId, tab.url ?? "");
    }
    if (msg?.type === "READ_SUPPLIER_LINK" && isExtension) {
      const started = Date.now();
      apiTrace("lecture", "aliexpress:start", { url: msg.url });
      try {
        const p = await readSupplierLink(
          msg.url,
          msg.prices !== false,
          msg.background === true
        );
        apiTrace("lecture", "aliexpress:ok", {
          ms: Date.now() - started,
          scanMs: p.variantScan?.durationMs,
          description: p.descriptionStatus,
          variants: p.variantScan?.costs.length
        });
        return p;
      } catch (error) {
        await recordPanelError("Lecture AliExpress", error);
        throw error;
      }
    }
    if (msg?.type === "CREATE_FROM_REFERENCE" && isExtension && Number.isInteger(msg.tabId) && typeof msg.aliUrl === "string")
      return createFromReference(msg.tabId, msg.aliUrl);
    if (msg?.type === "DRAFT_BATCH_START" && isExtension) return startBatch(msg.text, createFromReference, (id) => getNativeJob(id));
    if (msg?.type === "DRAFT_BATCH_STOP" && isExtension) return stopBatch();
    if (msg?.type === "DRAFT_BATCH_STATE" && isExtension) return batchState();
    if (msg?.type === "WATCH_STATE" && isExtension) return watchState();
    if (msg?.type === "WATCH_DISMISS" && isExtension)
      return dismissWatch(msg.productId, msg.hidden !== false);
    if (msg?.type === "WATCH_RUN" && isExtension) {
      const only = typeof msg.productId === "string" ? msg.productId : Array.isArray(msg.productIds) ? msg.productIds.filter((x) => typeof x === "string") : void 0;
      void runWatch(only).catch(() => {
      });
      return true;
    }
    if (msg?.type === "WATCH_SENT" && isExtension) return markWatchSent(msg.productId);
    if (msg?.type === "CREATE_FROM_EBAY_COPY" && isExtension && Number.isInteger(msg.tabId)) {
      await markPanelWork(msg.tabId, "Copie de l\u2019annonce eBay\u2026");
      try {
        return await createFromEbayCopy(msg.tabId);
      } catch (error) {
        await recordPanelError("Copie de l\u2019annonce eBay", error);
        throw error;
      } finally {
        await markPanelWork(null);
      }
    }
    if (msg?.type === "NATIVE_START" && isExtension) {
      try {
        const job = await startNativeImport(msg.choice);
        await saveNativeLibrary(job);
        return job;
      } catch (error) {
        await recordPanelError("Lancement de l\u2019import", error);
        throw error;
      }
    }
    if (msg?.type === "NATIVE_GET" && isExtension && Number.isInteger(msg.tabId))
      return getNativeJob(msg.tabId, true);
    if (msg?.type === "NATIVE_OPEN" && isExtension && Number.isInteger(msg.tabId) && typeof msg.id === "string")
      return openApiImport(msg.tabId, msg.id);
    if (msg?.type === "NATIVE_JOB" && isEbay && sender.tab?.id !== void 0)
      return getNativeJob(sender.tab.id);
    if (msg?.type === "NATIVE_COPY_RECOVER" && isEbay && sender.tab?.id !== void 0 && sender.frameId === 0)
      return recoverNativeCopy(sender.tab.id, msg.id, sender.url);
    if (msg?.type === "NATIVE_UPDATE" && isEbay && sender.tab?.id !== void 0) {
      const job = await updateNativeJob(
        sender.tab.id,
        msg.id,
        sender.url,
        msg.patch
      );
      if (job.stage === "ready") await saveNativeLibrary(job);
      return job;
    }
    if (msg?.type === "NATIVE_IMAGE" && isEbay && sender.tab?.id !== void 0)
      return nativeImage(sender.tab.id, msg.id, msg.url);
    if (msg?.type === "NATIVE_FRAME_REGISTER" && isEbay && sender.tab?.id !== void 0 && sender.frameId) {
      const job = await getNativeJob(sender.tab.id);
      const top = await chrome.tabs.get(sender.tab.id);
      if (!job?.supplierPlan || job.stage !== "filling" || !top.url || draftIdentity(top.url) !== job.identity || !(await getSettings()).enabled)
        throw Error("Formulaire d\u2019import non autoris\xE9.");
      const variants2 = msg.kind === "variants" && url.hostname === "bulkedit.ebay.com" && url.pathname === "/msku" && url.searchParams.get("draftId") === new URL(job.identity).searchParams.get("draftId");
      const photo = msg.kind === "photo" && url.origin === "https://www.ebay.com" && url.pathname === "/lstng/picupload" && url.searchParams.get("windowName") === "photo-iframe-picupload-variations" && url.searchParams.get("allowedUrl") === "https://bulkedit.ebay.com";
      if (!variants2 && !photo) throw Error("Cadre non autoris\xE9.");
      const photoValue = photo && typeof msg.inputId === "string" ? variantPhotoValue(
        msg.inputId,
        job.product.variantImages.map((i) => i.value)
      ) : null;
      if (photo && !photoValue) throw Error("Option de photo non autoris\xE9e.");
      await chrome.storage.session.set({
        [`nativeFrame:${job.id}:${msg.kind}`]: {
          frameId: sender.frameId,
          value: photoValue
        }
      });
      return true;
    }
    if (["NATIVE_VARIANTS", "NATIVE_VARIANT_PHOTO"].includes(msg?.type) && isEbay && sender.tab?.id !== void 0) {
      const job = await getNativeJob(sender.tab.id);
      if (!(await getSettings()).enabled || !job?.supplierPlan || job.id !== msg.id || job.stage !== "filling")
        throw Error("Import fournisseur non autoris\xE9.");
      const top = await chrome.tabs.get(sender.tab.id);
      if (!top.url || draftIdentity(top.url) !== job.identity)
        throw Error("Le brouillon a chang\xE9.");
      if (msg.type === "NATIVE_VARIANTS" && (sender.frameId !== 0 || url.pathname !== "/lstng"))
        throw Error(
          "Seule la page du nouveau brouillon peut ouvrir les variantes."
        );
      if (msg.type === "NATIVE_VARIANTS" && (msg.action !== void 0 && msg.action !== "cancel-for-retry" || msg.clearedAxes !== void 0 && (!Array.isArray(msg.clearedAxes) || msg.clearedAxes.length > 5 || msg.clearedAxes.some(
        (name) => typeof name !== "string" || !job.supplierPlan.axes.some((axis) => axis.name === name)
      ))))
        throw Error("Reprise des axes de variantes non autoris\xE9e.");
      if (msg.type === "NATIVE_VARIANT_PHOTO" && (url.hostname !== "bulkedit.ebay.com" || url.searchParams.get("draftId") !== new URL(job.identity).searchParams.get("draftId") || !job.product.variantImages.some((i) => i.url === msg.url)))
        throw Error("Photo de variante non autoris\xE9e.");
      const frameKey = `nativeFrame:${job.id}:${msg.type === "NATIVE_VARIANTS" ? "variants" : "photo"}`;
      const frame = (await chrome.storage.session.get(frameKey))[frameKey];
      if (!frame?.frameId || msg.type === "NATIVE_VARIANT_PHOTO" && frame.value !== msg.value)
        throw Error("Formulaire pas encore charg\xE9.");
      const response = await chrome.tabs.sendMessage(
        sender.tab.id,
        msg.type === "NATIVE_VARIANTS" ? {
          type: "NATIVE_VARIANTS_RUN",
          id: job.id,
          action: msg.action,
          clearedAxes: msg.clearedAxes ?? []
        } : {
          type: "NATIVE_PHOTO_RUN",
          id: job.id,
          url: msg.url,
          value: msg.value
        },
        { frameId: frame.frameId }
      );
      if (!response?.ok)
        throw Error(response?.error ?? "Formulaire pas encore charg\xE9.");
      return response.data;
    }
    if (msg?.type === "SOURCE_CAPTURE" && isAli) {
      const settings = await getSettings();
      if (!settings.enabled || !settings.captureEnabled) return false;
      const p = msg.product;
      if (!p || p.id !== url.pathname.match(/\/item\/(\d+)\.html/)?.[1] || p.url !== url.origin + url.pathname || typeof p.title !== "string" || JSON.stringify(p).length > 5e5)
        throw Error("Capture AliExpress invalide.");
      if (isSupplierCostReadTab(sender.tab?.id)) return true;
      p.capturedAt = Date.now();
      if (!(await getSettings()).enabled) return true;
      await writeSource(
        p,
        (x) => x.id !== p.id && Date.now() - x.capturedAt < 864e5
      );
      return true;
    }
    if (msg?.type === "OPTIMIZE_LOCK" && isExtension) {
      if (!(await getSettings()).enabled) throw Error("AurOEBay is paused.");
      let lockId = "";
      lockWrite = lockWrite.catch(() => {
      }).then(async () => {
        const { optimizationLocks = {} } = await chrome.storage.session.get(
          "optimizationLocks"
        );
        const key4 = String(msg.tabId);
        if (optimizationLocks[key4]?.until > Date.now())
          throw Error("Une optimisation est d\xE9j\xE0 en cours dans cet onglet.");
        lockId = crypto.randomUUID();
        optimizationLocks[key4] = {
          id: lockId,
          until: Date.now() + Math.min(18e4, Number(msg.timeout) || 9e4) + 1e4
        };
        await chrome.storage.session.set({ optimizationLocks });
      });
      await lockWrite;
      return lockId;
    }
    if (msg?.type === "OPTIMIZE_UNLOCK" && isExtension) {
      lockWrite = lockWrite.catch(() => {
      }).then(async () => {
        const { optimizationLocks = {} } = await chrome.storage.session.get(
          "optimizationLocks"
        );
        for (const [key4, value] of Object.entries(optimizationLocks))
          if (value.id === msg.lockId)
            delete optimizationLocks[key4];
        await chrome.storage.session.set({ optimizationLocks });
      });
      await lockWrite;
      return true;
    }
    if (msg?.type === "LIST_SOURCES" && isExtension) {
      const { sources = [] } = await chrome.storage.session.get("sources");
      return sources.filter(
        (x) => Date.now() - x.capturedAt < 864e5
      );
    }
    if (msg?.type === "CAPTURE_VARIANT_COSTS" && isExtension)
      return readSupplierCosts(msg.url);
    if (msg?.type === "READ_SELECTED_SOURCE" && isExtension) {
      const settings = await getSettings();
      if (!settings.enabled || !settings.captureEnabled)
        throw Error("Active AurOEBay et la capture AliExpress.");
      const target = new URL(msg.url);
      if (target.protocol !== "https:" || !/(^|\.)aliexpress\.(com|us)$/.test(target.hostname) || !/^\/item\/\d+\.html$/.test(target.pathname))
        throw Error("Source invalide");
      const tabs = await chrome.tabs.query({
        url: ["https://*.aliexpress.com/*", "https://*.aliexpress.us/*"]
      });
      const candidates = tabs.filter(
        (t) => t.url && new URL(t.url).origin + new URL(t.url).pathname === target.origin + target.pathname
      );
      if (candidates.length === 0)
        throw Error(
          "Onglet du produit AliExpress ferm\xE9 ou produit non ouvert."
        );
      if (candidates.length !== 1 || !candidates[0].id)
        throw Error("Garde un seul onglet ouvert pour ce produit AliExpress.");
      const response = await chrome.tabs.sendMessage(candidates[0].id, {
        type: "SOURCE_READ",
        url: target.origin + target.pathname
      });
      if (!response?.ok)
        throw Error(response?.error ?? "Lecture AliExpress indisponible");
      const p = response.data;
      if (p?.url !== target.origin + target.pathname || p.id !== target.pathname.match(/\/item\/(\d+)\.html/)?.[1])
        throw Error("La source AliExpress a chang\xE9 pendant la lecture.");
      return p;
    }
    if (msg?.type === "VARIANT_STOCK_PROOF" && isEbay) {
      if (!(await getSettings()).enabled) throw Error("AurOEBay en pause");
      const key4 = "variantCosts:" + String(msg.url);
      const scan = (await chrome.storage.session.get(key4))[key4];
      if (!scan || !Array.isArray(scan.unavailable) || Date.now() - scan.at > 15 * 60 * 1e3)
        throw Error(
          "Relis les co\xFBts et les stocks AliExpress : v\xE9rification absente ou trop ancienne (15 minutes)."
        );
      return scan;
    }
    if (msg?.type === "REFRESH_SOURCES" && isExtension) {
      if (!(await getSettings()).enabled) return false;
      const tabs = await chrome.tabs.query({
        url: ["https://*.aliexpress.com/*", "https://*.aliexpress.us/*"]
      });
      await Promise.allSettled(
        tabs.filter((t) => t.id).map(
          (t) => chrome.tabs.sendMessage(t.id, { type: "SOURCE_REFRESH" })
        )
      );
      return true;
    }
    if (msg?.type === "ORDER_SUPPLIERS" && isEbay && sender.frameId === 0 && /^\/mesh\/ord\/details/.test(url.pathname)) {
      if (!(await getSettings()).enabled) return [];
      return orderSuppliers(msg.items);
    }
    if (msg?.type === "LISTING_PUBLISH_CLICK" && isEbay && sender.tab?.id !== void 0 && sender.frameId === 0) {
      if (!(await getSettings()).enabled) return false;
      return rememberPublishClick(sender.tab.id, msg.draftId, {
        supplierId: msg.supplierId,
        title: msg.title
      });
    }
    if (msg?.type === "LISTING_PUBLISHED" && isEbay && sender.tab?.id !== void 0 && sender.frameId === 0) {
      if (!(await getSettings()).enabled) return null;
      return publishedPage(sender.tab.id, msg.itemIds);
    }
    if (msg?.type === "SELLER_LOOKUP" && isEbay && sender.tab?.id !== void 0) {
      const s = await getSettings();
      if (!s.enabled || !s.sellerEnabled)
        throw Error("Seller detector disabled");
      if (msg.cacheOnly === true) return cachedSeller(msg.username, s.sellerTtlDays);
      return resolveSeller(
        msg.username ?? null,
        s.sellerTtlDays,
        msg.storePath ?? null,
        async () => {
          const response = await chrome.tabs.sendMessage(
            sender.tab.id,
            {
              type: "SELLER_FETCH",
              username: msg.username ?? null,
              storePath: msg.storePath ?? null
            },
            { frameId: sender.frameId ?? 0 }
          );
          if (!response.ok) throw Error(response.error);
          return response.data;
        },
        msg.force === true
      );
    }
    throw Error("Message non autoris\xE9.");
  };
  run6().then((data) => reply({ ok: true, data })).catch(
    (e) => reply({
      ok: false,
      error: e instanceof Error ? e.message : "Operation failed"
    })
  );
  return true;
});
async function syncPower() {
  const s = await getSettings();
  if (s.enabled) {
    await showBadge(await watchState());
  } else {
    await chrome.action.setBadgeText({ text: "OFF" });
    await chrome.action.setBadgeBackgroundColor({ color: "#64748b" });
  }
  await chrome.action.setTitle({
    title: s.enabled ? "Ouvrir AurOEBay" : "AurOEBay en pause \u2014 cliquer pour r\xE9activer"
  });
  const tabs = await chrome.tabs.query({
    url: [
      "https://*.ebay.com/*",
      "https://*.aliexpress.com/*",
      "https://*.aliexpress.us/*"
    ]
  });
  await Promise.allSettled(
    tabs.filter((t) => t.id).map((t) => chrome.tabs.sendMessage(t.id, { type: "SETTINGS_CHANGED" }))
  );
}
void recoverScout().catch(() => {
});
void closeOwnTab().catch(() => {
});
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && (changes.extensionEnabled || changes.settings || changes[LICENSE_KEY]))
    void syncPower();
  if (area === "local" && changes[LICENSE_KEY]) void checkLicenseSeal().catch(() => {
  });
  if (area === "local" && changes[LICENSE_KEY] && !licenseActive(changes[LICENSE_KEY].newValue))
    stopScout();
  if (area === "local" && (changes["sales:v1"] || changes["profitSettings:v1"] || changes["taxRates:v1"])) {
    clearTimeout(targetTimer);
    targetTimer = setTimeout(() => void refreshPriceTarget().catch(() => {
    }), 3e3);
  }
});
var targetTimer;
void ready.then(() => refreshPriceTarget()).catch(() => {
});
void ready.then(() => checkLicenseSeal()).then(() => refreshLicense()).catch(() => {
});
void ready.then(() => checkUpdate()).catch(() => {
});
setupUpdateNotifications();
setupDiskWatch(updateBusy);
void ready.then(syncPower);
