"use strict";
(() => {
  // src/core/messaging.ts
  async function message(body2) {
    const reply = await chrome.runtime.sendMessage(body2);
    if (!reply?.ok)
      throw Error(reply?.error ?? "AurOEBay ne r\xE9pond pas. Recharge la page.");
    return reply.data;
  }

  // src/core/text.ts
  var compact = (s) => s.replace(/\s+/g, " ").trim();
  var norm = (s) => compact(s.normalize("NFKC")).toLowerCase().replace(/[\s\W_]+/g, " ").trim();
  var escapeHTML = (s) => s.replace(
    /[&<>"']/g,
    (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]
  );
  function redact(s) {
    return s.replace(/\bsk-[A-Za-z0-9_-]+/g, "[REDACTED_KEY]").replace(/Bearer\s+\S+/gi, "Bearer [REDACTED]").replace(/[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}/g, "[EMAIL]").replace(/https?:\/\/[^\s<>"']+/g, "[URL]");
  }

  // src/background/draftBatch.ts
  var BATCH_KEY = "draftBatch:v1";
  var MAX_ITEMS = 60;
  function parseBatchLines(text) {
    const items = [];
    const refused = [];
    const seen = /* @__PURE__ */ new Set();
    for (const raw of String(text ?? "").split(/\r?\n/)) {
      const line = raw.trim();
      if (!line) continue;
      const ebayId = line.match(/ebay\.[a-z.]+\/itm\/(?:[^/\s]*\/)?(\d{9,15})/i)?.[1];
      const aliId2 = line.match(/aliexpress\.[a-z.]+\/item\/(\d{6,25})\.html/i)?.[1];
      if (!ebayId || !aliId2) {
        refused.push(line.slice(0, 120));
        continue;
      }
      if (seen.has(aliId2)) continue;
      seen.add(aliId2);
      items.push({ ebayId, aliId: aliId2, state: "pending" });
    }
    return { items: items.slice(0, MAX_ITEMS), refused };
  }
  var draftUrl = (id) => `https://www.ebay.com/lstng?draftId=${encodeURIComponent(id)}&mode=AddItem`;

  // src/ui/draftBatchView.ts
  var STATE_LABEL = { pending: "en attente", running: "en cours\u2026", done: "\u2713 brouillon cr\xE9\xE9", error: "\u26A0 \xE9chec", skipped: "non fait (arr\xEAt\xE9)" };
  function setupDraftBatch(button) {
    const dialog = document.createElement("dialog");
    dialog.id = "batch-dialog";
    dialog.className = "batch-dialog";
    dialog.innerHTML = `
    <form method="dialog">
      <h2>\u{1F4E6} Brouillons en lot</h2>
      <p class="muted">Une ligne par produit : le lien de l\u2019annonce eBay d\u2019exemple et le lien du produit AliExpress. AurOEBay cr\xE9e les brouillons <b>un par un</b>, comme \xAB Cr\xE9er le brouillon eBay \xBB, avec ta r\xE8gle de prix. <b>Rien n\u2019est publi\xE9</b> : tu relis et tu publies toi-m\xEAme.</p>
      <p class="batch-rule muted" id="batch-rule"></p>
      <textarea id="batch-text" rows="8" spellcheck="false" placeholder="https://www.ebay.com/itm/236687798729  https://www.aliexpress.us/item/3256807652854766.html"></textarea>
      <p class="muted small" id="batch-count"></p>
      <div class="batch-actions">
        <button type="button" class="btn primary" id="batch-start">Lancer la cr\xE9ation</button>
        <button type="button" class="btn" id="batch-stop" hidden>Arr\xEAter apr\xE8s le produit en cours</button>
        <button type="submit" class="btn ghost" value="close">Fermer</button>
      </div>
      <p class="err small" id="batch-error" hidden></p>
      <div id="batch-list" class="batch-list"></div>
    </form>`;
    document.body.append(dialog);
    const $2 = (id) => dialog.querySelector("#" + id);
    const text = $2("batch-text");
    const count = () => {
      const { items, refused } = parseBatchLines(text.value);
      $2("batch-count").textContent = text.value.trim() ? `${items.length} produit(s) lisible(s)${refused.length ? ` \xB7 ${refused.length} ligne(s) ignor\xE9e(s)` : ""} \xB7 environ ${Math.max(1, Math.round(items.length * 1.5))} min` : "";
    };
    text.addEventListener("input", count);
    const render2 = (b) => {
      const running2 = !!b?.running;
      $2("batch-start").hidden = running2;
      $2("batch-stop").hidden = !running2;
      $2("batch-stop").disabled = !!b?.stopRequested;
      text.disabled = running2;
      const list2 = $2("batch-list");
      if (!b?.items.length) return void (list2.innerHTML = "");
      const done = b.items.filter((i) => i.state === "done").length;
      const errors = b.items.filter((i) => i.state === "error").length;
      list2.innerHTML = `
      <p><b>${done}/${b.items.length} brouillon(s) cr\xE9\xE9(s)</b>${errors ? ` \xB7 ${errors} \xE9chec(s)` : ""}${running2 ? b.stopRequested ? " \xB7 arr\xEAt apr\xE8s le produit en cours" : " \xB7 en cours, tu peux fermer cette fen\xEAtre" : " \xB7 termin\xE9"}</p>
      <ol>${b.items.map(
        (i) => `<li class="${i.state}"><span>${STATE_LABEL[i.state]}</span>
            <a href="https://www.ebay.com/itm/${escapeHTML(i.ebayId)}" target="_blank" rel="noopener">eBay ${escapeHTML(i.ebayId)}</a>
            \xB7 <a href="https://www.aliexpress.us/item/${escapeHTML(i.aliId)}.html" target="_blank" rel="noopener">AliExpress</a>
            ${i.draftId ? ` \xB7 <a href="${escapeHTML(draftUrl(i.draftId))}" target="_blank" rel="noopener"><b>Ouvrir le brouillon \u2197</b></a>` : ""}
            ${i.error ? `<div class="small err">${escapeHTML(i.error)}</div>` : ""}</li>`
      ).join("")}</ol>`;
    };
    const load2 = async () => {
      const rule2 = (await chrome.storage.local.get("variantPricing")).variantPricing;
      $2("batch-rule").textContent = rule2?.coefficient ? `R\xE8gle de prix : co\xFBt \xD7 ${rule2.coefficient} + ${rule2.fixed ?? 0} $, arrondi ${rule2.rounding ?? ""} (celle de ton dernier brouillon).` : "\u26A0 Aucune r\xE8gle de prix : cr\xE9e d\u2019abord un brouillon depuis une annonce eBay, elle sera reprise ici.";
      render2((await chrome.storage.local.get(BATCH_KEY))[BATCH_KEY] ?? null);
    };
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "local" && changes[BATCH_KEY]) render2(changes[BATCH_KEY].newValue ?? null);
    });
    const fail = (e) => {
      const box = $2("batch-error");
      box.hidden = false;
      box.textContent = e instanceof Error ? e.message : String(e);
    };
    $2("batch-start").addEventListener("click", async () => {
      $2("batch-error").hidden = true;
      const { items } = parseBatchLines(text.value);
      if (!items.length) return fail("Colle d\u2019abord les liens (un lien eBay et un lien AliExpress par ligne).");
      if (!confirm(`Cr\xE9er ${items.length} brouillon(s) eBay ? Ils ne seront pas publi\xE9s.`)) return;
      try {
        await message({ type: "DRAFT_BATCH_START", text: text.value });
      } catch (e) {
        fail(e);
      }
    });
    $2("batch-stop").addEventListener("click", () => void message({ type: "DRAFT_BATCH_STOP" }).catch(fail));
    button.addEventListener("click", () => {
      void load2();
      dialog.showModal();
    });
  }

  // src/core/shippingText.ts
  var PRICE = String.raw`(?:US\s*)?\$\s*(\d+(?:\.\d{1,2})?)`;
  var NAMED = new RegExp(String.raw`(?:standard|shipping|delivery|livraison)[^$·\d]{0,20}?${PRICE}`, "gi");
  var LABEL = new RegExp(String.raw`\b[A-Za-z][A-Za-z' -]{1,30}:\s*${PRICE}`, "g");
  var NOT_A_FEE = /over|orders|min|save|off\b|coupon|discount|code|price|extra/i;
  function paidShipping(text) {
    if (!text) return null;
    const hit = [...text.matchAll(NAMED), ...text.matchAll(LABEL)].find((m) => !NOT_A_FEE.test(m[0]));
    const cost = hit ? Number(hit[1]) : 0;
    return cost > 0 && cost < 200 ? cost : null;
  }

  // src/ebay/prices.ts
  var USUAL_SHIPPING = { cost: 1.99, freeOver: 10, usual: true };
  function shippingCharge(d) {
    const threshold = d?.freeShippingThreshold && d.freeShippingThreshold > 0 ? d.freeShippingThreshold : null;
    if (d && d.cost !== null && d.cost > 0 && (d.currency === null || d.currency === "USD"))
      return { cost: d.cost, freeOver: threshold };
    const written = d && d.cost === null ? paidShipping(d.evidence) : null;
    if (written !== null) return { cost: written, freeOver: threshold };
    return threshold ? { ...USUAL_SHIPPING, freeOver: threshold } : USUAL_SHIPPING;
  }
  function ruledPrice(cost, rule2) {
    const ship = typeof rule2.target === "number" ? shippingFor(cost, rule2.shipping) : 0;
    return sellingPrice(cost + ship, rule2.coefficient, rule2.fixed, rule2.rounding);
  }
  var shippingFor = (cost, s) => s && !(s.freeOver !== null && cost >= s.freeOver) ? s.cost : 0;
  function sellingPrice(cost, coefficient, fixed, rounding = "none") {
    if (![cost, coefficient, fixed].every(Number.isFinite) || cost <= 0 || coefficient <= 0 || fixed < 0)
      return null;
    let cents = Math.round((cost * coefficient + fixed + Number.EPSILON) * 100);
    if (!Number.isSafeInteger(cents) || cents <= 0) return null;
    const ending = (n) => Math.ceil((cents - n) / 100) * 100 + n;
    if (rounding === "49") cents = ending(49);
    else if (rounding === "99") cents = ending(99);
    else if (rounding === "49-or-99") cents = Math.min(ending(49), ending(99));
    else if (rounding !== "none") return null;
    return cents > 0 && cents <= 1e8 ? (cents / 100).toFixed(2) : null;
  }

  // src/core/country.ts
  var codes = "AD AE AF AG AI AL AM AO AQ AR AS AT AU AW AX AZ BA BB BD BE BF BG BH BI BJ BL BM BN BO BQ BR BS BT BV BW BY BZ CA CC CD CF CG CH CI CK CL CM CN CO CR CU CV CW CX CY CZ DE DJ DK DM DO DZ EC EE EG EH ER ES ET FI FJ FK FM FO FR GA GB GD GE GF GG GH GI GL GM GN GP GQ GR GS GT GU GW GY HK HM HN HR HT HU ID IE IL IM IN IO IQ IR IS IT JE JM JO JP KE KG KH KI KM KN KP KR KW KY KZ LA LB LC LI LK LR LS LT LU LV LY MA MC MD ME MF MG MH MK ML MM MN MO MP MQ MR MS MT MU MV MW MX MY MZ NA NC NE NF NG NI NL NO NP NR NU NZ OM PA PE PF PG PH PK PL PM PN PR PS PT PW PY QA RE RO RS RU RW SA SB SC SD SE SG SH SI SJ SK SL SM SN SO SR SS ST SV SX SY SZ TC TD TF TG TH TJ TK TL TM TN TO TR TT TV TW TZ UA UG UM US UY UZ VA VC VE VG VI VN VU WF WS YE YT ZA ZM ZW".split(
    " "
  );
  var names = new Intl.DisplayNames(["en"], { type: "region" });
  var map = /* @__PURE__ */ new Map();
  for (const code of codes) {
    const name = names.of(code);
    map.set(norm(code), name);
    map.set(norm(name), name);
  }
  for (const [alias, name] of Object.entries({
    "mainland china": "China",
    "cn origin": "China",
    "china mainland": "China",
    "china origin": "China",
    prc: "China",
    "people s republic of china": "China",
    usa: "United States",
    "u s a": "United States",
    "united states of america": "United States",
    uk: "United Kingdom",
    "great britain": "United Kingdom",
    "south korea": "South Korea",
    "republic of korea": "South Korea",
    taiwan: "Taiwan",
    vietnam: "Vietnam",
    turkey: "T\xFCrkiye"
  }))
    map.set(norm(alias), name);

  // src/aliexpress/images.ts
  function supplierImageURL(value) {
    try {
      const u = new URL(value.startsWith("//") ? "https:" + value : value);
      if (u.protocol !== "https:" || u.username || u.password || u.port || !/(^|\.)(alicdn\.com|aliexpress-media\.com)$/.test(u.hostname))
        return null;
      u.pathname = u.pathname.replace(
        /\.(jpg|jpeg|png|webp)(?:_\d+x\d+[^/]*)?(?:_\.avif)?$/i,
        ".$1"
      );
      u.hash = "";
      for (const key of [...u.searchParams.keys()]) {
        if (!["has_lang", "ver"].includes(key)) u.searchParams.delete(key);
        else
          u.searchParams.set(
            key,
            u.searchParams.get(key).replace(/_\d+x\d+.*$/, "")
          );
      }
      if (!/\.(jpe?g|png|webp)$/i.test(u.pathname)) return null;
      return u.href;
    } catch {
      return null;
    }
  }

  // src/ebay/savedDraft.ts
  var SCAN_LIMIT = 3 * 1024 * 1024;

  // src/ebay/draftApi.ts
  var HTML_LIMIT = 8 * 1024 * 1024;

  // src/core/profit.ts
  var EBAY_PERCENT = (0.136 + 0.0165) * 1.07;
  var round = (n) => Math.round(n * 100) / 100;
  function estimateProfit(priceUSD, costUSD, m, shipping = USUAL_SHIPPING) {
    const revenue = priceUSD * m.rate;
    const fees = revenue * m.feeRate + (m.feeFixed ?? 0) * m.rate;
    const supplier = (costUSD + shippingFor(costUSD, shipping)) * (1 + m.aliExtra) * m.rate;
    const charges = revenue * m.charges;
    return {
      revenue: round(revenue),
      fees: round(fees),
      supplier: round(supplier),
      charges: round(charges),
      net: round(revenue - fees - supplier - charges)
    };
  }
  function minimumPrice(costUSD, m, target = 0, shipping = USUAL_SHIPPING) {
    const keep = 1 - m.feeRate - m.charges;
    if (keep <= 0 || m.rate <= 0) return null;
    const exact = ((costUSD + shippingFor(costUSD, shipping)) * (1 + m.aliExtra) * m.rate + (m.feeFixed ?? 0) * m.rate + target) / (m.rate * keep);
    const whole = Math.floor(exact);
    for (const candidate of [whole + 0.49, whole + 0.99, whole + 1.49])
      if (candidate >= exact - 1e-9) return round(candidate);
    return round(whole + 1.99);
  }

  // src/core/supplierSearch.ts
  var STOP = new Set(
    "a an and the for with of to in on by from at as or is new hot sale free shipping fast usa us uk lot pcs pc set piece pieces 1pc 1pcs 2pcs women men womens mens unisex".split(
      " "
    )
  );
  function searchKeywords(title, max = 7) {
    const words2 = title.toLowerCase().replace(/[^a-z0-9\s-]/g, " ").split(/\s+/).filter((w) => w.length > 1 && !STOP.has(w) && !/^\d+$/.test(w));
    return [...new Set(words2)].slice(0, max);
  }
  function titleSimilarity(ebayTitle, supplierTitle) {
    const x = new Set(searchKeywords(ebayTitle, 40));
    const y = new Set(searchKeywords(supplierTitle, 40));
    if (!x.size || !y.size) return 0;
    let common = 0;
    for (const w of x) if (y.has(w)) common++;
    return common / x.size;
  }

  // src/core/priceStanding.ts
  function closestListings(cards, mine, max = 12) {
    const myShop = mine.seller ?? cards.find((c) => mine.itemId && c.itemId === mine.itemId)?.seller ?? null;
    const seen = /* @__PURE__ */ new Set();
    return cards.filter((c) => c.itemId !== mine.itemId && (!myShop || c.seller !== myShop) && c.price > 0).filter((c) => !seen.has(c.itemId) && seen.add(c.itemId)).map((c) => ({
      ...c,
      total: Math.round((c.price + (c.shipping ?? 0)) * 100) / 100,
      similarity: titleSimilarity(mine.title, c.title),
      url: `https://www.ebay.com/itm/${c.itemId}`
    })).filter((c) => c.similarity >= 0.5).sort((a, b) => b.similarity - a.similarity).slice(0, max).sort((a, b) => a.total - b.total);
  }
  function standing(myPrice, listings) {
    const totals = listings.map((l) => l.total).sort((a, b) => a - b);
    if (!totals.length) return { count: 0, min: null, median: null, max: null, rank: null };
    return {
      count: totals.length,
      min: totals[0],
      median: totals[Math.floor(totals.length / 2)],
      max: totals[totals.length - 1],
      rank: myPrice === null ? null : totals.filter((t) => t < myPrice).length + 1
    };
  }
  function justBelow(total) {
    const whole = Math.floor(total);
    for (const p of [whole + 0.99, whole + 0.49, whole - 0.01, whole - 0.51])
      if (p < total - 4e-3 && p > 0) return Math.round(p * 100) / 100;
    return Math.max(0.49, Math.round((total - 0.5) * 100) / 100);
  }
  function advisePrice(costUSD, model, listings, margin = 1, shipping) {
    const s = standing(null, listings);
    if (!costUSD || !model) return { floor: null, suggested: null, reason: "no-cost", netAtSuggested: null };
    const floor = minimumPrice(costUSD, model, margin, shipping);
    if (s.min === null) return { floor, suggested: floor, reason: "no-market", netAtSuggested: floor ? estimateProfit(floor, costUSD, model, shipping).net : null };
    const under = justBelow(s.min);
    if (floor !== null && under >= floor)
      return { floor, suggested: under, reason: "below-cheapest", netAtSuggested: estimateProfit(under, costUSD, model, shipping).net };
    if (floor !== null && s.median !== null && floor <= s.median)
      return { floor, suggested: floor, reason: "floor", netAtSuggested: estimateProfit(floor, costUSD, model, shipping).net };
    return { floor, suggested: floor, reason: "cannot-compete", netAtSuggested: floor ? estimateProfit(floor, costUSD, model, shipping).net : null };
  }

  // src/core/revive.ts
  var usd = (n) => `${n.toFixed(2)} $`;
  function roundDown(n) {
    const whole = Math.floor(n);
    for (const p of [whole + 0.99, whole + 0.49, whole - 0.01]) if (p <= n + 1e-9 && p > 0) return Math.round(p * 100) / 100;
    return Math.round(n * 100) / 100;
  }
  function revivePlan(input) {
    const { myPrice, costUSD, model, listings, shipping } = input;
    const s = standing(myPrice, listings);
    const advice = advisePrice(costUSD, model, listings, 1, shipping);
    const floor = costUSD && model ? minimumPrice(costUSD, model, 1, shipping) : null;
    const steps2 = [];
    const net = (p) => costUSD && model ? estimateProfit(p, costUSD, model, shipping).net : null;
    const netText = (p) => {
      const n = net(p);
      return n === null || !model ? "" : `, il te reste ${n.toLocaleString("fr-FR", { style: "currency", currency: model.currency })} net par vente`;
    };
    if (myPrice !== null && floor !== null) {
      let target = null;
      let why = "";
      if (advice.reason === "below-cheapest" && advice.suggested !== null && advice.suggested < myPrice - 4e-3) {
        target = advice.suggested;
        why = `juste sous le moins cher (${usd(s.min)})`;
      } else if (myPrice > floor + 4e-3) {
        target = Math.max(floor, roundDown(myPrice * 0.92));
        why = target === floor ? "ton prix minimum rentable" : "une baisse de 8 %";
      }
      if (target !== null && target < myPrice - 4e-3)
        steps2.push({ kind: "price", price: target, text: `Baisse le prix de ${usd(myPrice)} \xE0 ${usd(target)} (${why})${netText(target)}.` });
      else
        steps2.push({ kind: "price", text: `Ton prix (${usd(myPrice)}) est d\xE9j\xE0 au minimum rentable (${usd(floor)}) : ne baisse pas plus.` });
    } else if (myPrice !== null && !costUSD)
      steps2.push({ kind: "price", text: "Co\xFBt AliExpress inconnu : relis le fournisseur pour savoir jusqu\u2019o\xF9 baisser sans perdre d\u2019argent." });
    if (floor !== null && s.min !== null && s.min < floor - 4e-3)
      steps2.push({
        kind: "supplier",
        text: input.suppliers > 1 ? `Le moins cher est \xE0 ${usd(s.min)}, sous ton minimum (${usd(floor)}) : essaie ton autre fournisseur (\xAB Fournisseurs \xBB).` : `Le moins cher est \xE0 ${usd(s.min)}, sous ton minimum (${usd(floor)}) : cherche un fournisseur moins cher (\xAB \u{1F50D} Trouver le fournisseur \xBB sur l\u2019annonce).`
      });
    steps2.push({ kind: "title", text: "Am\xE9liore le titre : mets en premier les mots que les acheteurs tapent (marque, mod\xE8le, taille), jusqu\u2019\xE0 80 caract\xE8res. Le panneau AurOEBay propose un titre avec l\u2019IA." });
    if (input.days >= 120)
      steps2.push({ kind: "end", text: `${input.everSold ? "Aucune vente" : "Jamais vendue"} depuis ${input.days} jours : si une baisse ne change rien d\u2019ici 2 semaines, arr\xEAte l\u2019annonce sur eBay et archive le produit.` });
    return { myPrice, floor, steps: steps2 };
  }

  // src/core/brandRisk.ts
  var DANGER = [
    // Characters and licences
    "Disney",
    "Pixar",
    "Marvel",
    "Avengers",
    "Spider-Man",
    "Spiderman",
    "Batman",
    "Superman",
    "Deadpool",
    "Iron Man",
    "Captain America",
    "DC Comics",
    "Star Wars",
    "Baby Yoda",
    "Grogu",
    "Mandalorian",
    "Harry Potter",
    "Hogwarts",
    "Mickey Mouse",
    "Minnie Mouse",
    "Lilo and Stitch",
    "Lilo & Stitch",
    "Toy Story",
    "Winnie the Pooh",
    "Pokemon",
    "Pikachu",
    "Super Mario",
    "Mario Kart",
    "Zelda",
    "Sonic the Hedgehog",
    "Minecraft",
    "Fortnite",
    "Roblox",
    "Among Us",
    "Squid Game",
    "Hello Kitty",
    "Sanrio",
    "Kuromi",
    "Cinnamoroll",
    "My Melody",
    "Labubu",
    "Pop Mart",
    "Squishmallow",
    "Squishmallows",
    "Bluey",
    "Paw Patrol",
    "Peppa Pig",
    "Cocomelon",
    "Minions",
    "Barbie",
    "Hot Wheels",
    "LEGO",
    "Nerf",
    "Fisher-Price",
    "Naruto",
    "Dragon Ball",
    "Demon Slayer",
    "Jujutsu Kaisen",
    "My Hero Academia",
    "Sailor Moon",
    "Studio Ghibli",
    "Totoro",
    "Looney Tunes",
    "Snoopy",
    "Sesame Street",
    "Taylor Swift",
    "NFL",
    "NBA",
    "MLB",
    "NHL",
    "NCAA",
    "Harley-Davidson",
    "John Deere",
    "Coca-Cola",
    "Starbucks",
    // Fashion, luxury, sport
    "Nike",
    "Adidas",
    "Puma",
    "Reebok",
    "Under Armour",
    "New Balance",
    "Air Jordan",
    "Converse",
    "The North Face",
    "Patagonia",
    "Lululemon",
    "Gucci",
    "Louis Vuitton",
    "Chanel",
    "Dior",
    "Hermes",
    "Prada",
    "Versace",
    "Burberry",
    "Balenciaga",
    "Fendi",
    "Givenchy",
    "Yves Saint Laurent",
    "YSL",
    "Michael Kors",
    "Kate Spade",
    "Tory Burch",
    "Ralph Lauren",
    "Tommy Hilfiger",
    "Calvin Klein",
    "Rolex",
    "Cartier",
    "Tag Heuer",
    "Pandora",
    "Swarovski",
    "Ray-Ban",
    "Rayban",
    "Oakley",
    "Crocs",
    "Jibbitz",
    "UGG",
    "Birkenstock",
    "Dr Martens",
    "Timberland",
    // Copied household products
    "Stanley",
    "Yeti",
    "Hydro Flask",
    "Owala",
    "OtterBox",
    "PopSocket",
    "PopSockets",
    "Dyson",
    // Added 11/2026 (user's request « des mots / marques à bannir »)
    // Toys, collectibles, kids' licences
    "NeeDoh",
    "Nee Doh",
    "Schylling",
    "Jellycat",
    "Sonny Angel",
    "Smiski",
    "Funko",
    "Beanie Babies",
    "Ty Beanie",
    "Ms Rachel",
    "Blippi",
    "Gabby's Dollhouse",
    "Gabbys Dollhouse",
    "PJ Masks",
    "Thomas the Tank Engine",
    "SpongeBob",
    "Garfield",
    "Pusheen",
    "Care Bears",
    "My Little Pony",
    "Transformers",
    "Hasbro",
    "Mattel",
    "Play-Doh",
    "Magna-Tiles",
    "Tamagotchi",
    "Bandai",
    "Yu-Gi-Oh",
    "Magic the Gathering",
    "Bratz",
    "LOL Surprise",
    "Polly Pocket",
    "Tonka",
    "Crayola",
    "Hatchimals",
    "Kirby",
    "Animal Crossing",
    "Splatoon",
    "Call of Duty",
    "Pac-Man",
    "Tetris",
    "Rubik's",
    "Rubiks",
    "Pochacco",
    "Pompompurin",
    "Keroppi",
    "Badtz-Maru",
    "Chainsaw Man",
    "Attack on Titan",
    "Hunter x Hunter",
    "Tokyo Ghoul",
    "Spy x Family",
    "Stranger Things",
    "Moana",
    "Encanto",
    "Frozen Elsa",
    "Bluey Bingo",
    "Grinch",
    "Dr Seuss",
    "Elf on the Shelf",
    "Charlie Brown",
    "Jack Skellington",
    "Nightmare Before Christmas",
    "Hocus Pocus",
    "Beetlejuice",
    "Freddy Krueger",
    "Michael Myers",
    "Chucky",
    "Ghostface",
    "Lord of the Rings",
    "Game of Thrones",
    "Wednesday Addams",
    // Fashion, beauty, luxury
    "Vans Old Skool",
    "Skechers",
    "Hoka",
    "Asics",
    "Fila",
    "Carhartt",
    "Levi's",
    "Levis",
    "Wrangler Jeans",
    "Off-White",
    "Bape",
    "Stussy",
    "Fear of God",
    "Moncler",
    "Canada Goose",
    "Arc'teryx",
    "Arcteryx",
    "Longchamp",
    "Goyard",
    "Celine",
    "Bottega Veneta",
    "Valentino",
    "Miu Miu",
    "Loewe",
    "Van Cleef",
    "Bvlgari",
    "Bulgari",
    "Chrome Hearts",
    "Casio",
    "G-Shock",
    "Seiko",
    "Alo Yoga",
    "Gymshark",
    "Skims",
    "Victoria's Secret",
    "Bath and Body Works",
    "Sol de Janeiro",
    "Olaplex",
    "Beautyblender",
    "Fenty",
    "Rare Beauty",
    "Charlotte Tilbury",
    "Revlon",
    "Gillette",
    "Oral-B",
    "Sonicare",
    // Tech and home brands often copied
    "Anker",
    "Beats by Dre",
    "Beats Studio",
    "Beats Solo",
    "Beats Fit Pro",
    "Skullcandy",
    "Logitech",
    "Razer",
    "Corsair",
    "SteelSeries",
    "HyperX",
    "Roomba",
    "iRobot",
    "Vitamix",
    "Le Creuset",
    "Pyrex",
    "Tupperware",
    "Bissell",
    "Contigo",
    "Ember Mug",
    "Ka-Bar",
    "Kabar",
    "Lego Star Wars",
    // Sport teams, cars (logos)
    "FIFA",
    "UEFA",
    "Real Madrid",
    "FC Barcelona",
    "Manchester United",
    "Manchester City",
    "Liverpool FC",
    "Chelsea FC",
    "Dallas Cowboys",
    "Kansas City Chiefs",
    "New York Yankees",
    "Los Angeles Lakers",
    "Chicago Bulls",
    "Golden State Warriors",
    "Ferrari",
    "Lamborghini",
    "Porsche",
    "Red Bull",
    "Monster Energy",
    "Jack Daniels",
    "Jack Daniel's"
  ];
  var COMPATIBLE = [
    "iPhone",
    "iPad",
    "MacBook",
    "iMac",
    "Apple Watch",
    "Apple Pencil",
    "MagSafe",
    "AirPods",
    "AirTag",
    "Samsung",
    "Google Pixel",
    "Fitbit",
    "Garmin",
    "Nintendo",
    "PlayStation",
    "PS4",
    "PS5",
    "Xbox",
    "Tesla",
    "GoPro",
    "DJI",
    "Kindle",
    "JBL",
    "Bose",
    "Sony",
    "Microsoft",
    "Keurig",
    "Nespresso",
    "KitchenAid",
    "Instant Pot",
    "Cricut",
    "DeWalt",
    "Makita",
    "Bosch",
    // Added 11/2026: devices and cars accessories name (« for Toyota RAV4 »)
    "Steam Deck",
    "Meta Quest",
    "Oculus",
    "Echo Dot",
    "Alexa",
    "Roku",
    "Chromecast",
    "Ring Doorbell",
    "Polaroid",
    "Instax",
    "Fujifilm",
    "Canon",
    "Nikon",
    "Milwaukee",
    "Ryobi",
    "Ninja Creami",
    "Ninja Foodi",
    "Xiaomi",
    "Huawei",
    "OnePlus",
    "Motorola",
    "Lenovo",
    "Dell",
    "Toyota",
    "Honda",
    "Ford",
    "Chevrolet",
    "Chevy",
    "Jeep",
    "BMW",
    "Mercedes",
    "Audi",
    "Volkswagen",
    "Subaru",
    "Nissan",
    "Hyundai",
    "Kia",
    "Mazda",
    "Lexus",
    "Dodge",
    "RAM 1500"
  ];
  var words = (text) => ` ${text.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, " ").trim()} `;
  var LIST = [
    ...DANGER.map((name) => ({ name, level: "danger", w: words(name) })),
    ...COMPATIBLE.map((name) => ({ name, level: "compatible", w: words(name) }))
  ];
  function brandRisks(text) {
    if (!text) return [];
    const t = words(text);
    const hits = [];
    const seen = /* @__PURE__ */ new Set();
    for (const b of LIST) {
      const key = b.w.replace(/ /g, "");
      if (seen.has(key) || !t.includes(b.w)) continue;
      if (hits.some((h) => words(h.name).includes(b.w) || b.w.includes(words(h.name)))) continue;
      seen.add(key);
      hits.push({ name: b.name, level: b.level });
    }
    return hits.sort((a, b) => Number(a.level !== "danger") - Number(b.level !== "danger"));
  }

  // src/core/sleeping.ts
  var SLEEP_DAYS = 60;
  var DAY = 864e5;
  var itemIds = (p) => p.ownListings.filter((l) => l.kind === "item").map((l) => l.url.match(/\/itm\/(?:[^/]+\/)?(\d{9,15})/)?.[1]).filter((x) => !!x);
  function sleepingProducts(products2, sales, now = Date.now()) {
    const lastSale = /* @__PURE__ */ new Map();
    for (const s of sales) {
      if (s.status === "cancelled" || !s.soldAt) continue;
      for (const i of s.items) if (i.itemId) lastSale.set(i.itemId, Math.max(lastSale.get(i.itemId) ?? 0, s.soldAt));
    }
    const out = /* @__PURE__ */ new Map();
    for (const p of products2) {
      if (p.archived) continue;
      const ids = itemIds(p);
      if (!ids.length) continue;
      const listedAt = Math.min(...p.ownListings.filter((l) => l.kind === "item").map((l) => l.savedAt || now));
      if (now - listedAt < SLEEP_DAYS * DAY) continue;
      const last = Math.max(0, ...ids.map((id) => lastSale.get(id) ?? 0)) || null;
      const since = last ?? listedAt;
      if (now - since >= SLEEP_DAYS * DAY) out.set(p.id, { days: Math.floor((now - since) / DAY), lastSaleAt: last });
    }
    return out;
  }
  function soldPrices(sales) {
    const seen = /* @__PURE__ */ new Map();
    for (const s of sales) {
      if (s.status === "cancelled" || !s.soldAt) continue;
      for (const i of s.items) {
        if (!i.itemId || i.price?.currency !== "USD" || !(i.price.amount > 0)) continue;
        const list2 = seen.get(i.itemId) ?? /* @__PURE__ */ new Map();
        const key = i.variation ?? "";
        if ((list2.get(key)?.at ?? 0) <= s.soldAt) list2.set(key, { price: i.price.amount, at: s.soldAt });
        seen.set(i.itemId, list2);
      }
    }
    return new Map([...seen].map(([id, list2]) => [id, [...list2].map(([variation, v]) => ({ price: v.price, variation }))]));
  }

  // src/core/lossCheck.ts
  function pairPrices(prices2, costs2) {
    const p = prices2.filter((n) => n > 0).sort((a, b) => a - b);
    const c = costs2.filter((n) => n > 0).sort((a, b) => a - b);
    if (!p.length || !c.length) return [];
    if (p.length === c.length) return p.map((price, i) => ({ price, cost: c[i] }));
    if (p.length < c.length) return p.map((price) => ({ price, cost: c[0] }));
    return [{ price: p[0], cost: c[0] }, { price: p[p.length - 1], cost: c[c.length - 1] }];
  }
  function listingLoss(input, model, shipping) {
    if (!model) return null;
    const cheapest = input.costs.length ? Math.min(...input.costs) : null;
    const sold = (input.sold ?? []).flatMap((s) => {
      const cost = s.cost ?? cheapest;
      return cost && s.price > 0 ? [{ price: s.price, cost }] : [];
    });
    const listed = input.pairs?.length ? input.pairs : pairPrices(input.listed ?? [], input.costs);
    const [rows, source] = listed.length ? [listed, "ebay"] : sold.length ? [sold, "sale"] : [pairPrices(input.ruled ?? [], input.costs), "rule"];
    if (!rows.length) return null;
    const nets = rows.map((r) => ({ ...r, net: estimateProfit(r.price, r.cost, model, shipping).net }));
    const losing = nets.filter((r) => r.net < 0);
    if (!losing.length) return null;
    const worst = losing.reduce((a, b) => b.net < a.net ? b : a);
    return { ...worst, minPrice: minimumPrice(worst.cost, model, 0, shipping), source, losing: losing.length, total: rows.length };
  }
  var SOURCE = {
    ebay: "prix relu sur eBay",
    sale: "prix de ta derni\xE8re vente",
    rule: "prix calcul\xE9 par ta r\xE8gle, pas relu sur eBay"
  };
  function lossText(l, model, shipping) {
    const money = (n) => n.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    const net = l.net.toLocaleString("fr-FR", { style: "currency", currency: model.currency });
    const port = shipping && !(shipping.freeOver !== null && l.cost >= shipping.freeOver) ? ` + port ${shipping.usual ? "estim\xE9 " : ""}${money(shipping.cost)} $` : "";
    return [
      `\u26A0 \xC0 perte : ${net} \xE0 ${money(l.price)} $ (co\xFBt ${money(l.cost)} $${port})`,
      l.minPrice !== null ? `mini ${money(l.minPrice)} $` : "",
      l.total > 1 ? `${l.losing}/${l.total} variantes` : "",
      SOURCE[l.source]
    ].filter(Boolean).join(" \xB7 ");
  }

  // src/core/variantMatch.ts
  function variantValue(value) {
    return value.normalize("NFKC").toLowerCase().replace(/(\d),(\d)/g, "$1.$2").replace(/[\s\u00a0_-]+/g, "").trim();
  }

  // src/core/profitReview.ts
  function soldVariantCost(variation, costs2) {
    const usd2 = costs2.filter((c) => c.currency === "USD" && Number.isFinite(c.cost) && c.cost > 0);
    if (!usd2.length) return null;
    if (usd2.length === 1) return usd2[0].cost;
    const sold = variation.split(/\s*[·•|]\s*/).map((part) => part.split(":").slice(1).join(":")).map(variantValue).filter(Boolean);
    if (!sold.length) return null;
    const hits = usd2.filter((c) => c.values.length && c.values.every((v) => sold.includes(variantValue(v))));
    return hits.length === 1 ? hits[0].cost : null;
  }

  // src/ui/profitView.ts
  var pct = (fraction) => `${(fraction * 100).toFixed(1).replace(".", ",").replace(",0", "")} %`;
  function profitBasis(m) {
    return `Estim\xE9 apr\xE8s frais eBay + pub ${pct(m.feeRate)}${m.feeFixed ? " + 0,40 $" : ""} (${m.feeSamples ? `observ\xE9s sur ${m.feeSamples} vente(s)` : "tarifs eBay"}), port AliExpress, taxe US AliExpress +${pct(m.aliExtra)}, URSSAF + imp\xF4t ${pct(m.charges)}${m.rateEstimated ? ", taux de change estim\xE9" : ""}. R\xE9glable dans \xAB Ventes \xBB.`;
  }

  // src/ui/listingThumbs.ts
  var KEY = "listingThumbs:v1";
  var cache = {};
  var loaded = null;
  var loadListingThumbs = () => loaded ??= chrome.storage.local.get(KEY).then((v) => void (cache = v[KEY] ?? {})).catch(() => {
  });
  function ownItemId(p) {
    for (const l of p.ownListings) {
      const id = l.kind === "item" ? l.url.match(/\/itm\/(?:[^/]+\/)?(\d{9,15})/)?.[1] : null;
      if (id) return id;
    }
    return null;
  }
  var small = (url) => url.replace(/\/s-l\d+(\.\w+)/, "/s-l300$1");
  function knownListingPhoto(p) {
    for (const l of [p.ebayReference, ...p.ownListings])
      if (l?.snapshot?.images?.[0]) return small(l.snapshot.images[0]);
    const id = ownItemId(p);
    return id && cache[id] ? cache[id] : null;
  }
  function itemPagePhoto(html) {
    const meta = html.match(/<meta\b[^>]*\bproperty=["']og:image["'][^>]*>/)?.[0];
    const raw = meta?.match(/\bcontent=["']([^"']+)["']/)?.[1] ?? html.match(/https:\/\/i\.ebayimg\.com\/images\/g\/[\w~-]+\/s-l\d+\.(?:jpg|jpeg|png|webp)/)?.[0] ?? null;
    return raw && /^https:\/\/i\.ebayimg\.com\//.test(raw) ? small(raw.replace(/&amp;/g, "&")) : null;
  }
  var observer = null;
  var queue = [];
  var running = 0;
  var saveTimer;
  async function next() {
    if (running >= 3) return;
    const box = queue.shift();
    if (!box) return;
    const id = box.dataset.item;
    running++;
    try {
      if (!cache[id]) {
        const r = await fetch(`https://www.ebay.com/itm/${id}`, { credentials: "include" });
        const url = r.ok ? itemPagePhoto(await r.text()) : null;
        if (url) {
          cache[id] = url;
          clearTimeout(saveTimer);
          saveTimer = setTimeout(() => void chrome.storage.local.set({ [KEY]: cache }).catch(() => {
          }), 1500);
        }
      }
      if (cache[id] && box.isConnected && !box.querySelector("img")) {
        const img = document.createElement("img");
        img.src = cache[id];
        img.alt = "";
        img.referrerPolicy = "no-referrer";
        box.append(img);
      }
    } catch {
    } finally {
      running--;
      void next();
    }
  }
  function watchListingThumbs(root) {
    observer?.disconnect();
    queue.length = 0;
    observer = new IntersectionObserver((entries) => {
      for (const e of entries) {
        if (!e.isIntersecting) continue;
        observer.unobserve(e.target);
        queue.push(e.target);
        void next();
        void next();
        void next();
      }
    });
    root.querySelectorAll(".thumb[data-item]").forEach((el) => observer.observe(el));
  }

  // src/core/listingSync.ts
  function typedPrice(value) {
    if (typeof value !== "string" && typeof value !== "number") return null;
    const t = String(value).trim().replace(",", ".");
    if (!/^\d{1,5}(\.\d{1,2})?$/.test(t)) return null;
    const n = Number(t);
    return n >= 0.99 && n <= 99999 ? n.toFixed(2) : null;
  }

  // src/core/ebaySeed.ts
  function aliProductURL(value) {
    const u = new URL(value.trim());
    if (u.protocol !== "https:" || u.username || u.password || u.port || !/(^|\.)aliexpress\.(com|us)$/.test(u.hostname) || !/^\/item\/\d+\.html$/.test(u.pathname))
      throw Error(
        "Colle le lien complet d\u2019une fiche produit AliExpress (.com ou .us)."
      );
    return u.origin + u.pathname;
  }

  // src/core/license.ts
  var LICENSE_KEY = "license:v1";
  var CHECKOUT_URL = "https://auroebay.lemonsqueezy.com/checkout/buy/1b765c13-2f39-4847-82fa-e7950d112d63";
  var TRIAL_DAYS = 15;
  var GRACE_DAYS = 3;
  var DAY2 = 864e5;
  var OWNER_EXTENSION_ID = "bbedjpfnnkjadfjpbbmppikmgocoglfh";
  var SKEW = 10 * 6e4;
  var extensionId = () => globalThis.chrome?.runtime?.id ?? "";
  var ownerInstall = () => extensionId() === OWNER_EXTENSION_ID;
  function licenseActive(s, now = Date.now()) {
    if (!s) return false;
    if (s.owner) return ownerInstall();
    if (s.status === "trial") return trialActive(s, now);
    if (!s.key || s.status !== "active" || !s.checkedAt) return false;
    if (s.checkedAt > now + SKEW || (s.triedAt ?? 0) > now + SKEW) return false;
    if (typeof s.expiresAt === "string" && Date.parse(s.expiresAt) < now - DAY2) return false;
    return now - s.checkedAt < GRACE_DAYS * DAY2;
  }
  var PEPPER = "AurOEBay\xB7licence\xB7v1\xB74f1c9e27b8d36a05";
  var SEALED = ["owner", "key", "instanceId", "status", "checkedAt", "triedAt", "email", "expiresAt", "error", "trialUntil", "trialId"];
  async function hmac(text) {
    const enc = new TextEncoder();
    const raw = await crypto.subtle.digest("SHA-256", enc.encode(PEPPER + "|" + extensionId()));
    const key = await crypto.subtle.importKey("raw", raw, { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
    const sig = await crypto.subtle.sign("HMAC", key, enc.encode(text));
    return [...new Uint8Array(sig)].map((b) => b.toString(16).padStart(2, "0")).join("");
  }
  var body = (s) => JSON.stringify(SEALED.map((k) => s[k] ?? null));
  async function sealValid(s) {
    if (!s || typeof s.seal !== "string") return false;
    try {
      return s.seal === await hmac(body(s));
    } catch {
      return false;
    }
  }
  async function trustedLicense(raw) {
    const s = raw && typeof raw === "object" ? raw : {};
    if (await sealValid(s)) return { state: s, sealed: true };
    if (s.owner === true && ownerInstall()) return { state: { owner: true }, sealed: false };
    if (typeof s.key === "string" && typeof s.instanceId === "string")
      return { state: { key: s.key, instanceId: s.instanceId, status: "unverified" }, sealed: false };
    return { state: {}, sealed: false };
  }
  async function readLicense() {
    const raw = (await chrome.storage.local.get(LICENSE_KEY))[LICENSE_KEY];
    return (await trustedLicense(raw)).state;
  }
  function trialActive(s, now = Date.now()) {
    if (typeof s.trialUntil !== "number" || now >= s.trialUntil) return false;
    if ((s.checkedAt ?? 0) > now + SKEW) return false;
    return s.trialUntil - now <= (TRIAL_DAYS + 1) * DAY2;
  }
  var trialDaysLeft = (s, now = Date.now()) => s?.status === "trial" && trialActive(s, now) ? Math.ceil((s.trialUntil - now) / DAY2) : 0;
  function licenseLabel(s, now = Date.now()) {
    if (s?.owner) return "Version propri\xE9taire : aucune licence n\xE9cessaire.";
    if (s?.status === "trial" && trialActive(s, now)) {
      const left = trialDaysLeft(s, now);
      const end = new Date(s.trialUntil).toLocaleDateString("fr-FR", { day: "numeric", month: "long" });
      return `Essai gratuit : encore ${left} jour${left > 1 ? "s" : ""} (jusqu\u2019au ${end}). Abonne-toi avant pour continuer sans coupure.`;
    }
    if (s?.status === "trial" || s?.status === "trial-ended") return "Ton essai gratuit est termin\xE9 : abonne-toi pour continuer. Tes donn\xE9es sont gard\xE9es.";
    if (!s?.key) return `Aucune cl\xE9 de licence : commence ton essai gratuit de ${TRIAL_DAYS} jours, puis colle la cl\xE9 re\xE7ue par e-mail.`;
    if (licenseActive(s, now)) return `Abonnement actif${s.email ? ` (${s.email})` : ""}.`;
    if (s.status === "unverified") return s.error ? `${s.error} Ta licence sera v\xE9rifi\xE9e d\xE8s le retour de la connexion.` : "V\xE9rification de ta licence aupr\xE8s de Lemon Squeezy\u2026";
    if (s.status === "active") return "Impossible de v\xE9rifier ta licence depuis plus de 3 jours : v\xE9rifie ta connexion internet.";
    if (s.status === "expired") return "Abonnement termin\xE9 : renouvelle-le pour r\xE9activer AurOEBay.";
    if (s.status === "disabled") return "Licence d\xE9sactiv\xE9e : contacte bonjour@impression-minute.fr.";
    return s.error ?? "Licence inactive.";
  }
  function versionBelow(version, than) {
    if (!version) return false;
    const a = version.split(".").map(Number);
    const b = than.split(".").map(Number);
    for (let i = 0; i < 3; i++) if ((a[i] ?? 0) !== (b[i] ?? 0)) return (a[i] ?? 0) < (b[i] ?? 0);
    return false;
  }

  // src/ui/license.ts
  var read = readLicense;
  function licenseBanner(doc = document) {
    if (/\/(welcome|options)\.html$/.test(location.pathname)) return;
    const show = async () => {
      doc.getElementById("lic-banner")?.remove();
      const s = await read();
      const left = trialDaysLeft(s);
      if (left > 0 && left <= 3) {
        const note = doc.createElement("div");
        note.id = "lic-banner";
        note.className = "lic-banner";
        note.innerHTML = `<span>\u23F3 ${escapeHTML(licenseLabel(s))}</span>
        <span><a class="btn small primary" href="${CHECKOUT_URL}" target="_blank" rel="noopener">S\u2019abonner</a> <a class="btn small secondary" href="welcome.html">Entrer ma cl\xE9</a></span>`;
        doc.body.prepend(note);
        return;
      }
      if (licenseActive(s)) return;
      const bar = doc.createElement("div");
      bar.id = "lic-banner";
      bar.className = "lic-banner";
      bar.innerHTML = `<span>\u{1F512} ${escapeHTML(licenseLabel(s))} AurOEBay est en pause ; tes donn\xE9es restent ici.</span>
      <span><a class="btn small primary" href="welcome.html">Entrer ma cl\xE9</a> <a class="btn small secondary" href="${CHECKOUT_URL}" target="_blank" rel="noopener">${s.key || s.status?.startsWith("trial") ? "S\u2019abonner" : `Essai gratuit ${TRIAL_DAYS} jours`}</a></span>`;
      doc.body.prepend(bar);
    };
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "local" && changes[LICENSE_KEY]) void show();
    });
    void show().catch(() => {
    });
  }

  // src/core/update.ts
  var UPDATE_KEY = "update:v1";
  var VERSION_URL = "https://auroebay.netlify.app/version.json";
  var MIRROR = "https://raw.githubusercontent.com/ImpressionMinute/auroebay-maj/main/";
  var VERSION_URLS = [VERSION_URL, MIRROR + "version.json"];
  var UPDATE_GUIDE_URL = "https://auroebay.netlify.app/mise-a-jour.html";
  var UPDATE_EVERY_MS = 24 * 36e5;
  var UPDATE_RECHECK_MS = 2 * 6e4;
  var WHATS_NEW_KEY = "whatsNew:v1";
  var NEWS_URL = "https://auroebay.netlify.app/nouveautes.html";
  var MAC_COMMAND = `curl -fsSL ${MIRROR}maj-mac.sh | bash`;
  var WINDOWS_COMMAND = `powershell -ExecutionPolicy Bypass -c "[Net.ServicePointManager]::SecurityProtocol=3072;irm ${MIRROR}maj-windows.ps1|iex"`;
  var DISK_WAIT_KEY = "updateOnDisk:v1";
  var SITE = "https://auroebay.netlify.app/";
  function cleanNotes(value) {
    if (!Array.isArray(value)) return [];
    return value.filter((n) => typeof n === "string").map((n) => n.replace(/\s+/g, " ").trim().slice(0, 240)).filter(Boolean).slice(0, 8);
  }
  function parseReleaseNotes(value) {
    if (!Array.isArray(value)) return [];
    return value.flatMap((r) => {
      const v = r;
      if (typeof v?.version !== "string" || !/^\d{1,4}\.\d{1,5}\.\d{1,6}$/.test(v.version)) return [];
      const notes = cleanNotes(v.notes);
      return notes.length ? [{ version: v.version, date: typeof v.date === "string" ? v.date.slice(0, 10) : "", notes }] : [];
    });
  }
  function parseVersionFile(value) {
    const v = value;
    if (typeof v?.version !== "string" || !/^\d{1,4}\.\d{1,5}\.\d{1,6}$/.test(v.version)) return null;
    if (typeof v.url !== "string" || !(v.url.startsWith(SITE) || v.url.startsWith(MIRROR)) || /["'<>\s]/.test(v.url)) return null;
    return { latest: v.version, url: v.url, notes: cleanNotes(v.notes) };
  }
  function updateAvailable(info, current) {
    return !!info?.latest && !!info.url && versionBelow(current, info.latest);
  }

  // src/ui/update.ts
  var DISMISSED = "updateDismissed:v1";
  var isWindows = () => /Windows/i.test(navigator.userAgent);
  function steps() {
    return isWindows() ? `<ol class="upd-steps"><li>Clique <b>Copier</b>.</li><li>Appuie sur les touches <kbd>\u229E Windows</kbd> + <kbd>R</kbd>.</li><li>Appuie sur <kbd>Ctrl</kbd> + <kbd>V</kbd>, puis <kbd>Entr\xE9e</kbd>.</li><li>Quand \xAB C\u2019est fait \xBB s\u2019affiche : <b>ferme compl\xE8tement Chrome et rouvre-le</b> (obligatoire).</li></ol>` : `<ol class="upd-steps"><li>Clique <b>Copier</b>.</li><li>Appuie sur <kbd>\u2318 Cmd</kbd> + <kbd>Espace</kbd>, tape <b>Terminal</b>, puis <kbd>Entr\xE9e</kbd>.</li><li>Appuie sur <kbd>\u2318 Cmd</kbd> + <kbd>V</kbd>, puis <kbd>Entr\xE9e</kbd>.</li><li>Quand \xAB C\u2019est fait \xBB s\u2019affiche : <b>quitte Chrome</b> (<kbd>\u2318 Cmd</kbd> + <kbd>Q</kbd>) <b>et rouvre-le</b> (obligatoire).</li></ol>`;
  }
  var list = (notes) => notes.length ? `<ul class="upd-notes">${notes.map((n) => `<li>${escapeHTML(n)}</li>`).join("")}</ul>` : "";
  function updateBanner(doc = document) {
    const current = chrome.runtime.getManifest().version;
    const show = async () => {
      doc.getElementById("upd-banner")?.remove();
      const got = await chrome.storage.local.get([UPDATE_KEY, DISMISSED]);
      const saved = got[UPDATE_KEY];
      const ok = parseVersionFile({ version: saved?.latest, url: saved?.url, notes: saved?.notes });
      const info = ok ? { ...ok, checkedAt: saved?.checkedAt } : void 0;
      if (!updateAvailable(info, current) || got[DISMISSED] === info.latest) return;
      const bar = doc.createElement("div");
      bar.id = "upd-banner";
      bar.className = "lic-banner upd-banner";
      const waiting = (await chrome.storage.local.get(DISK_WAIT_KEY))[DISK_WAIT_KEY];
      bar.innerHTML = waiting?.version ? `<div><b>\u2705 AurOEBay ${escapeHTML(waiting.version)} est pr\xEAt.</b> Il se recharge tout seul d\xE8s que ${escapeHTML(waiting.reason ?? "le travail en cours")} sera fini.</div>
      <span><button type="button" class="btn small primary" id="upd-now">Recharger maintenant</button></span>` : `<div><b>\u{1F195} AurOEBay ${escapeHTML(info.latest)} est disponible</b> (tu as ${escapeHTML(current)}).${ok.notes.length ? ` Ce que \xE7a apporte :${list(ok.notes)}` : ""}<p class="upd-how">Mise \xE0 jour en 1 minute, tes donn\xE9es sont gard\xE9es :</p>${steps()}<p class="upd-how small">Sans red\xE9marrer Chrome, les boutons AurOEBay ne marchent pas sur les pages eBay et AliExpress.</p></div>
      <span><button type="button" class="btn small primary" id="upd-copy">\u{1F4CB} Copier</button>
      <a class="btn small secondary" href="${UPDATE_GUIDE_URL}" target="_blank" rel="noopener">Aide en images</a>
      <button type="button" class="btn small secondary" id="upd-later">Plus tard</button></span>`;
      bar.querySelector("#upd-later")?.addEventListener("click", () => {
        void chrome.storage.local.set({ [DISMISSED]: info.latest });
      });
      bar.querySelector("#upd-now")?.addEventListener("click", () => {
        if (confirm("Recharger AurOEBay maintenant ? Le travail en cours sera interrompu (tes donn\xE9es sont gard\xE9es)."))
          void chrome.runtime.sendMessage({ type: "UPDATE_RELOAD_NOW" }).catch(() => {
          });
      });
      const copy = bar.querySelector("#upd-copy");
      copy?.addEventListener("click", () => {
        void navigator.clipboard.writeText(isWindows() ? WINDOWS_COMMAND : MAC_COMMAND).then(() => copy.textContent = "\u2713 Copi\xE9 ! \xC9tape 2 \u2192").catch(() => copy.textContent = "\u26A0 Copie impossible : utilise l\u2019aide en images");
      });
      doc.body.prepend(bar);
      poll();
    };
    let polling;
    const poll = () => {
      if (polling) return;
      polling = setInterval(() => {
        if (!doc.getElementById("upd-banner")) return void (clearInterval(polling), polling = void 0);
        void chrome.runtime.sendMessage({ type: "UPDATE_DISK" }).catch(() => {
        });
      }, 4e3);
    };
    const news = async () => {
      doc.getElementById("upd-news")?.remove();
      if ((await chrome.storage.local.get(WHATS_NEW_KEY))[WHATS_NEW_KEY] !== current) return;
      const notes = await fetch(chrome.runtime.getURL("release-notes.json")).then((r) => r.json()).then((v) => parseReleaseNotes(v).find((r) => r.version === current)?.notes ?? []).catch(() => []);
      if (!notes.length) return;
      const bar = doc.createElement("div");
      bar.id = "upd-news";
      bar.className = "lic-banner upd-banner upd-news";
      bar.innerHTML = `<div><b>\u{1F389} AurOEBay est \xE0 jour (${escapeHTML(current)}). Les nouveaut\xE9s :</b>${list(notes)}<p class="upd-how small">Si ce n\u2019est pas d\xE9j\xE0 fait : ferme compl\xE8tement Chrome et rouvre-le, sinon les boutons AurOEBay ne marchent pas sur les pages eBay et AliExpress d\xE9j\xE0 ouvertes.</p></div>
      <span><a class="btn small secondary" href="${NEWS_URL}" target="_blank" rel="noopener">Toutes les nouveaut\xE9s</a>
      <button type="button" class="btn small primary" id="upd-news-ok">J\u2019ai compris</button></span>`;
      bar.querySelector("#upd-news-ok")?.addEventListener("click", () => void chrome.storage.local.remove(WHATS_NEW_KEY));
      doc.body.prepend(bar);
    };
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "local") return;
      if (changes[UPDATE_KEY] || changes[DISMISSED] || changes[DISK_WAIT_KEY]) void show().catch(() => {
      });
      if (changes[WHATS_NEW_KEY]) void news().catch(() => {
      });
    });
    void show().catch(() => {
    });
    void news().catch(() => {
    });
    void chrome.runtime.sendMessage({ type: "UPDATE_CHECK" }).catch(() => {
    });
  }

  // src/core/debug.ts
  function safeDiagnostic(value) {
    if (typeof value === "string") return redact(value).slice(0, 3e4);
    if (Array.isArray(value)) return value.slice(0, 200).map(safeDiagnostic);
    if (value && typeof value === "object")
      return Object.fromEntries(
        Object.entries(value).filter(
          ([k]) => !/(api.?key|authorization|cookie|token|secret|password)/i.test(k) || /^(input_tokens|output_tokens|reasoning_tokens|maxOutputTokens)$/.test(
            k
          )
        ).map(([k, v]) => [k, safeDiagnostic(v)])
      );
    return value;
  }

  // src/core/links.ts
  var DISCORD_URL = "https://discord.gg/sr2g2ZZZQ9";

  // src/ui/report.ts
  var REPORT_URL = "https://auroebay.netlify.app/";
  var SUPPORT_EMAIL = "bonjour@impression-minute.fr";
  var MAX_IMAGE = 5 * 1024 * 1024;
  async function technicalReport(extra) {
    const health = await message({ type: "HEALTH_CHECK" }).catch(() => []);
    let session = {};
    try {
      session = await chrome.storage.session.get(["apiTrace:v1", "lastPanelError:v1"]);
    } catch {
    }
    const trace = session["apiTrace:v1"];
    const report = {
      version: chrome.runtime.getManifest().version,
      navigateur: navigator.userAgent,
      page: location.pathname,
      "tout-va-bien": health.map((x) => `${x.ok ? "OK" : x.unknown ? "?" : "!!"} ${x.title} : ${x.text}`),
      "derniere-erreur": session["lastPanelError:v1"] ?? null,
      "trace-import": trace?.slice(-40) ?? []
    };
    const text = JSON.stringify(safeDiagnostic(report), null, 2);
    return (extra ? `${text}

--- Panneau ---
${extra}` : text).slice(0, 6e4);
  }
  var CSS = `
.rp{border:0;border-radius:18px;padding:0;max-width:520px;width:calc(100vw - 32px);background:var(--surface,#fff);color:var(--text,#1d1a24);box-shadow:0 24px 60px rgba(0,0,0,.4);font:14px system-ui,-apple-system,sans-serif}
.rp::backdrop{background:rgba(10,8,14,.55)}
.rp form{display:grid;gap:12px;padding:20px 22px}
.rp h2{margin:0;font-size:19px}
.rp p{margin:0;color:var(--muted,#a49bb0);line-height:1.45}
.rp .rp-community a{color:#ff8a3d;font-weight:600}
.rp label{display:grid;gap:6px;font-weight:600}
.rp textarea,.rp input[type=email]{font:inherit;padding:10px 12px;border-radius:10px;border:1px solid var(--line,#3a3346);background:var(--bg,var(--field,#faf7f3));color:inherit}
.rp textarea{min-height:110px;resize:vertical}
.rp .rp-check{display:flex;align-items:center;gap:8px;font-weight:500;color:var(--muted,#75697d)}.rp .rp-check input{width:auto;flex:none;margin:0}.rp h2{color:inherit}
.rp .rp-actions{display:flex;flex-wrap:wrap;gap:8px;justify-content:flex-end}.rp .rp-copy{margin-right:auto;font-weight:500}
.rp button{font:600 14px system-ui;border-radius:10px;padding:9px 16px;border:1px solid var(--line,#ddd);background:transparent;color:var(--text,#1d1a24);cursor:pointer}
.rp button.primary{background:linear-gradient(135deg,#ff5f3a,#ff8a3d 50%,#ffb347);border-color:transparent;color:#fff}
.rp button:disabled{opacity:.6;cursor:default}
.rp .rp-msg{font-weight:600}
.rp .rp-msg.ok{color:#3fd09a}.rp .rp-msg.err{color:#ff6b78}
`;
  function openReport(extra) {
    document.getElementById("auroebay-report")?.remove();
    if (!document.getElementById("auroebay-report-css")) {
      const style = document.createElement("style");
      style.id = "auroebay-report-css";
      style.textContent = CSS;
      document.head.append(style);
    }
    const dialog = document.createElement("dialog");
    dialog.id = "auroebay-report";
    dialog.className = "rp";
    dialog.innerHTML = `<form method="dialog">
      <h2>\u{1F198} Un souci avec AurOEBay ?</h2>
      <p>Explique simplement ce qui ne marche pas. Le message part directement, pas besoin de bo\xEEte e-mail.</p>
      <p class="rp-community">\u{1F4AC} Plut\xF4t une question ? <a href="${DISCORD_URL}" target="_blank" rel="noopener">Demande \xE0 la communaut\xE9 AurOEBay sur Discord \u2197</a></p>
      <label>Qu\u2019est-ce qui ne marche pas ?<textarea name="message" required maxlength="4000" placeholder="Ex. : quand je clique \xAB Cr\xE9er le brouillon \xBB, rien ne se passe."></textarea></label>
      <label>Une capture d\u2019\xE9cran (si tu veux)<input name="capture" type="file" accept="image/*"></label>
      <label>Ton e-mail, pour te r\xE9pondre (si tu veux)<input name="email" type="email" maxlength="200" placeholder="toi@exemple.fr"></label>
      <label class="rp-check"><input name="tech" type="checkbox" checked> Joindre le rapport technique (aucun mot de passe ni cl\xE9)</label>
      <p class="rp-msg" hidden></p>
      <div class="rp-actions"><button type="button" class="rp-copy" title="Pour le coller dans un message">\u{1F4CB} Copier le rapport</button><button type="button" value="cancel" class="rp-cancel">Annuler</button><button type="submit" class="primary">Envoyer</button></div>
    </form>`;
    document.body.append(dialog);
    const form = dialog.querySelector("form");
    const msg = dialog.querySelector(".rp-msg");
    const send = dialog.querySelector("button[type=submit]");
    const say = (text, kind = "") => {
      msg.hidden = false;
      msg.className = `rp-msg ${kind}`;
      msg.textContent = text;
    };
    dialog.querySelector(".rp-cancel").addEventListener("click", () => dialog.close());
    dialog.querySelector(".rp-copy").addEventListener("click", async () => {
      try {
        await navigator.clipboard.writeText(await technicalReport(extra ? await extra().catch(() => "") : void 0));
        say("\u{1F4CB} Rapport copi\xE9 (aucun mot de passe ni cl\xE9).", "ok");
      } catch {
        say("Copie impossible.", "err");
      }
    });
    dialog.addEventListener("close", () => dialog.remove());
    form.addEventListener("submit", async (event) => {
      event.preventDefault();
      const text = form.elements.namedItem("message").value.trim();
      if (!text) return say("\xC9cris d\u2019abord ce qui ne marche pas.", "err");
      const file = form.elements.namedItem("capture").files?.[0];
      if (file && file.size > MAX_IMAGE) return say("Capture trop lourde (5 Mo au plus).", "err");
      send.disabled = true;
      say("Envoi\u2026");
      const version = chrome.runtime.getManifest().version;
      const tech = form.elements.namedItem("tech").checked ? await technicalReport(extra ? await extra().catch(() => "") : void 0).catch(() => "") : "";
      const body2 = new FormData();
      body2.set("form-name", "probleme");
      body2.set("bot-field", "");
      body2.set("message", text);
      body2.set("email", form.elements.namedItem("email").value.trim());
      body2.set("version", version);
      body2.set("rapport", tech);
      if (file) body2.set("capture", file, file.name);
      try {
        const r = await fetch(REPORT_URL, { method: "POST", body: body2, signal: AbortSignal.timeout(3e4) });
        if (!r.ok) throw Error(String(r.status));
        say("\u2705 Envoy\xE9, merci ! Tu auras une r\xE9ponse par e-mail si tu as laiss\xE9 ton adresse.", "ok");
        send.textContent = "Fermer";
        send.disabled = false;
        send.type = "button";
        send.addEventListener("click", () => dialog.close(), { once: true });
      } catch {
        try {
          await navigator.clipboard.writeText(`${text}

${tech}`);
        } catch {
        }
        window.open(
          `mailto:${SUPPORT_EMAIL}?subject=${encodeURIComponent(`AurOEBay ${version} : un probl\xE8me`)}&body=${encodeURIComponent(`${text}

(Le rapport est copi\xE9 : colle-le ici avec Cmd+V ou Ctrl+V.)`)}`,
          "_blank"
        );
        say("L\u2019envoi direct n\u2019a pas march\xE9 : un e-mail s\u2019ouvre, ton message y est d\xE9j\xE0 (colle le rapport avec Cmd+V ou Ctrl+V).", "err");
        send.disabled = false;
      }
    });
    dialog.showModal();
    form.elements.namedItem("message").focus();
  }

  // src/ui/theme.ts
  function setupTheme() {
    licenseBanner();
    updateBanner();
    simpleTopbar();
    const system = matchMedia("(prefers-color-scheme: dark)");
    const button = document.getElementById("theme-toggle");
    const choice = document.getElementById(
      "theme-choice"
    );
    let theme = "system";
    let revision = 0;
    const valid = (value) => value === "light" || value === "dark" ? value : "system";
    const render2 = () => {
      const dark = theme === "dark" || theme === "system" && system.matches;
      document.documentElement.dataset.theme = dark ? "dark" : "light";
      if (button) {
        button.textContent = dark ? "\u2600" : "\u263E";
        button.setAttribute("aria-pressed", String(dark));
        button.setAttribute(
          "aria-label",
          dark ? "Activer le mode clair" : "Activer le mode sombre"
        );
        button.title = button.getAttribute("aria-label");
      }
      if (choice) choice.value = theme;
    };
    const save = async (value) => {
      revision++;
      theme = value;
      render2();
      try {
        await chrome.storage.local.set({ uiTheme: value });
      } catch {
      }
    };
    button?.addEventListener(
      "click",
      () => void save(
        document.documentElement.dataset.theme === "dark" ? "light" : "dark"
      )
    );
    choice?.addEventListener("change", () => void save(valid(choice.value)));
    system.addEventListener("change", render2);
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "local" && changes.uiTheme) {
        revision++;
        theme = valid(changes.uiTheme.newValue);
        render2();
      }
    });
    const initial = revision;
    void chrome.storage.local.get("uiTheme").then(({ uiTheme }) => {
      if (revision === initial) theme = valid(uiTheme);
      render2();
    }).catch(() => render2());
    render2();
  }
  var PAGES = [
    ["routine.html", "\u2600\uFE0F Ma journ\xE9e"],
    ["dashboard.html", "\u{1F4E6} Mes produits"],
    ["scout.html", "\u{1F50D} Trouver"],
    ["sales.html", "\u{1F4D2} Ventes"]
  ];
  function simpleTopbar() {
    const bar = document.querySelector("header.topbar");
    const actions = bar?.querySelector(".top-actions");
    if (!bar || !actions || bar.querySelector(".ao-nav")) return;
    const here = location.pathname.split("/").pop() || "";
    if (here === "welcome.html") return;
    actions.querySelectorAll("a[href]").forEach((a) => {
      if (PAGES.some(([href]) => a.getAttribute("href") === href)) a.remove();
    });
    const nav = document.createElement("nav");
    nav.className = "ao-nav";
    nav.setAttribute("aria-label", "Pages d\u2019AurOEBay");
    for (const [href, label] of PAGES) {
      const a = document.createElement("a");
      a.href = href;
      a.textContent = label;
      if (href === here) {
        a.className = "on";
        a.setAttribute("aria-current", "page");
      }
      nav.append(a);
    }
    bar.querySelector(".brand")?.after(nav);
    bar.querySelector(".brand .crumb")?.remove();
    if (here !== "options.html") {
      const settings = document.createElement("a");
      settings.className = "btn ghost";
      settings.href = "options.html";
      settings.textContent = "\u2699\uFE0F Param\xE8tres";
      actions.append(settings);
    }
    const help = document.createElement("button");
    help.id = "help-report";
    help.type = "button";
    help.className = "btn ghost";
    help.textContent = "\u{1F198} Aide";
    help.title = "Un souci ? \xC9cris-nous, c\u2019est envoy\xE9 tout de suite";
    help.addEventListener("click", () => openReport());
    actions.append(help);
  }

  // src/core/syncSeries.ts
  var SERIES_MAX = 20;
  var SERIES_FAILS = 2;
  var startSeries = (ids, auto = false) => ({
    ...auto ? { auto: true } : {},
    ids: [...new Set(ids)].slice(0, SERIES_MAX),
    at: 0,
    sent: 0,
    skipped: 0,
    failed: 0,
    failsInARow: 0
  });
  var seriesNext = (s) => s.ids[s.at] ?? null;
  var seriesLabel = (s) => `Annonce ${s.at + 1} sur ${s.ids.length}`;
  var seriesDone = (s, result) => ({
    ...s,
    at: s.at + 1,
    sent: s.sent + (result === "sent" ? 1 : 0),
    skipped: s.skipped + (result === "skipped" ? 1 : 0),
    failed: s.failed + (result === "failed" ? 1 : 0),
    failsInARow: result === "failed" ? s.failsInARow + 1 : 0
  });
  var seriesBlocked = (s) => s.failsInARow >= SERIES_FAILS;
  function seriesSummary(s, stopped = false) {
    const n = (count, one, many) => `${count} ${count > 1 ? many : one}`;
    const parts = [
      n(s.sent, "annonce envoy\xE9e", "annonces envoy\xE9es"),
      s.skipped ? s.auto ? `${s.skipped} d\xE9j\xE0 \xE0 jour` : n(s.skipped, "pass\xE9e", "pass\xE9es") : "",
      s.failed ? n(s.failed, "illisible", "illisibles") : ""
    ].filter(Boolean);
    const left = s.ids.length - s.at;
    const end = seriesBlocked(s) ? " S\xE9rie arr\xEAt\xE9e : v\xE9rifie ta connexion \xE0 eBay, puis relance." : stopped && left > 0 ? ` S\xE9rie arr\xEAt\xE9e, ${n(left, "annonce restante", "annonces restantes")}.` : "";
    const validate = s.auto ? " Valide chacune avec \xAB Revise listing \xBB dans son onglet eBay." : " Valide-les avec \xAB Revise listing \xBB sur eBay.";
    return `${parts.join(", ")}.${end}${s.sent ? validate : ""}`;
  }

  // src/core/watch.ts
  var urgentIssues = (r) => r.issues.filter((i) => i.kind === "out" || i.kind === "price_up").length;

  // src/ui/watchPanel.ts
  var KINDS = {
    out: { label: "en rupture sur AliExpress mais en vente sur eBay", cls: "neg" },
    price_up: { label: "prix \xE0 monter (co\xFBt AliExpress en hausse)", cls: "neg" },
    back: { label: "de retour en stock sur AliExpress", cls: "pos" },
    price_down: { label: "prix pouvant baisser", cls: "" },
    unknown: { label: "introuvable(s) sur AliExpress", cls: "warn" }
  };
  var when = (t) => t ? new Date(t).toLocaleString("fr-FR", { dateStyle: "short", timeStyle: "short" }) : "jamais";
  function backupLine(r) {
    const b = r.backup;
    if (!b) return "";
    const cost = b.minCost !== null && b.currency ? ` \xB7 d\xE8s ${b.minCost.toLocaleString("fr-FR", { style: "currency", currency: b.currency })}` : "";
    return `<li class="pos">\u{1F501} Fournisseur de secours : <a href="${escapeHTML(b.url)}" target="_blank" rel="noopener noreferrer">${escapeHTML(b.title || "autre fournisseur")}</a> \u2014 ${b.problems ? `${b.problems} variante(s) \xE0 revoir` : "tout en stock"} au lieu de ${b.primaryProblems}${escapeHTML(cost)} (lu le ${escapeHTML(when(b.at))}).</li>`;
  }
  function setupWatchPanel(onSync, supplierOf = () => void 0, onPrimary, onBulk) {
    const box = document.getElementById("watch");
    let state = null;
    const render2 = () => {
      if (!state) return;
      const results = Object.values(state.results).sort(
        (a, b) => urgentIssues(b) - urgentIssues(a) || b.issues.length - a.issues.length
      );
      const all = results.filter((r) => r.issues.length || r.error || r.ended);
      const todo = all.filter((r) => !r.dismissed && !r.sent);
      const sent = all.filter((r) => r.sent && !r.dismissed).length;
      const hidden = all.length - todo.length - sent;
      const fixable = todo.filter((r) => r.issues.some((i) => i.kind !== "unknown")).map((r) => r.productId);
      const errors = todo.filter((r) => r.error).map((r) => r.productId);
      const progress = state.progress ? ` \xB7 v\xE9rification ${state.progress.done}/${state.progress.total}\u2026` : "";
      box.innerHTML = `
      <div class="watch-head">
        <div>
          <span class="label">Surveillance stock / prix</span>
          <strong>${todo.length ? `${todo.length} annonce(s) \xE0 revoir` : results.length ? "\u2713 Tout est \xE0 jour" : "Aucune annonce en ligne reli\xE9e"}</strong>
          <small class="muted">Derni\xE8re v\xE9rification : ${escapeHTML(when(state.at))} \xB7 ${results.length} annonce(s) suivie(s)${escapeHTML(progress)}${hidden ? ` \xB7 ${hidden} alerte(s) masqu\xE9e(s) <button class="link-button" id="watch-show" type="button">r\xE9afficher</button>` : ""}</small>
          ${sent ? `<small class="pos">\u2713 ${sent} annonce(s) envoy\xE9e(s) \xE0 eBay : valide chacune avec \xAB Revise listing \xBB dans son onglet eBay. Elles seront rev\xE9rifi\xE9es \xE0 la prochaine v\xE9rification.</small>` : ""}
        </div>
        <div class="watch-actions">
          ${fixable.length && onBulk && !state.running ? `<button class="btn primary small" id="watch-bulk" type="button" title="Pr\xE9pare les annonces l\u2019une apr\xE8s l\u2019autre avec ta r\xE8gle de prix, sans fen\xEAtre \xE0 valider. Tu cliques ensuite \xAB Revise listing \xBB dans chaque onglet eBay.">\u26A1 Tout mettre \xE0 jour</button>` : ""}
          ${errors.length && !state.running ? `<button class="btn small" id="watch-errors" type="button" title="Relit seulement les annonces en erreur">\u{1F504} Rev\xE9rifier les erreurs (${errors.length})</button>` : ""}
          ${todo.length ? '<button class="btn ghost small" id="watch-hide-all" type="button">Tout ignorer</button>' : ""}
          <button class="btn small" id="watch-run" type="button" ${state.running ? "disabled" : ""}>${state.running ? "V\xE9rification\u2026" : "V\xE9rifier maintenant"}</button>
        </div>
      </div>
      ${todo.map((r) => {
        const groups = /* @__PURE__ */ new Map();
        for (const i of r.issues) groups.set(i.kind, [...groups.get(i.kind) ?? [], i]);
        const lines = [...groups].map(([kind, list2]) => {
          const names2 = list2.slice(0, 4).map((i) => (i.values.join(" / ") || "produit") + (i.newPrice ? ` ${i.price} \u2192 ${i.newPrice} $` : "")).join(", ");
          return `<li class="${KINDS[kind].cls}">${list2.length} variante(s) ${KINDS[kind].label} : ${escapeHTML(names2)}${list2.length > 4 ? "\u2026" : ""}</li>`;
        }).join("");
        return `<div class="watch-item">
            <div><b>${escapeHTML(r.name)}</b>
            <span class="watch-links"><a href="dashboard.html?product=${encodeURIComponent(r.productId)}">fiche AurOEBay</a> \xB7 <a href="https://www.ebay.com/itm/${escapeHTML(r.itemId)}" target="_blank" rel="noopener noreferrer">annonce eBay \u2197</a>${supplierOf(r.productId) ?? r.supplierUrl ? ` \xB7 <a href="${escapeHTML(supplierOf(r.productId) ?? r.supplierUrl)}" target="_blank" rel="noopener noreferrer">AliExpress \u2197</a>` : ""}</span>
            <ul>${r.ended ? '<li class="warn">Annonce termin\xE9e sur eBay.</li>' : ""}${r.error ? `<li class="warn">${escapeHTML(r.error)}</li>` : ""}${lines}${backupLine(r)}</ul></div>
            <div class="watch-item-actions">
              ${r.backup && onPrimary && r.backup.url !== (supplierOf(r.productId) ?? r.supplierUrl) ? `<button class="btn small" data-primary="${escapeHTML(r.productId)}" data-supplier="${escapeHTML(r.backup.supplierId)}" type="button" title="Ce fournisseur devient le principal : la mise \xE0 jour stock/prix et le raccourci commande l\u2019utiliseront.">\u{1F501} Passer en principal</button>` : ""}
              ${r.issues.length ? `<button class="btn primary small" data-sync="${escapeHTML(r.productId)}" type="button">Mettre \xE0 jour stock/prix</button>` : ""}
              ${r.error && !state.running ? `<button class="btn small" data-recheck="${escapeHTML(r.productId)}" type="button" title="Relit cette annonce eBay et son fournisseur">\u{1F504} Rev\xE9rifier</button>` : ""}
              <button class="btn ghost small" data-hide="${escapeHTML(r.productId)}" type="button" title="Masquer jusqu\u2019\xE0 la prochaine v\xE9rification">Ignorer</button>
            </div>
          </div>`;
      }).join("")}`;
      box.querySelector("#watch-run").addEventListener("click", () => {
        void message({ type: "WATCH_RUN" });
      });
      box.querySelector("#watch-bulk")?.addEventListener("click", () => onBulk?.(fixable));
      box.querySelector("#watch-errors")?.addEventListener("click", () => {
        void message({ type: "WATCH_RUN", productIds: errors });
      });
      box.querySelectorAll("[data-recheck]").forEach(
        (b) => b.addEventListener("click", () => void message({ type: "WATCH_RUN", productId: b.dataset.recheck }))
      );
      box.querySelectorAll("[data-hide]").forEach(
        (b) => b.addEventListener("click", () => void message({ type: "WATCH_DISMISS", productId: b.dataset.hide }))
      );
      box.querySelector("#watch-hide-all")?.addEventListener("click", () => {
        void message({ type: "WATCH_DISMISS", productId: "all" });
      });
      box.querySelector("#watch-show")?.addEventListener("click", () => {
        void message({ type: "WATCH_DISMISS", productId: "all", hidden: false });
      });
      box.querySelectorAll("[data-primary]").forEach(
        (b) => b.addEventListener("click", () => {
          b.disabled = true;
          void onPrimary(b.dataset.primary, b.dataset.supplier).finally(() => b.disabled = false);
        })
      );
      box.querySelectorAll("[data-sync]").forEach(
        (b) => b.addEventListener("click", () => onSync(b.dataset.sync))
      );
    };
    const load2 = async () => {
      state = await message({ type: "WATCH_STATE" });
      render2();
    };
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "local" && changes["watch:v1"]) void load2().catch(() => {
      });
    });
    void load2().catch(() => {
    });
    return { render: render2 };
  }

  // src/core/rivalSuppliers.ts
  var RIVAL_SUPPLIERS_KEY = "competitorSuppliers:v1";
  async function rivalSuppliersOn() {
    return message({ type: "PAGE_PREF", key: RIVAL_SUPPLIERS_KEY }).catch(() => true);
  }
  function rivalSuppliersToggle(doc, className = "rival-sup") {
    const label = doc.createElement("label");
    label.className = className;
    label.title = "Pendant la v\xE9rification, chercher le fournisseur AliExpress des nouvelles annonces (une \xE0 la fois, 20 au plus)";
    const box = doc.createElement("input");
    box.type = "checkbox";
    box.checked = true;
    label.append(box, " Chercher aussi les fournisseurs AliExpress");
    void rivalSuppliersOn().then((on) => box.checked = on);
    box.addEventListener("change", () => void message({ type: "PAGE_PREF", key: RIVAL_SUPPLIERS_KEY, value: box.checked }).catch(() => {
    }));
    try {
      const sync = (changes, area) => {
        if (!label.isConnected) return chrome.storage.onChanged.removeListener(sync);
        if (area === "local" && changes[RIVAL_SUPPLIERS_KEY]) box.checked = changes[RIVAL_SUPPLIERS_KEY].newValue !== false;
      };
      chrome.storage.onChanged.addListener(sync);
    } catch {
    }
    return label;
  }

  // src/ui/competitorsPanel.ts
  var when2 = (t) => t ? new Date(t).toLocaleString("fr-FR", { dateStyle: "short", timeStyle: "short" }) : "jamais";
  function setupCompetitorsPanel(root, toast2) {
    let rows = [];
    let listOpen = false;
    const render2 = () => {
      const typing = root.querySelector("#rival-input");
      const draft = typing?.value ?? "";
      const focused = !!typing && document.activeElement === typing;
      queueMicrotask(() => {
        const input = root.querySelector("#rival-input");
        if (!input || !draft) return;
        input.value = draft;
        if (focused) input.focus();
      });
      const last = rows.reduce((m, r) => r.lastCheck && (!m || r.lastCheck > m) ? r.lastCheck : m, null);
      root.innerHTML = `
      <div class="watch-head">
        <div><b>\u{1F52D} Mes concurrents</b><span class="muted" style="font-size:13px">${rows.length ? `${rows.length} vendeur(s) suivi(s) \xB7 derni\xE8re v\xE9rification : ${escapeHTML(when2(last))}` : "Suis des dropshippers (hors US) pour rep\xE9rer leurs nouvelles annonces qui d\xE9marrent bien."}</span></div>
        <div class="watch-actions">
          <form id="rival-form" class="rival-form"><input id="rival-input" placeholder="Nom du vendeur eBay, ou plusieurs s\xE9par\xE9s par des espaces / virgules" title="Le plus s\xFBr : \xAB \u2B50 Suivre \xBB dans Produits gagnants. Un nom de boutique peut diff\xE9rer du nom du vendeur." autocomplete="off" /><button class="btn small" type="submit">Ajouter</button></form>
          <button id="rival-open" class="btn primary small" type="button"${rows.length ? "" : " disabled"}>Voir leurs nouveaut\xE9s</button>
        </div>
      </div>
      ${rows.length ? (() => {
        const chip = (r) => `<span class="rival"><a href="https://www.ebay.com/sch/i.html?_ssn=${encodeURIComponent(r.seller)}&_sop=10&LH_PrefLoc=99" target="_blank" rel="noopener">${escapeHTML(r.seller)}</a>${r.lastNew ? `<b class="rival-new">${r.lastNew} nouv.</b>` : ""}<button type="button" data-remove="${escapeHTML(r.seller)}" title="Ne plus suivre">\u2715</button></span>`;
        if (rows.length <= 8) return `<div class="rival-list">${rows.map(chip).join("")}</div>`;
        const news = rows.filter((r) => r.lastNew);
        return `${news.length ? `<div class="rival-list">${news.map(chip).join("")}</div>` : ""}<details class="rival-more"${listOpen ? " open" : ""}><summary>Voir les ${rows.length} vendeurs suivis</summary><div class="rival-list">${rows.filter((r) => !r.lastNew).map(chip).join("")}</div></details>`;
      })() : ""}`;
      root.querySelector("#rival-form").addEventListener("submit", (e) => {
        e.preventDefault();
        const input = root.querySelector("#rival-input");
        if (input.value.trim().split(/[\s,;]+/).length > 1) {
          void message({ type: "COMPETITOR_ADD_MANY", text: input.value }).then((r) => {
            toast2(
              `${r.added.length} vendeur(s) ajout\xE9(s)${r.already.length ? ` \xB7 ${r.already.length} d\xE9j\xE0 suivi(s)` : ""}${r.refused.length ? ` \xB7 non reconnu(s) : ${r.refused.slice(0, 3).join(", ")}` : ""}.`,
              !r.added.length && !!r.refused.length
            );
            const box = root.querySelector("#rival-input");
            if (box) box.value = "";
            return load2();
          }).catch((err) => toast2(err instanceof Error ? err.message : String(err), true));
          return;
        }
        void message({ type: "COMPETITOR_ADD", seller: input.value }).then((seller) => {
          toast2(`${seller} ajout\xE9 \xE0 tes concurrents.`);
          const box = root.querySelector("#rival-input");
          if (box) box.value = "";
          return load2();
        }).catch((err) => toast2(err instanceof Error ? err.message : String(err), true));
      });
      root.querySelector("#rival-open").after(rivalSuppliersToggle(document));
      root.querySelector("#rival-open").addEventListener("click", () => {
        void message({ type: "COMPETITOR_OPEN" }).catch((err) => toast2(err instanceof Error ? err.message : String(err), true));
      });
      root.querySelector(".rival-more")?.addEventListener("toggle", (e) => listOpen = e.target.open);
      root.querySelectorAll("[data-remove]").forEach(
        (b) => b.addEventListener("click", () => {
          void message({ type: "COMPETITOR_REMOVE", seller: b.dataset.remove }).then(load2);
        })
      );
    };
    const load2 = async () => {
      rows = await message({ type: "COMPETITOR_LIST" }).catch(() => []);
      render2();
    };
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "local" && changes["competitors:v1"]) void load2();
    });
    void load2();
  }

  // src/ui/listingImport.ts
  var library = (command) => message({ type: "LIBRARY", command });
  var aliId = (url) => url.match(/\/item\/(\d{6,20})\.html/)?.[1] ?? null;
  var itemOf = (url) => url.match(/\/itm\/(\d{9,15})/)?.[1] ?? null;
  function planListingImport(map2, products2) {
    const linked = new Set(products2.flatMap((p) => p.ownListings.map((l) => itemOf(l.url)).filter(Boolean)));
    const byAli = /* @__PURE__ */ new Map();
    for (const p of products2) for (const s of p.suppliers) byAli.set(s.id, p.id);
    const plan = { create: [], link: [], already: 0 };
    const planned = /* @__PURE__ */ new Set();
    for (const [key, url] of Object.entries(map2)) {
      const itemId = key.match(/^item:(\d{9,15})$/)?.[1];
      const id = aliId(url);
      if (!itemId || !id) continue;
      if (linked.has(itemId)) {
        plan.already++;
        continue;
      }
      const productId = byAli.get(id);
      if (productId) plan.link.push({ itemId, productId });
      else if (planned.has(id)) plan.link.push({ itemId, productId: `ali:${id}` });
      else {
        planned.add(id);
        plan.create.push({ itemId, aliUrl: url });
      }
    }
    return plan;
  }
  function itemTitle(html) {
    const raw = html.match(/<h1[^>]*x-item-title__mainTitle[^>]*>[\s\S]*?<span[^>]*>([^<]{3,200})<\/span>/)?.[1] ?? html.match(/<meta property="og:title" content="([^"]{3,200})"/)?.[1] ?? null;
    const decoded = raw ? new DOMParser().parseFromString(`<p>${raw}</p>`, "text/html").body.textContent?.replace(/\s*\|\s*eBay\s*$/i, "").trim() ?? null : null;
    return { title: decoded, ended: /This listing (was|has) ended|The seller has ended this listing/i.test(html) };
  }
  function stubSource(aliUrl, title) {
    const id = aliId(aliUrl);
    return {
      id,
      url: aliUrl,
      title: title.slice(0, 2e3),
      capturedAt: 0,
      // not read yet
      specs: [],
      description: "",
      variants: [],
      supplierNames: [],
      descriptionStatus: "unavailable"
    };
  }
  async function runListingImport(plan, progress) {
    const result = { created: 0, linked: 0, ended: [], failed: [] };
    const createdByAli = /* @__PURE__ */ new Map();
    const queue2 = [...plan.create];
    let done = 0;
    const total = plan.create.length + plan.link.length;
    let writing2 = Promise.resolve();
    const write = (job) => writing2 = writing2.then(job, job);
    const worker = async () => {
      while (queue2.length) {
        const entry = queue2.shift();
        let title = null;
        try {
          const r = await fetch(`https://www.ebay.com/itm/${entry.itemId}`, { credentials: "include" });
          const page = itemTitle(await r.text());
          if (page.ended) {
            result.ended.push(entry.itemId);
            done++;
            continue;
          }
          title = page.title;
        } catch {
        }
        const name = title ?? `Annonce eBay ${entry.itemId}`;
        await write(async () => {
          try {
            const product = await library({
              action: "save-source",
              source: stubSource(entry.aliUrl, name),
              newProduct: true
            });
            await library({
              action: "link-ebay",
              productId: product.id,
              role: "own",
              url: `https://www.ebay.com/itm/${entry.itemId}`,
              title: name.slice(0, 200)
            });
            createdByAli.set(aliId(entry.aliUrl), product.id);
            result.created++;
          } catch {
            result.failed.push(entry.itemId);
          }
        });
        done++;
        progress(`Import\u2026 ${done}/${total} (${result.created} fiche(s) cr\xE9\xE9e(s))`);
      }
    };
    await Promise.all([worker(), worker(), worker(), worker()]);
    await writing2;
    for (const entry of plan.link) {
      const productId = entry.productId.startsWith("ali:") ? createdByAli.get(entry.productId.slice(4)) : entry.productId;
      try {
        if (!productId) throw Error();
        await library({ action: "link-ebay", productId, role: "own", url: `https://www.ebay.com/itm/${entry.itemId}` });
        result.linked++;
      } catch {
        result.failed.push(entry.itemId);
      }
      done++;
      progress(`Import\u2026 ${done}/${total}`);
    }
    return result;
  }

  // src/core/backupExtras.ts
  var BACKUP_EXTRA_KEYS = [
    "taxRates:v1",
    "disputes:v1",
    "aliParcels:v1",
    "hiddenProducts:v1",
    "monthGoal:v1",
    "firstSale:v1",
    "watch:v1",
    "competitorSuppliers:v1",
    "productShipping:v1",
    "listingPrices:v1"
  ];
  function backupExtras(local) {
    return Object.fromEntries(BACKUP_EXTRA_KEYS.flatMap((k) => local[k] === void 0 ? [] : [[k, local[k]]]));
  }
  function extrasToRestore(extras, local) {
    if (!extras || typeof extras !== "object") return {};
    const from = extras;
    return Object.fromEntries(BACKUP_EXTRA_KEYS.flatMap((k) => from[k] === void 0 || local[k] !== void 0 ? [] : [[k, from[k]]]));
  }

  // src/ui/backup.ts
  var STATUS = "backupStatus:v1";
  var MAIN_FILE = "auroebay-sauvegarde.json";
  var KEEP_DAYS = 14;
  var EVERY_MS = 6 * 36e5;
  async function fullBackup() {
    const local = await chrome.storage.local.get([
      "sales:v1",
      "listingSuppliers:v1",
      "variantPricing",
      "competitors:v1",
      "profitSettings:v1",
      "urssafDeclarations:v1",
      ...BACKUP_EXTRA_KEYS
    ]);
    return {
      format: "auroebay-full",
      version: 1,
      exportedAt: Date.now(),
      library: await message({ type: "LIBRARY", command: { action: "export" } }),
      sales: local["sales:v1"] ?? {},
      listingSuppliers: local["listingSuppliers:v1"] ?? {},
      variantPricing: local.variantPricing ?? null,
      competitors: local["competitors:v1"] ?? {},
      profitSettings: local["profitSettings:v1"] ?? null,
      urssafDeclarations: local["urssafDeclarations:v1"] ?? null,
      extras: backupExtras(local)
    };
  }
  async function restoreBackup(data) {
    const full = data;
    if (full?.format !== "auroebay-full") {
      const r2 = await message({ type: "LIBRARY", command: { action: "import", backup: data } });
      return `${r2.added} produit(s) ajout\xE9(s), ${r2.unchanged} d\xE9j\xE0 pr\xE9sent(s).`;
    }
    const r = await message({ type: "LIBRARY", command: { action: "import", backup: full.library } });
    const sales = await message({ type: "SALES_IMPORT", sales: full.sales ?? {} });
    const local = await chrome.storage.local.get([
      "listingSuppliers:v1",
      "variantPricing",
      "competitors:v1",
      "profitSettings:v1",
      "urssafDeclarations:v1",
      ...BACKUP_EXTRA_KEYS
    ]);
    await chrome.storage.local.set({
      ...extrasToRestore(full.extras, local),
      "listingSuppliers:v1": { ...full.listingSuppliers ?? {}, ...local["listingSuppliers:v1"] ?? {} },
      ...local.variantPricing || !full.variantPricing ? {} : { variantPricing: full.variantPricing },
      // Followed sellers: the ones already here are kept as they are.
      ...full.competitors && typeof full.competitors === "object" ? { "competitors:v1": { ...full.competitors, ...local["competitors:v1"] ?? {} } } : {},
      ...local["profitSettings:v1"] || !full.profitSettings ? {} : { "profitSettings:v1": full.profitSettings },
      ...local["urssafDeclarations:v1"] || !full.urssafDeclarations ? {} : { "urssafDeclarations:v1": full.urssafDeclarations }
    });
    return `${r.added} produit(s) et ${sales} vente(s) ajout\xE9s, rien d\u2019\xE9cras\xE9.`;
  }
  function db() {
    return new Promise((resolve, reject) => {
      const open = indexedDB.open("auroebay-backup", 1);
      open.onupgradeneeded = () => open.result.createObjectStore("kv");
      open.onsuccess = () => resolve(open.result);
      open.onerror = () => reject(open.error);
    });
  }
  async function kv(mode, value) {
    const d = await db();
    return new Promise((resolve, reject) => {
      const store = d.transaction("kv", mode === "get" ? "readonly" : "readwrite").objectStore("kv");
      const req = mode === "get" ? store.get("folder") : mode === "put" ? store.put(value, "folder") : store.delete("folder");
      req.onsuccess = () => resolve(mode === "get" ? req.result : void 0);
      req.onerror = () => reject(req.error);
    });
  }
  var backupFolder = () => kv("get").catch(() => void 0);
  async function chooseFolder() {
    const picker = window.showDirectoryPicker;
    if (!picker) throw Error("Ce navigateur ne permet pas de choisir un dossier.");
    const handle = await picker({ id: "auroebay-backup", mode: "readwrite" });
    await kv("put", handle);
    await writeBackup(true);
    return handle.name;
  }
  async function stopBackup() {
    await kv("delete");
    await chrome.storage.local.set({ [STATUS]: { at: null, folder: null } });
  }
  async function backupStatus() {
    const status2 = (await chrome.storage.local.get(STATUS))[STATUS] ?? { at: null, folder: null };
    const handle = await backupFolder();
    return {
      ...status2,
      folder: handle?.name ?? null,
      permission: handle ? await handle.queryPermission({ mode: "readwrite" }).catch(() => "denied") : "none"
    };
  }
  var writing = null;
  async function writeBackup(force = false) {
    if (writing) return writing;
    writing = (async () => {
      const handle = await backupFolder();
      if (!handle || await handle.queryPermission({ mode: "readwrite" }) !== "granted") return;
      const status2 = (await chrome.storage.local.get(STATUS))[STATUS] ?? {};
      if (!force && status2.at && Date.now() - status2.at < 6e4) return;
      try {
        const text = JSON.stringify(await fullBackup());
        const day = `auroebay-${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.json`;
        for (const name of [MAIN_FILE, day]) {
          const file = await handle.getFileHandle(name, { create: true });
          const w = await file.createWritable();
          await w.write(text);
          await w.close();
        }
        const dated = [];
        for await (const name of handle.keys()) if (/^auroebay-\d{4}-\d{2}-\d{2}\.json$/.test(name)) dated.push(name);
        for (const old of dated.sort().slice(0, Math.max(0, dated.length - KEEP_DAYS)))
          await handle.removeEntry(old).catch(() => {
          });
        await chrome.storage.local.set({ [STATUS]: { at: Date.now(), folder: handle.name } });
      } catch (e) {
        await chrome.storage.local.set({
          [STATUS]: { ...status2, folder: handle.name, error: e instanceof Error ? e.message : String(e) }
        });
      }
    })().finally(() => writing = null);
    return writing;
  }
  function setupAutoBackup(bar) {
    let timer;
    const refresh2 = async () => {
      const s = await backupStatus();
      bar.hidden = true;
      bar.replaceChildren();
      if (s.permission === "none") return;
      if (s.permission !== "granted") {
        const button = document.createElement("button");
        button.className = "btn small";
        button.type = "button";
        button.textContent = "R\xE9activer";
        button.addEventListener("click", async () => {
          const handle = await backupFolder();
          if (handle && await handle.requestPermission({ mode: "readwrite" }) === "granted") {
            await writeBackup(true);
            await refresh2();
          }
        });
        bar.append(`Sauvegarde automatique en pause : Chrome demande d\u2019autoriser \xE0 nouveau le dossier \xAB ${s.folder} \xBB. `, button);
        bar.hidden = false;
        return;
      }
      if (!s.at || Date.now() - s.at > EVERY_MS) {
        await writeBackup(true);
      }
    };
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "local" || !(changes.libraryRevision || changes["sales:v1"] || changes["listingSuppliers:v1"] || changes["competitors:v1"] || changes["urssafDeclarations:v1"]))
        return;
      clearTimeout(timer);
      timer = setTimeout(() => void writeBackup(true), 2e4);
    });
    void refresh2().catch(() => {
    });
    return { refresh: refresh2 };
  }

  // src/ui/dashboard.ts
  var $ = (id) => document.getElementById(id);
  var library2 = (command) => message({ type: "LIBRARY", command });
  var products = [];
  var tab = "all";
  var rule = null;
  var busy = false;
  var selecting = false;
  var chosen = /* @__PURE__ */ new Set();
  var shownSyncable = [];
  var series = null;
  var safeUrl = (url) => /^https:\/\//.test(url) ? url : "#";
  var focusId = new URLSearchParams(location.search).get("product");
  function toast(text, error = false) {
    const el = $("toast");
    el.textContent = text;
    el.className = "toast" + (error ? " error" : "");
    el.hidden = false;
    clearTimeout(toast.t);
    toast.t = window.setTimeout(
      () => el.hidden = true,
      error ? 9e3 : 4500
    );
  }
  async function work(label, action) {
    if (busy) return;
    busy = true;
    document.body.classList.add("busy");
    toast(label);
    const box = $("toast");
    box.classList.add("loading");
    clearTimeout(toast.t);
    try {
      await action();
      if (box.classList.contains("loading")) box.hidden = true;
    } catch (e) {
      toast(e instanceof Error ? e.message : String(e), true);
    } finally {
      busy = false;
      box.classList.remove("loading");
      document.body.classList.remove("busy");
    }
  }
  var primary = (p) => p.suppliers.find((s) => s.id === p.primarySupplierId) ?? p.suppliers[0];
  var syncable = (p) => !p.archived && !!primary(p) && (status(p) === "live" || status(p) === "draft");
  function status(p) {
    if (p.archived) return "archived";
    if (p.ownListings.some((l) => l.kind === "item")) return "live";
    if (p.ownListings.some((l) => l.kind === "draft")) return "draft";
    return "todo";
  }
  var statusLabel = {
    all: "",
    todo: "\xC0 cr\xE9er",
    draft: "Brouillon",
    live: "En vente",
    sleep: "En vente",
    loss: "",
    archived: "Archiv\xE9"
  };
  function photo(p) {
    const s = primary(p)?.source;
    const raw = s?.images?.find((i) => i.role === "gallery")?.url ?? s?.images?.[0]?.url;
    return raw ? supplierImageURL(raw) : knownListingPhoto(p);
  }
  function costs(p) {
    const s = primary(p)?.source;
    return (s?.variantScan?.costs ?? s?.variantCosts ?? []).filter((c) => c.currency === "USD" && c.cost > 0).map((c) => c.cost);
  }
  var range = (values, suffix = " $") => {
    if (!values.length) return "\u2014";
    const min = Math.min(...values), max = Math.max(...values);
    return min === max ? `${min.toFixed(2)}${suffix}` : `${min.toFixed(2)} \u2013 ${max.toFixed(2)}${suffix}`;
  };
  var listedPrices = {};
  var readShipping = {};
  function shippingOf(p) {
    const own = shippingCharge(primary(p)?.source.shippingDetails);
    return own.usual && readShipping[p.id] ? readShipping[p.id] : own;
  }
  async function loadListedPrices() {
    const saved = await chrome.storage.local.get(["listingPrices:v1", "productShipping:v1"]);
    listedPrices = saved["listingPrices:v1"] ?? {};
    readShipping = saved["productShipping:v1"] ?? {};
  }
  function prices(p) {
    if (listedPrices[p.id]?.prices.length) return listedPrices[p.id].prices;
    const r = p.pricing ?? rule;
    if (!r) return [];
    const withShipping = { ...r, shipping: shippingOf(p) };
    return costs(p).map((c) => Number(ruledPrice(c, withShipping))).filter((n) => n > 0);
  }
  var date = (t) => t ? new Date(t).toLocaleDateString("fr-FR", { day: "numeric", month: "short" }) : "";
  function lossMap() {
    const out = /* @__PURE__ */ new Map();
    for (const p of products) {
      const st = status(p);
      if (st !== "live" && st !== "draft") continue;
      const source = primary(p)?.source;
      const r = p.pricing ?? rule;
      const shipping = shippingOf(p);
      const loss = listingLoss(
        {
          costs: costs(p),
          pairs: listedPrices[p.id]?.pairs,
          listed: listedPrices[p.id]?.prices,
          sold: itemIds(p).flatMap((id) => lastSold.get(id) ?? []).map((s) => ({ price: s.price, cost: soldVariantCost(s.variation, source?.variantCosts ?? []) })),
          ruled: r ? costs(p).map((c) => Number(ruledPrice(c, { ...r, shipping }))) : []
        },
        profitModelCache,
        shipping
      );
      if (loss) out.set(p.id, loss);
    }
    return out;
  }
  function render() {
    const q = $("search").value.trim().toLowerCase();
    const counts = { all: 0, todo: 0, draft: 0, live: 0, sleep: sleeping.size, loss: 0, archived: 0 };
    const losses = lossMap();
    counts.loss = losses.size;
    $("tab-loss").hidden = !losses.size && tab !== "loss";
    for (const p of products) {
      const st = status(p);
      counts[st]++;
      if (st !== "archived") counts.all++;
    }
    for (const k of Object.keys(counts))
      $(`n-${k}`).textContent = String(counts[k]);
    const shown = products.filter(
      (p) => tab === "all" ? status(p) !== "archived" : tab === "sleep" ? sleeping.has(p.id) : tab === "loss" ? losses.has(p.id) : status(p) === tab
    ).filter(
      (p) => !q || [p.name, primary(p)?.source.title, p.ebayReference?.title].join(" ").toLowerCase().includes(q)
    ).sort(
      (a, b) => tab === "sleep" ? sleeping.get(b.id).days - sleeping.get(a.id).days : tab === "loss" ? losses.get(a.id).net - losses.get(b.id).net : b.updatedAt - a.updatedAt
    );
    $("sleep-hint").hidden = tab !== "sleep" || !shown.length;
    $("loss-hint").hidden = tab !== "loss" || !shown.length;
    $("count").textContent = `${shown.length} produit${shown.length > 1 ? "s" : ""}`;
    $("empty").hidden = shown.length > 0;
    const veroLine = (p) => {
      const names2 = brandRisks([p.name, p.ebayReference?.title, ...p.ownListings.map((l) => l.title)].join(" \n ")).filter((b) => b.level === "danger").map((b) => b.name);
      return names2.length ? `<div class="vero" title="Sans autorisation du propri\xE9taire, eBay retire l\u2019annonce et peut suspendre ton compte (programme VeRO). Retire ce nom du titre, de la description et des photos.">\u{1F6AB} Marque prot\xE9g\xE9e : ${escapeHTML(names2.join(", "))}</div>` : "";
    };
    shownSyncable = shown.filter(syncable).map((p) => p.id);
    renderSeriesBar();
    $("list").innerHTML = shown.map((p) => {
      const s = primary(p), img = photo(p), st = status(p), own = p.ownListings.find((l) => l.kind === "item") ?? p.ownListings[0];
      const canSync = syncable(p);
      const canCreate = !p.archived && !!s && !!p.ebayReference && !canSync;
      return `<article class="row${p.id === focusId ? " focus" : ""}" data-id="${escapeHTML(p.id)}">
        <div class="thumb"${!img && ownItemId(p) ? ` data-item="${escapeHTML(ownItemId(p))}"` : ""}>${img ? `<img src="${escapeHTML(img)}" alt="" loading="lazy" referrerpolicy="no-referrer" />` : ""}</div>
        <div class="main">
          ${selecting && canSync ? `<label class="series-check"><input type="checkbox" data-series="${escapeHTML(p.id)}"${chosen.has(p.id) ? " checked" : ""}> \xC0 mettre \xE0 jour</label>` : ""}
          <div class="name" title="${escapeHTML(p.name)}">${escapeHTML(p.name)}</div>
          ${veroLine(p)}
          ${losses.has(p.id) && profitModelCache ? `<div class="loss-line">${escapeHTML(lossText(losses.get(p.id), profitModelCache, shippingOf(p)))}</div>` : ""}
          <div class="links">
            ${p.ebayReference ? `<a href="${escapeHTML(safeUrl(p.ebayReference.url))}" target="_blank" rel="noopener noreferrer">R\xE9f\xE9rence eBay \u2197</a>` : '<span class="warn">Pas de r\xE9f\xE9rence eBay</span>'}
            ${s ? `<a href="${escapeHTML(safeUrl(s.url))}" target="_blank" rel="noopener noreferrer">AliExpress \u2197</a>${p.suppliers.length > 1 ? ` <button class="link-button" data-act="suppliers" type="button">+${p.suppliers.length - 1} fournisseur(s)</button>` : ""}` : '<span class="warn">Pas de fournisseur</span>'}
            ${own ? `<a href="${escapeHTML(safeUrl(own.url))}" target="_blank" rel="noopener noreferrer">${own.kind === "draft" ? "Mon brouillon" : "Mon annonce"} \u2197</a>` : ""}
          </div>
        </div>
        <div class="num"><span>Co\xFBt</span><b>${escapeHTML(range(costs(p)))}</b></div>
        <div class="num"><span>Prix eBay</span><b>${escapeHTML(range(prices(p)))}</b></div>
        <div class="state"><span class="pill ${st}">${statusLabel[st]}</span><small>${s && !s.source.capturedAt ? '<span class="warn">AliExpress \xE0 lire</span>' : escapeHTML(date(s?.source.capturedAt))}</small>${sleeping.has(p.id) ? `<small class="warn" title="Aucune vente depuis ${sleeping.get(p.id).days} jours">\u{1F634} ${sleeping.get(p.id).lastSaleAt ? "pas de vente" : "jamais vendu"} \xB7 ${sleeping.get(p.id).days} j</small>` : ""}</div>
        <div class="actions">
          ${canCreate ? `<button class="btn primary small" data-act="create" type="button">Cr\xE9er le brouillon</button>` : ""}
          ${sleeping.has(p.id) && own?.kind === "item" ? `<button class="btn small" data-act="revive" type="button" title="Actions pr\xEAtes pour relancer cette annonce : prix rentable, titre, fournisseur">\u{1F504} Relancer</button>` : ""}
          ${canSync ? `<button class="btn primary small" data-act="sync" type="button" title="Relit le stock et les prix AliExpress et les met dans ${st === "live" ? "la r\xE9vision de ton annonce" : "ton brouillon"} eBay">Mettre \xE0 jour stock/prix</button>` : ""}
          <details class="menu"><summary class="btn ghost small" aria-label="Plus d\u2019actions">\u22EF</summary>
            <div class="menu-list">
              <button data-act="rename" type="button">Renommer</button>
              ${p.ebayReference ? "" : '<button data-act="reference" type="button">Ajouter la r\xE9f\xE9rence eBay</button>'}
              <button data-act="suppliers" type="button">Fournisseurs (${p.suppliers.length})</button>
              <button data-act="own" type="button">Relier mon annonce eBay</button>
              ${own?.kind === "item" ? '<button data-act="market" type="button">\u{1F4CA} Prix vs concurrence</button>' : ""}
              ${s ? '<button data-act="refresh" type="button">Relire AliExpress</button>' : ""}
              <button data-act="archive" type="button">${p.archived ? "Restaurer" : "Archiver"}</button>
            </div>
          </details>
        </div>
      </article>`;
    }).join("");
    watchListingThumbs($("list"));
    if (!$("list").classList.contains("settled")) setTimeout(() => $("list").classList.add("settled"), 900);
    if (focusId && !focusScrolled) {
      focusScrolled = true;
      document.querySelector(".row.focus")?.scrollIntoView({ block: "center" });
    }
  }
  var focusShown = false;
  var focusScrolled = false;
  var sleeping = /* @__PURE__ */ new Map();
  var lastSold = /* @__PURE__ */ new Map();
  async function load() {
    products = await library2({ action: "list" });
    const sales = await message({ type: "SALES_LIST" }).catch(() => []);
    sleeping = sleepingProducts(products, sales);
    await currentProfitModel();
    lastSold = soldPrices(sales);
    await loadListingThumbs();
    if (focusId && !focusShown) {
      focusShown = true;
      if (products.find((p) => p.id === focusId)?.archived) {
        tab = "archived";
        document.querySelectorAll("#tabs button").forEach((b) => b.classList.toggle("active", b.dataset.tab === "archived"));
      }
    }
    render();
    watchPanel?.render();
  }
  async function loadRule() {
    rule = (await chrome.storage.local.get("variantPricing")).variantPricing ?? null;
    $("rule-coef").value = rule ? String(rule.coefficient) : "";
    $("rule-fixed").value = rule ? String(rule.fixed) : "0";
    $("rule-round").value = rule?.rounding ?? "none";
    const target = rule?.target;
    $("rule-mode").value = typeof target === "number" ? "target" : "coef";
    if (typeof target === "number") $("rule-target").value = String(target);
    showRuleMode();
    const formula = rule ? `co\xFBt \xD7 ${rule.coefficient} + ${rule.fixed} $${rule.rounding === "none" ? "" : `, arrondi ${rule.rounding === "49-or-99" ? ".49/.99" : "." + rule.rounding}`}` : "\xE0 d\xE9finir";
    $("rule-text").textContent = typeof target === "number" ? `rentable \xE0 ${String(target).replace(".", ",")} \u20AC net par vente : frais eBay + pub, URSSAF, taxe US et port AliExpress de chaque produit compt\xE9s tout seuls` : formula;
  }
  function showRuleMode() {
    const on = $("rule-mode").value === "target";
    document.querySelectorAll(".rule-coef-box").forEach((e) => e.hidden = on);
    document.querySelectorAll(".rule-target-box").forEach((e) => e.hidden = !on);
    $("rule-coef").required = !on;
    $("rule-fixed").required = !on;
    $("rule-target").required = on;
  }
  $("rule-mode").addEventListener("change", showRuleMode);
  $("rule-form").addEventListener("submit", (e) => {
    e.preventDefault();
    if ($("rule-mode").value === "target") {
      const target = Number($("rule-target").value.replace(",", "."));
      void message({ type: "PRICE_TARGET", target, rounding: $("rule-round").value }).then(async () => {
        await loadRule();
        render();
        toast(`R\xE8gle enregistr\xE9e : rentable \xE0 ${String(target).replace(".", ",")} \u20AC par vente.`);
      }).catch((err) => toast(err instanceof Error ? err.message : String(err), true));
      return;
    }
    const next2 = {
      coefficient: Number($("rule-coef").value),
      fixed: Number($("rule-fixed").value),
      rounding: $("rule-round").value
    };
    if (!sellingPrice(1, next2.coefficient, next2.fixed, next2.rounding))
      return toast("Coefficient ou montant fixe invalide.", true);
    void chrome.storage.local.set({ variantPricing: next2 }).then(async () => {
      await loadRule();
      render();
      toast("R\xE8gle de prix enregistr\xE9e.");
    });
  });
  function ask(title, body2, ok, onOk) {
    const dialog = $("dialog");
    $("dialog-title").textContent = title;
    $("dialog-body").innerHTML = body2;
    $("dialog-ok").textContent = ok;
    $("dialog-error").hidden = true;
    const form = $("dialog-form");
    form.onsubmit = async (e) => {
      const submitter = e.submitter;
      if (submitter?.value !== "ok") return;
      e.preventDefault();
      if (!form.reportValidity()) return;
      const okButton = $("dialog-ok");
      okButton.disabled = true;
      try {
        await onOk(form);
        dialog.close();
      } catch (error) {
        $("dialog-error").textContent = error instanceof Error ? error.message : String(error);
        $("dialog-error").hidden = false;
      } finally {
        okButton.disabled = false;
      }
    };
    dialog.showModal();
  }
  function addProduct() {
    ask(
      "Ajouter un produit",
      `<label>Lien AliExpress<input id="f-ali" type="url" required placeholder="https://www.aliexpress.us/item/\u2026html" /></label>
     <label>Annonce eBay de r\xE9f\xE9rence <small>(facultatif)</small><input id="f-ebay" type="url" placeholder="https://www.ebay.com/itm/\u2026" /></label>
     <p class="muted">AliExpress est lu en arri\xE8re-plan (photos, description, prix des variantes).</p>`,
      "Ajouter",
      async () => {
        const ali = aliProductURL($("f-ali").value);
        const ebay = $("f-ebay").value.trim();
        $("dialog-ok").textContent = "Lecture AliExpress\u2026";
        const source = await message({
          type: "READ_SUPPLIER_LINK",
          url: ali,
          prices: true,
          background: true
        });
        const saved = await library2({
          action: "save-source",
          source,
          newProduct: true
        });
        if (ebay)
          await library2({
            action: "link-ebay",
            productId: saved.id,
            role: "reference",
            url: ebay
          });
        await load();
        toast("Produit ajout\xE9.");
      }
    );
  }
  async function marketDialog(p, fresh = false) {
    const own = p.ownListings.find((l) => l.kind === "item");
    const itemId = own?.url.match(/\/itm\/(?:[^/]+\/)?(\d{9,15})/)?.[1] ?? null;
    if (!own || !itemId) return;
    ask(
      "\u{1F4CA} Prix vs concurrence",
      `<p><b>${escapeHTML(p.name)}</b></p><div class="mk-wait"><span class="ao-loader" style="--ao-size:56px"><span class="ao-mark"></span></span><span>Recherche des annonces les plus proches sur eBay\u2026</span></div>`,
      "Fermer",
      async () => {
      }
    );
    try {
      const [market, model] = await Promise.all([
        message({ type: "MARKET_SEARCH", title: own.title || p.name, itemId, fresh }),
        currentProfitModel()
      ]);
      const listings = closestListings(market.cards, { title: own.title || p.name, itemId });
      const mine = market.cards.find((c) => c.itemId === itemId);
      const myPrice = mine ? Math.round((mine.price + (mine.shipping ?? 0)) * 100) / 100 : prices(p)[0] ?? null;
      const cost = costs(p).length ? Math.min(...costs(p)) : null;
      const st = standing(myPrice, listings);
      const advice = advisePrice(cost, model, listings, 1, shippingOf(p));
      const money = (n) => n === null ? "\u2014" : `${n.toFixed(2)} $`;
      const when3 = new Date(market.at).toLocaleString("fr-FR", { dateStyle: "short", timeStyle: "short" });
      const verdict = advice.reason === "below-cheapest" ? `Prix conseill\xE9 <b>${money(advice.suggested)}</b> : juste sous le moins cher (${money(st.min)}), b\xE9n\xE9fice net ${model ? fmtNet(advice.netAtSuggested, model.currency) : "?"}.` : advice.reason === "floor" ? `Prix conseill\xE9 <b>${money(advice.suggested)}</b> : ton minimum (1 \u20AC net), sous la m\xE9diane (${money(st.median)}). Passer sous le moins cher (${money(st.min)}) te ferait perdre de l\u2019argent.` : advice.reason === "cannot-compete" ? `\u26A0 Difficile d\u2019\xEAtre comp\xE9titif : le moins cher est \xE0 ${money(st.min)}, ton minimum rentable est ${money(advice.floor)}. Cherche un fournisseur moins cher ou mets en avant autre chose (livraison, photos).` : advice.reason === "no-market" ? "Aucune annonce assez proche trouv\xE9e : pas de concurrence directe visible." : "Co\xFBt AliExpress inconnu : relis le fournisseur pour avoir un prix conseill\xE9.";
      $("dialog-body").innerHTML = `<p><b>${escapeHTML(p.name)}</b></p>
      <div class="mk-stats">
        <div><span>Ton prix</span><b>${money(myPrice)}</b></div>
        <div><span>Ton rang</span><b>${st.rank ? `${st.rank} / ${st.count + 1}` : "\u2014"}</b></div>
        <div><span>Le moins cher</span><b>${money(st.min)}</b></div>
        <div><span>M\xE9diane</span><b>${money(st.median)}</b></div>
      </div>
      <p class="profit-box ${advice.reason === "cannot-compete" ? "loss" : "ok"}">${verdict}</p>
      <div class="mk-list">${listings.map(
        (l) => `<a class="mk-row${myPrice !== null && l.total < myPrice ? " cheaper" : ""}" href="${escapeHTML(l.url)}" target="_blank" rel="noopener">
            <img src="${escapeHTML(l.image)}" alt="" referrerpolicy="no-referrer" loading="lazy">
            <span class="mk-t"><span class="mk-title">${escapeHTML(l.title)}</span><small>${escapeHTML(l.seller ?? "")}${l.sold ? ` \xB7 ${l.sold} vendus` : ""} \xB7 ressemblance ${Math.round(l.similarity * 100)} %</small></span>
            <b>${money(l.total)}<small>${l.shipping ? `dont ${money(l.shipping)} de livraison` : l.shipping === 0 ? "livraison offerte" : ""}</small></b>
          </a>`
      ).join("")}</div>
      <p class="muted" style="font-size:12px">${listings.length} annonce(s) proches sur \xAB ${escapeHTML(market.words.join(" "))} \xBB (Achat imm\xE9diat), prix livraison comprise \xB7 ${market.cached ? `m\xE9moris\xE9 le ${when3}` : `lu le ${when3}`} \xB7 <a href="${escapeHTML(market.searchUrl)}" target="_blank" rel="noopener">voir sur eBay \u2197</a> \xB7 <button type="button" class="link-button" id="mk-redo">\u21BB Relancer</button></p>`;
      document.getElementById("mk-redo")?.addEventListener("click", () => void marketDialog(p, true));
    } catch (e) {
      $("dialog-body").innerHTML = `<p class="warn">\u26A0 ${escapeHTML(e instanceof Error ? e.message : String(e))}</p>`;
    }
  }
  async function reviveDialog(p) {
    const own = p.ownListings.find((l) => l.kind === "item");
    const itemId = own?.url.match(/\/itm\/(?:[^/]+\/)?(\d{9,15})/)?.[1] ?? null;
    const sleep = sleeping.get(p.id);
    if (!own || !itemId || !sleep) return;
    ask(
      "\u{1F504} Relancer l\u2019annonce",
      `<p><b>${escapeHTML(p.name)}</b></p><div class="mk-wait"><span class="ao-loader" style="--ao-size:56px"><span class="ao-mark"></span></span><span>Comparaison avec les annonces proches sur eBay\u2026</span></div>`,
      "Fermer",
      async () => {
      }
    );
    try {
      const [market, model] = await Promise.all([
        message({ type: "MARKET_SEARCH", title: own.title || p.name, itemId, fresh: false }),
        currentProfitModel()
      ]);
      const listings = closestListings(market.cards, { title: own.title || p.name, itemId });
      const mine = market.cards.find((c) => c.itemId === itemId);
      const myPrice = mine ? Math.round((mine.price + (mine.shipping ?? 0)) * 100) / 100 : prices(p)[0] ?? null;
      const plan = revivePlan({
        myPrice,
        costUSD: costs(p).length ? Math.min(...costs(p)) : null,
        model,
        listings,
        days: sleep.days,
        everSold: !!sleep.lastSaleAt,
        suppliers: p.suppliers.length
      });
      const icon = { price: "\u{1F4B2}", title: "\u270D\uFE0F", supplier: "\u{1F501}", end: "\u{1F6D1}" };
      const step = plan.steps.find((s) => s.price);
      const typed = step?.price !== void 0 ? Math.round((step.price - (mine?.shipping ?? 0)) * 100) / 100 : null;
      const priced = typed !== null && typed > 0 ? { price: typed } : null;
      $("dialog-body").innerHTML = `<p><b>${escapeHTML(p.name)}</b> \xB7 \u{1F634} ${sleep.lastSaleAt ? "pas de vente" : "jamais vendu"} depuis ${sleep.days} jours</p>
      <ol class="revive">${plan.steps.map((s) => `<li><span>${icon[s.kind]}</span> ${escapeHTML(s.text)}</li>`).join("")}</ol>
      <p class="actions-row">
        <a class="btn primary small" href="https://www.ebay.com/lstng?mode=ReviseItem&itemId=${escapeHTML(itemId)}" target="_blank" rel="noopener">Modifier l\u2019annonce sur eBay \u2197</a>
        ${priced ? `<button class="btn small" type="button" id="rv-copy">\u{1F4CB} Copier le prix ${escapeHTML(priced.price.toFixed(2))}</button>` : ""}
      </p>
      <p class="muted" style="font-size:12px">Sur eBay, change le prix (et le titre), puis clique \xAB Revise listing \xBB. AurOEBay ne modifie rien tout seul. Prix livraison comprise, compar\xE9s \xE0 ${listings.length} annonce(s) proches.</p>`;
      document.getElementById("rv-copy")?.addEventListener(
        "click",
        () => void navigator.clipboard.writeText(priced.price.toFixed(2)).then(() => toast("Prix copi\xE9 : colle-le dans le champ \xAB Price \xBB sur eBay."))
      );
    } catch (e) {
      $("dialog-body").innerHTML = `<p class="warn">\u26A0 ${escapeHTML(e instanceof Error ? e.message : String(e))}</p>`;
    }
  }
  var fmtNet = (n, cur) => n === null ? "?" : `${n >= 0 ? "+" : ""}${n.toLocaleString("fr-FR", { style: "currency", currency: cur })}`;
  var profitModelCache = null;
  async function currentProfitModel() {
    profitModelCache ??= await message({ type: "PROFIT_MODEL" }).catch(() => null);
    return profitModelCache;
  }
  function netCell(model, price, cost, shipping) {
    if (!model || !cost || !(price > 0)) return '<span class="muted">\u2014</span>';
    const net = estimateProfit(price, cost, model, shipping).net;
    const min = net < 0 ? minimumPrice(cost, model, 0, shipping) : null;
    return `<span class="net-pill ${net < 0 ? "loss" : "ok"}" title="${escapeHTML(profitBasis(model))}">${net >= 0 ? "+" : ""}${escapeHTML(net.toLocaleString("fr-FR", { style: "currency", currency: model.currency }))}</span>${min ? `<br><small class="muted">mini ${min.toFixed(2)} $</small>` : ""}`;
  }
  var shippingNote = (s) => s.usual ? `Port compt\xE9 : ${s.cost.toFixed(2)} $ (port habituel, pas lu sur la fiche AliExpress).` : `Port AliExpress de ce produit compt\xE9 : ${s.cost.toFixed(2)} $${s.freeOver ? ` (offert \xE0 partir de ${s.freeOver.toFixed(2)} $)` : ""}.`;
  function lossNote(model, rows, shipping) {
    if (!model) return "";
    const losses = rows.filter((r) => r.cost && r.price > 0 && estimateProfit(r.price, r.cost, model, shipping).net < 0).length;
    return losses ? `<p class="profit-box loss"><strong>\u26A0 ${losses} variante(s) \xE0 perte \xE0 ce prix</strong>Monte leur prix (le \xAB mini \xBB indiqu\xE9) avant de mettre en vente.<small>${escapeHTML(shippingNote(shipping))} ${escapeHTML(profitBasis(model))}</small></p>` : `<p class="muted" style="font-size:12px">${escapeHTML(shippingNote(shipping))} B\xE9n\xE9fice net estim\xE9 apr\xE8s frais eBay, AliExpress et URSSAF. ${escapeHTML(profitBasis(model))}</p>`;
  }
  async function createDraft(p) {
    const s = primary(p);
    if (!s || !p.ebayReference) return;
    await work("Lecture eBay et AliExpress\u2026", async () => {
      const prepared = await message({
        type: "LIBRARY_PREPARE_DRAFT",
        productId: p.id,
        supplierId: s.id
      });
      await load();
      const model = await currentProfitModel();
      ask(
        "Cr\xE9er le brouillon eBay",
        `<p><b>${escapeHTML(prepared.title)}</b></p>
       <p class="muted">${prepared.galleryCount} photos \xB7 ${prepared.descriptionImageCount} images de description${prepared.omitted ? ` \xB7 ${prepared.omitted} rupture(s) exclue(s)` : ""}</p>
       <table class="mini"><thead><tr><th>Variante</th><th>Co\xFBt</th><th>Prix eBay</th><th>B\xE9n\xE9fice net</th></tr></thead><tbody>
       ${prepared.rows.map((r) => `<tr><td>${escapeHTML(r.values.join(" / ") || "Produit")}</td><td>${r.cost.toFixed(2)} $</td><td><b>${escapeHTML(r.price)} $</b></td><td>${netCell(model, Number(r.price), r.cost, shippingOf(p))}</td></tr>`).join("")}
       </tbody></table>
       ${lossNote(model, prepared.rows.map((r) => ({ price: Number(r.price), cost: r.cost })), shippingOf(p))}
       <p class="muted">Quantit\xE9 3 par variante. Le brouillon s\u2019ouvrira tout seul. Rien n\u2019est publi\xE9.</p>`,
        "Cr\xE9er le brouillon",
        async () => {
          await message({
            type: "LIBRARY_CREATE_DRAFT",
            token: prepared.token,
            reviewed: true
          });
          toast("Cr\xE9ation du brouillon lanc\xE9e. Il s\u2019ouvrira dans un onglet.");
        }
      );
    });
  }
  async function syncListing(p, inSeries = false, fromWatch = false) {
    let opened = false;
    await work(inSeries && series ? `${seriesLabel(series)} : lecture d\u2019AliExpress et de ton annonce eBay\u2026` : "Lecture du stock AliExpress et de ton annonce eBay\u2026", async () => {
      const preview = await message({ type: "LISTING_SYNC_PREVIEW", productId: p.id });
      const model = await currentProfitModel();
      let applied = false;
      const dialog = $("dialog");
      dialog.classList.add("sync");
      dialog.addEventListener(
        "close",
        () => {
          dialog.classList.remove("sync");
          if (!applied) void message({ type: "LISTING_SYNC_CANCEL", token: preview.token }).catch(() => {
          });
          if (inSeries && series) stepSeries(applied ? "sent" : "skipped");
        },
        { once: true }
      );
      const label = { in_stock: "En stock", out_of_stock: "Rupture", unknown: "Introuvable" };
      const links = preview.rows.map((_, i) => preview.links?.[i] ?? null);
      const typed = preview.rows.map(() => null);
      const typedPrices = preview.rows.map(() => null);
      const choiceKey = (values) => JSON.stringify(values);
      const effective = (i) => {
        const r = preview.rows[i];
        const link = links[i];
        const c = link ? preview.choices.find((x) => choiceKey(x.values) === choiceKey(link)) : void 0;
        return c ? { supplier: c.inStock ? "in_stock" : "out_of_stock", cost: c.cost, rulePrice: c.rulePrice ?? r.price, stockQuantity: c.inStock ? 3 : 0, linked: true } : { supplier: r.supplier, cost: r.cost, rulePrice: r.rulePrice, stockQuantity: r.stockQuantity, linked: false };
      };
      const quantityOf = (i, stock, zero) => {
        const e = effective(i);
        return typed[i] ?? (stock ? e.supplier === "unknown" && zero ? 0 : e.stockQuantity : preview.rows[i].quantity);
      };
      const r0Simple = preview.rows.length === 1 && !preview.rows[0].values.length;
      const options = (i) => `<option value="">${r0Simple ? "Quelle option AliExpress est cette annonce ?" : "M\xEAme nom (automatique)"}</option>` + preview.choices.map(
        (c, k) => `<option value="${k}"${links[i] && choiceKey(links[i]) === choiceKey(c.values) ? " selected" : ""}>${escapeHTML(c.values.join(" / ") || "Produit")} \xB7 ${c.inStock && c.cost ? `${c.cost.toFixed(2)} $` : "rupture"}</option>`
      ).join("");
      const byPhoto = preview.choices.some((c) => c.photo);
      let picking = null;
      const undo = [];
      const thumb = (url, cls = "f-thumb") => url ? `<img class="${cls}" src="${escapeHTML(safeUrl(url))}" alt="" loading="lazy" referrerpolicy="no-referrer">` : "";
      const ebayPhoto = (i) => preview.rows[i].photo ?? (r0Simple ? photo(p) : null);
      const linkedPhoto = (i) => {
        const link = links[i];
        return link ? preview.choices.find((c) => choiceKey(c.values) === choiceKey(link))?.photo : null;
      };
      const nextToPick = (i) => {
        const free = (k) => k !== i && effective(k).supplier === "unknown";
        const after = preview.rows.findIndex((_, k) => k > i && free(k));
        return after >= 0 ? after : preview.rows.findIndex((_, k) => free(k));
      };
      const picker = (i) => {
        const used = new Set(links.filter((l, k) => l && k !== i).map((l) => choiceKey(l)));
        const tiles = preview.choices.map((c, k) => {
          const on = links[i] && choiceKey(links[i]) === choiceKey(c.values);
          const taken = !on && used.has(choiceKey(c.values));
          return `<button type="button" class="f-tile${on ? " on" : ""}${taken ? " used" : ""}${c.inStock ? "" : " out"}" data-i="${i}" data-k="${k}" title="${escapeHTML(c.values.join(" / "))}">${on ? `<i class="f-check">\u2713</i>` : ""}
          ${thumb(c.photo, "") || `<span class="f-nophoto">\u{1F4F7}</span>`}
          <b>${escapeHTML(c.values.join(" / ") || "Produit")}</b>
          <small>${c.inStock && c.cost ? `${c.cost.toFixed(2)} $` : "rupture"}${used.has(choiceKey(c.values)) ? " \xB7 d\xE9j\xE0 prise" : ""}</small>
        </button>`;
        });
        return `<tr class="f-picker"><td colspan="5"><div class="f-picker-in">
        <div class="f-ebay">${thumb(ebayPhoto(i), "") || `<span class="f-nophoto">\u{1F4F7}</span>`}<small>Ton annonce eBay</small><b>${escapeHTML(preview.rows[i].values.join(" / ") || "Produit")}</b></div>
        <div><p class="f-picker-title">Clique la m\xEAme photo chez AliExpress</p><div class="f-tiles">${tiles.join("")}</div>
        <p class="f-picker-end">${links[i] ? `\u2713 Choisi. ` : ""}${nextToPick(i) < 0 ? "Toutes les variantes ont leur option. " : ""}${nextToPick(i) >= 0 ? `<button type="button" class="btn f-pick-next" data-i="${i}">Variante suivante \u2192</button> ` : ""}${undo.length ? `<button type="button" class="btn ghost f-undo">\u21A9 Annuler le dernier choix</button> ` : ""}${links[i] ? `<button type="button" class="link-button f-unlink" data-i="${i}">${r0Simple ? "Enlever ce choix" : "Revenir \xE0 \xAB m\xEAme nom \xBB"}</button> \xB7 ` : ""}<button type="button" class="link-button f-pick-close">Fermer</button></p></div>
      </div></td></tr>`;
      };
      const table = (stock, prices2, zero = false) => {
        const rows = preview.rows.map((r, i) => {
          const e = effective(i);
          const qty = quantityOf(i, stock, zero);
          const price = typedPrices[i] ?? (prices2 ? e.rulePrice : r.price);
          const diff = qty !== r.quantity || Number(price) !== Number(r.price);
          const pick = preview.choices.length && (preview.rows.length > 1 || preview.choices.length > 1);
          return `<tr${diff ? ' style="font-weight:600"' : ""}><td><span class="f-name">${thumb(ebayPhoto(i))}${escapeHTML(r.values.join(" / ") || "Produit")}</span></td>
          <td>${e.linked ? thumb(linkedPhoto(i)) : ""}<span class="${e.supplier === "in_stock" ? "pos" : e.supplier === "out_of_stock" ? "neg" : "warn"}">${e.linked ? "\u{1F517} " : ""}${label[e.supplier]}${e.cost ? ` \xB7 ${e.cost.toFixed(2)} $` : ""}</span>
            ${pick && byPhoto ? `<br><button type="button" class="btn ghost f-pick-open" data-i="${i}" title="Choisir l\u2019option AliExpress \xE0 partir de sa photo">\u{1F5BC}\uFE0F ${e.linked ? "Changer" : "Choisir en photo"}</button>` : pick ? e.supplier === "unknown" || e.linked ? `<br><select class="f-link" data-i="${i}" style="max-width:230px;margin-top:4px;font-size:12px" title="Lier \xE0 une autre option AliExpress (renomm\xE9e)">${options(i)}</select>` : ` <button type="button" class="link-button f-link-open" data-i="${i}" title="Lier \xE0 une autre option AliExpress">\u{1F517}</button>` : ""}</td>
          <td style="white-space:nowrap">${r.quantity} \u2192 <input class="f-qty" data-i="${i}" type="number" min="0" max="999" step="1" value="${qty}" style="width:58px${typed[i] !== null ? ";border-color:var(--accent,#ff5f3a)" : ""}" title="Quantit\xE9 \xE0 mettre sur eBay (tu peux la changer)"></td>
          <td style="white-space:nowrap">${escapeHTML(r.price)} \u2192 <input class="f-price" data-i="${i}" type="text" inputmode="decimal" value="${escapeHTML(price)}" style="width:72px${typedPrices[i] !== null ? ";border-color:var(--accent,#ff5f3a)" : ""}" title="Prix \xE0 mettre sur eBay, en $ (tu peux le changer)"> $</td>
          <td>${netCell(model, Number(price), e.cost, preview.shipping)}</td></tr>${picking === i ? picker(i) : ""}`;
        });
        const n = preview.rows.filter((r, i) => {
          const e = effective(i);
          return quantityOf(i, stock, zero) !== r.quantity || Number(typedPrices[i] ?? (prices2 ? e.rulePrice : r.price)) !== Number(r.price);
        }).length;
        const note = lossNote(
          model,
          preview.rows.map((r, i) => ({ price: Number(typedPrices[i] ?? (prices2 ? effective(i).rulePrice : r.price)), cost: effective(i).cost })),
          preview.shipping
        );
        return { html: rows.join(""), n, note };
      };
      const unknown = preview.rows.filter((r) => r.supplier === "unknown").length;
      ask(
        `${inSeries && series ? `${seriesLabel(series)} \xB7 ` : ""}${preview.live ? "Mettre \xE0 jour mon annonce" : "Mettre \xE0 jour mon brouillon"}`,
        `<p><b>${escapeHTML(p.name)}</b></p>
       ${inSeries ? `<p class="muted">\xAB Annuler \xBB passe \xE0 l\u2019annonce suivante. <button type="button" class="link-button" id="f-series-stop">Arr\xEAter la s\xE9rie</button></p>` : ""}
       <label class="inline"><input type="checkbox" id="f-stock" checked> Stock : 3 si dispo chez AliExpress, 0 si rupture</label><br>
       <label class="inline"><input type="checkbox" id="f-prices"${preview.hasRule ? inSeries || fromWatch ? " checked" : "" : " disabled"}> Prix : appliquer ma r\xE8gle de prix aux co\xFBts du jour</label>
       <div id="f-scroll" style="max-height:${byPhoto ? 62 : 46}vh;overflow:auto"><table class="mini"><thead><tr><th>Variante eBay</th><th>AliExpress</th><th>Quantit\xE9</th><th>Prix</th><th>B\xE9n\xE9fice net</th></tr></thead><tbody id="f-rows"></tbody></table></div>
       <p id="f-count" class="muted"></p>
       <div id="f-profit"></div>
       ${unknown ? `<label class="inline warn"><input type="checkbox" id="f-zero"> <span id="f-unknown">${unknown}</span> variante(s) eBay introuvable(s) chez AliExpress (option retir\xE9e ?) : les mettre \xE0 0</label><br>` : ""}
       <p class="muted" style="font-size:12px">${byPhoto ? "\u{1F5BC}\uFE0F : si les noms ne sont pas les m\xEAmes, choisis la bonne option AliExpress \xE0 partir de sa photo" : "\u{1F517} : si AliExpress a renomm\xE9 une option, lie la variante eBay \xE0 la bonne option AliExpress"} (m\xE9moris\xE9 pour les prochaines mises \xE0 jour). La quantit\xE9 et le prix de chaque ligne se changent \xE0 la main si besoin (un prix tap\xE9 passe avant la r\xE8gle de prix).</p>
       <p class="muted">${preview.live ? "Les changements vont dans la r\xE9vision de ton annonce. eBay s\u2019ouvre ensuite : v\xE9rifie puis clique toi-m\xEAme \xAB Revise listing \xBB. Rien n\u2019est publi\xE9 sans toi." : "Les changements vont dans ton brouillon, qui s\u2019ouvre ensuite."}</p>`,
        "Envoyer \xE0 eBay",
        async () => {
          const stock = $("f-stock").checked;
          const prices2 = $("f-prices").checked;
          const zeroUnknown = !!document.querySelector("#f-zero")?.checked;
          const r = await message({
            type: "LISTING_SYNC_APPLY",
            token: preview.token,
            stock,
            prices: prices2,
            zeroUnknown,
            links,
            quantities: typed,
            typedPrices
          });
          applied = true;
          void message({ type: "WATCH_SENT", productId: p.id }).catch(() => {
          });
          toast(
            r.changed ? `${r.changed} variante(s) mise(s) \xE0 jour (${r.zero} mise(s) \xE0 0, ${r.restocked} remise(s) en stock). ${r.live ? "Clique \xAB Revise listing \xBB sur eBay pour valider." : ""}` : "Rien \xE0 changer : eBay est d\xE9j\xE0 \xE0 jour."
          );
        }
      );
      const render2 = () => {
        const box = document.getElementById("f-scroll");
        const top = box?.scrollTop ?? 0;
        const t = table(
          $("f-stock").checked,
          $("f-prices").checked,
          !!document.querySelector("#f-zero")?.checked
        );
        $("f-rows").innerHTML = t.html;
        $("f-profit").innerHTML = t.note;
        $("f-count").textContent = t.n ? `${t.n} variante(s) \xE0 modifier.` : "Aucun changement avec ces choix.";
        const left = preview.rows.filter((_, i) => effective(i).supplier === "unknown").length;
        if (document.getElementById("f-unknown")) $("f-unknown").textContent = String(left);
        if (box) box.scrollTop = top;
      };
      $("f-rows").addEventListener("change", (e) => {
        const el = e.target;
        const i = Number(el.dataset.i);
        if (!Number.isInteger(i)) return;
        if (el.classList.contains("f-link")) {
          const c = el.value === "" ? null : preview.choices[Number(el.value)];
          links[i] = c ? c.values : null;
        } else if (el.classList.contains("f-qty")) {
          const q = Number(el.value);
          typed[i] = el.value !== "" && Number.isInteger(q) && q >= 0 && q <= 999 ? q : null;
        } else if (el.classList.contains("f-price")) {
          typedPrices[i] = typedPrice(el.value);
        }
        render2();
      });
      const switchPicker = (i) => {
        const box = document.getElementById("f-scroll");
        const at = (el) => el && box ? el.getBoundingClientRect().top - box.getBoundingClientRect().top : null;
        const before = at(document.querySelector(".f-picker"));
        picking = i;
        render2();
        const after = at(document.querySelector(".f-picker"));
        if (box && before !== null && after !== null) box.scrollTop += after - before;
        const ebay = document.querySelector(".f-picker .f-ebay");
        ebay?.classList.add("f-flash");
        setTimeout(() => ebay?.classList.remove("f-flash"), 700);
      };
      const showPicker = (i) => {
        picking = i;
        render2();
        document.querySelector(".f-picker")?.previousElementSibling?.scrollIntoView({ block: "start" });
      };
      $("f-rows").addEventListener("click", (e) => {
        const t = e.target;
        const open = t.closest(".f-pick-open");
        if (open) return showPicker(picking === Number(open.dataset.i) ? null : Number(open.dataset.i));
        if (t.closest(".f-pick-close")) return showPicker(null);
        const unlink = t.closest(".f-unlink");
        if (unlink) {
          const i = Number(unlink.dataset.i);
          undo.push({ i, before: links[i] });
          links[i] = null;
          return render2();
        }
        const tile = t.closest(".f-tile");
        if (tile) {
          const i = Number(tile.dataset.i);
          const values = preview.choices[Number(tile.dataset.k)].values;
          if (!(links[i] && choiceKey(links[i]) === choiceKey(values))) {
            undo.push({ i, before: links[i] });
            links[i] = values;
          }
          const k = nextToPick(i);
          return k >= 0 ? switchPicker(k) : render2();
        }
        if (t.closest(".f-undo")) {
          const last = undo.pop();
          if (!last) return;
          links[last.i] = last.before;
          return picking === last.i ? render2() : switchPicker(last.i);
        }
        const next2 = t.closest(".f-pick-next");
        if (next2) {
          const k = nextToPick(Number(next2.dataset.i));
          return k >= 0 ? switchPicker(k) : showPicker(null);
        }
        const b = t.closest(".f-link-open");
        if (!b) return;
        const select = Object.assign(document.createElement("select"), { className: "f-link", title: "Lier \xE0 une autre option AliExpress (renomm\xE9e)" });
        select.dataset.i = b.dataset.i;
        select.style.cssText = "max-width:230px;margin-top:4px;font-size:12px";
        select.innerHTML = options(Number(b.dataset.i));
        b.replaceWith(document.createElement("br"), select);
        select.focus();
      });
      $("f-stock").addEventListener("change", render2);
      $("f-prices").addEventListener("change", render2);
      document.querySelector("#f-zero")?.addEventListener("change", render2);
      render2();
      opened = true;
      if (!inSeries) return;
      document.getElementById("f-series-stop")?.addEventListener("click", () => {
        const s = series;
        series = null;
        dialog.close();
        if (s) toast(seriesSummary(s, true));
      });
      if (!unknown && !table(true, preview.hasRule).n) dialog.close();
    });
    return opened;
  }
  function stepSeries(result) {
    if (!series) return;
    series = seriesDone(series, result);
    setTimeout(() => void runSeries(), 0);
  }
  async function autoSync(p) {
    let result = "failed";
    await work(`${series ? seriesLabel(series) : ""} : ${p.name.slice(0, 60)}\u2026`, async () => {
      const preview = await message({ type: "LISTING_SYNC_PREVIEW", productId: p.id });
      const r = await message({
        type: "LISTING_SYNC_APPLY",
        token: preview.token,
        stock: true,
        prices: preview.hasRule,
        zeroUnknown: false,
        links: preview.links,
        quiet: true,
        lower: series?.lower === true
      });
      result = r.changed ? "sent" : "skipped";
      void message({ type: "WATCH_SENT", productId: p.id }).catch(() => {
      });
    });
    return result;
  }
  async function runSeries() {
    if (!series) return;
    const id = seriesNext(series);
    const p = products.find((x) => x.id === id);
    if (seriesBlocked(series) || !id) {
      toast(seriesSummary(series, true), seriesBlocked(series));
      series = null;
      showBulkBar();
      return;
    }
    if (series.auto) {
      if (bulkStop) {
        const s = series;
        series = null;
        showBulkBar();
        toast(seriesSummary(s, true));
        return;
      }
      showBulkBar();
      stepSeries(p ? await autoSync(p) : "failed");
      return;
    }
    if (!p || !await syncListing(p, true)) stepSeries("failed");
  }
  var bulkStop = false;
  function showBulkBar() {
    let bar = document.getElementById("bulk-bar");
    if (!series?.auto) {
      bar?.remove();
      bulkStop = false;
      return;
    }
    if (!bar) {
      bar = document.createElement("div");
      bar.id = "bulk-bar";
      bar.style.cssText = "position:fixed;left:50%;bottom:20px;transform:translateX(-50%);z-index:1000;display:flex;gap:12px;align-items:center;padding:10px 16px;border-radius:12px;background:var(--panel,#1f1f24);border:1px solid var(--line,#444);box-shadow:0 8px 30px rgba(0,0,0,.35)";
      document.body.append(bar);
      bar.addEventListener("click", (e) => {
        if (!e.target.closest("#bulk-stop")) return;
        bulkStop = true;
        showBulkBar();
      });
    }
    bar.innerHTML = bulkStop ? `<b>\u23F9 Arr\xEAt apr\xE8s l\u2019annonce en cours\u2026</b>` : `<b>\u26A1 ${escapeHTML(seriesLabel(series))}</b><button class="btn small" id="bulk-stop" type="button" title="Termine l\u2019annonce en cours puis s\u2019arr\xEAte">\u23F9 Stop</button>`;
  }
  function startBulk(ids) {
    if (busy || series) return toast("Une mise \xE0 jour est d\xE9j\xE0 en cours.", true);
    const list2 = ids.filter((id) => products.some((p) => p.id === id)).slice(0, SERIES_MAX);
    if (!list2.length) return toast("Aucune annonce \xE0 mettre \xE0 jour.", true);
    ask(
      "\u26A1 Tout mettre \xE0 jour",
      `<p>AurOEBay pr\xE9pare <b>${list2.length} annonce${list2.length > 1 ? "s" : ""}</b> l\u2019une apr\xE8s l\u2019autre (${SERIES_MAX} au maximum par tour), sans fen\xEAtre \xE0 valider :</p>
     <ul>
       <li>stock : 3 si dispo chez AliExpress, 0 si rupture ;</li>
       <li>prix : ta r\xE8gle de prix, <span id="bulk-way"><b>seulement \xE0 la hausse</b> (un prix n\u2019est jamais baiss\xE9)</span> ;</li>
       <li>les variantes introuvables chez AliExpress ne changent pas.</li>
     </ul>
     <label class="inline"><input type="checkbox" id="bulk-lower"${lowerPref() ? " checked" : ""}> Baisser aussi les prix quand le fournisseur a baiss\xE9 les siens</label>
     <p>Chaque annonce modifi\xE9e reste ouverte dans un onglet eBay en arri\xE8re-plan. \xC0 la fin, passe d\u2019onglet en onglet et clique toi-m\xEAme <b>\xAB Revise listing \xBB</b>. Rien n\u2019est publi\xE9 sans toi.</p>
     <p class="muted">${rule ? "" : "\u26A0 Aucune r\xE8gle de prix : seul le stock changera. "}Ne ferme pas cette page pendant la pr\xE9paration. Le bouton \u23F9 Stop, en bas de la page, arr\xEAte apr\xE8s l\u2019annonce en cours.</p>`,
      "Commencer",
      async () => {
        const lower = $("bulk-lower").checked;
        lowerPref(lower);
        series = { ...startSeries(list2, true), ...lower ? { lower: true } : {} };
        bulkStop = false;
        setTimeout(() => void runSeries(), 0);
      }
    );
    const way = () => $("bulk-way").innerHTML = $("bulk-lower").checked ? "<b>\xE0 la hausse comme \xE0 la baisse</b> (le prix suit le co\xFBt du fournisseur)" : "<b>seulement \xE0 la hausse</b> (un prix n\u2019est jamais baiss\xE9)";
    $("bulk-lower").addEventListener("change", way);
    way();
  }
  function lowerPref(value) {
    try {
      if (value !== void 0) localStorage.setItem("bulkLower", value ? "1" : "0");
      return localStorage.getItem("bulkLower") === "1";
    } catch {
      return false;
    }
  }
  function renderSeriesBar() {
    const bar = $("series-bar");
    bar.hidden = !selecting;
    if (!selecting) return;
    const n = chosen.size;
    bar.innerHTML = `<b>${n} annonce${n > 1 ? "s" : ""} coch\xE9e${n > 1 ? "s" : ""}</b>
    <button class="btn ghost small" id="series-all" type="button">Tout cocher ici</button>
    <button class="btn primary small" id="series-start" type="button"${n ? "" : " disabled"}>Commencer</button>
    <button class="link-button" id="series-cancel" type="button">Annuler</button>
    <span class="muted">${SERIES_MAX} au maximum. Pour chacune : tu relis, tu envoies, puis tu cliques \xAB Revise listing \xBB sur eBay.${rule ? "" : " Sans r\xE8gle de prix, seul le stock change."}</span>`;
  }
  function stopSelecting() {
    selecting = false;
    chosen.clear();
    render();
  }
  $("series-toggle").addEventListener("click", () => selecting ? stopSelecting() : (selecting = true, render()));
  $("series-bar").addEventListener("click", (e) => {
    const id = e.target.closest("button")?.id;
    if (id === "series-cancel") stopSelecting();
    if (id === "series-all") {
      shownSyncable.slice(0, SERIES_MAX).forEach((x) => chosen.add(x));
      render();
    }
    if (id === "series-start" && chosen.size && !busy) {
      series = startSeries([...chosen]);
      stopSelecting();
      void runSeries();
    }
  });
  $("list").addEventListener("change", (e) => {
    const box = e.target;
    if (!box.dataset.series) return;
    if (box.checked && chosen.size >= SERIES_MAX) {
      box.checked = false;
      toast(`${SERIES_MAX} annonces au maximum par s\xE9rie.`, true);
      return;
    }
    if (box.checked) chosen.add(box.dataset.series);
    else chosen.delete(box.dataset.series);
    renderSeriesBar();
  });
  function rename(p) {
    ask(
      "Renommer",
      `<label>Nom<input id="f-name" required maxlength="200" value="${escapeHTML(p.name)}" /></label>`,
      "Enregistrer",
      async () => {
        await library2({
          action: "patch-product",
          productId: p.id,
          expectedRevision: p.revision,
          patch: { name: $("f-name").value.trim() }
        });
        await load();
      }
    );
  }
  function addReference(p) {
    ask(
      "Ajouter la r\xE9f\xE9rence eBay",
      `<label>Annonce eBay<input id="f-ref" type="url" required placeholder="https://www.ebay.com/itm/\u2026" /></label>`,
      "Enregistrer",
      async () => {
        await library2({
          action: "link-ebay",
          productId: p.id,
          role: "reference",
          url: $("f-ref").value.trim()
        });
        await load();
      }
    );
  }
  function suppliersDialog(p) {
    const supplierCosts = (s) => (s.source.variantScan?.costs ?? s.source.variantCosts ?? []).filter((c) => c.currency === "USD" && c.cost > 0).map((c) => c.cost);
    const rows = p.suppliers.map(
      (s) => `<div class="supplier-row">
        <label class="inline"><input type="radio" name="f-primary" value="${escapeHTML(s.id)}" ${s.id === (p.primarySupplierId ?? p.suppliers[0]?.id) ? "checked" : ""}> <b>Principal</b></label>
        <div class="supplier-main"><a href="${escapeHTML(s.url)}" target="_blank" rel="noopener noreferrer">${escapeHTML((s.source.title || s.url).slice(0, 90))} \u2197</a>
        <small class="muted">${escapeHTML(s.source.supplierNames.join(" \xB7 ") || "AliExpress")} \xB7 co\xFBt ${escapeHTML(range(supplierCosts(s)))} \xB7 lu le ${escapeHTML(date(s.source.capturedAt))}</small></div>
        <label class="inline"><input type="checkbox" class="f-remove" value="${escapeHTML(s.id)}"> retirer</label>
      </div>`
    ).join("");
    ask(
      `Fournisseurs \xB7 ${p.name.slice(0, 60)}`,
      `${rows || '<p class="muted">Aucun fournisseur.</p>'}
     <label>Ajouter un fournisseur (lien AliExpress)<input id="f-new-supplier" type="url" placeholder="https://www.aliexpress.us/item/\u2026html" /></label>
     <p class="muted">Le fournisseur <b>principal</b> sert pour les brouillons, \xAB Mettre \xE0 jour stock/prix \xBB et la surveillance. Les autres restent en secours : passe-en un en principal si le premier est en rupture ou plus cher.</p>`,
      "Enregistrer",
      async () => {
        let product = p;
        const reload = async () => {
          product = await library2({ action: "get-product", productId: p.id });
        };
        const url = $("f-new-supplier").value.trim();
        const chosen2 = document.querySelector('input[name="f-primary"]:checked')?.value ?? null;
        const removed = [...document.querySelectorAll(".f-remove:checked")].map((b) => b.value);
        if (url) {
          $("dialog-ok").textContent = "Lecture AliExpress\u2026";
          const source = await message({
            type: "READ_SUPPLIER_LINK",
            url: aliProductURL(url),
            prices: true,
            background: true
          });
          await library2({ action: "save-source", source, productId: p.id });
          await reload();
        }
        for (const id of removed)
          if (product.suppliers.some((s) => s.id === id)) {
            await library2({ action: "remove-supplier", productId: p.id, supplierId: id });
            await reload();
          }
        if (chosen2 && !removed.includes(chosen2) && chosen2 !== product.primarySupplierId)
          await library2({ action: "patch-product", productId: p.id, patch: { primarySupplierId: chosen2 } });
        await load();
        toast("Fournisseurs enregistr\xE9s.");
      }
    );
  }
  function linkOwn(p) {
    const current = p.ownListings.map(
      (l, i) => `<label class="inline"><input type="checkbox" class="f-own" value="${i}" checked> ${l.kind === "draft" ? "Brouillon" : "Annonce"} : <a href="${escapeHTML(l.url)}" target="_blank" rel="noopener noreferrer">${escapeHTML(l.url.replace("https://www.ebay.com", ""))}</a></label>`
    ).join("");
    ask(
      "Relier mon annonce eBay",
      `<label>Lien de mon annonce (ou brouillon) eBay<input id="f-own" type="url" placeholder="https://www.ebay.com/itm/\u2026" /></label>
     ${current ? `<p class="muted">D\xE9j\xE0 reli\xE9s (d\xE9coche pour d\xE9lier) :</p>${current}` : '<p class="muted">Aucune annonce reli\xE9e pour l\u2019instant.</p>'}`,
      "Enregistrer",
      async () => {
        const url = $("f-own").value.trim();
        for (const box of document.querySelectorAll(".f-own"))
          if (!box.checked)
            await library2({
              action: "unlink-ebay",
              productId: p.id,
              role: "own",
              url: p.ownListings[Number(box.value)].url
            });
        if (url)
          await library2({ action: "link-ebay", productId: p.id, role: "own", url, title: p.name.slice(0, 200) });
        await load();
        toast(url ? "Annonce eBay reli\xE9e au produit et \xE0 son fournisseur." : "Liens eBay mis \xE0 jour.");
      }
    );
  }
  async function refresh(p) {
    const s = primary(p);
    if (!s) return;
    await work("Relecture AliExpress\u2026", async () => {
      const source = await message({
        type: "READ_SUPPLIER_LINK",
        url: s.url,
        prices: true,
        background: true
      });
      await library2({
        action: "save-source",
        source,
        productId: p.id,
        expectedRevision: p.revision
      });
      await load();
      toast("Fournisseur relu : photos, description et prix \xE0 jour.");
    });
  }
  async function archive(p) {
    await work(p.archived ? "Restauration\u2026" : "Archivage\u2026", async () => {
      await library2({
        action: "patch-product",
        productId: p.id,
        expectedRevision: p.revision,
        patch: { archived: !p.archived }
      });
      await load();
      toast(p.archived ? "Produit restaur\xE9." : "Produit archiv\xE9.");
    });
  }
  $("list").addEventListener("click", (e) => {
    const button = e.target.closest(
      "button[data-act]"
    );
    if (!button) return;
    const id = button.closest(".row")?.dataset.id;
    const p = products.find((x) => x.id === id);
    if (!p) return;
    button.closest("details")?.removeAttribute("open");
    const act = button.dataset.act;
    if (act === "create") void createDraft(p);
    if (act === "sync") void syncListing(p);
    if (act === "market") void marketDialog(p);
    if (act === "revive") void reviveDialog(p);
    if (act === "rename") rename(p);
    if (act === "reference") addReference(p);
    if (act === "own") linkOwn(p);
    if (act === "suppliers") suppliersDialog(p);
    if (act === "refresh") void refresh(p);
    if (act === "archive") void archive(p);
  });
  $("tabs").addEventListener("click", (e) => {
    const button = e.target.closest(
      "button[data-tab]"
    );
    if (!button) return;
    tab = button.dataset.tab;
    document.querySelectorAll("#tabs button").forEach((b) => b.classList.toggle("active", b === button));
    render();
  });
  $("search").addEventListener("input", render);
  $("add").addEventListener("click", addProduct);
  $("export").addEventListener(
    "click",
    () => void work("Pr\xE9paration de la sauvegarde\u2026", async () => {
      const url = URL.createObjectURL(
        new Blob([JSON.stringify(await fullBackup())], { type: "application/json" })
      );
      const a = document.createElement("a");
      a.href = url;
      a.download = `auroebay-sauvegarde-${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.json`;
      a.click();
      setTimeout(() => URL.revokeObjectURL(url), 2e3);
      toast("Sauvegarde compl\xE8te t\xE9l\xE9charg\xE9e (produits, ventes, liens).");
    })
  );
  $("import").addEventListener("click", () => $("import-file").click());
  $("import-file").addEventListener("change", () => {
    const file = $("import-file").files?.[0];
    if (!file) return;
    void work("Import de la sauvegarde\u2026", async () => {
      const text = await restoreBackup(JSON.parse(await file.text()));
      await load();
      toast(text);
    });
    $("import-file").value = "";
  });
  var autoBackup = setupAutoBackup($("backup-bar"));
  setupDraftBatch($("draft-batch"));
  $("draft-batch").addEventListener("click", () => $("draft-batch").closest("details")?.removeAttribute("open"));
  $("import-listings").addEventListener("click", async () => {
    $("import-listings").closest("details")?.removeAttribute("open");
    const map2 = (await chrome.storage.local.get("listingSuppliers:v1"))["listingSuppliers:v1"] ?? {};
    const plan = planListingImport(map2, products);
    const room = 1500 - products.length;
    ask(
      "Importer mes annonces eBay",
      `<p>AurOEBay conna\xEEt <b>${Object.keys(map2).length}</b> annonce(s) eBay avec leur lien AliExpress (relev\xE9s dans Seller Hub).</p>
     <ul>
       <li><b>${plan.create.length}</b> fiche(s) \xE0 cr\xE9er</li>
       <li><b>${plan.link.length}</b> annonce(s) \xE0 rattacher \xE0 une fiche existante (m\xEAme produit AliExpress)</li>
       <li>${plan.already} d\xE9j\xE0 dans ta biblioth\xE8que</li>
     </ul>
     <p class="muted">Import rapide : seul le titre eBay est lu. Le produit AliExpress est not\xE9 \xAB \xE0 lire \xBB : il sera lu par \xAB Relire AliExpress \xBB, \xAB Mettre \xE0 jour stock/prix \xBB ou la surveillance. Les annonces termin\xE9es sont ignor\xE9es. Rien d\u2019existant n\u2019est modifi\xE9.</p>
     ${plan.create.length > room ? `<p class="error">Place disponible : ${room} fiche(s) seulement (limite 1 500).</p>` : ""}
     <p id="import-progress" class="muted"></p>`,
      plan.create.length + plan.link.length ? "Importer" : "Fermer",
      async () => {
        if (!plan.create.length && !plan.link.length) return;
        if (plan.create.length > room) throw Error("Trop de fiches pour la limite de la biblioth\xE8que.");
        busy = true;
        try {
          const r = await runListingImport(plan, (text) => $("import-progress").textContent = text);
          await load();
          toast(
            `${r.created} fiche(s) cr\xE9\xE9e(s), ${r.linked} annonce(s) rattach\xE9e(s)` + (r.ended.length ? `, ${r.ended.length} termin\xE9e(s) ignor\xE9e(s)` : "") + (r.failed.length ? `, ${r.failed.length} \xE9chec(s)` : "") + ".",
            r.failed.length > 0
          );
        } finally {
          busy = false;
        }
      }
    );
  });
  $("auto-backup").addEventListener("click", async () => {
    $("auto-backup").closest("details")?.removeAttribute("open");
    const s = await backupStatus();
    const when3 = s.at ? new Date(s.at).toLocaleString("fr-FR", { dateStyle: "short", timeStyle: "short" }) : "jamais";
    ask(
      "Sauvegarde automatique",
      `<p>AurOEBay \xE9crit une sauvegarde compl\xE8te (produits, fournisseurs, ventes, liens, r\xE8gle de prix \u2014 jamais ta cl\xE9 OpenAI) dans un dossier de ton Mac. Choisis un dossier <b>iCloud Drive</b> (ou Google Drive) : il est envoy\xE9 en ligne automatiquement.</p>
     <p class="muted">\xC9crite \xE0 l\u2019ouverture de \xAB Mes produits \xBB / \xAB Ventes \xBB (toutes les 6 h) et apr\xE8s chaque changement. Fichier <b>auroebay-sauvegarde.json</b> + une copie par jour (14 derniers jours). Pour restaurer : Sauvegarde \u2192 Importer une sauvegarde.</p>
     <p>${s.folder ? `Dossier : <b>${escapeHTML(s.folder)}</b> \xB7 derni\xE8re sauvegarde : ${escapeHTML(when3)}${s.permission !== "granted" ? " \xB7 <span class='warn'>acc\xE8s \xE0 r\xE9autoriser</span>" : ""}${s.error ? ` \xB7 <span class='warn'>${escapeHTML(s.error)}</span>` : ""}` : "Aucun dossier choisi."}</p>
     ${s.folder ? '<label class="inline"><input type="checkbox" id="f-backup-stop"> arr\xEAter la sauvegarde automatique</label>' : ""}`,
      s.folder ? "Sauvegarder maintenant" : "Choisir le dossier",
      async () => {
        if (document.getElementById("f-backup-stop")?.checked) {
          await stopBackup();
          toast("Sauvegarde automatique arr\xEAt\xE9e (les fichiers d\xE9j\xE0 \xE9crits restent).");
          return;
        }
        if (!s.folder) {
          const name = await chooseFolder();
          toast(`Sauvegarde automatique activ\xE9e dans \xAB ${name} \xBB.`);
        } else {
          const handle = await backupFolder();
          if (handle && await handle.queryPermission({ mode: "readwrite" }) !== "granted")
            await handle.requestPermission({ mode: "readwrite" });
          await writeBackup(true);
          toast("Sauvegarde \xE9crite.");
        }
        await autoBackup.refresh();
      }
    );
  });
  if (location.hash === "#backup") setTimeout(() => $("auto-backup").click(), 300);
  chrome.storage.onChanged.addListener((changes, area) => {
    if (changes.libraryRevision && !busy) void load().catch(() => {
    });
    if (area === "local" && changes.variantPricing)
      void loadRule().then(render);
    if (area === "local" && (changes["listingPrices:v1"] || changes["productShipping:v1"]))
      void loadListedPrices().then(render);
  });
  document.addEventListener("click", (e) => {
    document.querySelectorAll("details.menu[open]").forEach((menu) => {
      if (!menu.contains(e.target)) menu.open = false;
    });
  });
  document.addEventListener(
    "error",
    (e) => {
      const img = e.target;
      if (img.tagName === "IMG") img.style.visibility = "hidden";
    },
    true
  );
  setupTheme();
  setupCompetitorsPanel($("rivals"), toast);
  var watchPanel = setupWatchPanel(
    (productId) => {
      const p = products.find((x) => x.id === productId);
      if (p) void syncListing(p, false, true);
      else toast("Produit introuvable dans la biblioth\xE8que.", true);
    },
    (productId) => {
      const p = products.find((x) => x.id === productId);
      return p ? primary(p)?.url : void 0;
    },
    // « 🔁 Passer en principal » (fournisseur de secours).
    async (productId, supplierId) => {
      try {
        await library2({ action: "patch-product", productId, patch: { primarySupplierId: supplierId } });
        await load();
        watchPanel.render();
        toast("Fournisseur principal chang\xE9 : clique \xAB Mettre \xE0 jour stock/prix \xBB pour reporter ses prix et son stock sur eBay.");
      } catch (e) {
        toast(e instanceof Error ? e.message : String(e), true);
      }
    },
    startBulk
  );
  void Promise.all([loadRule(), loadListedPrices()]).then(load).catch((e) => toast(e instanceof Error ? e.message : String(e), true));
})();
