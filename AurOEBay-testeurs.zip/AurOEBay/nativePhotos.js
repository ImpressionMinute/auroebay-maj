"use strict";
(() => {
  // src/core/messaging.ts
  async function message(body) {
    const reply = await chrome.runtime.sendMessage(body);
    if (!reply?.ok)
      throw Error(reply?.error ?? "AurOEBay ne r\xE9pond pas. Recharge la page.");
    return reply.data;
  }

  // src/core/text.ts
  var delay = (ms) => new Promise((r) => setTimeout(r, ms));

  // src/ebay/variantPhotoInput.ts
  function variantPhotoInput(doc) {
    const input = [
      ...doc.querySelectorAll('input[type="file"]')
    ].at(-1);
    return input && input.id && !input.disabled ? input : null;
  }
  function variantPhotoValue(inputId, values) {
    const matches = [...new Set(values)].filter(
      (value) => value.replaceAll(" ", "_") === inputId
    );
    return matches.length === 1 ? matches[0] : null;
  }

  // src/core/staleContext.ts
  var stale = (reason) => /Extension context invalidated/i.test(reason instanceof Error ? reason.message : String(reason));
  var extensionAlive = () => {
    try {
      return !!chrome.runtime?.id;
    } catch {
      return false;
    }
  };
  function quietStaleContext(win = window) {
    win.addEventListener("error", (e) => {
      if (stale(e.error ?? e.message)) e.preventDefault();
    });
    win.addEventListener("unhandledrejection", (e) => {
      if (stale(e.reason)) e.preventDefault();
    });
  }

  // src/ebay/nativePhotoContent.ts
  quietStaleContext();
  var busy = false;
  var enabled = true;
  if (new URL(location.href).searchParams.get("windowName") === "photo-iframe-picupload-variations") {
    let registeredValue = "";
    const register = () => {
      if (!extensionAlive()) return watcher.disconnect();
      const value = variantPhotoInput(document)?.id;
      if (!value || value === registeredValue) return;
      registeredValue = value;
      void message({
        type: "NATIVE_FRAME_REGISTER",
        kind: "photo",
        inputId: value
      }).catch(() => {
        if (registeredValue === value) registeredValue = "";
      });
    };
    const watcher = new MutationObserver(register);
    watcher.observe(document.documentElement, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ["id"]
    });
    register();
  }
  chrome.runtime.onMessage.addListener((msg, sender, reply) => {
    if (sender.id !== chrome.runtime.id) return;
    if (msg?.type === "SETTINGS_CHANGED") {
      void message({ type: "PUBLIC_SETTINGS" }).then((s) => {
        enabled = s.enabled;
      });
      return;
    }
    if (msg?.type !== "NATIVE_PHOTO_RUN" || !sender.url?.startsWith(chrome.runtime.getURL("")) || new URL(location.href).searchParams.get("windowName") !== "photo-iframe-picupload-variations")
      return;
    if (busy) {
      reply({ ok: false, error: "Envoi de photo en cours." });
      return;
    }
    busy = true;
    void (async () => {
      const job = await message({ type: "NATIVE_JOB" });
      enabled = (await message({ type: "PUBLIC_SETTINGS" })).enabled;
      if (!enabled || !job?.supplierPlan || job.id !== msg.id || job.stage !== "filling" || !job.product.variantImages.some(
        (i) => i.url === msg.url && i.value === msg.value
      ))
        throw Error("Photo de variante non autoris\xE9e.");
      const until = Date.now() + 1e4;
      const selectedValue = (input2) => input2 && variantPhotoValue(
        input2.id,
        job.product.variantImages.map((i) => i.value)
      );
      let input = null;
      while (Date.now() < until) {
        input = variantPhotoInput(document);
        if (selectedValue(input) === msg.value) break;
        await delay(150);
      }
      if (!input || selectedValue(input) !== msg.value || document.querySelector(".uploader-thumbnails-ux__image--ready"))
        throw Error("Galerie de la variante modifi\xE9e ou non reconnue.");
      const photo = await message({
        type: "NATIVE_IMAGE",
        id: job.id,
        url: msg.url
      });
      const active = () => enabled && variantPhotoInput(document) === input && selectedValue(input) === msg.value;
      if (!active()) throw Error("Photo interrompue : option chang\xE9e.");
      const data = Uint8Array.from(atob(photo.data), (c) => c.charCodeAt(0));
      const file = new File([data], "auro-variant.jpg", { type: photo.mime });
      const bitmap = await createImageBitmap(file);
      const small = bitmap.width < 200 || bitmap.height < 200;
      bitmap.close();
      if (small) throw Error("Photo de variante trop petite.");
      if (!active()) throw Error("Photo interrompue : option chang\xE9e.");
      const transfer = new DataTransfer();
      transfer.items.add(file);
      input.files = transfer.files;
      input.dispatchEvent(new Event("change", { bubbles: true }));
      const limit = Date.now() + 45e3;
      while (Date.now() < limit) {
        if (!active()) throw Error("Photo interrompue : option chang\xE9e.");
        if (document.querySelectorAll(
          '.uploader-thumbnails-ux__image--ready button.uploader-thumbnails-ux__image[style*="background-image"]'
        ).length === 1 && !document.querySelector('[role="progressbar"]'))
          return true;
        await delay(250);
      }
      throw Error("Photo de variante non confirm\xE9e par eBay.");
    })().then((data) => reply({ ok: true, data })).catch((e) => reply({ ok: false, error: e.message })).finally(() => {
      busy = false;
    });
    return true;
  });
})();
