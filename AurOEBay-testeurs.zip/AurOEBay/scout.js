"use strict";
(() => {
  // src/core/text.ts
  var escapeHTML = (s) => s.replace(
    /[&<>"']/g,
    (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]
  );
  function redact(s) {
    return s.replace(/\bsk-[A-Za-z0-9_-]+/g, "[REDACTED_KEY]").replace(/Bearer\s+\S+/gi, "Bearer [REDACTED]").replace(/[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}/g, "[EMAIL]").replace(/https?:\/\/[^\s<>"']+/g, "[URL]");
  }

  // src/core/messaging.ts
  async function message(body2) {
    const reply = await chrome.runtime.sendMessage(body2);
    if (!reply?.ok)
      throw Error(reply?.error ?? "AurOEBay ne r\xE9pond pas. Recharge la page.");
    return reply.data;
  }

  // src/core/license.ts
  var LICENSE_KEY = "license:v1";
  var CHECKOUT_URL = "https://auroebay.lemonsqueezy.com/checkout/buy/1b765c13-2f39-4847-82fa-e7950d112d63";
  var TRIAL_DAYS = 15;
  var GRACE_DAYS = 3;
  var DAY = 864e5;
  var OWNER_EXTENSION_ID = "bbedjpfnnkjadfjpbbmppikmgocoglfh";
  var SKEW = 10 * 6e4;
  var extensionId = () => globalThis.chrome?.runtime?.id ?? "";
  var ownerInstall = () => extensionId() === OWNER_EXTENSION_ID;
  function licenseActive(s, now = Date.now()) {
    if (!s) return false;
    if (s.owner) return ownerInstall();
    if (s.status === "trial") return trialActive(s, now);
    if (!s.key || s.status !== "active" || !s.checkedAt) return false;
    if (s.checkedAt > now + SKEW || (s.triedAt ?? 0) > now + SKEW) return false;
    if (typeof s.expiresAt === "string" && Date.parse(s.expiresAt) < now - DAY) return false;
    return now - s.checkedAt < GRACE_DAYS * DAY;
  }
  var PEPPER = "AurOEBay\xB7licence\xB7v1\xB74f1c9e27b8d36a05";
  var SEALED = ["owner", "key", "instanceId", "status", "checkedAt", "triedAt", "email", "expiresAt", "error", "trialUntil", "trialId"];
  async function hmac(text) {
    const enc = new TextEncoder();
    const raw = await crypto.subtle.digest("SHA-256", enc.encode(PEPPER + "|" + extensionId()));
    const key = await crypto.subtle.importKey("raw", raw, { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
    const sig = await crypto.subtle.sign("HMAC", key, enc.encode(text));
    return [...new Uint8Array(sig)].map((b) => b.toString(16).padStart(2, "0")).join("");
  }
  var body = (s) => JSON.stringify(SEALED.map((k) => s[k] ?? null));
  async function sealValid(s) {
    if (!s || typeof s.seal !== "string") return false;
    try {
      return s.seal === await hmac(body(s));
    } catch {
      return false;
    }
  }
  async function trustedLicense(raw) {
    const s = raw && typeof raw === "object" ? raw : {};
    if (await sealValid(s)) return { state: s, sealed: true };
    if (s.owner === true && ownerInstall()) return { state: { owner: true }, sealed: false };
    if (typeof s.key === "string" && typeof s.instanceId === "string")
      return { state: { key: s.key, instanceId: s.instanceId, status: "unverified" }, sealed: false };
    return { state: {}, sealed: false };
  }
  async function readLicense() {
    const raw = (await chrome.storage.local.get(LICENSE_KEY))[LICENSE_KEY];
    return (await trustedLicense(raw)).state;
  }
  function trialActive(s, now = Date.now()) {
    if (typeof s.trialUntil !== "number" || now >= s.trialUntil) return false;
    if ((s.checkedAt ?? 0) > now + SKEW) return false;
    return s.trialUntil - now <= (TRIAL_DAYS + 1) * DAY;
  }
  var trialDaysLeft = (s, now = Date.now()) => s?.status === "trial" && trialActive(s, now) ? Math.ceil((s.trialUntil - now) / DAY) : 0;
  function licenseLabel(s, now = Date.now()) {
    if (s?.owner) return "Version propri\xE9taire : aucune licence n\xE9cessaire.";
    if (s?.status === "trial" && trialActive(s, now)) {
      const left = trialDaysLeft(s, now);
      const end = new Date(s.trialUntil).toLocaleDateString("fr-FR", { day: "numeric", month: "long" });
      return `Essai gratuit : encore ${left} jour${left > 1 ? "s" : ""} (jusqu\u2019au ${end}). Abonne-toi avant pour continuer sans coupure.`;
    }
    if (s?.status === "trial" || s?.status === "trial-ended") return "Ton essai gratuit est termin\xE9 : abonne-toi pour continuer. Tes donn\xE9es sont gard\xE9es.";
    if (!s?.key) return `Aucune cl\xE9 de licence : commence ton essai gratuit de ${TRIAL_DAYS} jours, puis colle la cl\xE9 re\xE7ue par e-mail.`;
    if (licenseActive(s, now)) return `Abonnement actif${s.email ? ` (${s.email})` : ""}.`;
    if (s.status === "unverified") return s.error ? `${s.error} Ta licence sera v\xE9rifi\xE9e d\xE8s le retour de la connexion.` : "V\xE9rification de ta licence aupr\xE8s de Lemon Squeezy\u2026";
    if (s.status === "active") return "Impossible de v\xE9rifier ta licence depuis plus de 3 jours : v\xE9rifie ta connexion internet.";
    if (s.status === "expired") return "Abonnement termin\xE9 : renouvelle-le pour r\xE9activer AurOEBay.";
    if (s.status === "disabled") return "Licence d\xE9sactiv\xE9e : contacte bonjour@impression-minute.fr.";
    return s.error ?? "Licence inactive.";
  }
  function versionBelow(version, than) {
    if (!version) return false;
    const a = version.split(".").map(Number);
    const b = than.split(".").map(Number);
    for (let i = 0; i < 3; i++) if ((a[i] ?? 0) !== (b[i] ?? 0)) return (a[i] ?? 0) < (b[i] ?? 0);
    return false;
  }

  // src/ui/license.ts
  var read = readLicense;
  function licenseBanner(doc = document) {
    if (/\/(welcome|options)\.html$/.test(location.pathname)) return;
    const show = async () => {
      doc.getElementById("lic-banner")?.remove();
      const s = await read();
      const left = trialDaysLeft(s);
      if (left > 0 && left <= 3) {
        const note = doc.createElement("div");
        note.id = "lic-banner";
        note.className = "lic-banner";
        note.innerHTML = `<span>\u23F3 ${escapeHTML(licenseLabel(s))}</span>
        <span><a class="btn small primary" href="${CHECKOUT_URL}" target="_blank" rel="noopener">S\u2019abonner</a> <a class="btn small secondary" href="welcome.html">Entrer ma cl\xE9</a></span>`;
        doc.body.prepend(note);
        return;
      }
      if (licenseActive(s)) return;
      const bar = doc.createElement("div");
      bar.id = "lic-banner";
      bar.className = "lic-banner";
      bar.innerHTML = `<span>\u{1F512} ${escapeHTML(licenseLabel(s))} AurOEBay est en pause ; tes donn\xE9es restent ici.</span>
      <span><a class="btn small primary" href="welcome.html">Entrer ma cl\xE9</a> <a class="btn small secondary" href="${CHECKOUT_URL}" target="_blank" rel="noopener">${s.key || s.status?.startsWith("trial") ? "S\u2019abonner" : `Essai gratuit ${TRIAL_DAYS} jours`}</a></span>`;
      doc.body.prepend(bar);
    };
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "local" && changes[LICENSE_KEY]) void show();
    });
    void show().catch(() => {
    });
  }

  // src/core/update.ts
  var UPDATE_KEY = "update:v1";
  var VERSION_URL = "https://auroebay.netlify.app/version.json";
  var MIRROR = "https://raw.githubusercontent.com/ImpressionMinute/auroebay-maj/main/";
  var VERSION_URLS = [VERSION_URL, MIRROR + "version.json"];
  var UPDATE_GUIDE_URL = "https://auroebay.netlify.app/mise-a-jour.html";
  var UPDATE_EVERY_MS = 24 * 36e5;
  var UPDATE_RECHECK_MS = 2 * 6e4;
  var WHATS_NEW_KEY = "whatsNew:v1";
  var NEWS_URL = "https://auroebay.netlify.app/nouveautes.html";
  var MAC_COMMAND = `curl -fsSL ${MIRROR}maj-mac.sh | bash`;
  var WINDOWS_COMMAND = `powershell -ExecutionPolicy Bypass -c "[Net.ServicePointManager]::SecurityProtocol=3072;irm ${MIRROR}maj-windows.ps1|iex"`;
  var DISK_WAIT_KEY = "updateOnDisk:v1";
  var SITE = "https://auroebay.netlify.app/";
  function cleanNotes(value) {
    if (!Array.isArray(value)) return [];
    return value.filter((n) => typeof n === "string").map((n) => n.replace(/\s+/g, " ").trim().slice(0, 240)).filter(Boolean).slice(0, 8);
  }
  function parseReleaseNotes(value) {
    if (!Array.isArray(value)) return [];
    return value.flatMap((r) => {
      const v = r;
      if (typeof v?.version !== "string" || !/^\d{1,4}\.\d{1,5}\.\d{1,6}$/.test(v.version)) return [];
      const notes = cleanNotes(v.notes);
      return notes.length ? [{ version: v.version, date: typeof v.date === "string" ? v.date.slice(0, 10) : "", notes }] : [];
    });
  }
  function parseVersionFile(value) {
    const v = value;
    if (typeof v?.version !== "string" || !/^\d{1,4}\.\d{1,5}\.\d{1,6}$/.test(v.version)) return null;
    if (typeof v.url !== "string" || !(v.url.startsWith(SITE) || v.url.startsWith(MIRROR)) || /["'<>\s]/.test(v.url)) return null;
    return { latest: v.version, url: v.url, notes: cleanNotes(v.notes) };
  }
  function updateAvailable(info, current) {
    return !!info?.latest && !!info.url && versionBelow(current, info.latest);
  }

  // src/ui/update.ts
  var DISMISSED = "updateDismissed:v1";
  var isWindows = () => /Windows/i.test(navigator.userAgent);
  function steps() {
    return isWindows() ? `<ol class="upd-steps"><li>Clique <b>Copier</b>.</li><li>Appuie sur les touches <kbd>\u229E Windows</kbd> + <kbd>R</kbd>.</li><li>Appuie sur <kbd>Ctrl</kbd> + <kbd>V</kbd>, puis <kbd>Entr\xE9e</kbd>.</li><li>Quand \xAB C\u2019est fait \xBB s\u2019affiche : <b>ferme compl\xE8tement Chrome et rouvre-le</b> (obligatoire).</li></ol>` : `<ol class="upd-steps"><li>Clique <b>Copier</b>.</li><li>Appuie sur <kbd>\u2318 Cmd</kbd> + <kbd>Espace</kbd>, tape <b>Terminal</b>, puis <kbd>Entr\xE9e</kbd>.</li><li>Appuie sur <kbd>\u2318 Cmd</kbd> + <kbd>V</kbd>, puis <kbd>Entr\xE9e</kbd>.</li><li>Quand \xAB C\u2019est fait \xBB s\u2019affiche : <b>quitte Chrome</b> (<kbd>\u2318 Cmd</kbd> + <kbd>Q</kbd>) <b>et rouvre-le</b> (obligatoire).</li></ol>`;
  }
  var list = (notes) => notes.length ? `<ul class="upd-notes">${notes.map((n) => `<li>${escapeHTML(n)}</li>`).join("")}</ul>` : "";
  function updateBanner(doc = document) {
    const current = chrome.runtime.getManifest().version;
    const show = async () => {
      doc.getElementById("upd-banner")?.remove();
      const got = await chrome.storage.local.get([UPDATE_KEY, DISMISSED]);
      const saved = got[UPDATE_KEY];
      const ok = parseVersionFile({ version: saved?.latest, url: saved?.url, notes: saved?.notes });
      const info = ok ? { ...ok, checkedAt: saved?.checkedAt } : void 0;
      if (!updateAvailable(info, current) || got[DISMISSED] === info.latest) return;
      const bar = doc.createElement("div");
      bar.id = "upd-banner";
      bar.className = "lic-banner upd-banner";
      const waiting = (await chrome.storage.local.get(DISK_WAIT_KEY))[DISK_WAIT_KEY];
      bar.innerHTML = waiting?.version ? `<div><b>\u2705 AurOEBay ${escapeHTML(waiting.version)} est pr\xEAt.</b> Il se recharge tout seul d\xE8s que ${escapeHTML(waiting.reason ?? "le travail en cours")} sera fini.</div>
      <span><button type="button" class="btn small primary" id="upd-now">Recharger maintenant</button></span>` : `<div><b>\u{1F195} AurOEBay ${escapeHTML(info.latest)} est disponible</b> (tu as ${escapeHTML(current)}).${ok.notes.length ? ` Ce que \xE7a apporte :${list(ok.notes)}` : ""}<p class="upd-how">Mise \xE0 jour en 1 minute, tes donn\xE9es sont gard\xE9es :</p>${steps()}<p class="upd-how small">Sans red\xE9marrer Chrome, les boutons AurOEBay ne marchent pas sur les pages eBay et AliExpress.</p></div>
      <span><button type="button" class="btn small primary" id="upd-copy">\u{1F4CB} Copier</button>
      <a class="btn small secondary" href="${UPDATE_GUIDE_URL}" target="_blank" rel="noopener">Aide en images</a>
      <button type="button" class="btn small secondary" id="upd-later">Plus tard</button></span>`;
      bar.querySelector("#upd-later")?.addEventListener("click", () => {
        void chrome.storage.local.set({ [DISMISSED]: info.latest });
      });
      bar.querySelector("#upd-now")?.addEventListener("click", () => {
        if (confirm("Recharger AurOEBay maintenant ? Le travail en cours sera interrompu (tes donn\xE9es sont gard\xE9es)."))
          void chrome.runtime.sendMessage({ type: "UPDATE_RELOAD_NOW" }).catch(() => {
          });
      });
      const copy = bar.querySelector("#upd-copy");
      copy?.addEventListener("click", () => {
        void navigator.clipboard.writeText(isWindows() ? WINDOWS_COMMAND : MAC_COMMAND).then(() => copy.textContent = "\u2713 Copi\xE9 ! \xC9tape 2 \u2192").catch(() => copy.textContent = "\u26A0 Copie impossible : utilise l\u2019aide en images");
      });
      doc.body.prepend(bar);
      poll();
    };
    let polling;
    const poll = () => {
      if (polling) return;
      polling = setInterval(() => {
        if (!doc.getElementById("upd-banner")) return void (clearInterval(polling), polling = void 0);
        void chrome.runtime.sendMessage({ type: "UPDATE_DISK" }).catch(() => {
        });
      }, 4e3);
    };
    const news = async () => {
      doc.getElementById("upd-news")?.remove();
      if ((await chrome.storage.local.get(WHATS_NEW_KEY))[WHATS_NEW_KEY] !== current) return;
      const notes = await fetch(chrome.runtime.getURL("release-notes.json")).then((r) => r.json()).then((v) => parseReleaseNotes(v).find((r) => r.version === current)?.notes ?? []).catch(() => []);
      if (!notes.length) return;
      const bar = doc.createElement("div");
      bar.id = "upd-news";
      bar.className = "lic-banner upd-banner upd-news";
      bar.innerHTML = `<div><b>\u{1F389} AurOEBay est \xE0 jour (${escapeHTML(current)}). Les nouveaut\xE9s :</b>${list(notes)}<p class="upd-how small">Si ce n\u2019est pas d\xE9j\xE0 fait : ferme compl\xE8tement Chrome et rouvre-le, sinon les boutons AurOEBay ne marchent pas sur les pages eBay et AliExpress d\xE9j\xE0 ouvertes.</p></div>
      <span><a class="btn small secondary" href="${NEWS_URL}" target="_blank" rel="noopener">Toutes les nouveaut\xE9s</a>
      <button type="button" class="btn small primary" id="upd-news-ok">J\u2019ai compris</button></span>`;
      bar.querySelector("#upd-news-ok")?.addEventListener("click", () => void chrome.storage.local.remove(WHATS_NEW_KEY));
      doc.body.prepend(bar);
    };
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "local") return;
      if (changes[UPDATE_KEY] || changes[DISMISSED] || changes[DISK_WAIT_KEY]) void show().catch(() => {
      });
      if (changes[WHATS_NEW_KEY]) void news().catch(() => {
      });
    });
    void show().catch(() => {
    });
    void news().catch(() => {
    });
    void chrome.runtime.sendMessage({ type: "UPDATE_CHECK" }).catch(() => {
    });
  }

  // src/core/debug.ts
  function safeDiagnostic(value) {
    if (typeof value === "string") return redact(value).slice(0, 3e4);
    if (Array.isArray(value)) return value.slice(0, 200).map(safeDiagnostic);
    if (value && typeof value === "object")
      return Object.fromEntries(
        Object.entries(value).filter(
          ([k]) => !/(api.?key|authorization|cookie|token|secret|password)/i.test(k) || /^(input_tokens|output_tokens|reasoning_tokens|maxOutputTokens)$/.test(
            k
          )
        ).map(([k, v]) => [k, safeDiagnostic(v)])
      );
    return value;
  }

  // src/core/links.ts
  var DISCORD_URL = "https://discord.gg/sr2g2ZZZQ9";

  // src/ui/report.ts
  var REPORT_URL = "https://auroebay.netlify.app/";
  var SUPPORT_EMAIL = "bonjour@impression-minute.fr";
  var MAX_IMAGE = 5 * 1024 * 1024;
  async function technicalReport(extra) {
    const health = await message({ type: "HEALTH_CHECK" }).catch(() => []);
    let session = {};
    try {
      session = await chrome.storage.session.get(["apiTrace:v1", "lastPanelError:v1"]);
    } catch {
    }
    const trace = session["apiTrace:v1"];
    const report = {
      version: chrome.runtime.getManifest().version,
      navigateur: navigator.userAgent,
      page: location.pathname,
      "tout-va-bien": health.map((x) => `${x.ok ? "OK" : x.unknown ? "?" : "!!"} ${x.title} : ${x.text}`),
      "derniere-erreur": session["lastPanelError:v1"] ?? null,
      "trace-import": trace?.slice(-40) ?? []
    };
    const text = JSON.stringify(safeDiagnostic(report), null, 2);
    return (extra ? `${text}

--- Panneau ---
${extra}` : text).slice(0, 6e4);
  }
  var CSS = `
.rp{border:0;border-radius:18px;padding:0;max-width:520px;width:calc(100vw - 32px);background:var(--surface,#fff);color:var(--text,#1d1a24);box-shadow:0 24px 60px rgba(0,0,0,.4);font:14px system-ui,-apple-system,sans-serif}
.rp::backdrop{background:rgba(10,8,14,.55)}
.rp form{display:grid;gap:12px;padding:20px 22px}
.rp h2{margin:0;font-size:19px}
.rp p{margin:0;color:var(--muted,#a49bb0);line-height:1.45}
.rp .rp-community a{color:#ff8a3d;font-weight:600}
.rp label{display:grid;gap:6px;font-weight:600}
.rp textarea,.rp input[type=email]{font:inherit;padding:10px 12px;border-radius:10px;border:1px solid var(--line,#3a3346);background:var(--bg,var(--field,#faf7f3));color:inherit}
.rp textarea{min-height:110px;resize:vertical}
.rp .rp-check{display:flex;align-items:center;gap:8px;font-weight:500;color:var(--muted,#75697d)}.rp .rp-check input{width:auto;flex:none;margin:0}.rp h2{color:inherit}
.rp .rp-actions{display:flex;flex-wrap:wrap;gap:8px;justify-content:flex-end}.rp .rp-copy{margin-right:auto;font-weight:500}
.rp button{font:600 14px system-ui;border-radius:10px;padding:9px 16px;border:1px solid var(--line,#ddd);background:transparent;color:var(--text,#1d1a24);cursor:pointer}
.rp button.primary{background:linear-gradient(135deg,#ff5f3a,#ff8a3d 50%,#ffb347);border-color:transparent;color:#fff}
.rp button:disabled{opacity:.6;cursor:default}
.rp .rp-msg{font-weight:600}
.rp .rp-msg.ok{color:#3fd09a}.rp .rp-msg.err{color:#ff6b78}
`;
  function openReport(extra) {
    document.getElementById("auroebay-report")?.remove();
    if (!document.getElementById("auroebay-report-css")) {
      const style = document.createElement("style");
      style.id = "auroebay-report-css";
      style.textContent = CSS;
      document.head.append(style);
    }
    const dialog = document.createElement("dialog");
    dialog.id = "auroebay-report";
    dialog.className = "rp";
    dialog.innerHTML = `<form method="dialog">
      <h2>\u{1F198} Un souci avec AurOEBay ?</h2>
      <p>Explique simplement ce qui ne marche pas. Le message part directement, pas besoin de bo\xEEte e-mail.</p>
      <p class="rp-community">\u{1F4AC} Plut\xF4t une question ? <a href="${DISCORD_URL}" target="_blank" rel="noopener">Demande \xE0 la communaut\xE9 AurOEBay sur Discord \u2197</a></p>
      <label>Qu\u2019est-ce qui ne marche pas ?<textarea name="message" required maxlength="4000" placeholder="Ex. : quand je clique \xAB Cr\xE9er le brouillon \xBB, rien ne se passe."></textarea></label>
      <label>Une capture d\u2019\xE9cran (si tu veux)<input name="capture" type="file" accept="image/*"></label>
      <label>Ton e-mail, pour te r\xE9pondre (si tu veux)<input name="email" type="email" maxlength="200" placeholder="toi@exemple.fr"></label>
      <label class="rp-check"><input name="tech" type="checkbox" checked> Joindre le rapport technique (aucun mot de passe ni cl\xE9)</label>
      <p class="rp-msg" hidden></p>
      <div class="rp-actions"><button type="button" class="rp-copy" title="Pour le coller dans un message">\u{1F4CB} Copier le rapport</button><button type="button" value="cancel" class="rp-cancel">Annuler</button><button type="submit" class="primary">Envoyer</button></div>
    </form>`;
    document.body.append(dialog);
    const form = dialog.querySelector("form");
    const msg = dialog.querySelector(".rp-msg");
    const send = dialog.querySelector("button[type=submit]");
    const say = (text, kind = "") => {
      msg.hidden = false;
      msg.className = `rp-msg ${kind}`;
      msg.textContent = text;
    };
    dialog.querySelector(".rp-cancel").addEventListener("click", () => dialog.close());
    dialog.querySelector(".rp-copy").addEventListener("click", async () => {
      try {
        await navigator.clipboard.writeText(await technicalReport(extra ? await extra().catch(() => "") : void 0));
        say("\u{1F4CB} Rapport copi\xE9 (aucun mot de passe ni cl\xE9).", "ok");
      } catch {
        say("Copie impossible.", "err");
      }
    });
    dialog.addEventListener("close", () => dialog.remove());
    form.addEventListener("submit", async (event) => {
      event.preventDefault();
      const text = form.elements.namedItem("message").value.trim();
      if (!text) return say("\xC9cris d\u2019abord ce qui ne marche pas.", "err");
      const file = form.elements.namedItem("capture").files?.[0];
      if (file && file.size > MAX_IMAGE) return say("Capture trop lourde (5 Mo au plus).", "err");
      send.disabled = true;
      say("Envoi\u2026");
      const version = chrome.runtime.getManifest().version;
      const tech = form.elements.namedItem("tech").checked ? await technicalReport(extra ? await extra().catch(() => "") : void 0).catch(() => "") : "";
      const body2 = new FormData();
      body2.set("form-name", "probleme");
      body2.set("bot-field", "");
      body2.set("message", text);
      body2.set("email", form.elements.namedItem("email").value.trim());
      body2.set("version", version);
      body2.set("rapport", tech);
      if (file) body2.set("capture", file, file.name);
      try {
        const r = await fetch(REPORT_URL, { method: "POST", body: body2, signal: AbortSignal.timeout(3e4) });
        if (!r.ok) throw Error(String(r.status));
        say("\u2705 Envoy\xE9, merci ! Tu auras une r\xE9ponse par e-mail si tu as laiss\xE9 ton adresse.", "ok");
        send.textContent = "Fermer";
        send.disabled = false;
        send.type = "button";
        send.addEventListener("click", () => dialog.close(), { once: true });
      } catch {
        try {
          await navigator.clipboard.writeText(`${text}

${tech}`);
        } catch {
        }
        window.open(
          `mailto:${SUPPORT_EMAIL}?subject=${encodeURIComponent(`AurOEBay ${version} : un probl\xE8me`)}&body=${encodeURIComponent(`${text}

(Le rapport est copi\xE9 : colle-le ici avec Cmd+V ou Ctrl+V.)`)}`,
          "_blank"
        );
        say("L\u2019envoi direct n\u2019a pas march\xE9 : un e-mail s\u2019ouvre, ton message y est d\xE9j\xE0 (colle le rapport avec Cmd+V ou Ctrl+V).", "err");
        send.disabled = false;
      }
    });
    dialog.showModal();
    form.elements.namedItem("message").focus();
  }

  // src/ui/theme.ts
  function setupTheme() {
    licenseBanner();
    updateBanner();
    simpleTopbar();
    const system = matchMedia("(prefers-color-scheme: dark)");
    const button = document.getElementById("theme-toggle");
    const choice = document.getElementById(
      "theme-choice"
    );
    let theme = "system";
    let revision = 0;
    const valid = (value) => value === "light" || value === "dark" ? value : "system";
    const render2 = () => {
      const dark = theme === "dark" || theme === "system" && system.matches;
      document.documentElement.dataset.theme = dark ? "dark" : "light";
      if (button) {
        button.textContent = dark ? "\u2600" : "\u263E";
        button.setAttribute("aria-pressed", String(dark));
        button.setAttribute(
          "aria-label",
          dark ? "Activer le mode clair" : "Activer le mode sombre"
        );
        button.title = button.getAttribute("aria-label");
      }
      if (choice) choice.value = theme;
    };
    const save = async (value) => {
      revision++;
      theme = value;
      render2();
      try {
        await chrome.storage.local.set({ uiTheme: value });
      } catch {
      }
    };
    button?.addEventListener(
      "click",
      () => void save(
        document.documentElement.dataset.theme === "dark" ? "light" : "dark"
      )
    );
    choice?.addEventListener("change", () => void save(valid(choice.value)));
    system.addEventListener("change", render2);
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "local" && changes.uiTheme) {
        revision++;
        theme = valid(changes.uiTheme.newValue);
        render2();
      }
    });
    const initial = revision;
    void chrome.storage.local.get("uiTheme").then(({ uiTheme }) => {
      if (revision === initial) theme = valid(uiTheme);
      render2();
    }).catch(() => render2());
    render2();
  }
  var PAGES = [
    ["routine.html", "\u2600\uFE0F Ma journ\xE9e"],
    ["dashboard.html", "\u{1F4E6} Mes produits"],
    ["scout.html", "\u{1F50D} Trouver"],
    ["sales.html", "\u{1F4D2} Ventes"]
  ];
  function simpleTopbar() {
    const bar = document.querySelector("header.topbar");
    const actions = bar?.querySelector(".top-actions");
    if (!bar || !actions || bar.querySelector(".ao-nav")) return;
    const here = location.pathname.split("/").pop() || "";
    if (here === "welcome.html") return;
    actions.querySelectorAll("a[href]").forEach((a) => {
      if (PAGES.some(([href]) => a.getAttribute("href") === href)) a.remove();
    });
    const nav = document.createElement("nav");
    nav.className = "ao-nav";
    nav.setAttribute("aria-label", "Pages d\u2019AurOEBay");
    for (const [href, label] of PAGES) {
      const a = document.createElement("a");
      a.href = href;
      a.textContent = label;
      if (href === here) {
        a.className = "on";
        a.setAttribute("aria-current", "page");
      }
      nav.append(a);
    }
    bar.querySelector(".brand")?.after(nav);
    bar.querySelector(".brand .crumb")?.remove();
    if (here !== "options.html") {
      const settings = document.createElement("a");
      settings.className = "btn ghost";
      settings.href = "options.html";
      settings.textContent = "\u2699\uFE0F Param\xE8tres";
      actions.append(settings);
    }
    const help = document.createElement("button");
    help.id = "help-report";
    help.type = "button";
    help.className = "btn ghost";
    help.textContent = "\u{1F198} Aide";
    help.title = "Un souci ? \xC9cris-nous, c\u2019est envoy\xE9 tout de suite";
    help.addEventListener("click", () => openReport());
    actions.append(help);
  }

  // src/core/niches.ts
  var NICHES = {
    Maison: [
      "led strip lights",
      "sunset projection lamp",
      "moon lamp",
      "galaxy projector",
      "motion sensor night light",
      "magnetic spice rack",
      "under sink organizer",
      "drawer divider",
      "vacuum storage bags",
      "cable organizer box",
      "shower caddy",
      "rotating makeup organizer",
      "silicone stretch lids",
      "electric milk frother",
      "vegetable chopper",
      "garlic press",
      "reusable silicone bags",
      "door draft stopper",
      "self adhesive hooks",
      "blackout curtain clips"
    ],
    Cuisine: [
      "silicone baking mat",
      "air fryer liners",
      "coffee scale",
      "pour over kettle",
      "ice cube tray with lid",
      "knife sharpener",
      "oil sprayer bottle",
      "herb scissors",
      "fruit infuser bottle",
      "bento lunch box"
    ],
    "T\xE9l\xE9phone & tech": [
      "magnetic phone mount",
      "phone tripod",
      "ring light",
      "wireless charger stand",
      "usb c hub",
      "laptop stand",
      "webcam cover",
      "cable protector",
      "tablet holder for bed",
      "bluetooth tracker tag",
      "car vent phone holder",
      "screen cleaner spray",
      "mini projector",
      "smart plug",
      "keyboard wrist rest"
    ],
    "Montres & bijoux": [
      "watch band 44mm",
      "solo loop watch band",
      "magnetic watch strap",
      "watch screen protector",
      "stainless steel bracelet",
      "titanium ring",
      "birthstone necklace",
      "initial necklace",
      "anklet",
      "hair claw clip"
    ],
    Voiture: [
      "car seat gap filler",
      "car trash can",
      "steering wheel cover",
      "car sun shade",
      "trunk organizer",
      "tire pressure gauge",
      "car interior led lights",
      "dash cam mount",
      "seat back organizer",
      "car cup holder expander"
    ],
    "Animaux": [
      "cat water fountain",
      "slow feeder dog bowl",
      "lick mat",
      "cat scratcher",
      "dog poop bag holder",
      "pet hair remover",
      "cat tunnel",
      "dog harness no pull",
      "pet grooming glove",
      "automatic cat toy"
    ],
    "Sport & ext\xE9rieur": [
      "resistance bands",
      "jump rope",
      "yoga mat strap",
      "massage gun attachments",
      "grip strengthener",
      "camping lantern",
      "hammock straps",
      "waterproof phone pouch",
      "cooling towel",
      "bike phone mount",
      "fishing lure kit",
      "hiking trekking poles",
      "headlamp rechargeable",
      "collapsible water bottle"
    ],
    "Beaut\xE9 & soin": [
      "gua sha",
      "ice roller",
      "scalp massager",
      "facial steamer",
      "nail art stickers",
      "makeup brush cleaner",
      "eyelash curler heated",
      "hair bonnet satin",
      "heatless curling rod",
      "blackhead remover"
    ],
    "B\xE9b\xE9 & enfants": [
      "silicone teether",
      "baby food feeder",
      "busy board",
      "kids water bottle",
      "magnetic tiles",
      "sensory toys",
      "baby proof cabinet locks",
      "night light for kids",
      "drawing tablet for kids",
      "bath toys"
    ],
    "Loisirs & jouets": [
      "fidget toys",
      "speed cube",
      "diamond painting kit",
      "puzzle mat",
      "plush keychain",
      "kite for kids",
      "rc car",
      "building blocks",
      "card sleeves",
      "dice set resin"
    ],
    "Bureau & rangement": [
      "desk organizer",
      "monitor riser",
      "label maker tape",
      "acrylic display case",
      "magnetic whiteboard",
      "pen holder",
      "file organizer",
      "document bag",
      "sticky notes dispenser",
      "under desk drawer"
    ],
    "Jardin": [
      "solar garden lights",
      "plant grow light",
      "self watering planter",
      "garden kneeler",
      "bird feeder",
      "hose nozzle",
      "plant labels",
      "seed starter tray",
      "pruning shears",
      "outdoor string lights"
    ]
  };
  var ALL_NICHES = Object.entries(NICHES).flatMap(([category, list2]) => list2.map((niche) => ({ niche, category })));
  function pickNiches(count, recent2 = [], random = Math.random, categories) {
    const recentSet = new Set(recent2);
    const allowed = categories?.length ? ALL_NICHES.filter((n) => categories.includes(n.category)) : ALL_NICHES;
    let pool = allowed.filter((n) => !recentSet.has(n.niche));
    if (pool.length < count) pool = [...allowed];
    const out = [];
    const usedCategories = /* @__PURE__ */ new Set();
    while (out.length < count && pool.length) {
      const fresh = pool.filter((n) => !usedCategories.has(n.category));
      const from = fresh.length ? fresh : pool;
      const pick = from[Math.floor(random() * from.length)];
      out.push(pick);
      usedCategories.add(pick.category);
      pool = pool.filter((n) => n !== pick);
    }
    return out;
  }

  // src/core/brandRisk.ts
  var DANGER = [
    // Characters and licences
    "Disney",
    "Pixar",
    "Marvel",
    "Avengers",
    "Spider-Man",
    "Spiderman",
    "Batman",
    "Superman",
    "Deadpool",
    "Iron Man",
    "Captain America",
    "DC Comics",
    "Star Wars",
    "Baby Yoda",
    "Grogu",
    "Mandalorian",
    "Harry Potter",
    "Hogwarts",
    "Mickey Mouse",
    "Minnie Mouse",
    "Lilo and Stitch",
    "Lilo & Stitch",
    "Toy Story",
    "Winnie the Pooh",
    "Pokemon",
    "Pikachu",
    "Super Mario",
    "Mario Kart",
    "Zelda",
    "Sonic the Hedgehog",
    "Minecraft",
    "Fortnite",
    "Roblox",
    "Among Us",
    "Squid Game",
    "Hello Kitty",
    "Sanrio",
    "Kuromi",
    "Cinnamoroll",
    "My Melody",
    "Labubu",
    "Pop Mart",
    "Squishmallow",
    "Squishmallows",
    "Bluey",
    "Paw Patrol",
    "Peppa Pig",
    "Cocomelon",
    "Minions",
    "Barbie",
    "Hot Wheels",
    "LEGO",
    "Nerf",
    "Fisher-Price",
    "Naruto",
    "Dragon Ball",
    "Demon Slayer",
    "Jujutsu Kaisen",
    "My Hero Academia",
    "Sailor Moon",
    "Studio Ghibli",
    "Totoro",
    "Looney Tunes",
    "Snoopy",
    "Sesame Street",
    "Taylor Swift",
    "NFL",
    "NBA",
    "MLB",
    "NHL",
    "NCAA",
    "Harley-Davidson",
    "John Deere",
    "Coca-Cola",
    "Starbucks",
    // Fashion, luxury, sport
    "Nike",
    "Adidas",
    "Puma",
    "Reebok",
    "Under Armour",
    "New Balance",
    "Air Jordan",
    "Converse",
    "The North Face",
    "Patagonia",
    "Lululemon",
    "Gucci",
    "Louis Vuitton",
    "Chanel",
    "Dior",
    "Hermes",
    "Prada",
    "Versace",
    "Burberry",
    "Balenciaga",
    "Fendi",
    "Givenchy",
    "Yves Saint Laurent",
    "YSL",
    "Michael Kors",
    "Kate Spade",
    "Tory Burch",
    "Ralph Lauren",
    "Tommy Hilfiger",
    "Calvin Klein",
    "Rolex",
    "Cartier",
    "Tag Heuer",
    "Pandora",
    "Swarovski",
    "Ray-Ban",
    "Rayban",
    "Oakley",
    "Crocs",
    "Jibbitz",
    "UGG",
    "Birkenstock",
    "Dr Martens",
    "Timberland",
    // Copied household products
    "Stanley",
    "Yeti",
    "Hydro Flask",
    "Owala",
    "OtterBox",
    "PopSocket",
    "PopSockets",
    "Dyson",
    // Added 11/2026 (user's request « des mots / marques à bannir »)
    // Toys, collectibles, kids' licences
    "NeeDoh",
    "Nee Doh",
    "Schylling",
    "Jellycat",
    "Sonny Angel",
    "Smiski",
    "Funko",
    "Beanie Babies",
    "Ty Beanie",
    "Ms Rachel",
    "Blippi",
    "Gabby's Dollhouse",
    "Gabbys Dollhouse",
    "PJ Masks",
    "Thomas the Tank Engine",
    "SpongeBob",
    "Garfield",
    "Pusheen",
    "Care Bears",
    "My Little Pony",
    "Transformers",
    "Hasbro",
    "Mattel",
    "Play-Doh",
    "Magna-Tiles",
    "Tamagotchi",
    "Bandai",
    "Yu-Gi-Oh",
    "Magic the Gathering",
    "Bratz",
    "LOL Surprise",
    "Polly Pocket",
    "Tonka",
    "Crayola",
    "Hatchimals",
    "Kirby",
    "Animal Crossing",
    "Splatoon",
    "Call of Duty",
    "Pac-Man",
    "Tetris",
    "Rubik's",
    "Rubiks",
    "Pochacco",
    "Pompompurin",
    "Keroppi",
    "Badtz-Maru",
    "Chainsaw Man",
    "Attack on Titan",
    "Hunter x Hunter",
    "Tokyo Ghoul",
    "Spy x Family",
    "Stranger Things",
    "Moana",
    "Encanto",
    "Frozen Elsa",
    "Bluey Bingo",
    "Grinch",
    "Dr Seuss",
    "Elf on the Shelf",
    "Charlie Brown",
    "Jack Skellington",
    "Nightmare Before Christmas",
    "Hocus Pocus",
    "Beetlejuice",
    "Freddy Krueger",
    "Michael Myers",
    "Chucky",
    "Ghostface",
    "Lord of the Rings",
    "Game of Thrones",
    "Wednesday Addams",
    // Fashion, beauty, luxury
    "Vans Old Skool",
    "Skechers",
    "Hoka",
    "Asics",
    "Fila",
    "Carhartt",
    "Levi's",
    "Levis",
    "Wrangler Jeans",
    "Off-White",
    "Bape",
    "Stussy",
    "Fear of God",
    "Moncler",
    "Canada Goose",
    "Arc'teryx",
    "Arcteryx",
    "Longchamp",
    "Goyard",
    "Celine",
    "Bottega Veneta",
    "Valentino",
    "Miu Miu",
    "Loewe",
    "Van Cleef",
    "Bvlgari",
    "Bulgari",
    "Chrome Hearts",
    "Casio",
    "G-Shock",
    "Seiko",
    "Alo Yoga",
    "Gymshark",
    "Skims",
    "Victoria's Secret",
    "Bath and Body Works",
    "Sol de Janeiro",
    "Olaplex",
    "Beautyblender",
    "Fenty",
    "Rare Beauty",
    "Charlotte Tilbury",
    "Revlon",
    "Gillette",
    "Oral-B",
    "Sonicare",
    // Tech and home brands often copied
    "Anker",
    "Beats by Dre",
    "Beats Studio",
    "Beats Solo",
    "Beats Fit Pro",
    "Skullcandy",
    "Logitech",
    "Razer",
    "Corsair",
    "SteelSeries",
    "HyperX",
    "Roomba",
    "iRobot",
    "Vitamix",
    "Le Creuset",
    "Pyrex",
    "Tupperware",
    "Bissell",
    "Contigo",
    "Ember Mug",
    "Ka-Bar",
    "Kabar",
    "Lego Star Wars",
    // Sport teams, cars (logos)
    "FIFA",
    "UEFA",
    "Real Madrid",
    "FC Barcelona",
    "Manchester United",
    "Manchester City",
    "Liverpool FC",
    "Chelsea FC",
    "Dallas Cowboys",
    "Kansas City Chiefs",
    "New York Yankees",
    "Los Angeles Lakers",
    "Chicago Bulls",
    "Golden State Warriors",
    "Ferrari",
    "Lamborghini",
    "Porsche",
    "Red Bull",
    "Monster Energy",
    "Jack Daniels",
    "Jack Daniel's"
  ];
  var COMPATIBLE = [
    "iPhone",
    "iPad",
    "MacBook",
    "iMac",
    "Apple Watch",
    "Apple Pencil",
    "MagSafe",
    "AirPods",
    "AirTag",
    "Samsung",
    "Google Pixel",
    "Fitbit",
    "Garmin",
    "Nintendo",
    "PlayStation",
    "PS4",
    "PS5",
    "Xbox",
    "Tesla",
    "GoPro",
    "DJI",
    "Kindle",
    "JBL",
    "Bose",
    "Sony",
    "Microsoft",
    "Keurig",
    "Nespresso",
    "KitchenAid",
    "Instant Pot",
    "Cricut",
    "DeWalt",
    "Makita",
    "Bosch",
    // Added 11/2026: devices and cars accessories name (« for Toyota RAV4 »)
    "Steam Deck",
    "Meta Quest",
    "Oculus",
    "Echo Dot",
    "Alexa",
    "Roku",
    "Chromecast",
    "Ring Doorbell",
    "Polaroid",
    "Instax",
    "Fujifilm",
    "Canon",
    "Nikon",
    "Milwaukee",
    "Ryobi",
    "Ninja Creami",
    "Ninja Foodi",
    "Xiaomi",
    "Huawei",
    "OnePlus",
    "Motorola",
    "Lenovo",
    "Dell",
    "Toyota",
    "Honda",
    "Ford",
    "Chevrolet",
    "Chevy",
    "Jeep",
    "BMW",
    "Mercedes",
    "Audi",
    "Volkswagen",
    "Subaru",
    "Nissan",
    "Hyundai",
    "Kia",
    "Mazda",
    "Lexus",
    "Dodge",
    "RAM 1500"
  ];
  var words = (text) => ` ${text.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, " ").trim()} `;
  var LIST = [
    ...DANGER.map((name) => ({ name, level: "danger", w: words(name) })),
    ...COMPATIBLE.map((name) => ({ name, level: "compatible", w: words(name) }))
  ];
  function brandRisks(text) {
    if (!text) return [];
    const t = words(text);
    const hits = [];
    const seen = /* @__PURE__ */ new Set();
    for (const b of LIST) {
      const key = b.w.replace(/ /g, "");
      if (seen.has(key) || !t.includes(b.w)) continue;
      if (hits.some((h) => words(h.name).includes(b.w) || b.w.includes(words(h.name)))) continue;
      seen.add(key);
      hits.push({ name: b.name, level: b.level });
    }
    return hits.sort((a, b) => Number(a.level !== "danger") - Number(b.level !== "danger"));
  }

  // src/core/aliVerify.ts
  var ALI_VERIFY_URL = "https://www.aliexpress.us/";
  var asksAliVerify = (text) => typeof text === "string" && /AliExpress (demande|a demandé) une vérification/.test(text);
  var aliVerifyLink = (style = "") => `<a href="${ALI_VERIFY_URL}" target="_blank" rel="noopener" class="ali-verify"${style ? ` style="${style}"` : ""}>\u{1F513} Ouvrir AliExpress pour faire la v\xE9rification \u2197</a>`;
  var ALI_COOKIES = "AliExpress refuse les recherches : trop de cookies AliExpress dans Chrome";
  var ALI_COOKIES_TEXT = `${ALI_COOKIES} (erreur \xAB Cookie Too Large \xBB). Clique \xAB \u{1F9F9} Nettoyer AliExpress dans Chrome \xBB, supprime les donn\xE9es d\u2019aliexpress (ic\xF4ne corbeille), reconnecte-toi sur aliexpress.us, puis relance.`;
  var asksAliCookies = (text) => typeof text === "string" && text.includes(ALI_COOKIES);
  var aliCookiesButton = (style = "") => `<button type="button" class="ali-cookies" data-ali-cookies${style ? ` style="${style}"` : ""}>\u{1F9F9} Nettoyer AliExpress dans Chrome</button>`;
  var ALI_REGION = "AliExpress n\u2019est pas pr\xEAt pour les \xC9tats-Unis";
  var asksAliRegion = (text) => typeof text === "string" && text.includes(ALI_REGION);
  var aliRegionLink = (style = "") => `<a href="${ALI_VERIFY_URL}" target="_blank" rel="noopener" class="ali-verify"${style ? ` style="${style}"` : ""}>\u{1F1FA}\u{1F1F8} Ouvrir AliExpress US \u2197</a>`;

  // src/core/trend.ts
  var MIN_D30 = 4;
  function trendOf(d7, d30, capped = false) {
    if (d7 === null || d7 === void 0 || d30 === null || d30 === void 0) return null;
    if (capped)
      return {
        kind: "busy",
        ratio: null,
        label: "\u{1F525} Tr\xE8s demand\xE9",
        title: "Plus de 100 ventes en moins d\u2019un mois sur une m\xEAme annonce : eBay n\u2019en montre pas plus, la tendance ne peut pas \xEAtre mesur\xE9e. Produit tr\xE8s demand\xE9, souvent avec beaucoup de concurrence."
      };
    const before = Math.max(0, d30 - d7);
    if (!before) return d7 >= 3 ? newTrend(d7) : null;
    if (d30 < MIN_D30) return null;
    const usual = before / 23 * 7;
    const ratio = Math.round(d7 / usual * 10) / 10;
    const base = `${d7} vente${d7 > 1 ? "s" : ""} ces 7 derniers jours, pour environ ${(Math.round(usual * 10) / 10).toLocaleString("fr-FR")} par semaine avant.`;
    if (ratio >= 1.5) return { kind: "up", ratio, label: `\u{1F4C8} En hausse \xD7${String(ratio).replace(".", ",")}`, title: `${base} Le produit d\xE9colle.` };
    if (ratio <= 0.5) return { kind: "down", ratio, label: "\u{1F4C9} En baisse", title: `${base} Les ventes ralentissent.` };
    return { kind: "steady", ratio, label: "\u27A1\uFE0F Stable", title: `${base} Ventes r\xE9guli\xE8res.` };
  }
  var newTrend = (d7) => ({
    kind: "new",
    ratio: null,
    label: "\u{1F680} D\xE9marre",
    title: `${d7} ventes ces 7 derniers jours et aucune avant : le produit vient de d\xE9marrer.`
  });
  function trendScore(p) {
    if (p.d7 === null || p.d30 === null) return -1;
    const t = trendOf(p.d7, p.d30, p.capped);
    const factor = !t || t.kind === "busy" ? 1 : t.kind === "new" ? 4 : Math.min(4, Math.max(0.25, t.ratio ?? 1));
    return p.d7 * factor;
  }

  // src/core/eventSearches.ts
  var EVENT_SEARCHES = {
    superbowl: [
      "football party decorations",
      "game day snack tray",
      "football party supplies",
      "foam finger",
      "football cupcake toppers",
      "stadium snack holder",
      "referee costume",
      "football string lights",
      "football balloons",
      "football table cover",
      "football banner",
      "football napkins",
      "football party plates",
      "chip and dip bowl",
      "football serving bowl",
      "can cooler sleeve",
      "party cups set",
      "face paint sticks",
      "eye black stickers",
      "football centerpiece",
      "touchdown banner",
      "mini foam football",
      "football keychain",
      "sports fan scarf",
      "tv tray table",
      "beer pong set",
      "cornhole bean bags",
      "party noise makers",
      "cheering horn",
      "stadium seat cushion",
      "stadium blanket",
      "clear stadium bag",
      "football pinata",
      "football cookie cutter",
      "football ice mold",
      "chicken wing rack",
      "disposable chafing dish set",
      "party ice bucket",
      "drink dispenser",
      "led cups",
      "game day shirt",
      "referee whistle",
      "football field rug",
      "football throw pillow",
      "beer glass set"
    ],
    valentine: [
      "valentines day gifts",
      "heart necklace",
      "rose bear",
      "couple gifts",
      "preserved rose",
      "led heart light",
      "couple keychain",
      "love lamp",
      "heart pillow",
      "valentines decorations",
      "galaxy rose",
      "couple bracelets",
      "heart balloons",
      "artificial rose petals",
      "heart garland",
      "heart string lights",
      "love letter jar",
      "scratch off date cards",
      "couples card game",
      "matching couple rings",
      "magnetic couple bracelets",
      "heart pendant",
      "name necklace",
      "projection necklace",
      "love bear plush",
      "rose gift box",
      "soap flowers",
      "rose in glass dome",
      "heart cake topper",
      "valentine table runner",
      "valentine banner",
      "heart confetti",
      "couple mugs",
      "heart jewelry box",
      "heart earrings",
      "heart sunglasses",
      "valentine gnome",
      "valentine wreath",
      "neon heart sign",
      "candle gift set",
      "heart bath bombs",
      "valentine socks",
      "couple pajamas",
      "kids valentine cards",
      "valentine treat bags",
      "valentine stickers",
      "heart silicone mold",
      "heart shaped box"
    ],
    stpatrick: [
      "st patricks day decorations",
      "shamrock earrings",
      "leprechaun hat",
      "shamrock garland",
      "green party supplies",
      "shamrock headband",
      "irish party decorations",
      "shamrock sunglasses",
      "green beads necklace",
      "leprechaun costume",
      "green bow tie",
      "shamrock socks",
      "irish flag",
      "shamrock string lights",
      "plastic gold coins",
      "pot of gold decor",
      "rainbow decorations",
      "green tablecloth",
      "shamrock confetti",
      "leprechaun trap kit",
      "st patricks day shirt",
      "green tutu",
      "shamrock hair clip",
      "green feather boa",
      "shamrock wreath",
      "irish door hanger",
      "clover necklace",
      "four leaf clover keychain",
      "shamrock garden flag",
      "green balloons",
      "shamrock banner",
      "green top hat",
      "shamrock tattoos",
      "green wig",
      "shamrock napkins",
      "green party cups",
      "st patricks gnome",
      "lucky charm bracelet",
      "shamrock cookie cutter",
      "green suspenders"
    ],
    easter: [
      "easter decorations",
      "easter basket stuffers",
      "fillable easter eggs",
      "bunny ears headband",
      "easter wreath",
      "egg decorating kit",
      "easter garden flag",
      "bunny plush",
      "easter tablecloth",
      "easter egg hunt kit",
      "easter basket",
      "easter grass",
      "light up easter eggs",
      "easter bunny decor",
      "carrot decor",
      "easter gnome",
      "easter garland",
      "easter banner",
      "easter table runner",
      "easter centerpiece",
      "easter egg tree",
      "egg dye kit",
      "chocolate egg mold",
      "bunny cookie cutter",
      "easter cupcake toppers",
      "easter treat bags",
      "bunny costume",
      "easter dress girls",
      "easter bow tie",
      "egg cup set",
      "easter napkins",
      "easter door hanger",
      "easter string lights",
      "wind up toys",
      "squishy toys",
      "bubble wands",
      "chick plush",
      "easter stickers",
      "easter coloring book",
      "lamb plush",
      "spring wreath",
      "artificial tulips",
      "bunny tail plush",
      "egg shaped containers",
      "easter pillow covers"
    ],
    spring: [
      "solar garden lights",
      "garden kneeler",
      "plant support stakes",
      "seed starter tray",
      "hose nozzle",
      "bird feeder",
      "garden tool set",
      "plant labels",
      "self watering spikes",
      "hanging planter",
      "expandable garden hose",
      "garden gloves",
      "pruning shears",
      "plant grow light",
      "raised garden bed",
      "grow bags",
      "seed storage box",
      "plant mister",
      "soil moisture meter",
      "trellis for climbing plants",
      "garden netting",
      "macrame plant hanger",
      "window bird feeder",
      "hummingbird feeder",
      "bird bath",
      "wind chimes",
      "garden statue",
      "solar fountain pump",
      "solar path lights",
      "garden stepping stones",
      "kitchen compost bin",
      "watering can",
      "lawn sprinkler",
      "hose reel",
      "weeding tool",
      "garden apron",
      "kids gardening set",
      "herb garden kit",
      "mini greenhouse",
      "plant clips",
      "garden border edging",
      "outdoor rug",
      "patio cushion covers",
      "microfiber cleaning cloths",
      "window cleaning tool"
    ],
    mother: [
      "mothers day gifts",
      "jewelry box",
      "flower lamp",
      "mom necklace",
      "spa gift set",
      "preserved flower",
      "mom tumbler",
      "jewelry organizer",
      "bath bombs gift set",
      "eternal rose",
      "mom bracelet",
      "birthstone necklace",
      "family tree necklace",
      "engraved bracelet",
      "mom keychain",
      "mom mug",
      "mom blanket",
      "heated eye mask",
      "neck massager",
      "foot massager",
      "silk pillowcase",
      "satin pajamas set",
      "womens robe",
      "makeup bag",
      "travel jewelry case",
      "ring holder dish",
      "photo frame",
      "digital photo frame",
      "memory book for mom",
      "recipe binder",
      "tote bag women",
      "silk scarf",
      "hair claw clip set",
      "scented candle set",
      "essential oil diffuser",
      "aromatherapy gift set",
      "crystal flower",
      "music box",
      "artificial succulents",
      "artificial flower bouquet",
      "hand cream gift set",
      "makeup brush set",
      "led makeup mirror",
      "wine tumbler"
    ],
    graduation: [
      "graduation decorations",
      "graduation party supplies",
      "graduation cap topper",
      "graduation photo props",
      "graduation gifts",
      "graduation balloons",
      "graduation banner",
      "graduation centerpiece",
      "graduation tablecloth",
      "graduation cupcake toppers",
      "graduation sash",
      "graduation stole",
      "graduation lei",
      "money lei",
      "graduation cap decoration kit",
      "autograph book",
      "graduation photo frame",
      "graduation backdrop",
      "graduation confetti",
      "graduation napkins",
      "graduation plates",
      "graduation yard sign",
      "graduation card box",
      "graduation teddy bear",
      "graduation keychain",
      "graduation bracelet",
      "inspirational necklace",
      "compass necklace",
      "travel organizer",
      "toiletry bag",
      "laptop backpack",
      "dorm essentials",
      "portable charger",
      "money holder card",
      "graduation gift box",
      "graduation party favors",
      "graduation pins",
      "honor cords",
      "diploma frame",
      "graduation mug",
      "balloon arch kit",
      "kindergarten graduation gifts"
    ],
    father: [
      "fathers day gifts",
      "bbq grill tools",
      "multitool",
      "beard grooming kit",
      "whiskey stones",
      "car organizer",
      "mens wallet",
      "grill accessories",
      "tool gifts for men",
      "dad mug",
      "grill thermometer",
      "grill brush",
      "grill mat",
      "meat claws",
      "smoker box",
      "bbq apron",
      "whiskey glass set",
      "whiskey decanter",
      "bottle opener",
      "beer caddy",
      "flask",
      "mens bracelet",
      "mens necklace",
      "cufflinks",
      "tie clip",
      "watch box",
      "valet tray",
      "keychain for men",
      "minimalist wallet",
      "money clip",
      "card holder",
      "mens belt",
      "nose hair trimmer",
      "beard straightener",
      "shaving kit",
      "socks gift box",
      "golf accessories",
      "golf ball marker",
      "fishing tackle box",
      "fishing gifts",
      "tactical flashlight",
      "headlamp",
      "tool belt",
      "magnetic wristband",
      "socket set",
      "car vacuum",
      "mini massage gun"
    ],
    summer: [
      "pool floats",
      "beach tent",
      "cooling towel",
      "portable neck fan",
      "snorkel mask",
      "waterproof phone pouch",
      "camping lantern",
      "water gun",
      "beach bag",
      "inflatable pool",
      "sun shade",
      "pool toys",
      "beach umbrella anchor",
      "sand free beach mat",
      "beach towel clips",
      "beach cart",
      "cooler bag",
      "insulated tumbler",
      "swim goggles",
      "swim cap",
      "pool noodles",
      "dive toys",
      "splash pad",
      "sprinkler for kids",
      "water balloons",
      "bubble machine",
      "outdoor games",
      "frisbee",
      "paddle ball set",
      "sand toys",
      "kite",
      "sun hat",
      "uv umbrella",
      "handheld fan",
      "misting fan",
      "popsicle molds",
      "portable blender",
      "outdoor string lights",
      "citronella candle",
      "bug zapper",
      "mosquito net",
      "hammock",
      "camping chair",
      "camping fan",
      "tent lights",
      "solar shower",
      "beach chair"
    ],
    july4: [
      "american flag decor",
      "patriotic decorations",
      "usa flag string lights",
      "red white blue garland",
      "patriotic tablecloth",
      "american flag bandana",
      "patriotic party supplies",
      "usa flag garden flag",
      "patriotic wreath",
      "patriotic banner",
      "star garland",
      "bunting flags",
      "american flag pinwheels",
      "patriotic balloons",
      "patriotic table runner",
      "patriotic napkins",
      "patriotic plates",
      "star sunglasses",
      "usa headband",
      "patriotic hat",
      "american flag shirt",
      "american flag socks",
      "patriotic earrings",
      "usa flag necklace",
      "light up necklace",
      "glow sticks",
      "led foam sticks",
      "confetti poppers",
      "patriotic gnome",
      "patriotic door hanger",
      "uncle sam hat",
      "patriotic porch sign",
      "solar flag pole light",
      "flag pole kit",
      "american flag 3x5",
      "mini american flags",
      "patriotic tumbler",
      "picnic blanket",
      "patriotic dog bandana",
      "patriotic tutu",
      "star cookie cutter",
      "patriotic cupcake toppers"
    ],
    school: [
      "school supplies",
      "pencil case",
      "desk organizer",
      "kids backpack",
      "lunch box kids",
      "kids water bottle",
      "led desk lamp",
      "book stand",
      "pencil pouch",
      "dorm room essentials",
      "bento box",
      "insulated lunch bag",
      "backpack keychain",
      "name labels kids",
      "highlighters set",
      "gel pens",
      "colored pencils",
      "mechanical pencils",
      "cute erasers",
      "sticky notes",
      "index cards",
      "binder clips",
      "file folders",
      "student planner",
      "electric pencil sharpener",
      "ruler set",
      "geometry set",
      "art supplies kit",
      "watercolor set",
      "scissors kids",
      "kids headphones",
      "laptop sleeve",
      "kids tablet case",
      "dorm storage bins",
      "bed risers",
      "clip on fan",
      "shower caddy dorm",
      "laundry hamper",
      "desk chair cushion",
      "mini whiteboard",
      "cork board",
      "wall calendar",
      "alarm clock",
      "book light",
      "bookmarks",
      "locker organizer",
      "clear backpack"
    ],
    halloween: [
      "halloween decorations",
      "led pumpkin",
      "skeleton decor",
      "spider web decoration",
      "halloween string lights",
      "witch hat",
      "halloween door cover",
      "animated halloween prop",
      "glow in the dark skeleton",
      "halloween costume kids",
      "halloween window clings",
      "fog machine",
      "giant spider",
      "hanging ghost",
      "halloween wreath",
      "halloween garland",
      "halloween tablecloth",
      "candy bowl",
      "trick or treat bag",
      "pumpkin carving kit",
      "halloween masks",
      "witch broom",
      "skull decor",
      "tombstone yard decor",
      "halloween yard stakes",
      "caution tape halloween",
      "creepy cloth",
      "halloween projector",
      "flickering led candles",
      "black cat decor",
      "bat wall decor",
      "halloween pillow covers",
      "halloween doormat",
      "costume makeup kit",
      "fake blood",
      "vampire teeth",
      "witch costume",
      "skeleton costume",
      "inflatable costume",
      "dog halloween costume",
      "halloween headband",
      "halloween party favors",
      "halloween treat bags",
      "halloween gnome",
      "halloween village",
      "scary sound box",
      "motion sensor halloween"
    ],
    thanksgiving: [
      "thanksgiving decorations",
      "fall wreath",
      "turkey decor",
      "harvest table runner",
      "fall garland",
      "pumpkin decor",
      "thanksgiving tablecloth",
      "fall centerpiece",
      "artificial pumpkins",
      "artificial fall leaves",
      "maple leaf garland",
      "fall string lights",
      "fall doormat",
      "fall pillow covers",
      "scarecrow decor",
      "fall gnome",
      "thankful sign",
      "place card holders",
      "napkin rings",
      "cloth napkins",
      "turkey baster",
      "meat thermometer",
      "roasting rack",
      "carving knife set",
      "gravy boat",
      "pie dish",
      "pie crust shield",
      "leaf cookie cutter",
      "serving platter",
      "casserole carrier",
      "food warmer",
      "butter dish",
      "salt and pepper shakers",
      "candle holders",
      "taper candles",
      "fall candles",
      "harvest basket",
      "thanksgiving banner",
      "kids thanksgiving crafts",
      "turkey hat",
      "thanksgiving shirt",
      "round fall tablecloth"
    ],
    blackfriday: [
      "gifts for him",
      "gifts for her",
      "kitchen gadgets",
      "tech gifts",
      "gadget gifts",
      "phone accessories gift",
      "car gadgets",
      "unique gifts",
      "gifts for mom",
      "gifts for dad",
      "gifts for teens",
      "gifts for kids",
      "white elephant gifts",
      "secret santa gifts",
      "gifts under 20",
      "stocking stuffers for men",
      "stocking stuffers for women",
      "mini projector",
      "smart watch band",
      "earbuds case",
      "bluetooth speaker",
      "power bank",
      "wireless charger",
      "phone tripod",
      "ring light",
      "led strip lights",
      "sunset lamp",
      "galaxy projector",
      "massage gun",
      "neck massager",
      "heated blanket",
      "electric lighter",
      "digital photo frame",
      "smart plug",
      "label maker",
      "air fryer accessories",
      "coffee gifts",
      "cocktail kit",
      "wine accessories",
      "bath gift set",
      "makeup organizer",
      "jewelry organizer",
      "travel gadgets",
      "cable organizer",
      "desk gadgets",
      "fidget toys",
      "gaming accessories",
      "controller holder",
      "headphone stand"
    ],
    christmas: [
      "christmas ornaments",
      "christmas lights",
      "advent calendar",
      "stocking stuffers",
      "christmas tree topper",
      "christmas village",
      "star projector",
      "snow globe",
      "christmas tablecloth",
      "family christmas pajamas",
      "christmas window decorations",
      "gift wrap organizer",
      "christmas stockings",
      "personalized ornaments",
      "christmas tree skirt",
      "christmas tree collar",
      "christmas garland",
      "christmas wreath",
      "prelit garland",
      "christmas pillow covers",
      "christmas doormat",
      "christmas table runner",
      "christmas centerpiece",
      "christmas gnome",
      "christmas nutcracker",
      "santa hat",
      "elf costume",
      "ugly christmas sweater",
      "christmas socks",
      "christmas earrings",
      "christmas headband",
      "christmas napkins",
      "christmas cookie cutters",
      "gingerbread house kit",
      "christmas mug",
      "hot cocoa bomb mold",
      "christmas candle",
      "led window lights",
      "icicle lights",
      "curtain lights",
      "christmas projector light",
      "outdoor christmas decorations",
      "inflatable santa",
      "light up reindeer",
      "christmas tree stand",
      "ornament storage box",
      "wreath storage bag",
      "christmas gift bags",
      "gift tags",
      "ribbon bows",
      "christmas cards",
      "santa letter kit",
      "christmas countdown calendar",
      "christmas train set",
      "christmas music box",
      "dog christmas sweater"
    ],
    winter: [
      "rechargeable hand warmer",
      "heated gloves",
      "ice scraper",
      "thermal socks",
      "windshield snow cover",
      "door draft stopper",
      "heated insoles",
      "fleece blanket",
      "touchscreen gloves",
      "snow brush",
      "heated vest",
      "heated scarf",
      "electric blanket",
      "heated throw",
      "thermal underwear",
      "led beanie",
      "balaclava",
      "ear warmers",
      "fleece neck gaiter",
      "ice cleats",
      "shoe spikes",
      "window insulation kit",
      "heated mug",
      "sherpa blanket",
      "wearable blanket",
      "slipper socks",
      "fuzzy socks",
      "house slippers",
      "humidifier",
      "heated seat cover",
      "heated steering wheel cover",
      "snow shovel",
      "snow sled",
      "snowball maker",
      "boot tray",
      "boot dryer",
      "weather stripping",
      "thermal curtains",
      "hot water bottle",
      "microwave heating pad",
      "winter hat",
      "faux fur headband",
      "cold weather face mask",
      "lip balm holder",
      "car snow brush"
    ]
  };

  // src/core/seasons.ts
  var DAY2 = 864e5;
  var LEAD = 28;
  var HORIZON = 120;
  var local = (y, m, d) => new Date(y, m, d).getTime();
  function nthWeekday(y, m, weekday, n) {
    const first = new Date(y, m, 1).getDay();
    return local(y, m, 1 + (weekday - first + 7) % 7 + (n - 1) * 7);
  }
  function easter(y) {
    const a = y % 19, b = Math.floor(y / 100), c = y % 100, d = Math.floor(b / 4), e = b % 4, f = Math.floor((b + 8) / 25), g = Math.floor((b - f + 1) / 3), h = (19 * a + b - d - g + 15) % 30, i = Math.floor(c / 4), k = c % 4, l = (32 + 2 * e + 2 * i - h - k) % 7, m = Math.floor((a + 11 * h + 22 * l) / 451), n = h + l - 7 * m + 114;
    return local(y, Math.floor(n / 31) - 1, n % 31 + 1);
  }
  var day = (t) => new Date(t).toLocaleDateString("fr-FR", { day: "numeric", month: "long" });
  var inDays = (t, now) => Math.max(0, Math.round((t - now) / DAY2));
  var US_EVENTS = [
    {
      id: "superbowl",
      icon: "\u{1F3C8}",
      name: "le Super Bowl",
      short: "Super Bowl",
      date: (y) => nthWeekday(y, 1, 0, 2),
      searches: EVENT_SEARCHES.superbowl
    },
    {
      id: "valentine",
      icon: "\u{1F49D}",
      name: "la Saint-Valentin",
      short: "Saint-Valentin",
      date: (y) => local(y, 1, 14),
      searches: EVENT_SEARCHES.valentine
    },
    {
      id: "stpatrick",
      icon: "\u2618\uFE0F",
      name: "la Saint-Patrick",
      short: "Saint-Patrick",
      date: (y) => local(y, 2, 17),
      searches: EVENT_SEARCHES.stpatrick
    },
    {
      id: "easter",
      icon: "\u{1F423}",
      name: "P\xE2ques",
      short: "P\xE2ques",
      date: (y) => easter(y),
      searches: EVENT_SEARCHES.easter
    },
    {
      id: "spring",
      icon: "\u{1F331}",
      name: "le printemps (jardin)",
      short: "Jardin",
      date: (y) => local(y, 3, 15),
      searches: EVENT_SEARCHES.spring
    },
    {
      id: "mother",
      icon: "\u{1F490}",
      name: "la f\xEAte des m\xE8res aux \xC9tats-Unis",
      short: "F\xEAte des m\xE8res",
      date: (y) => nthWeekday(y, 4, 0, 2),
      searches: EVENT_SEARCHES.mother
    },
    {
      id: "graduation",
      icon: "\u{1F393}",
      name: "les remises de dipl\xF4mes",
      short: "Remise des dipl\xF4mes",
      date: (y) => local(y, 4, 25),
      searches: EVENT_SEARCHES.graduation
    },
    {
      id: "father",
      icon: "\u{1F454}",
      name: "la f\xEAte des p\xE8res aux \xC9tats-Unis",
      short: "F\xEAte des p\xE8res",
      date: (y) => nthWeekday(y, 5, 0, 3),
      searches: EVENT_SEARCHES.father
    },
    {
      id: "summer",
      icon: "\u{1F3D6}\uFE0F",
      name: "l\u2019\xE9t\xE9",
      short: "\xC9t\xE9",
      date: (y) => local(y, 5, 21),
      searches: EVENT_SEARCHES.summer
    },
    {
      id: "july4",
      icon: "\u{1F386}",
      name: "le 4 juillet (f\xEAte nationale am\xE9ricaine)",
      short: "4 juillet",
      date: (y) => local(y, 6, 4),
      searches: EVENT_SEARCHES.july4
    },
    {
      id: "school",
      icon: "\u{1F392}",
      name: "la rentr\xE9e scolaire aux \xC9tats-Unis",
      short: "Rentr\xE9e",
      date: (y) => local(y, 7, 15),
      searches: EVENT_SEARCHES.school
    },
    {
      id: "halloween",
      icon: "\u{1F383}",
      name: "Halloween",
      short: "Halloween",
      date: (y) => local(y, 9, 31),
      searches: EVENT_SEARCHES.halloween
    },
    {
      id: "thanksgiving",
      icon: "\u{1F983}",
      name: "Thanksgiving",
      short: "Thanksgiving",
      date: (y) => nthWeekday(y, 10, 4, 4),
      searches: EVENT_SEARCHES.thanksgiving
    },
    {
      id: "blackfriday",
      icon: "\u{1F6CD}\uFE0F",
      name: "le Black Friday",
      short: "Black Friday",
      date: (y) => nthWeekday(y, 10, 4, 4) + DAY2,
      searches: EVENT_SEARCHES.blackfriday,
      note: "Les acheteurs comparent les prix : v\xE9rifie que tes annonces rentables sont en stock chez le fournisseur, et pr\xE9vois une petite promotion seulement si ton b\xE9n\xE9fice le permet."
    },
    {
      id: "christmas",
      icon: "\u{1F384}",
      name: "No\xEBl",
      short: "No\xEBl",
      date: (y) => local(y, 11, 25),
      searches: EVENT_SEARCHES.christmas,
      note: "Apr\xE8s le 5 d\xE9cembre environ, un colis AliExpress risque d\u2019arriver apr\xE8s No\xEBl : ne promets plus de livraison avant le 25 dans tes messages."
    },
    {
      id: "winter",
      icon: "\u2744\uFE0F",
      name: "le grand froid",
      short: "Hiver",
      date: (y) => local(y, 0, 15),
      searches: EVENT_SEARCHES.winter
    }
  ];
  function upcomingEvents(now = Date.now(), horizon = HORIZON) {
    const d = new Date(now);
    const today = local(d.getFullYear(), d.getMonth(), d.getDate());
    const out = [];
    for (const e of US_EVENTS)
      for (const y of [d.getFullYear(), d.getFullYear() + 1]) {
        const date = e.date(y);
        if (date < today || date - today > horizon * DAY2) continue;
        const deadline = date - LEAD * DAY2;
        out.push({
          id: e.id,
          key: `${e.id}:${y}`,
          icon: e.icon,
          name: e.name,
          short: e.short,
          date,
          deadline,
          daysLeft: inDays(date, today),
          ready: today <= deadline,
          searches: e.searches,
          note: e.note
        });
      }
    return out.sort((a, b) => a.date - b.date);
  }
  function eventThemes(now = Date.now()) {
    const seen = /* @__PURE__ */ new Set();
    return upcomingEvents(now, 400).filter((e) => e.ready && !seen.has(e.id) && seen.add(e.id));
  }
  var deadlineText = (e) => e.ready ? `annonces en ligne avant le ${day(e.deadline)}` : "trop tard pour de nouvelles annonces livr\xE9es \xE0 temps";

  // src/ui/scout.ts
  var KEY = "productScout:v1";
  var $ = (id) => document.getElementById(id);
  var usd = (n) => `$${n.toFixed(2)}`;
  var safeUrl = (url) => /^https:\/\//.test(url) ? url : "#";
  var toastTimer;
  function toast(text, error = false) {
    const t = $("toast");
    t.textContent = text;
    t.className = "toast" + (error ? " error" : "");
    t.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => t.hidden = true, 4e3);
  }
  var veroBadge = (title) => {
    const names = brandRisks(title).filter((b) => b.level === "danger").map((b) => b.name);
    return names.length ? `<div class="vero" title="Sans autorisation du propri\xE9taire, eBay retire l\u2019annonce et peut suspendre ton compte (programme VeRO). Choisis plut\xF4t un produit sans marque.">\u{1F6AB} Marque prot\xE9g\xE9e : ${escapeHTML(names.join(", "))} \xB7 \xE0 \xE9viter</div>` : "";
  };
  var trendBadge = (p) => {
    const t = trendOf(p.d7, p.d30, p.capped);
    return t ? `<span class="trend ${t.kind}" title="${escapeHTML(t.title)}">${escapeHTML(t.label)}</span>` : "";
  };
  var followed = /* @__PURE__ */ new Set();
  var followButton = (seller) => !seller ? "" : followed.has(seller.toLowerCase()) ? `<span class="sc-follow on" title="Dans \xAB Mes concurrents \xBB">\u2713 Suivi</span>` : `<button type="button" class="sc-follow" data-follow="${escapeHTML(seller)}" title="Ajouter ${escapeHTML(seller)} \xE0 \xAB Mes concurrents \xBB pour voir ses nouvelles annonces">\u2B50 Suivre</button>`;
  var pct = (photo) => photo !== null ? ` ${Math.round(photo * 100)} %` : "";
  function card(p, i, busy) {
    const money = (n) => n.toLocaleString("fr-FR", { style: "currency", currency: p.currency });
    const where = Object.entries(p.located).sort((a, b) => b[1] - a[1]).map(([c, n]) => `${c} ${n}`).join(" \xB7 ");
    const off = busy ? " disabled" : "";
    const again = `<button class="btn small" type="button" data-photo="${escapeHTML(p.itemId)}"${off} title="Recherche par image sur AliExpress avec la photo de l\u2019annonce, puis celles des autres dropshippers hors US si besoin">${p.searchedAt ? "\u{1F504} Rechercher \xE0 nouveau par photo" : "\u{1F4F8} Chercher le fournisseur sur AliExpress (photo)"}</button>`;
    const alts = (p.alts ?? []).filter((a) => a.url !== p.supplier?.url).slice(0, 4);
    const others = alts.length ? `<details class="sc-alts"><summary>${alts.length} autre(s) boutique(s) AliExpress avec la m\xEAme photo</summary>${alts.map(
      (a) => `<div class="sc-alt"><img src="${escapeHTML(a.image)}" alt="" referrerpolicy="no-referrer" loading="lazy">
            <a href="${escapeHTML(safeUrl(a.url))}" target="_blank" rel="noopener">${a.price !== null ? usd(a.price) : "prix ?"} \xB7 \u{1F4F8} photo exacte${pct(a.photo)}<small>${escapeHTML(a.title.slice(0, 60))}${a.sold ? ` \xB7 ${a.sold.toLocaleString("fr-FR")}+ vendus` : ""}</small></a>
            <button class="btn small" type="button" data-pick="${escapeHTML(p.itemId)}" data-url="${escapeHTML(a.url)}"${off}>Choisir</button></div>`
    ).join("")}</details>` : "";
    const supplier = p.supplier ? `<div class="sc-ali"><img src="${escapeHTML(p.supplier.image)}" alt="" referrerpolicy="no-referrer" loading="lazy">
        <div><b>AliExpress ${p.supplier.price !== null ? usd(p.supplier.price) : "prix ?"}</b> \xB7 \u{1F4F8} photo exacte${pct(p.supplier.photo)}
        <small>${escapeHTML(p.supplier.title.slice(0, 70))}${p.supplier.sold ? ` \xB7 ${p.supplier.sold.toLocaleString("fr-FR")}+ vendus` : ""}</small>
        ${p.net !== null ? `<span class="net-pill ${p.net >= 0 ? "ok" : "loss"}">${p.net >= 0 ? "+" : ""}${money(p.net)} net au prix des dropshippers hors US</span>${p.floor ? ` <small>prix mini rentable ${usd(p.floor)}</small>` : ""}` : ""}</div></div>` : `<div class="sc-ali"><small>${p.searchedAt ? `Aucun produit AliExpress avec exactement la m\xEAme photo (${p.photosTried ?? 1} photo(s) eBay essay\xE9e(s)) : fournisseur pas trouv\xE9, ne devine pas.` : "Fournisseur AliExpress pas encore cherch\xE9."}</small></div>`;
    const flag = (status) => status === "NON_US" ? "\u{1F30D}" : status === "US" ? "\u{1F1FA}\u{1F1F8}" : "\u2754";
    const sellers = p.listings.slice(0, 5).map(
      (l) => `<div class="sc-seller"><a href="https://www.ebay.com/itm/${escapeHTML(l.itemId)}" target="_blank" rel="noopener" title="${escapeHTML(l.country ?? "pays inconnu")}">${flag(l.status)} ${escapeHTML(l.seller ?? "?")}${l.country && l.status === "NON_US" ? ` (${escapeHTML(l.country)})` : ""} \xB7 ${usd(l.total)}${l.d7 !== null && l.d7 !== void 0 ? ` \xB7 <b>${l.d7}</b> ventes 7 j \xB7 ${l.d30} en 30 j` : l.sold ? ` \xB7 ${l.sold} vendus` : ""}</a>${followButton(l.seller)}</div>`
    ).join("");
    const countries = Object.entries(p.countries).sort((a, b) => b[1] - a[1]).map(([c, n]) => n > 1 ? `${c} ${n}` : c).join(", ");
    return `<article class="sc-card${p.net !== null && p.net > 0 ? " good" : ""}" style="animation-delay:${i * 0.04}s">
    <div class="sc-top"><img src="${escapeHTML(p.image)}" alt="" referrerpolicy="no-referrer" loading="lazy">
      <div><div class="sc-title">${escapeHTML(p.title)}</div>${veroBadge(p.title)}
      <div class="sc-stats"><span class="hot">\u{1F30D} ${p.nonUS} dropshipper(s) hors US</span>${p.us ? `<span>\u{1F1FA}\u{1F1F8} ${p.us} US</span>` : ""}${p.unknown ? `<span>\u2754 ${p.unknown} pays inconnu</span>` : ""}${p.soldShown ? `<span>${p.soldShown.toLocaleString("fr-FR")} vendus (affich\xE9s)</span>` : ""}${p.d7 !== null && p.d7 !== void 0 ? `<span class="hot">\u{1F525} ${p.d7} ventes 7 j \xB7 ${p.d30} en 30 j</span>` : ""}${trendBadge(p)}<span>prix hors US ${usd(p.median)} livr\xE9</span>${p.niche ? `<span>niche : ${escapeHTML(p.niche)}</span>` : ""}</div>
      <div class="muted" style="font-size:12px;margin-top:4px">${escapeHTML(countries)}${where ? ` \xB7 exp\xE9di\xE9 depuis ${escapeHTML(where)}` : ""}</div></div></div>
    <div class="sc-sellers">${sellers}</div>
    ${supplier}
    ${others}
    <div class="sc-acts">
      <a class="btn small" href="https://www.ebay.com/itm/${escapeHTML(p.itemId)}" target="_blank" rel="noopener" title="L\u2019annonce qui a le plus vendu ces 7 derniers jours">Meilleure annonce eBay \u2197</a>
      ${p.supplier ? `<a class="btn small primary" href="${escapeHTML(safeUrl(p.supplier.url))}" target="_blank" rel="noopener">AliExpress \u2197</a><button class="btn small" type="button" data-copy="${escapeHTML(p.supplier.url)}">Copier le lien AliExpress</button>` : ""}
      ${again}
    </div>
  </article>`;
  }
  var elapsed = (since) => {
    const sec = Math.max(0, Math.round((Date.now() - since) / 1e3));
    return sec < 60 ? `${sec} s` : `${Math.floor(sec / 60)} min ${String(sec % 60).padStart(2, "0")} s`;
  };
  function subLine(s) {
    const sub = s.sub;
    if (!sub) return "";
    const pct2 = sub.total > 0 ? Math.min(100, Math.round(sub.done / sub.total * 100)) : null;
    const text = s.step.endsWith(sub.text) ? "" : escapeHTML(sub.text);
    return `<div class="sc-sub">
    <div class="sc-sub-text">${text}${pct2 !== null ? `${text ? " \xB7 " : ""}<b>${sub.done}/${sub.total}</b>` : ""} <span class="muted">\u23F1 <span data-since="${sub.since}">${elapsed(sub.since)}</span></span></div>
    <div class="sc-sub-bar${pct2 === null ? " busy" : ""}"><i style="width:${pct2 ?? 30}%"></i></div>
  </div>`;
  }
  var lastCards = "";
  var shown;
  var SORT = "scoutSort";
  var sort = "trend";
  try {
    const saved = localStorage.getItem(SORT);
    if (saved === "d7" || saved === "nonUS" || saved === "net" || saved === "trend") sort = saved;
  } catch {
  }
  function sorted(products) {
    const key = {
      trend: trendScore,
      d7: (p) => p.d7 ?? -1,
      nonUS: (p) => p.nonUS,
      net: (p) => p.net ?? -Infinity
    };
    return products.map((p, i) => ({ p, i })).sort((a, b) => key[sort](b.p) - key[sort](a.p) || a.i - b.i).map((x) => x.p);
  }
  var exactOnly = (p) => {
    const alts = p.alts?.filter((a) => a.exact);
    return p.supplier && !p.supplier.exact ? { ...p, supplier: null, net: null, floor: null, alts } : { ...p, alts };
  };
  function render(s) {
    if (s?.products?.some((p) => typeof p.nonUS !== "number")) s = void 0;
    if (s) s = { ...s, products: s.products.map(exactOnly) };
    if (s?.state === "running" && Date.now() - (s.beat ?? s.at) > 3 * 6e4)
      s = { ...s, state: "stopped", step: "Recherche interrompue (plus de nouvelles depuis 3 min). Relance-la." };
    const status = $("sc-status");
    const go = $("sc-go");
    if (!s) {
      status.hidden = true;
      return;
    }
    status.hidden = false;
    go.disabled = s.state === "running";
    const pct2 = s.total ? Math.round(s.done / s.total * 100) : 0;
    $("auto-go").disabled = s.state === "running";
    const auto = s.mode === "auto" && s.auto;
    const why = auto ? (() => {
      const r = auto.refused ?? {};
      const parts = [r.brand ? `marque prot\xE9g\xE9e ${r.brand}` : "", r.price ? `prix ${r.price}` : "", r.sales ? `ventes 30 j ${r.sales}` : "", r.profit ? `b\xE9n\xE9fice ${r.profit}` : ""].filter(Boolean);
      return ` \xB7 ${auto.seen ?? 0} produit(s) avec assez de dropshippers hors US vus${parts.length ? `, refus\xE9s : ${parts.join(", ")}` : ""}`;
    })() : "";
    const missing = s.products.filter((p) => !p.supplier && !p.searchedAt).length;
    const all = s.state !== "running" && missing ? ` <button type="button" class="btn small primary" id="sc-photo-all">\u{1F4F8} Chercher les fournisseurs par photo (${missing})</button>` : "";
    status.innerHTML = s.state === "running" && s.task === "suppliers" ? `<p><span class="ao-spinner"></span> ${escapeHTML(s.step)} (${s.done + 1}/${s.total}) <button type="button" class="btn small" id="sc-stop">\u25A0 Arr\xEAter</button></p><div class="ao-progress"><i style="--p:${Math.round(s.done / s.total * 100)}%"></i></div>${subLine(s)}` : s.state === "running" ? auto ? `<p><span class="ao-spinner"></span> \u{1F916} Autopilote${auto.event ? ` ${escapeHTML(auto.event)}` : ""} \xB7 <b>${s.products.length}/${auto.target}</b> produit(s) trouv\xE9(s) \xB7 ${auto.tried.length} niche(s) essay\xE9e(s)${escapeHTML(why)}<br><small class="muted">${escapeHTML(s.step)}</small> <button type="button" class="btn small" id="sc-stop">\u25A0 Arr\xEAter</button></p><div class="ao-progress"><i style="--p:${Math.round(s.products.length / auto.target * 100)}%"></i></div>${subLine(s)}` : `<p><span class="ao-spinner"></span> \xAB ${escapeHTML(s.query)} \xBB \xB7 ${escapeHTML(s.step)}${s.total > 1 ? ` (${s.done}/${s.total})` : ""} <button type="button" class="btn small" id="sc-stop">\u25A0 Arr\xEAter</button></p><div class="ao-progress"><i style="--p:${pct2}%"></i></div>${subLine(s)}` : s.state === "error" ? `<p class="warn">\u26A0 ${escapeHTML(s.error ?? "Erreur")}</p>` : auto ? `<p>\u{1F916} Autopilote${auto.event ? ` ${escapeHTML(auto.event)}` : ""}${s.state === "stopped" ? " (arr\xEAt\xE9)" : ""} \xB7 ${escapeHTML(s.step)}${escapeHTML(why)} <span class="muted">Niches : ${escapeHTML(auto.tried.join(", "))}</span></p>` : `<p>\xAB ${escapeHTML(s.query)} \xBB \xB7 ${s.read} annonces en stock lues \xB7 ${escapeHTML(s.step)} <span class="muted">(${new Date(s.at).toLocaleString("fr-FR", { dateStyle: "short", timeStyle: "short" })})</span></p>`;
    if (all) status.insertAdjacentHTML("beforeend", `<p>${all}</p>`);
    if ([s.error, s.step, s.sub?.text].some(asksAliRegion)) status.insertAdjacentHTML("beforeend", `<p>${aliRegionLink()}</p>`);
    else if ([s.error, s.step, s.sub?.text].some(asksAliCookies)) status.insertAdjacentHTML("beforeend", `<p>${aliCookiesButton()}</p>`);
    else if ([s.error, s.step, s.sub?.text].some(asksAliVerify)) status.insertAdjacentHTML("beforeend", `<p>${aliVerifyLink()}</p>`);
    if (s.query && !$("sc-query").value) $("sc-query").value = s.query;
    shown = s;
    if (s.state !== "running") rememberTried(s);
    $("sc-sort").hidden = s.products.length < 2;
    const html = sorted(s.products).map((p, i) => card(p, i, s.state === "running")).join("");
    if (html !== lastCards) {
      lastCards = html;
      $("sc-results").innerHTML = html;
    }
  }
  async function load() {
    followed = new Set(
      (await message({ type: "COMPETITOR_LIST" }).catch(() => []) ?? []).map((c) => c.seller.toLowerCase())
    );
    render((await chrome.storage.local.get(KEY))[KEY]);
  }
  var RECENT = "scoutRecentNiches";
  var recent = () => {
    try {
      return JSON.parse(localStorage.getItem(RECENT) ?? "[]");
    } catch {
      return [];
    }
  };
  var remember = (niche) => {
    try {
      localStorage.setItem(RECENT, JSON.stringify([...recent().filter((n) => n !== niche), niche].slice(-40)));
    } catch {
    }
  };
  function ideas() {
    const [first, ...more] = pickNiches(6, recent());
    const input = $("sc-query");
    input.value = first.niche;
    input.focus();
    const box = $("sc-ideas");
    box.hidden = false;
    box.innerHTML = `<span class="muted">Id\xE9e : <b>${escapeHTML(first.niche)}</b> <small>(${escapeHTML(first.category)})</small> \xB7 autres :</span>` + more.map((n) => `<button type="button" class="sc-chip" data-niche="${escapeHTML(n.niche)}" title="${escapeHTML(n.category)}">${escapeHTML(n.niche)}</button>`).join("") + `<button type="button" class="sc-chip again" id="sc-again" title="D\u2019autres id\xE9es">\u{1F504}</button>`;
  }
  $("auto-cats").innerHTML = Object.keys(NICHES).map((c) => `<label class="sc-cat"><input type="checkbox" value="${escapeHTML(c)}" checked> ${escapeHTML(c)}</label>`).join("");
  function autoCriteria() {
    const num = (id) => {
      const v = $(id).value.trim();
      return v === "" ? null : Number(v);
    };
    return {
      categories: [...document.querySelectorAll("#auto-cats input:checked")].map((i) => i.value),
      minNonUS: Number($("auto-min").value),
      priceMin: num("auto-pmin"),
      priceMax: num("auto-pmax"),
      // Optional (user's request 11/2026: often priced at or above the dropshippers).
      minNet: $("auto-net-on").checked ? num("auto-net") : null,
      minD30: num("auto-d30") ?? 0,
      target: num("auto-target") ?? 10,
      pages: Number($("auto-pages").value),
      photoSearch: $("auto-photo").checked
    };
  }
  var NET_ON = "scoutMinNetOn";
  function showNet() {
    const on = $("auto-net-on").checked;
    $("auto-net").hidden = !on;
    $("auto-net-cur").hidden = !on;
    try {
      localStorage.setItem(NET_ON, on ? "1" : "");
    } catch {
    }
  }
  try {
    $("auto-net-on").checked = localStorage.getItem(NET_ON) === "1";
  } catch {
  }
  showNet();
  $("auto-net-on").addEventListener("change", () => {
    showNet();
    if ($("auto-net-on").checked) $("auto-net").focus();
  });
  $("auto-form").addEventListener("submit", (e) => {
    e.preventDefault();
    const fail = (err) => toast(err instanceof Error ? err.message : String(err), true);
    const theme = themes.find((t) => t.id === $("auto-theme").value);
    if (theme) {
      sort = "trend";
      try {
        localStorage.setItem(SORT, sort);
      } catch {
      }
      $("sc-sort-by").value = sort;
      return void message({
        type: "SCOUT_AUTO",
        criteria: { ...autoCriteria(), niches: theme.searches, event: themeLabel(theme), avoid: triedOf(theme.id) }
      }).catch(fail);
    }
    const criteria = autoCriteria();
    if (!criteria.categories.length) return toast("Coche au moins une cat\xE9gorie.", true);
    void message({ type: "SCOUT_AUTO", criteria }).catch(fail);
  });
  var themes = eventThemes();
  var THEME = "scoutTheme";
  var TRIED = "scoutThemeTried";
  var themeLabel = (t) => `${t.icon} ${t.short}`;
  var dayMonth = (t) => new Date(t).toLocaleDateString("fr-FR", { day: "numeric", month: "long" });
  var triedAll = () => {
    try {
      return JSON.parse(localStorage.getItem(TRIED) ?? "{}");
    } catch {
      return {};
    }
  };
  var triedOf = (id) => Array.isArray(triedAll()[id]) ? triedAll()[id] : [];
  function rememberTried(s) {
    const theme = s.mode === "auto" && s.auto?.event ? themes.find((t) => themeLabel(t) === s.auto.event) : void 0;
    if (!theme || !s.auto.tried.length) return;
    const all = triedAll();
    const before = Array.isArray(all[theme.id]) ? all[theme.id] : [];
    const list2 = [...before.filter((q) => !s.auto.tried.includes(q)), ...s.auto.tried].slice(-(theme.searches.length - 1));
    if (list2.join("|") === before.join("|")) return;
    try {
      localStorage.setItem(TRIED, JSON.stringify({ ...all, [theme.id]: list2 }));
    } catch {
    }
  }
  var themeSelect = $("auto-theme");
  {
    const soon = themes.filter((t) => t.daysLeft <= 120);
    const later = themes.filter((t) => t.daysLeft > 120);
    const option = (t) => `<option value="${escapeHTML(t.id)}">${t.icon} ${escapeHTML(t.short)} \xB7 ${t.searches.length} recherches \xB7 en ligne avant le ${escapeHTML(dayMonth(t.deadline))}</option>`;
    themeSelect.innerHTML = `<option value="">\u{1F3B2} Niches au hasard (cat\xE9gories coch\xE9es)</option>` + (soon.length ? `<optgroup label="F\xEAtes \xE0 venir (encore le temps)">${soon.map(option).join("")}</optgroup>` : "") + (later.length ? `<optgroup label="Plus tard (pour prendre de l\u2019avance)">${later.map(option).join("")}</optgroup>` : "");
  }
  function setTheme(id, save = true) {
    const theme = themes.find((t) => t.id === id);
    themeSelect.value = theme ? id : "";
    if (save)
      try {
        localStorage.setItem(THEME, theme ? id : "");
      } catch {
      }
    $("auto-cats").hidden = !!theme;
    const list2 = $("auto-theme-list");
    list2.hidden = !theme;
    $("auto-theme-info").innerHTML = theme ? `${theme.icon} le ${escapeHTML(dayMonth(theme.date))} (dans ${theme.daysLeft} j) : nouvelles annonces en ligne avant le <b>${escapeHTML(dayMonth(theme.deadline))}</b>. ${theme.note ? escapeHTML(theme.note) + " " : ""}L\u2019autopilote essaie jusqu\u2019\xE0 40 recherches au hasard, d\u2019abord celles pas encore essay\xE9es.` : "AurOEBay pioche des niches au hasard dans les cat\xE9gories coch\xE9es.";
    if (theme) {
      const tried = new Set(triedOf(theme.id));
      list2.querySelector("summary").textContent = `Voir les ${theme.searches.length} recherches de ce th\xE8me${tried.size ? ` (${tried.size} d\xE9j\xE0 essay\xE9e(s))` : ""} \xB7 clique pour en chercher une seule`;
      list2.querySelector(".sc-ideas").innerHTML = theme.searches.map((q) => `<button type="button" class="sc-chip${tried.has(q) ? " tried" : ""}" data-niche="${escapeHTML(q)}"${tried.has(q) ? ' title="D\xE9j\xE0 essay\xE9e par l\u2019autopilote"' : ""}>${escapeHTML(q)}</button>`).join("");
    }
    renderEvents();
  }
  themeSelect.addEventListener("change", () => setTheme(themeSelect.value));
  $("auto-theme-list").addEventListener("click", (e) => {
    const chip = e.target.closest("[data-niche]");
    if (!chip) return;
    $("sc-query").value = chip.dataset.niche ?? "";
    $("sc-query").focus();
    window.scrollTo({ top: 0, behavior: "smooth" });
    toast("Recherche choisie : clique \xAB \u{1F50D} Chercher \xBB.");
  });
  function renderEvents() {
    const events = upcomingEvents().filter((e) => e.ready).slice(0, 6);
    const box = $("sc-events");
    box.hidden = !events.length;
    if (!events.length) return;
    box.innerHTML = `<div class="sc-ev-head"><b>\u{1F4C5} F\xEAtes \xE0 venir aux \xC9tats-Unis</b> <span class="muted">Les produits de saison se vendent quelques semaines avant la date : AliExpress met 1 \xE0 3 semaines \xE0 livrer. Clique une f\xEAte pour la choisir comme th\xE8me de l\u2019autopilote.</span></div>
    <div class="sc-ev-list">${events.map(
      (e) => `<button type="button" class="sc-ev${e.id === themeSelect.value ? " on" : ""}" data-event="${escapeHTML(e.id)}"><span>${e.icon} ${escapeHTML(e.short)}</span><small>dans ${e.daysLeft} j \xB7 ${escapeHTML(deadlineText(e))}</small></button>`
    ).join("")}</div>`;
  }
  function chooseTheme(id) {
    setTheme(id);
    const auto = $("sc-auto");
    auto.open = true;
    auto.scrollIntoView({ behavior: "smooth", block: "start" });
  }
  $("sc-events").addEventListener("click", (e) => {
    const ev = e.target.closest("[data-event]");
    if (!ev) return;
    if (ev.dataset.event === themeSelect.value) return setTheme("");
    chooseTheme(ev.dataset.event);
  });
  {
    const asked = new URLSearchParams(location.search).get("event");
    let saved = "";
    try {
      saved = localStorage.getItem(THEME) ?? "";
    } catch {
    }
    if (asked && themes.some((t) => t.id === asked)) chooseTheme(asked);
    else setTheme(saved, false);
  }
  $("sc-sort-by").value = sort;
  $("sc-sort-by").addEventListener("change", () => {
    sort = $("sc-sort-by").value;
    try {
      localStorage.setItem(SORT, sort);
    } catch {
    }
    render(shown);
  });
  $("sc-status").addEventListener("click", (e) => {
    if (e.target.closest("[data-ali-cookies]")) return void message({ type: "OPEN_ALI_COOKIES" }).catch(() => {
    });
    if (e.target.closest("#sc-photo-all"))
      return void message({ type: "SCOUT_SUPPLIERS" }).catch((err) => toast(err instanceof Error ? err.message : String(err), true));
    if (e.target.closest("#sc-stop"))
      void message({ type: "SCOUT_STOP" }).then(() => toast("Arr\xEAt demand\xE9 : la recherche s\u2019arr\xEAte apr\xE8s l\u2019\xE9tape en cours."));
  });
  setupTheme();
  $("sc-idea").addEventListener("click", ideas);
  $("sc-ideas").addEventListener("click", (e) => {
    const b = e.target.closest("button");
    if (!b) return;
    if (b.id === "sc-again") return ideas();
    $("sc-query").value = b.dataset.niche ?? "";
    $("sc-ideas").querySelectorAll(".sc-chip").forEach((c) => c.classList.toggle("on", c === b));
  });
  $("scout-form").addEventListener("submit", (e) => {
    e.preventDefault();
    remember($("sc-query").value.trim().toLowerCase());
    void message({
      type: "SCOUT_RUN",
      query: $("sc-query").value,
      minNonUS: Number($("sc-min").value),
      pages: Number($("sc-pages").value),
      suppliers: Number($("sc-sup").value)
    }).catch((err) => toast(err instanceof Error ? err.message : String(err), true));
  });
  $("sc-results").addEventListener("click", (e) => {
    const fail = (err) => toast(err instanceof Error ? err.message : String(err), true);
    const photo = e.target.closest("[data-photo]");
    if (photo) {
      photo.disabled = true;
      return void message({ type: "SCOUT_SUPPLIERS", itemIds: [photo.dataset.photo], fresh: true }).catch(fail);
    }
    const pick = e.target.closest("[data-pick]");
    if (pick)
      return void message({ type: "SCOUT_PICK", itemId: pick.dataset.pick, url: pick.dataset.url }).then(() => toast("Fournisseur choisi : le b\xE9n\xE9fice est recalcul\xE9 avec son prix.")).catch(fail);
    const follow = e.target.closest("[data-follow]");
    if (follow) {
      const seller = follow.dataset.follow;
      follow.disabled = true;
      return void message({ type: "COMPETITOR_ADD", seller }).then(() => {
        followed.add(seller.toLowerCase());
        render(shown);
        toast(`${seller} ajout\xE9 \xE0 \xAB Mes concurrents \xBB : ses nouveaut\xE9s dans Ma journ\xE9e et Mes produits.`);
      }).catch((err) => {
        follow.disabled = false;
        fail(err);
      });
    }
    const b = e.target.closest("[data-copy]");
    if (!b) return;
    void navigator.clipboard.writeText(b.dataset.copy).then(() => toast("Lien AliExpress copi\xE9 : colle-le dans le panneau AurOEBay sur l\u2019annonce eBay."));
  });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && changes[KEY]) render(changes[KEY].newValue);
  });
  void load();
  setInterval(() => {
    document.querySelectorAll("[data-since]").forEach((el) => el.textContent = elapsed(Number(el.dataset.since)));
  }, 1e3);
  setInterval(() => {
    void chrome.storage.local.get(KEY).then((v) => {
      if (v[KEY]?.state === "running") render(v[KEY]);
    });
  }, 3e4);
})();
