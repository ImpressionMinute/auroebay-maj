"use strict";
(() => {
  // src/aliexpress/usLocale.ts
  function usLocaleCookie(cookie) {
    const raw = cookie.split("; ").find((c) => c.startsWith("aep_usuc_f="))?.slice("aep_usuc_f=".length);
    if (raw === void 0) return null;
    const want = {
      c_tp: "USD",
      b_locale: "en_US",
      region: "US"
    };
    let changed = false;
    const seen = /* @__PURE__ */ new Set();
    const parts = decodeURIComponent(raw).split("&").filter(Boolean).map((part) => {
      const key = part.split("=")[0];
      seen.add(key);
      if (key in want && part !== `${key}=${want[key]}`) {
        changed = true;
        return `${key}=${want[key]}`;
      }
      return part;
    });
    for (const [key, value] of Object.entries(want))
      if (!seen.has(key)) {
        parts.push(`${key}=${value}`);
        changed = true;
      }
    return changed ? parts.join("&") : null;
  }
  function enforceUsLocale(doc = document) {
    if (!/(^|\.)aliexpress\.us$/.test(location.hostname)) return false;
    const next = usLocaleCookie(doc.cookie);
    if (!next) return false;
    const guard = "auroebay-us-locale";
    try {
      const last2 = Number(sessionStorage.getItem(guard) ?? 0);
      if (Date.now() - last2 < 6e4) return false;
      sessionStorage.setItem(guard, String(Date.now()));
    } catch {
      return false;
    }
    const domain = "." + location.hostname.split(".").slice(-2).join(".");
    doc.cookie = `aep_usuc_f=${next}; domain=${domain}; path=/; max-age=31536000; secure`;
    location.reload();
    return true;
  }

  // src/core/messaging.ts
  async function message(body) {
    const reply = await chrome.runtime.sendMessage(body);
    if (!reply?.ok)
      throw Error(reply?.error ?? "AurOEBay ne r\xE9pond pas. Recharge la page.");
    return reply.data;
  }

  // src/core/staleContext.ts
  var stale = (reason) => /Extension context invalidated/i.test(reason instanceof Error ? reason.message : String(reason));
  var extensionAlive = () => {
    try {
      return !!chrome.runtime?.id;
    } catch {
      return false;
    }
  };
  function quietStaleContext(win = window) {
    win.addEventListener("error", (e) => {
      if (stale(e.error ?? e.message)) e.preventDefault();
    });
    win.addEventListener("unhandledrejection", (e) => {
      if (stale(e.reason)) e.preventDefault();
    });
  }

  // src/core/brand.ts
  var BRAND = {
    ember: "#ff5f3a",
    flame: "#ff8a3d",
    sun: "#ffb347",
    night: "#15121c",
    night2: "#1e1a27",
    night3: "#2a2534",
    nightLine: "#373042",
    paper: "#fbf7f3",
    paper2: "#ffffff",
    paper3: "#f4ede6",
    paperLine: "#ebe1d7",
    inkDark: "#f1ecf4",
    inkLight: "#1d1828",
    mutedDark: "#a49bb0",
    mutedLight: "#75697d",
    ok: "#22b07d",
    warn: "#f0a63a",
    danger: "#ef4f5f",
    info: "#7c8cff",
    gradient: "linear-gradient(135deg,#ff5f3a 0%,#ff8a3d 48%,#ffb347 100%)",
    ease: "cubic-bezier(.2,.8,.2,1)",
    spring: "cubic-bezier(.34,1.56,.64,1)"
  };
  function brandMarkSVG(size = 28, id = "ao") {
    return `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 48 48" aria-hidden="true"><defs><linearGradient id="${id}g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${BRAND.ember}"/><stop offset=".5" stop-color="${BRAND.flame}"/><stop offset="1" stop-color="${BRAND.sun}"/></linearGradient></defs><rect x="2" y="2" width="44" height="44" rx="13" fill="url(#${id}g)"/><path d="M14.5 36 24 12.5 33.5 36" fill="none" stroke="#fff" stroke-width="4.6" stroke-linecap="round" stroke-linejoin="round"/><path d="M18.6 30.2a5.4 5.4 0 0 1 10.8 0" fill="none" stroke="#fff" stroke-width="3.4" stroke-linecap="round"/><path class="ao-spark" d="M38 6.5l1.5 3.6 3.6 1.5-3.6 1.5L38 16.7l-1.5-3.6-3.6-1.5 3.6-1.5z" fill="#fff"/></svg>`;
  }
  var markURL = `url("data:image/svg+xml,${encodeURIComponent(brandMarkSVG(48, "u"))}")`;
  var BRAND_CSS = `
:root,:host{--ao-ember:${BRAND.ember};--ao-flame:${BRAND.flame};--ao-sun:${BRAND.sun};--ao-gradient:${BRAND.gradient};--ao-ease:${BRAND.ease};--ao-spring:${BRAND.spring};--ao-ok:${BRAND.ok};--ao-warn:${BRAND.warn};--ao-danger:${BRAND.danger};--ao-info:${BRAND.info};--ao-glow:0 10px 30px rgba(255,95,58,.35)}
.ao-mark{display:inline-block;flex:none;width:28px;height:28px;background:${markURL} center/contain no-repeat}
.ao-loader{position:relative;display:inline-grid;place-items:center;flex:none;width:var(--ao-size,64px);height:var(--ao-size,64px)}
.ao-loader::before{content:"";position:absolute;inset:0;border-radius:50%;background:conic-gradient(from 0deg,transparent 0 40%,${BRAND.sun} 70%,${BRAND.ember} 100%);-webkit-mask:radial-gradient(circle closest-side,transparent calc(100% - max(2px,calc(var(--ao-size,64px) * .05))),#000 calc(100% - max(2px,calc(var(--ao-size,64px) * .05)) + 1px));mask:radial-gradient(circle closest-side,transparent calc(100% - max(2px,calc(var(--ao-size,64px) * .05))),#000 calc(100% - max(2px,calc(var(--ao-size,64px) * .05)) + 1px));animation:ao-spin 1.15s linear infinite}
.ao-loader::after{content:"";position:absolute;top:50%;left:50%;width:max(3px,calc(var(--ao-size,64px) * .08));height:max(3px,calc(var(--ao-size,64px) * .08));margin:calc(max(3px,calc(var(--ao-size,64px) * .08)) / -2);border-radius:50%;background:#fff;box-shadow:0 0 8px 2px ${BRAND.sun};animation:ao-orbit 2.2s linear infinite}
.ao-loader>.ao-mark{width:64%;height:64%;animation:ao-breathe 2.4s var(--ao-ease) infinite;filter:drop-shadow(0 4px 10px rgba(255,95,58,.45))}
.ao-spinner{display:inline-block;flex:none;width:var(--ao-size,14px);height:var(--ao-size,14px);border-radius:50%;background:conic-gradient(from 0deg,transparent 0 35%,${BRAND.sun} 65%,${BRAND.ember});-webkit-mask:radial-gradient(circle closest-side,transparent 68%,#000 72%);mask:radial-gradient(circle closest-side,transparent 68%,#000 72%);animation:ao-spin .8s linear infinite;vertical-align:-2px}
.ao-sweep{position:relative;overflow:hidden;isolation:isolate}
.ao-sweep::after{content:"";position:absolute;inset:-20% auto -20% -60%;width:45%;background:linear-gradient(100deg,transparent,rgba(255,255,255,.28),transparent);transform:skewX(-18deg);animation:ao-sweep 4.8s var(--ao-ease) infinite;pointer-events:none;z-index:1}
.ao-rise{animation:ao-rise .5s var(--ao-ease) both}
.ao-progress{position:relative;height:6px;border-radius:99px;background:rgba(127,112,140,.18);overflow:hidden}
.ao-progress>i{position:absolute;inset:0 auto 0 0;width:var(--p,0%);border-radius:inherit;background:var(--ao-gradient);transition:width .7s var(--ao-ease)}
.ao-progress>i::after{content:"";position:absolute;inset:0;background:linear-gradient(90deg,transparent,rgba(255,255,255,.55),transparent);transform:translateX(-100%);animation:ao-shine 1.6s ease-in-out infinite}
.ao-progress.indeterminate>i{width:38%;animation:ao-slide 1.4s cubic-bezier(.65,0,.35,1) infinite}
.ao-spark{transform-box:fill-box;transform-origin:center;animation:ao-twinkle 3.2s ease-in-out infinite}
.profit-box{margin:10px 0;padding:10px 12px;border-radius:12px;border:1px solid rgba(127,112,140,.3);background:rgba(127,112,140,.08);font-size:12.5px;line-height:1.45;animation:ao-rise .4s var(--ao-ease) both}
.profit-box strong{display:block;font-size:13px;margin-bottom:2px}
.profit-box.ok{border-color:rgba(34,176,125,.45);background:rgba(34,176,125,.08)}
.profit-box.ok strong{color:${BRAND.ok}}
.profit-box.loss{border-color:rgba(255,95,58,.55);background:rgba(255,95,58,.09)}
.profit-box.loss strong{color:${BRAND.ember}}
.profit-box p{margin:4px 0}
.profit-box ul{margin:6px 0;padding-left:18px}
.profit-box li{margin:2px 0}
.profit-box small{display:block;margin-top:6px;opacity:.7;font-size:11px}
.net-pill{display:inline-block;padding:1px 7px;border-radius:99px;font-size:11.5px;font-weight:650;white-space:nowrap}
.net-pill.ok{background:rgba(34,176,125,.15);color:${BRAND.ok}}
.net-pill.loss{background:rgba(255,95,58,.16);color:${BRAND.ember}}
@keyframes ao-spin{to{transform:rotate(360deg)}}
@keyframes ao-orbit{from{transform:rotate(0) translateX(calc(var(--ao-size,64px) / 2)) rotate(0)}to{transform:rotate(360deg) translateX(calc(var(--ao-size,64px) / 2)) rotate(-360deg)}}
@keyframes ao-breathe{50%{transform:scale(.92) translateY(-1px)}}
@keyframes ao-sweep{0%,55%{left:-60%}100%{left:130%}}
@keyframes ao-rise{from{opacity:0;transform:translateY(10px) scale(.985)}to{opacity:1;transform:none}}
@keyframes ao-shine{to{transform:translateX(100%)}}
@keyframes ao-slide{from{transform:translateX(-105%)}to{transform:translateX(270%)}}
@keyframes ao-twinkle{0%,70%,100%{opacity:1;transform:scale(1) rotate(0)}80%{opacity:.35;transform:scale(.55) rotate(45deg)}90%{opacity:1;transform:scale(1.25) rotate(90deg)}}
@keyframes ao-pop{0%{transform:scale(.6);opacity:0}100%{transform:scale(1);opacity:1}}
@keyframes ao-pulse{0%{box-shadow:0 0 0 0 rgba(255,95,58,.5)}70%{box-shadow:0 0 0 10px rgba(255,95,58,0)}100%{box-shadow:0 0 0 0 rgba(255,95,58,0)}}
@media (prefers-reduced-motion:reduce){.ao-loader::before,.ao-loader::after,.ao-loader>.ao-mark,.ao-spinner,.ao-sweep::after,.ao-rise,.ao-progress>i::after,.ao-progress.indeterminate>i,.ao-spark{animation:none!important}}
`;
  var WINDOW_TOKENS = `--bg:${BRAND.night2};--bg2:${BRAND.night3};--line:${BRAND.nightLine};--ink:${BRAND.inkDark};--muted:${BRAND.mutedDark};--accent:${BRAND.ember};--ok:#3fd09a;--warn:${BRAND.warn};--err:#ff6b78`;

  // src/core/floating.ts
  var KEY = "floatingPosition:v1";
  var FLOAT_CSS = `${BRAND_CSS}
  :host{${WINDOW_TOKENS}}
  .card{position:relative;width:316px;max-height:75vh;overflow:auto;background:var(--bg);color:var(--ink);border:1px solid var(--line);border-radius:16px;box-shadow:0 18px 44px rgba(10,6,16,.45),0 0 0 1px rgba(255,255,255,.02) inset;font:13px/1.45 -apple-system,system-ui,sans-serif;animation:ao-rise .38s var(--ao-ease)}
  .card::before{content:"";position:sticky;top:0;display:block;height:2px;margin-bottom:-2px;background:linear-gradient(90deg,var(--ao-ember),var(--ao-sun),var(--ao-ember)) 0 0/200% 100%;animation:fline 6s linear infinite;z-index:2}
  .head{display:flex;justify-content:space-between;align-items:center;gap:8px;font-weight:700;padding:10px 12px;cursor:grab;user-select:none;border-bottom:1px solid var(--line)}
  .head>span{display:flex;align-items:center;gap:8px}
  .head:active{cursor:grabbing}
  .logo{width:22px;height:22px;transition:transform .45s var(--ao-spring)}
  .head:hover .logo{transform:rotate(-8deg) scale(1.08)}
  .body{padding:8px 12px 12px}
  .mini .body,.mini .t,.mini .x{display:none}
  .mini .card{width:auto;border-radius:16px;overflow:visible;background:transparent;border-color:transparent;box-shadow:none;animation:fpop .5s var(--ao-spring)}
  .mini .card::before{display:none}
  .mini .head{padding:0;border:0;cursor:pointer}
  .mini .logo{width:44px;height:44px;border-radius:13px;filter:drop-shadow(0 8px 18px rgba(255,95,58,.45));animation:fhalo 3.6s ease-out 1s infinite}
  .mini .head:hover .logo{transform:scale(1.12) rotate(-6deg)}
  button{font:600 13px system-ui;border-radius:10px;border:1px solid var(--line);background:var(--bg2);color:var(--ink);padding:8px 10px;cursor:pointer;width:100%;margin-top:6px;text-align:left;transition:background-position .4s var(--ao-ease),border-color .2s,transform .12s,box-shadow .2s}
  button:hover{border-color:color-mix(in srgb,var(--accent) 45%,var(--line))}
  button:active{transform:translateY(1px) scale(.99)}
  button.primary{background:var(--ao-gradient);background-size:170% 100%;border-color:transparent;color:#fff;box-shadow:0 6px 16px rgba(255,95,58,.3)}
  button.primary:hover{background-position:100% 0;box-shadow:0 8px 22px rgba(255,95,58,.42)}
  button.track{background:linear-gradient(135deg,#f0a63a,#ffcf6b);border-color:transparent;color:#2a1a05}
  button:disabled{opacity:.75;cursor:wait;position:relative;overflow:hidden}
  button:disabled::after{content:"";position:absolute;inset:0;background:linear-gradient(100deg,transparent 30%,rgba(255,255,255,.22) 50%,transparent 70%);transform:translateX(-100%);animation:ao-shine 1.4s ease-in-out infinite}
  button.primary:disabled::before{content:"";display:inline-block;width:12px;height:12px;margin-right:7px;vertical-align:-2px;border-radius:50%;background:conic-gradient(transparent 0 40%,#fff);-webkit-mask:radial-gradient(circle closest-side,transparent 62%,#000 70%);mask:radial-gradient(circle closest-side,transparent 62%,#000 70%);animation:ao-spin .8s linear infinite}
  @keyframes fline{to{background-position:-200% 0}}
  @keyframes fpop{0%{opacity:0;transform:scale(.4) rotate(-20deg)}100%{opacity:1;transform:none}}
  @keyframes fhalo{0%,60%,100%{filter:drop-shadow(0 8px 18px rgba(255,95,58,.45))}75%{filter:drop-shadow(0 0 22px rgba(255,179,71,.85))}}
  @media (prefers-reduced-motion:reduce){*,*::before,*::after{animation:none!important;transition:none!important}}
  .x{background:none;border:0;width:auto;margin:0;padding:0 4px;color:var(--muted);font-size:15px;transition:color .2s}.x:hover{color:var(--ink)}
  .status{margin:4px 0;color:var(--muted)}.ok{color:var(--ok)}.warn{color:var(--warn)}.err{color:var(--err)}
  ul{margin:6px 0 0;padding-left:18px}.small,.s{font-size:12px;color:var(--muted)}
  .label{margin:10px 0 4px;font:700 11px system-ui;letter-spacing:.06em;color:var(--muted)}
  label.row{display:flex;align-items:center;justify-content:space-between;gap:8px;margin:5px 0}
  input,select{font:13px system-ui;background:#15121c;color:var(--ink);border:1px solid var(--line);border-radius:9px;padding:6px 8px;transition:border-color .2s,box-shadow .2s}input:focus,select:focus{outline:0;border-color:var(--accent);box-shadow:0 0 0 3px rgba(255,95,58,.2)}
  label.row input,label.row select{width:150px;text-align:right}
  label.row.check{justify-content:flex-start;margin:8px 0;cursor:pointer}
  label.row.check input{width:auto;margin:0}
  input[type=search]{width:100%;box-sizing:border-box;margin-top:6px}
  .il-zip{margin-top:8px;padding:8px;border:1px solid var(--line);border-radius:12px}.il-zip-row{display:flex;gap:6px;margin-top:6px}.il-zip-row input{flex:1;min-width:0}.il-zip-row button{width:auto;margin:0;white-space:nowrap}
  .sale{margin-top:8px;padding:8px;border:1px solid var(--line);border-radius:12px;background:var(--bg2);animation:ao-rise .35s var(--ao-ease) both}
`;
  function floatingBox(doc, id, heading = "AurOEBay") {
    doc.getElementById(id)?.remove();
    const host = doc.createElement("div");
    host.id = id;
    host.style.cssText = "position:fixed;top:120px;right:20px;z-index:2147483645;";
    const root = host.attachShadow({ mode: "open" });
    root.innerHTML = `<style>${FLOAT_CSS}</style><div class="wrap"><div class="card"><div class="head"><span><span class="logo ao-mark"></span><span class="t"></span></span><button class="x" title="R\xE9duire">\u2013</button></div><div class="body"></div></div></div>`;
    const wrap = root.querySelector(".wrap");
    const head = root.querySelector(".head");
    const title = root.querySelector(".t");
    const toggle = root.querySelector(".x");
    title.textContent = heading;
    const site = location.hostname.replace(/^.*\.(ebay|aliexpress)\..*$/, "$1");
    const save = () => {
      if (!extensionAlive()) return;
      const r = host.getBoundingClientRect();
      void chrome.storage.local.get(KEY).then(
        (v) => chrome.storage.local.set({
          [KEY]: { ...v[KEY] ?? {}, [site]: { x: r.left, y: r.top, mini: wrap.classList.contains("mini") } }
        })
      ).catch(() => {
      });
    };
    const place = (x, y) => {
      const maxX = Math.max(0, innerWidth - 60);
      const maxY = Math.max(0, innerHeight - 40);
      host.style.left = Math.min(Math.max(0, x), maxX) + "px";
      host.style.top = Math.min(Math.max(0, y), maxY) + "px";
      host.style.right = "auto";
    };
    const startMini = site === "ebay";
    const setMini = (mini) => {
      wrap.classList.toggle("mini", mini);
      toggle.textContent = mini ? "+" : "\u2013";
      head.title = mini ? `AurOEBay \xB7 ${heading} \u2014 cliquer pour ouvrir` : "";
      if (!mini) {
        const r = host.getBoundingClientRect();
        if (r.right > innerWidth || r.bottom > innerHeight)
          place(Math.min(r.left, innerWidth - r.width - 8), Math.min(r.top, innerHeight - Math.min(r.height, innerHeight * 0.75) - 8));
      }
    };
    setMini(startMini);
    void chrome.storage.local.get(KEY).then((v) => {
      const pos = v[KEY]?.[site];
      if (pos && Number.isFinite(pos.x) && Number.isFinite(pos.y)) place(pos.x, pos.y);
      if (!startMini && pos?.mini) setMini(true);
    }).catch(() => {
    });
    toggle.addEventListener("click", (e) => {
      e.stopPropagation();
      setMini(!wrap.classList.contains("mini"));
      save();
    });
    head.addEventListener("pointerdown", (e) => {
      if (e.target.closest(".x")) return;
      const r = host.getBoundingClientRect();
      const dx = e.clientX - r.left, dy = e.clientY - r.top;
      const x0 = e.clientX, y0 = e.clientY;
      head.setPointerCapture(e.pointerId);
      const move = (ev) => place(ev.clientX - dx, ev.clientY - dy);
      const up = (ev) => {
        head.removeEventListener("pointermove", move);
        head.removeEventListener("pointerup", up);
        head.removeEventListener("pointercancel", up);
        if (ev.type === "pointerup" && wrap.classList.contains("mini") && Math.hypot(ev.clientX - x0, ev.clientY - y0) < 5) setMini(false);
        save();
      };
      head.addEventListener("pointermove", move);
      head.addEventListener("pointerup", up);
      head.addEventListener("pointercancel", up);
    });
    doc.documentElement.append(host);
    return { host, root, body: root.querySelector(".body"), title, remove: () => host.remove(), open: () => setMini(false) };
  }

  // src/core/address.ts
  var IL_DISTRICTS = Object.fromEntries(
    [
      ["Tel Aviv", "tel aviv,tel aviv yafo,tel aviv jaffa,jaffa,yafo,givatayim,givataim,ramat gan,bnei brak,bene beraq,holon,bat yam,herzliya,herzliyya,ramat hasharon,kiryat ono,or yehuda,azor"],
      ["Jerusalem", "jerusalem,yerushalayim,beit shemesh,bet shemesh,mevaseret zion,mevaseret tsiyon,abu ghosh,tzur hadassah"],
      ["Haifa", "haifa,hefa,hadera,kiryat ata,kiryat bialik,kiryat motzkin,kiryat yam,nesher,tirat carmel,tirat karmel,zikhron yaakov,zichron yaakov,or akiva,pardes hanna,pardes hana karkur,binyamina,daliyat al karmel,umm al fahm"],
      ["HaDarom (South)", "beersheba,beer sheva,beer sheba,ashdod,ashkelon,eilat,elat,dimona,sderot,netivot,ofakim,kiryat gat,kiryat malakhi,arad,yeruham,mitzpe ramon,rahat"],
      ["HaMerkaz (Central)", "petah tikva,petach tikva,petah tiqwa,rishon lezion,rishon letsiyon,netanya,rehovot,kfar saba,kefar sava,raanana,modiin,modiin maccabim reut,lod,ramla,rosh haayin,hod hasharon,ness ziona,nes tsiyona,yavne,yavneh,kfar yona,even yehuda,elad,shoham,yehud,gedera,kadima,tayibe,kafr qasim,beer yaakov,gan yavne,mazkeret batya"],
      ["HaZafon (North)", "pekiin,peqiin,nazareth,nazrat,tiberias,tveria,afula,karmiel,nahariya,akko,acre,safed,tzfat,zefat,kiryat shmona,maalot tarshiha,migdal haemek,beit shean,bet shean,yokneam,yokneam illit,nof hagalil,nazareth illit,shfaram,sakhnin,katzrin,qatsrin"],
      ["Judea and Samaria", "ariel,maale adumim,modiin illit,beitar illit,efrat,maale shomron,maale shomeron,karnei shomron,kedumim,immanuel,emmanuel,kiryat arba,elkana,oranit,alfei menashe,givat zeev,beit el,ofra,shilo,maale efrayim"]
    ].flatMap(([district, cities]) => cities.split(",").map((c) => [c.replace(/[^a-z]/g, ""), district]))
  );
  function translitKey(t) {
    return t.normalize("NFKD").toLowerCase().replace(/\([^)]*\)/g, " ").replace(/[^a-z]/g, "").replace(/ph/g, "f").replace(/ts|tz/g, "z").replace(/ck|[cq]/g, "k").replace(/[vw]/g, "b").replace(/[aeiouyh]/g, "").replace(/(.)\1+/g, "$1");
  }
  var IL_BY_SOUND = /* @__PURE__ */ new Map();
  for (const [city, district] of Object.entries(IL_DISTRICTS)) {
    const k = translitKey(city);
    if (k.length < 3) continue;
    const seen = IL_BY_SOUND.get(k);
    IL_BY_SOUND.set(k, seen === void 0 || seen === district ? district : null);
  }
  var ilDistrict = (city) => IL_DISTRICTS[city.toLowerCase().replace(/[^a-z]/g, "")] ?? IL_BY_SOUND.get(translitKey(city)) ?? null;
  var IL_DISTRICT_LABELS = [
    "HaMerkaz (Central)",
    "Tel Aviv",
    "HaZafon (North)",
    "Haifa",
    "Jerusalem",
    "HaDarom (South)",
    "Judea and Samaria"
  ];
  var NATIONS = ["England", "Scotland", "Wales", "Northern Ireland"];
  var SCOTLAND = /^(AB|DD|DG|EH|FK|G|HS|IV|KA|KW|KY|ML|PA|PH|TD|ZE)\d/;
  var WALES = /^(CF|LD|LL|NP|SA)\d/;
  function ukNation(state, postcode) {
    const s = state.trim().toLowerCase();
    const named = NATIONS.find((n) => n.toLowerCase() === s);
    if (named) return named;
    const pc = postcode.toUpperCase().replace(/\s+/g, "");
    if (/^BT\d/.test(pc)) return "Northern Ireland";
    if (SCOTLAND.test(pc)) return "Scotland";
    if (WALES.test(pc)) return "Wales";
    return "England";
  }
  function ilOldPostcode(a) {
    const zip = a.zip.replace(/\s/g, "");
    return a.country === "IL" && /^\d{5}$/.test(zip) ? zip : null;
  }
  function ilVillageCode(city, old) {
    return ilDistrict(city) ? null : `${old}00`;
  }
  function ilPostcodeSearchUrl(street, city) {
    const q = `${street} ${city} Israel postal code 7 digits`.replace(/\s+/g, " ").trim();
    return `https://www.google.com/search?q=${encodeURIComponent(q)}`;
  }
  function ilPostcodeCheck(typed, old) {
    const code = typed.replace(/[\s-]/g, "");
    if (!/^\d{7}$/.test(code)) return { code: null, warning: "Il faut 7 chiffres (ex. 5360014)." };
    if (old && !code.startsWith(old))
      return { code, warning: `Attention : ce code ne commence pas par ${old} (l\u2019ancien code du client). V\xE9rifie la rue et le num\xE9ro.` };
    return { code, warning: null };
  }

  // src/aliexpress/orderDetail.ts
  var CURRENCY = { "\u20AC": "EUR", $: "USD", "US $": "USD", "\xA3": "GBP" };
  var STATUS = /\b(Awaiting payment|Payment pending|Processing|Awaiting shipment|Shipped|Awaiting delivery|In transit|Delivered|Completed|Closed|Cancell?ed|Refunded)\b/i;
  function aliAmount(text) {
    const t = text.trim().replace(/[.,]+$/, "");
    const n = /,\d{1,2}$/.test(t) ? t.replace(/[.\s]/g, "").replace(",", ".") : t.replace(/[,\s]/g, "");
    return Number(n);
  }
  var AMOUNT = String.raw`(?:(US \$|€|\$|£)\s?(\d[\d.,]*)|(\d[\d.,]*)\s?(€|\$|£))`;
  function parsed(m, offset) {
    const symbol = m[offset] ?? m[offset + 3];
    const amount = aliAmount(m[offset + 1] ?? m[offset + 2]);
    return Number.isFinite(amount) ? { amount, currency: CURRENCY[symbol] ?? "USD" } : null;
  }
  function money(text, label) {
    let found = null;
    const re = new RegExp(`(?:${label.source})[^\\d$\u20AC\xA3\\n]{0,25}${AMOUNT}`, "g");
    for (const m of text.matchAll(re)) found = parsed(m, 1) ?? found;
    return found;
  }
  function itemsSum(text) {
    let sum = 0, currency = "";
    for (const m of text.matchAll(new RegExp(`${AMOUNT}\\s*[x\xD7]\\s?(\\d{1,3})\\b`, "g"))) {
      const p = parsed(m, 1);
      if (!p || currency && p.currency !== currency) return null;
      currency = p.currency;
      sum += p.amount * Number(m[5]);
    }
    return sum > 0 ? { amount: Math.round(sum * 100) / 100, currency } : null;
  }
  function readAliOrderDetail(doc, url) {
    const text = doc.body?.innerText ?? doc.body?.textContent ?? "";
    let orderId = null;
    try {
      orderId = new URL(url).searchParams.get("orderId");
    } catch {
    }
    if (!/^\d{8,25}$/.test(orderId ?? ""))
      orderId = text.match(/(?:Order (?:ID|number)|N° de commande)\s*:?\s*(\d{8,25})/i)?.[1] ?? null;
    const total = money(text, /(?<![A-Za-z])(?:Order total|Total payé|Montant total|Total)(?![a-z])/);
    const free = /(?:Shipping(?: fee)?|Livraison|Frais de port)\s*:?\s*(?:Free|Gratuit)/i.test(text);
    const shipping = free ? { amount: 0, currency: total?.currency ?? "USD" } : money(text, /(?<![A-Za-z])(?:Shipping(?: fee)?|Livraison|Frais de port|Frais de livraison)(?![a-z])/);
    const itemIds = [
      ...new Set(
        [...doc.querySelectorAll('a[href*="/item/"]')].flatMap(
          (a) => a.href.match(/\/item\/(\d{6,20})\.html/)?.[1] ?? []
        )
      )
    ];
    return {
      orderId,
      total,
      items: total ? null : itemsSum(text),
      shipping,
      status: text.match(STATUS)?.[1] ?? "",
      itemIds
    };
  }
  var euros = (m) => m.amount.toLocaleString("fr-FR", { style: "currency", currency: m.currency });
  var h = (tag, props = {}) => Object.assign(document.createElement(tag), props);
  function setupAliOrderDetail(enabled) {
    const box = floatingBox(document, "auroebay-ali-order", "Lier \xE0 une vente eBay");
    let active = true;
    const status = h("p", { className: "status" });
    const form = h("div");
    const list = h("div");
    box.body.append(status, form, list);
    const row = (label, control) => {
      const r = document.createElement("label");
      r.className = "row";
      const span = document.createElement("span");
      span.textContent = label;
      r.append(span, control);
      return r;
    };
    const field = (type, step) => {
      const i = document.createElement("input");
      i.type = type;
      if (step) {
        i.step = step;
        i.min = "0";
      }
      return i;
    };
    const orderInput = field("text");
    orderInput.inputMode = "numeric";
    const costInput = field("number", "0.01");
    const shipInput = field("number", "0.01");
    const curSelect = document.createElement("select");
    for (const c of ["USD", "EUR"]) curSelect.append(new Option(c, c));
    const statusInput = field("text");
    form.append(
      h("div", { className: "label", textContent: "COMMANDE ALIEXPRESS (\xC0 CORRIGER SI FAUX)" }),
      row("N\xB0 de commande", orderInput),
      row("Co\xFBt pay\xE9", costInput),
      row("Livraison", shipInput),
      row("Devise", curSelect),
      row("Statut", statusInput)
    );
    const purchase = () => {
      const cost = Number(costInput.value || 0) + Number(shipInput.value || 0);
      return {
        orderId: orderInput.value.trim(),
        cost: { amount: Math.round(cost * 100) / 100, currency: curSelect.value },
        status: statusInput.value.trim()
      };
    };
    const fail = (e) => {
      status.className = "status err";
      status.textContent = e instanceof Error ? e.message : String(e);
    };
    const card2 = (c, action) => {
      const d = h("div", { className: "sale" });
      const date = c.soldAt ? new Date(c.soldAt).toLocaleDateString("fr-FR") : "";
      const item = c.items[0];
      d.append(
        h("b", { textContent: `#${c.orderId}` }),
        h("div", {
          className: "s",
          textContent: `${date} \xB7 ${c.firstName}${c.country ? " \xB7 " + c.country : ""} \xB7 ${item?.quantity && item.quantity > 1 ? item.quantity + "\xD7 " : ""}${item?.title ?? ""}${item?.variation ? " \u2014 " + item.variation : ""}${c.items.length > 1 ? ` (+${c.items.length - 1})` : ""}`
        })
      );
      if (action) d.append(action);
      return d;
    };
    let info = null;
    const orderInfo = async (aliId) => {
      if (!info && aliId)
        info = (await message({ type: "ALI_ORDER_INFO", orderIds: [aliId], details: true }).catch(() => []))[0] ?? null;
      return info;
    };
    const found = h("p", { className: "s" });
    async function render() {
      if (!active || !enabled()) return;
      const page = readAliOrderDetail(document, location.href);
      const aliId = orderInput.value.trim() || page.orderId || "";
      const linked = aliId ? await message({ type: "SALE_SUPPLIER_STATE", aliOrderId: aliId }).catch(() => null) : null;
      if (!form.dataset.filled) {
        form.dataset.filled = "1";
        orderInput.value = aliId;
        const api = await orderInfo(aliId);
        const cost = linked?.supplier.share?.total ?? linked?.supplier.cost ?? api?.total ?? page.total ?? page.items;
        const source = linked ? "lien enregistr\xE9" : api?.total ? "donn\xE9es de la commande AliExpress" : page.total ? "Total affich\xE9 sur la page" : page.items ? "somme des articles (livraison \xE0 ajouter si payante)" : "";
        costInput.value = cost ? String(cost.amount) : "";
        shipInput.value = !linked && !api?.total && !page.total && page.items && page.shipping ? String(page.shipping.amount) : "0";
        curSelect.value = cost?.currency === "EUR" ? "EUR" : "USD";
        statusInput.value = linked?.supplier.status || page.status;
        found.textContent = [
          cost ? `Co\xFBt lu : ${source}.` : "Co\xFBt introuvable sur la page : saisis-le.",
          api?.tracking ? `Suivi : ${api.tracking}${api.carrier ? " (" + api.carrier + ")" : ""}.` : ""
        ].filter(Boolean).join(" ");
        form.append(found);
      }
      list.replaceChildren();
      if (linked) {
        const sharedIds = linked.shared?.map((s) => s.orderId) ?? [];
        status.className = "status ok";
        status.textContent = linked.shared ? `\u2713 Une commande AliExpress pour ${linked.shared.length} ventes eBay (co\xFBt r\xE9parti) : ${linked.shared.map((s) => `#${s.orderId} ${euros(s.cost)}`).join(" \xB7 ")}.` : `\u2713 Li\xE9e \xE0 la vente eBay #${linked.orderId}${linked.how === "auto" ? " (automatiquement : nom + code postal)" : ""}.`;
        const save = h("button", { className: "primary", textContent: "\u{1F4BE} Enregistrer les corrections" });
        save.addEventListener("click", () => void (linked.shared ? shareTo(sharedIds, save) : link(linked.orderId, save)));
        const more = h("button", {
          textContent: "\u2795 Ajouter une autre vente eBay (m\xEAme client)",
          title: "Le client a pass\xE9 plusieurs commandes eBay (ex. 2 variantes) achet\xE9es en une seule commande AliExpress : le co\xFBt est r\xE9parti entre elles."
        });
        more.addEventListener("click", () => void choose2(true, sharedIds.length ? sharedIds : [linked.orderId]));
        const open = h("button", { textContent: "\u{1F4D2} Ouvrir la vente dans AurOEBay" });
        open.addEventListener("click", () => void message({ type: "OPEN_SALES", orderId: linked.orderId }).catch(() => {
        }));
        const change = h("button", { textContent: "\u{1F501} Lier \xE0 une autre vente" });
        change.addEventListener("click", () => void choose2(true));
        const unlink = h("button", { textContent: "\u2716 D\xE9lier" });
        unlink.addEventListener("click", async () => {
          const from = sharedIds.length ? `des ventes eBay #${sharedIds.join(", #")}` : `de la vente eBay #${linked.orderId}`;
          if (!confirm(`D\xE9lier cette commande AliExpress ${from} ?`)) return;
          await message({ type: "SALE_UNLINK_SUPPLIER", aliOrderId: linked.supplier.orderId }).catch(fail);
          await render();
        });
        list.append(card2(linked, null));
        const all = linked.purchases ?? [linked.supplier];
        const orders = h("div", { className: "s" });
        orders.append(
          h("div", {
            textContent: all.length > 1 ? `${all.length} commandes AliExpress pour cette vente :` : "Commande AliExpress de cette vente :"
          })
        );
        for (const p of all)
          orders.append(
            h("div", {
              textContent: `${p.orderId === linked.supplier.orderId ? "\u25B6 " : "\u2022 "}#${p.orderId} \xB7 ${p.cost.amount.toLocaleString("fr-FR", { style: "currency", currency: p.cost.currency })}${p.status ? " \xB7 " + p.status : ""}${p.tracking ? " \xB7 \u{1F4E6} " + p.tracking : ""}`
            })
          );
        list.append(orders, save, more, open, change, unlink);
        return;
      }
      status.className = "status warn";
      status.textContent = "Pas encore li\xE9e \xE0 une vente eBay.";
      await choose2(false);
    }
    let split = false;
    let multi = false;
    const picked = /* @__PURE__ */ new Set();
    async function choose2(move, preselect) {
      if (preselect) {
        multi = true;
        split = false;
        picked.clear();
        preselect.forEach((id) => picked.add(id));
      }
      list.replaceChildren(h("p", { className: "s", textContent: "Recherche des ventes eBay\u2026" }));
      const receiver = (await orderInfo(orderInput.value.trim()))?.receiver ?? null;
      let candidates = await message({
        type: "SALE_CANDIDATES",
        receiver,
        includeLinked: split
      }).catch(() => []);
      if (multi && picked.size) {
        const linkedOnes = await message({ type: "SALE_CANDIDATES", receiver, includeLinked: true }).catch(() => []);
        candidates = [...linkedOnes.filter((c) => picked.has(c.orderId)), ...candidates.filter((c) => !picked.has(c.orderId))];
      }
      const page = readAliOrderDetail(document, location.href);
      const scored = candidates.map((c) => {
        const sameProduct = c.items.some((i) => i.supplierId && page.itemIds.includes(i.supplierId));
        return { c, sameProduct, score: (c.score ?? 0) * 2 + (sameProduct ? 3 : 0) };
      }).sort((a, b) => b.score - a.score || (b.c.soldAt ?? 0) - (a.c.soldAt ?? 0));
      list.replaceChildren();
      if (move) {
        const back = h("button", { textContent: "\u2190 Annuler" });
        back.addEventListener("click", () => void render());
        list.append(back);
      }
      const toggle = document.createElement("label");
      toggle.className = "row check";
      const box2 = document.createElement("input");
      box2.type = "checkbox";
      box2.checked = split;
      box2.addEventListener("change", () => {
        split = box2.checked;
        if (split) multi = false;
        void choose2(move);
      });
      const caption = document.createElement("span");
      caption.textContent = "Commande scind\xE9e par AliExpress : ajouter \xE0 une vente d\xE9j\xE0 li\xE9e";
      toggle.append(box2, caption);
      const toggleMulti = document.createElement("label");
      toggleMulti.className = "row check";
      const boxMulti = document.createElement("input");
      boxMulti.type = "checkbox";
      boxMulti.checked = multi;
      boxMulti.addEventListener("change", () => {
        multi = boxMulti.checked;
        if (multi) split = false;
        else picked.clear();
        void choose2(move);
      });
      const captionMulti = document.createElement("span");
      captionMulti.textContent = "Une commande AliExpress pour plusieurs ventes eBay (m\xEAme client, plusieurs commandes eBay) : co\xFBt r\xE9parti";
      toggleMulti.append(boxMulti, captionMulti);
      list.append(toggle, toggleMulti);
      const shareButton = h("button", { className: "primary" });
      const refreshShare = () => {
        shareButton.textContent = `\u{1F517} Lier aux ${picked.size} ventes coch\xE9es (co\xFBt r\xE9parti)`;
        shareButton.disabled = picked.size < 2;
      };
      shareButton.addEventListener("click", () => void shareTo([...picked], shareButton));
      if (!scored.length) {
        list.append(
          h("p", {
            className: "s",
            textContent: split ? "Aucune vente eBay d\xE9j\xE0 li\xE9e \xE0 une commande AliExpress." : "Aucune vente eBay libre. Sur eBay \u2192 Commandes, clique \xAB Enregistrer les commandes de cette page \xBB. Commande scind\xE9e ? Coche la case ci-dessus."
          })
        );
        return;
      }
      const search = field("search");
      search.placeholder = "Filtrer (n\xB0, pr\xE9nom, produit)\u2026";
      list.append(
        h("p", {
          className: "s",
          textContent: `${receiver ? `Destinataire AliExpress : ${receiver.name.split(" ")[0]} (${receiver.zip}). ` : ""}\u{1F464} = m\xEAme client \xB7 \u2605 = m\xEAme produit.`
        }),
        search
      );
      const items = h("div");
      list.append(items);
      const draw = () => {
        const q = search.value.trim().toLowerCase();
        items.replaceChildren();
        for (const { c, sameProduct } of scored.filter(
          ({ c: c2 }) => !q || [c2.orderId, c2.firstName, ...c2.items.map((i) => i.title + " " + i.variation)].join(" ").toLowerCase().includes(q)
        ).slice(0, 25)) {
          const sameClient = (c.score ?? 0) >= 2;
          let go;
          if (multi) {
            const label = document.createElement("label");
            label.className = "row check";
            const tick = document.createElement("input");
            tick.type = "checkbox";
            tick.checked = picked.has(c.orderId);
            tick.addEventListener("change", () => {
              if (tick.checked) picked.add(c.orderId);
              else picked.delete(c.orderId);
              refreshShare();
            });
            label.append(tick, h("span", { textContent: `${sameClient ? "\u{1F464} " : ""}${sameProduct ? "\u2605 " : ""}Cette vente fait partie de la commande` }));
            go = label;
          } else {
            const button = h("button", {
              className: sameClient && sameProduct ? "primary" : "",
              textContent: `${sameClient ? "\u{1F464} " : ""}${sameProduct ? "\u2605 " : ""}${split ? "\u2795 Ajouter \xE0 cette vente" : "Lier \xE0 cette vente"}`
            });
            button.addEventListener("click", () => void link(c.orderId, button, split));
            go = button;
          }
          const entry = card2(c, go);
          if (c.linkedOrders?.length)
            go.before(h("div", { className: "s", textContent: `D\xE9j\xE0 li\xE9e : #${c.linkedOrders.join(", #")}` }));
          items.append(entry);
        }
      };
      search.addEventListener("input", draw);
      draw();
      if (multi) {
        refreshShare();
        list.append(
          h("p", { className: "s", textContent: "Coche toutes les ventes eBay pay\xE9es par cette commande AliExpress. Le co\xFBt est r\xE9parti selon le montant de chaque vente." }),
          shareButton
        );
      }
    }
    async function shareTo(saleIds, button) {
      if (!enabled()) return;
      button.disabled = true;
      try {
        const p = purchase();
        if (!/^\d{8,25}$/.test(p.orderId)) throw Error("N\xB0 de commande AliExpress invalide.");
        if (!(p.cost.amount > 0)) throw Error("Renseigne le co\xFBt pay\xE9 sur AliExpress.");
        await message({
          type: "SALE_SHARE_SUPPLIER",
          saleIds,
          purchase: { ...p, tracking: info?.tracking ?? "", carrier: info?.carrier ?? "" }
        });
        multi = false;
        picked.clear();
        status.className = "status ok";
        status.textContent = `\u2713 Commande AliExpress li\xE9e aux ventes eBay #${saleIds.join(", #")} (co\xFBt r\xE9parti).`;
        await render();
      } catch (e) {
        fail(e);
      } finally {
        button.disabled = false;
      }
    }
    async function link(saleId, button, add = false) {
      if (!enabled()) return;
      button.disabled = true;
      try {
        const p = purchase();
        if (!/^\d{8,25}$/.test(p.orderId)) throw Error("N\xB0 de commande AliExpress invalide.");
        if (!(p.cost.amount > 0)) throw Error("Renseigne le co\xFBt pay\xE9 sur AliExpress.");
        await message({
          type: "SALE_LINK_SUPPLIER",
          orderId: saleId,
          purchase: { ...p, move: true, add, tracking: info?.tracking ?? "", carrier: info?.carrier ?? "" }
        });
        status.className = "status ok";
        status.textContent = `\u2713 Commande AliExpress ${add ? "ajout\xE9e \xE0" : "li\xE9e \xE0"} la vente eBay #${saleId}.`;
        await render();
      } catch (e) {
        fail(e);
      } finally {
        button.disabled = false;
      }
    }
    let tries = 0;
    const start = () => {
      if (!active) return;
      const page = readAliOrderDetail(document, location.href);
      if (!page.total && !page.items && tries++ < 6) {
        setTimeout(start, 1e3);
        return;
      }
      void render();
    };
    start();
    return () => {
      active = false;
      box.remove();
    };
  }

  // src/aliexpress/addressFill.ts
  function fieldRole(placeholder) {
    const p = placeholder.trim();
    if (!p || /^Search by|^Delivery instructions|^Alternate phone|Katakana|^RFC|^CPF|^DD\/MM|^National address/i.test(p))
      return null;
    if (/^(Contact name|Name)\*?$/i.test(p) || /^Contact name/i.test(p)) return "name";
    if (/^First name/i.test(p)) return "first";
    if (/^Last name/i.test(p)) return "last";
    if (/^(Mobile|Phone) number/i.test(p)) return "phone";
    if (/^Address detail 1/i.test(p)) return "detail1";
    if (/^Address detail 2/i.test(p)) return "detail2";
    if (/^Address detail 3/i.test(p)) return "detail3";
    if (/^(Street number|House number|House number and addition)\*?(\s+e\.g\..*)?$/i.test(p)) return "number";
    if (/^Neighborhood/i.test(p)) return "neighborhood";
    if (/^Street name\*?$/i.test(p)) return "streetName";
    if (/^Street & apartment/i.test(p)) return "streetName";
    if (/^(Street|House number, building|Street number and name|Street address)/i.test(p)) return "street";
    if (/^(Apt|Apartment|House number, room|Additional delivery)/i.test(p)) return "apt";
    if (/^(ZIP|Zip|Postcode|Postal code|PLZ|E\.g\.)/i.test(p)) return "zip";
    if (/^State\/Province/i.test(p)) return "state";
    if (/^(City|Town)\*?$/i.test(p)) return "city";
    return null;
  }
  function japanBlock(street) {
    let m = street.match(/^(\d+(?:-\d+)*)\s+(.+)$/);
    if (m) return { block: m[1], town: m[2] };
    m = street.match(/^(.+?)\s+(\d+(?:-\d+)*)$/);
    return m ? { block: m[2], town: m[1] } : null;
  }
  function coloniaOf(line, known) {
    let rest = line.split(",")[0];
    for (const name of known.filter(Boolean).sort((x, y) => y.length - x.length)) {
      const at = rest.toLowerCase().lastIndexOf(name.toLowerCase().trim());
      if (at > 0) rest = rest.slice(0, at);
    }
    return rest.replace(/[\s,-]+$/, "").trim();
  }
  function roleValues(a, roles) {
    const split = roles.has("number");
    const bare = split && a.houseNumber ? a.street.replace(new RegExp(`(^|\\s)${a.houseNumber.replace(/[.*+?^${}()|[\]\\/]/g, "\\$&")}(\\s|,|$)`), " ").replace(/\s+/g, " ").replace(/^[\s,]+|[\s,]+$/g, "") : a.street;
    const jp = roles.has("detail2") ? japanBlock(a.street) : null;
    const neighborhood = roles.has("neighborhood") ? a.apt || a.city : "";
    return {
      name: `${a.firstName} ${a.lastName}`.trim(),
      first: a.firstName,
      last: a.lastName,
      phone: a.phone,
      street: roles.has("street") && roles.has("streetName") ? bare : a.street,
      // NL has both « Street name » and « Street & Apartment »: the latter is the apt.
      streetName: bare || a.street,
      number: a.houseNumber,
      apt: neighborhood ? "" : a.apt,
      neighborhood,
      zip: a.zip,
      state: a.state,
      city: a.city,
      // Japan: « 1-1 Chiyoda » → town « Chiyoda », block « 1-1 ».
      detail1: jp?.town ?? a.street,
      detail2: jp?.block ?? (a.houseNumber || a.street),
      detail3: a.apt
    };
  }
  function bestSuggestion(items, a) {
    const fold2 = (t) => t.normalize("NFKD").replace(/[̀-ͯ]/g, "").toLowerCase();
    const words2 = [a.city, a.state, a.apt, a.street].join(" ").split(/[^\p{L}\p{N}]+/u).map(fold2).filter((w) => w.length > 2);
    let best = 0, score = -1;
    items.forEach((text, i) => {
      const t = fold2(text);
      const s = words2.filter((w) => t.includes(w)).length;
      if (s > score) best = i, score = s;
    });
    return best;
  }
  var NATIONS_UK = ["England", "Scotland", "Wales", "Northern Ireland"];
  var sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  var visible = (e) => !!e.offsetParent;
  var fold = (t) => t.normalize("NFKD").replace(/[̀-ͯ]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
  function setValue(el, value) {
    const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set;
    el.focus();
    setter.call(el, value);
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
    el.dispatchEvent(new Event("blur", { bubbles: true }));
  }
  function typeSearch(el, value) {
    const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set;
    el.focus();
    setter.call(el, value);
    el.dispatchEvent(new Event("input", { bubbles: true }));
  }
  function press(item) {
    const target = item.querySelector(".next-menu-item-text > *") ?? item.querySelector(".next-menu-item-text") ?? item;
    for (const type of ["pointerdown", "mousedown", "pointerup", "mouseup", "click"])
      target.dispatchEvent(
        new (type.startsWith("pointer") && typeof PointerEvent === "function" ? PointerEvent : MouseEvent)(type, {
          bubbles: true,
          cancelable: true,
          view: window
        })
      );
  }
  var openItems = () => [...document.querySelectorAll(".next-overlay-wrapper .next-menu-item")].filter(visible);
  async function closeMenus() {
    for (const type of ["mousedown", "mouseup", "click"]) document.body.dispatchEvent(new MouseEvent(type, { bubbles: true }));
    document.dispatchEvent(new MouseEvent("mousedown", { bubbles: true }));
    await sleep(200);
  }
  function sameSkeleton(a, b) {
    const k = (t) => fold(t).replace(/[^a-z]/g, "").replace(/[aeiouy]/g, "");
    const x = k(a);
    return x.length >= 4 && x === k(b);
  }
  function sameTransliteration(a, b) {
    const x = translitKey(a);
    return x.length >= 3 && x === translitKey(b);
  }
  var onlyOne = (list) => list.length === 1 ? list[0] : void 0;
  async function choose(trigger, label, prefer = "") {
    trigger.click();
    const search = trigger.classList.contains("next-has-search") ? trigger.querySelector("input") : null;
    const want = fold(label);
    if (search) {
      await sleep(300);
      const other = /^[kqc]/.test(want) ? ["k", "q", "c"].map((l) => l + want.slice(1, 2)) : [];
      for (const query of [.../* @__PURE__ */ new Set([label, want, want.split(" ")[0], want.slice(0, 2), ...other])].filter((q) => q.length > 1)) {
        typeSearch(search, query);
        await sleep(1100);
        if (openItems().some(
          (it) => fold(it.textContent ?? "").startsWith(want.split(" ")[0]) || sameSkeleton(it.textContent ?? "", label) || sameTransliteration(it.textContent ?? "", label)
        ))
          break;
      }
    }
    for (let i = 0; i < 15; i++) {
      await sleep(150);
      const items = openItems();
      if (!items.length) continue;
      const text = (it) => fold(it.textContent ?? "");
      const starts = items.filter((it) => text(it).startsWith(want));
      const detailed = search && prefer && /\d/.test(label) ? starts.find((it) => text(it) !== want && text(it).includes(fold(prefer))) : void 0;
      const hit = detailed ?? items.find((it) => text(it) === want) ?? (search ? starts.find((it) => prefer && text(it).includes(fold(prefer))) ?? starts[0] : void 0) ?? items.find((it) => sameSkeleton(it.textContent ?? "", label)) ?? onlyOne(items.filter((it) => sameTransliteration(it.textContent ?? "", label)));
      if (hit) {
        hit.scrollIntoView({ block: "nearest" });
        press(hit);
        await sleep(400);
        return true;
      }
      if (i > 5) break;
    }
    await closeMenus();
    return false;
  }
  var textInputs = () => [...document.querySelectorAll("input")].filter(
    // Postcode / street boxes with suggestions sit in an « auto-complete »
    // select (seen live: Mexico); they are text boxes all the same.
    (i) => visible(i) && (i.type === "text" || i.type === "tel" || !i.type) && (!i.closest(".next-select") || !!i.closest(".next-select-auto-complete"))
  );
  var menus = () => [...document.querySelectorAll(".next-select.next-select-trigger")].filter(
    (s) => visible(s) && !s.classList.contains("next-select-auto-complete")
  );
  var menuText = (s) => (s.querySelector("input")?.placeholder || "") + " " + (s.textContent?.trim() ?? "");
  var signature = () => textInputs().map((i) => i.placeholder).join("|") + "#" + menus().map((m) => m.textContent?.trim()).join("|");
  async function settle(max = 6e3) {
    let last2 = signature(), same = 0;
    for (let t = 0; t < max; t += 250) {
      await sleep(250);
      const now = signature();
      if (now === last2) {
        if (++same >= 3) return;
      } else same = 0, last2 = now;
    }
  }
  function fields() {
    const out = /* @__PURE__ */ new Map();
    for (const i of textInputs()) {
      let role = fieldRole(i.placeholder);
      if (role === "streetName" && out.has("streetName")) role = "apt";
      if (role && !out.has(role)) out.set(role, i);
    }
    const plain = [...document.querySelectorAll(".address-selector-wrap .selector-item input")].filter(visible);
    if (plain[0] && !out.has("state")) out.set("state", plain[0]);
    if (plain[1] && !out.has("city")) out.set("city", plain[1]);
    return out;
  }
  function setAliZip(zip) {
    const box = fields().get("zip");
    if (!box) return false;
    setValue(box, zip);
    return true;
  }
  async function fillAliAddress(a) {
    const problems = [];
    const country = menus()[0];
    const current = country?.textContent?.trim() ?? "";
    const same = fold(current).startsWith(fold(a.countryLabel)) || a.country === "US" && /^(US|United States)$/i.test(current);
    if (country && !same) {
      if (await choose(country, a.countryLabel)) await settle();
      else problems.push(`Pays \xAB ${a.countryLabel} \xBB \xE0 choisir \xE0 la main dans le menu Pays.`);
    }
    const manual = [...document.querySelectorAll("a,span,button,div")].find(
      (e) => !e.childElementCount && /^Enter manually$/i.test(e.textContent?.trim() ?? "") && visible(e)
    );
    if (manual && !fields().has("street") && !fields().has("detail1")) {
      manual.click();
      await settle(3e3);
    }
    const prefix = document.querySelector(".pre-part input, input#phoneCountry") ?? null;
    if (prefix && visible(prefix) && a.calling && prefix.value.replace(/\D/g, "") !== a.calling) setValue(prefix, `+${a.calling}`);
    let cityOnStreet = false;
    let zipPicked = false;
    let picked = "";
    const zipBox = fields().get("zip");
    if (zipBox && a.zip && a.country !== "GB") {
      if (zipBox.value) {
        setValue(zipBox, "");
        await sleep(300);
      }
      setValue(zipBox, a.zip);
      zipBox.dispatchEvent(new Event("input", { bubbles: true }));
      const digits = a.zip.replace(/[^0-9A-Z]/gi, "").toLowerCase();
      for (let i = 0; i < 10 && !zipPicked; i++) {
        await sleep(250);
        const items = openItems().filter((it) => fold(it.textContent ?? "").replace(/ /g, "").startsWith(digits));
        if (!items.length) continue;
        const pick = items[bestSuggestion(items.map((it) => it.textContent ?? ""), a)];
        picked = pick.textContent ?? "";
        press(pick);
        zipPicked = true;
        await settle(3e3);
      }
      if (!zipPicked && openItems().length) await closeMenus();
    }
    if (a.country === "GB") {
      const nationMenu = menus()[1];
      const nation = ukNation(a.state, a.zip);
      if (!nationMenu || !await choose(nationMenu, nation)) problems.push(`Nation \xAB ${nation} \xBB \xE0 choisir \xE0 la main (menu sous l\u2019adresse).`);
      else await settle(2e3);
      const countyMenu = menus()[2];
      const county = NATIONS_UK.includes(a.state) ? "" : a.state;
      if (countyMenu && county) {
        const plain = county.replace(/^(Greater|County)\s+/i, "");
        if (!await choose(countyMenu, county) && !(plain !== county && await choose(countyMenu, plain)) && !(a.city && await choose(countyMenu, a.city)))
          problems.push(`Comt\xE9 \xAB ${county} \xBB \xE0 choisir \xE0 la main dans la liste AliExpress.`);
      } else if (countyMenu && !county) problems.push("Comt\xE9 \xE0 choisir \xE0 la main (eBay ne le donne pas).");
    } else if (!zipPicked) {
      const levels = [a.region, a.state, a.city, a.apt.split(",")[0]].filter((v) => !!v);
      let level = 0;
      for (let i = 1; i < 6; i++) {
        const m = menus()[i];
        if (!m) break;
        const label = menuText(m);
        const shown = fold(m.textContent ?? "");
        if (/PLZ|Postal|ZIP|Postcode/i.test(label) || a.zip && shown.startsWith(fold(a.zip))) {
          if (a.zip && !shown.startsWith(fold(a.zip)) && !await choose(m, a.zip, a.city))
            problems.push(`Code postal \xAB ${a.zip} \xBB \xE0 choisir \xE0 la main.`);
          await settle(2e3);
          continue;
        }
        const wanted = /City|Town|Suburb/i.test(label) ? [a.city] : levels.slice(level);
        let done = false;
        for (const [k, value] of wanted.entries()) {
          if (shown === fold(value) || await choose(m, value, a.city)) {
            level += k + 1;
            done = true;
            break;
          }
        }
        if (!done) {
          const last2 = i === menus().length - 1;
          if (last2 && a.country === "IL" && a.city && i >= 2) {
            const district = menus()[i - 1];
            const first2 = district?.textContent?.trim() ?? "";
            const tried = fold(first2);
            let found = "";
            for (const label2 of IL_DISTRICT_LABELS) {
              if (!district || fold(label2) === tried) continue;
              if (!await choose(district, label2)) continue;
              await settle(2e3);
              const city = menus()[i];
              if (city && await choose(city, a.city)) {
                found = label2;
                break;
              }
            }
            if (found) {
              problems.push(`R\xE9gion corrig\xE9e : \xAB ${a.city} \xBB est dans \xAB ${found} \xBB. V\xE9rifie.`);
              level++;
              await settle(2e3);
              continue;
            }
            if (district && first2 && fold(menus()[i - 1]?.textContent ?? "") !== tried) {
              await choose(district, first2);
              await settle(2e3);
            }
          }
          if (last2 && a.city && await choose(m, "Other")) {
            cityOnStreet = true;
            level++;
            await settle(2e3);
            continue;
          }
          const what = last2 ? `Ville / quartier \xAB ${a.city} \xBB` : `\xC9tat / r\xE9gion \xAB ${levels[level] ?? a.state} \xBB`;
          problems.push(`${what} absent de la liste AliExpress : choisis le plus proche \xE0 la main.`);
          level++;
        }
        await settle(2e3);
      }
      if (/^Armed Forces/.test(a.state)) {
        for (let k = problems.length - 1; k >= 0; k--) if (problems[k].includes("absent de la liste")) problems.splice(k, 1);
      }
      const zipMenu = menus().find((m) => /PLZ|Postal|ZIP|Postcode/i.test(menuText(m)) && !fold(m.textContent ?? "").startsWith(fold(a.zip)));
      if (zipMenu && a.zip && !await choose(zipMenu, a.zip, a.city) && !problems.some((p) => p.startsWith("Code postal")))
        problems.push(`Code postal \xAB ${a.zip} \xBB \xE0 choisir \xE0 la main.`);
    } else {
      for (const m of menus().slice(1)) {
        const shown = fold(m.textContent ?? "");
        if (shown && !fold(picked).includes(shown) && a.city && shown !== fold(a.city)) await choose(m, a.city);
      }
      const all = menus();
      const district = a.country === "MX" && all.length >= 4 ? all[all.length - 1] : null;
      const colonia = district ? coloniaOf(a.apt, all.slice(1, -1).map((m) => m.textContent ?? "").concat(a.city, a.state)) : "";
      if (district && colonia && fold(district.textContent ?? "") !== fold(colonia)) await choose(district, colonia);
      problems.push("\xC9tat, ville et quartier choisis par AliExpress d\u2019apr\xE8s le code postal : v\xE9rifie-les.");
    }
    const write = () => {
      const boxes = fields();
      const values = roleValues(a, new Set(boxes.keys()));
      const missing2 = [];
      for (const [role, el] of boxes) {
        const value = values[role] ?? "";
        if (role === "zip" && zipPicked) continue;
        if (el.value !== value && (value || role !== "zip")) setValue(el, value);
      }
      if (!boxes.has("name") && !boxes.has("first")) missing2.push("Nom");
      if (!boxes.has("phone")) missing2.push("T\xE9l\xE9phone");
      if (!boxes.has("street") && !boxes.has("streetName") && !boxes.has("detail1")) missing2.push("Rue");
      return missing2;
    };
    write();
    await sleep(700);
    const missing = write();
    await sleep(300);
    if (openItems().length) await closeMenus();
    for (const m of missing) problems.push(`Champ ${m} introuvable : remplis-le \xE0 la main.`);
    if (cityOnStreet) {
      const line = fields().get("street") ?? fields().get("streetName") ?? fields().get("detail1");
      if (line && !fold(line.value).includes(fold(a.city))) setValue(line, `${line.value}, ${a.city}`);
      problems.push(`Ville \xAB ${a.city} \xBB absente de la liste AliExpress : \xAB Other \xBB choisi, la ville est \xE9crite apr\xE8s la rue. V\xE9rifie.`);
    }
    if (a.country === "GB") {
      const line2 = fields().get("apt");
      if (line2 && a.city && !line2.value.toLowerCase().includes(a.city.toLowerCase()))
        setValue(line2, [line2.value, a.city].filter(Boolean).join(", "));
    }
    return problems;
  }

  // src/aliexpress/orders.ts
  var CURRENCY2 = { "\u20AC": "EUR", $: "USD", "US $": "USD", "\xA3": "GBP" };
  function readAliOrderCard(card2) {
    const text = card2.innerText ?? card2.textContent ?? "";
    const orderId = text.match(/(?:Ref\.? Number|Order ID|Order number|N° de commande)\s*:?\s*(\d{8,25})/i)?.[1] ?? null;
    const total = text.match(/Total\s*:\s*(US \$|€|\$|£)\s?([\d.,]+)/i);
    const amount = total ? Number(total[2].replace(/,(?=\d{3}\b)/g, "").replace(",", ".")) : NaN;
    const itemIds = [
      ...new Set(
        [...card2.querySelectorAll('a[href*="/item/"]')].flatMap(
          (a) => a.href.match(/\/item\/(\d{6,20})\.html/)?.[1] ?? []
        )
      )
    ];
    return {
      orderId,
      status: card2.querySelector(".order-item-header-status-text")?.textContent?.trim() ?? "",
      cost: total && Number.isFinite(amount) ? { amount, currency: CURRENCY2[total[1]] ?? "USD" } : null,
      itemIds,
      title: card2.querySelector(".order-item-content-info-name")?.textContent?.trim() ?? ""
    };
  }
  var css = (e, s) => (e.style.cssText = s, e);
  var pill = (bg) => `display:inline-block;margin-left:8px;padding:3px 9px;border-radius:8px;font:700 12px system-ui;color:#fff;background:${bg};cursor:pointer;border:0`;
  var CLOSED = /expired|closed|cancel|to pay|awaiting payment|annul/i;
  function setupOrderList(enabled) {
    let active = true;
    let running = false;
    let candidates = null;
    const info = /* @__PURE__ */ new Map();
    let results = {};
    const panel = floatingBox(document, "auroebay-ali-orders");
    const status = Object.assign(document.createElement("p"), { className: "status" });
    const rescan = Object.assign(document.createElement("button"), { textContent: "\u21BB Rescanner les commandes visibles" });
    const sales = Object.assign(document.createElement("button"), { textContent: "\u{1F4D2} Voir mes ventes" });
    panel.body.append(status, rescan, sales);
    sales.addEventListener("click", () => void message({ type: "OPEN_SALES" }).catch(() => {
    }));
    rescan.addEventListener("click", () => {
      info.clear();
      void render();
    });
    const rowsOf = () => [...document.querySelectorAll(".order-item")].map((card2) => ({ card: card2, ...readAliOrderCard(card2) }));
    const send = (rows) => message({
      type: "SALE_SUPPLIER_ROWS",
      rows: rows.filter((r) => r.orderId).map((r) => {
        const i = info.get(r.orderId);
        return {
          orderId: r.orderId,
          status: r.status,
          cost: r.cost,
          itemIds: r.itemIds,
          receiver: i?.receiver ?? null,
          tracking: i?.tracking ?? "",
          carrier: i?.carrier ?? ""
        };
      })
    }).catch(() => ({}));
    async function render() {
      if (!active || !enabled() || running) return;
      const rows = rowsOf();
      if (!rows.length) return;
      running = true;
      try {
        results = await send(rows);
        const todo = rows.filter((r) => r.orderId && !info.has(r.orderId) && !CLOSED.test(r.status));
        if (todo.length) {
          status.textContent = `Scan de ${todo.length} commande(s) AliExpress\u2026`;
          for (let i = 0; i < todo.length; i += 5) {
            const part = todo.slice(i, i + 5);
            const unlinked = part.filter((r) => !results[r.orderId]?.saleId).map((r) => r.orderId);
            const linked2 = part.filter((r) => results[r.orderId]?.saleId).map((r) => r.orderId);
            const got = [
              ...unlinked.length ? await message({ type: "ALI_ORDER_INFO", orderIds: unlinked, details: true }).catch(() => []) : [],
              ...linked2.length ? await message({ type: "ALI_ORDER_INFO", orderIds: linked2, details: false }).catch(() => []) : []
            ];
            for (const g of got) info.set(g.orderId, g);
            for (const id of [...unlinked, ...linked2]) if (!info.has(id)) info.set(id, { orderId: id, receiver: null, tracking: "", carrier: "" });
            if (!active) return;
          }
          results = await send(rows);
          candidates = null;
        }
        const auto = Object.values(results).filter((r) => r.auto).length;
        const linked = rows.filter((r) => r.orderId && results[r.orderId]?.saleId).length;
        const tracked = rows.filter((r) => r.orderId && results[r.orderId]?.tracking).length;
        status.textContent = `${linked}/${rows.length} commandes li\xE9es \xE0 une vente eBay${auto ? ` (${auto} li\xE9e(s) automatiquement)` : ""} \xB7 ${tracked} num\xE9ro(s) de suivi.`;
        paint(rows);
      } finally {
        running = false;
      }
    }
    function paint(rows) {
      for (const row of rows) {
        if (!row.orderId) continue;
        const r = results[row.orderId] ?? { saleId: null };
        const header = row.card.querySelector(".order-item-header-status") ?? row.card;
        const key = JSON.stringify([row.orderId, r.saleId, r.saleIds, r.tracking, r.suggestion]);
        const old = row.card.querySelector("[data-auroebay-ali]");
        if (old?.dataset.key === key) continue;
        old?.remove();
        const wrap = document.createElement("span");
        wrap.setAttribute("data-auroebay-ali", "");
        wrap.dataset.key = key;
        if (r.saleId) {
          const link = Object.assign(css(document.createElement("button"), pill("#16a34a")), {
            type: "button",
            textContent: r.saleIds?.length ? `\u2713 Ventes eBay #${r.saleIds.join(" + #")}` : `\u2713 Vente eBay #${r.saleId}`,
            title: r.auto ? "Li\xE9e automatiquement (nom + code postal). Clique pour ouvrir dans AurOEBay." : "Ouvrir cette vente dans AurOEBay"
          });
          link.addEventListener("click", (e) => {
            e.preventDefault();
            e.stopPropagation();
            void message({ type: "OPEN_SALES", orderId: r.saleId }).catch(() => {
            });
          });
          wrap.append(link);
          if (r.tracking)
            wrap.append(
              Object.assign(css(document.createElement("span"), pill("#2563eb")), {
                textContent: `\u{1F4E6} ${r.tracking}`,
                title: "Num\xE9ro de suivi AliExpress, \xE0 mettre sur eBay depuis la commande eBay (bouton \xAB Mettre le suivi \xBB)"
              })
            );
        } else {
          const button = Object.assign(css(document.createElement("button"), pill("#d97706")), {
            type: "button",
            title: "Plusieurs ventes eBay pour cette commande (m\xEAme client) ? Ouvre le d\xE9tail de la commande : \xAB Une commande AliExpress pour plusieurs ventes eBay \xBB.",
            textContent: r.suggestion ? `Lier \xE0 #${r.suggestion} ?` : "Lier \xE0 une vente eBay"
          });
          button.addEventListener("click", (e) => {
            e.preventDefault();
            e.stopPropagation();
            void picker(row, wrap, r.suggestion ?? null);
          });
          wrap.append(button);
        }
        header.append(wrap);
      }
    }
    async function picker(row, wrap, suggestion) {
      row.card.querySelector("[data-auroebay-picker]")?.remove();
      const panel2 = css(
        document.createElement("div"),
        "margin:8px 0;padding:10px;border:1px solid #d97706;border-radius:10px;background:#fff8f0;font:13px system-ui;color:#222"
      );
      panel2.setAttribute("data-auroebay-picker", "");
      if (!row.cost) {
        panel2.textContent = "Total de la commande AliExpress introuvable : ouvre le d\xE9tail de la commande.";
        wrap.after(panel2);
        return;
      }
      candidates ??= await message({ type: "SALE_CANDIDATES" }).catch(() => []);
      const receiver = info.get(row.orderId)?.receiver;
      const words2 = (s) => new Set(s.toLowerCase().normalize("NFKD").replace(/[^\p{L}]+/gu, " ").split(" ").filter((w) => w.length > 1));
      const recv = receiver ? words2(receiver.name) : /* @__PURE__ */ new Set();
      const scored = candidates.map((c) => {
        const sameProduct = c.items.some((i) => i.supplierId && row.itemIds.includes(i.supplierId));
        const sameName = [...words2(c.firstName)].some((w) => recv.has(w));
        return { c, score: (c.orderId === suggestion ? 10 : 0) + (sameProduct ? 3 : 0) + (sameName ? 2 : 0), sameProduct, sameName };
      }).sort((a, b) => b.score - a.score || (b.c.soldAt ?? 0) - (a.c.soldAt ?? 0));
      if (!scored.length) {
        panel2.textContent = "Aucune vente eBay \xE0 lier. Sur eBay (Commandes), clique \xAB Enregistrer les commandes de cette page \xBB d\u2019abord.";
        wrap.after(panel2);
        return;
      }
      const select = css(document.createElement("select"), "max-width:100%;padding:6px;margin:6px 0;font:13px system-ui");
      for (const { c, sameProduct, sameName } of scored) {
        const date = c.soldAt ? new Date(c.soldAt).toLocaleDateString("fr-FR") : "";
        const item = c.items[0];
        select.append(
          Object.assign(document.createElement("option"), {
            value: c.orderId,
            textContent: `${sameName ? "\u{1F464} " : ""}${sameProduct ? "\u2605 " : ""}#${c.orderId} \xB7 ${date} \xB7 ${c.firstName} \xB7 ${item?.title.slice(0, 50) ?? ""}${item?.variation ? " (" + item.variation.slice(0, 30) + ")" : ""}`
          })
        );
      }
      const ok = Object.assign(css(document.createElement("button"), pill("#16a34a")), { type: "button", textContent: "Lier" });
      const cancel = Object.assign(css(document.createElement("button"), pill("#888")), { type: "button", textContent: "Annuler" });
      const infoLine = document.createElement("div");
      infoLine.textContent = `Co\xFBt enregistr\xE9 : ${row.cost.amount.toFixed(2)} ${row.cost.currency}. \u{1F464} = m\xEAme client \xB7 \u2605 = m\xEAme produit. Plusieurs ventes eBay pour cette commande ? Ouvre son d\xE9tail.${receiver ? ` Destinataire AliExpress : ${receiver.name.split(" ")[0]} (${receiver.zip}).` : ""}`;
      panel2.append(infoLine, select, ok, cancel);
      cancel.addEventListener("click", () => panel2.remove());
      ok.addEventListener("click", async () => {
        ok.disabled = true;
        try {
          await message({
            type: "SALE_LINK_SUPPLIER",
            orderId: select.value,
            purchase: { orderId: row.orderId, cost: row.cost, status: row.status }
          });
          candidates = null;
          panel2.remove();
          await render();
        } catch (e) {
          infoLine.textContent = e instanceof Error ? e.message : String(e);
          ok.disabled = false;
        }
      });
      row.card.querySelector("[data-auroebay-picker]")?.remove();
      wrap.after(panel2);
    }
    let timer;
    const ours = (n) => n.closest?.("[data-auroebay-ali],[data-auroebay-picker],#auroebay-ali-orders") || n.hasAttribute?.("data-auroebay-ali") || n.hasAttribute?.("data-auroebay-picker");
    const observer2 = new MutationObserver((records) => {
      if (records.every((r) => [...r.addedNodes, ...r.removedNodes].every(ours))) return;
      clearTimeout(timer);
      timer = setTimeout(() => void render(), 800);
    });
    observer2.observe(document.body, { childList: true, subtree: true });
    void render();
    return () => {
      active = false;
      observer2.disconnect();
      panel.remove();
      document.querySelectorAll("[data-auroebay-ali],[data-auroebay-picker]").forEach((n) => n.remove());
    };
  }
  var visible2 = (e) => !!e.offsetParent;
  function input(placeholder) {
    return [...document.querySelectorAll("input")].find(
      (i) => visible2(i) && placeholder.test(i.placeholder)
    );
  }
  var sleepMs = (ms) => new Promise((r) => setTimeout(r, ms));
  var addressForm = () => (
    // « Name » alone: AliExpress' simpler form for some countries (seen live: Jordan).
    !!(input(/^Contact name/i) || input(/^Name\*?$/i) || input(/^First name/i) && input(/^Last name/i))
  );
  var onCheckout = () => /^\/p\/trade\/confirm/.test(location.pathname);
  function clickWithoutScriptLink(el) {
    const link = el.closest("a");
    if (link && /^\s*javascript:/i.test(link.getAttribute("href") ?? ""))
      link.addEventListener("click", (e) => e.preventDefault(), { once: true, capture: true });
    el.click();
  }
  async function openNewAddressForm() {
    if (addressForm()) return true;
    let add = document.querySelector("button.add-address");
    if (!add || !visible2(add)) {
      const change = [...document.querySelectorAll("a,span,div,button")].find(
        // AliExpress in French (seen live 27/10/2026): « Changer ».
        (e) => !e.childElementCount && /^(Change|Changer|Modifier|Cambiar|Ändern|Cambia|Wijzigen)$/i.test(e.textContent?.trim() ?? "") && visible2(e) && !!e.closest('[class*="address"]')
      );
      if (!change) return false;
      clickWithoutScriptLink(change);
      for (let i = 0; i < 20 && !(add && visible2(add)); i++) {
        await sleepMs(250);
        add = document.querySelector("button.add-address");
      }
    }
    if (!add || !visible2(add)) return false;
    add.click();
    for (let i = 0; i < 24 && !addressForm(); i++) await sleepMs(250);
    return addressForm();
  }
  var ALI_ADDRESS_BOOK = "https://www.aliexpress.us/p/address-manage/index.html";
  function addressLimitMessage(text) {
    const t = text.replace(/\s+/g, " ");
    return /address/i.test(t) && /(\b20\b|maximum|max\.?|limit|up to|exceed|full|plus de)/i.test(t) && t.length < 400;
  }
  function addressBookNote() {
    const p = document.createElement("p");
    p.className = "warn";
    p.append("\u26A0\uFE0F L\u2019adresse ne s\u2019est pas enregistr\xE9e. AliExpress n\u2019accepte que 20 adresses : si ton carnet est plein, supprime d\u2019anciennes adresses (garde ton adresse US par d\xE9faut) : ");
    p.append(Object.assign(document.createElement("a"), { href: ALI_ADDRESS_BOOK, target: "_blank", rel: "noopener", textContent: "G\xE9rer mes adresses \u2197" }));
    return p;
  }
  function watchAddressSave(out) {
    let shown = false;
    const until = Date.now() + 10 * 6e4;
    const show3 = () => {
      if (shown || !out.isConnected) return;
      shown = true;
      out.prepend(addressBookNote());
    };
    const limitShown = () => [...document.querySelectorAll('[role="alert"],[role="dialog"],[class*="toast" i],[class*="error" i],[class*="message" i]')].some(
      (e) => !e.closest("#auroebay-ali-paste") && e.offsetParent !== null && addressLimitMessage(e.innerText ?? "")
    );
    const onClick = (event) => {
      if (shown || Date.now() > until) return void document.removeEventListener("click", onClick, true);
      const button = event.target?.closest("button,[role=button],a,div");
      if (!button || !/^\s*confirm\s*$/i.test(button.textContent ?? "") || !addressForm()) return;
      setTimeout(() => {
        if (addressForm() || limitShown()) show3();
      }, 3e3);
    };
    document.addEventListener("click", onClick, true);
  }
  function ilPostcodeHelper(a, old) {
    const box = Object.assign(document.createElement("div"), { className: "il-zip" });
    const search = Object.assign(document.createElement("button"), { type: "button", textContent: "\u{1F50E} Chercher le code \xE0 7 chiffres" });
    const village = ilVillageCode(a.city, old);
    const hint = Object.assign(document.createElement("p"), {
      className: "s",
      textContent: village ? `Petite localit\xE9 : le code est en g\xE9n\xE9ral ${village}, d\xE9j\xE0 propos\xE9 ci-dessous. V\xE9rifie-le avec la recherche si tu as un doute.` : `Une recherche s\u2019ouvre : le bon code commence en g\xE9n\xE9ral par ${old} (ex. \xAB Herzog 15 - 5360014 \xBB). Colle-le ici :`
    });
    const row = Object.assign(document.createElement("div"), { className: "il-zip-row" });
    const field = Object.assign(document.createElement("input"), { type: "text", inputMode: "numeric", maxLength: 9, placeholder: `${old}\xB7\xB7`, value: village ?? "" });
    const put = Object.assign(document.createElement("button"), { type: "button", textContent: "Mettre dans le formulaire" });
    const say = Object.assign(document.createElement("p"), { className: "s" });
    row.append(field, put);
    box.append(search, hint, row, say);
    search.addEventListener("click", () => window.open(ilPostcodeSearchUrl(a.street, a.city), "_blank", "noopener"));
    put.addEventListener("click", () => {
      const { code, warning } = ilPostcodeCheck(field.value, old);
      if (!code) return void (say.textContent = warning ?? "");
      say.textContent = setAliZip(code) ? `\u2713 ${code} mis dans le formulaire.${warning ? ` ${warning}` : " Relis puis clique toi-m\xEAme \xAB Confirm \xBB."}` : "Case du code postal introuvable : tape-le \xE0 la main.";
    });
    return box;
  }
  function setupAddressPaste(enabled) {
    let active = true;
    let host = null;
    let mode = "";
    let pasted = "";
    let pasting = false;
    let missing = 0;
    const list = (items) => {
      const ul = document.createElement("ul");
      for (const i of items) ul.append(Object.assign(document.createElement("li"), { textContent: i }));
      return ul;
    };
    const show3 = (data, form) => {
      host?.remove();
      const box = floatingBox(document, "auroebay-ali-paste", data ? `Adresse eBay #${data.orderId}` : "Adresse eBay");
      host = box.host;
      if (!data) {
        box.body.append(
          Object.assign(document.createElement("p"), {
            className: "s",
            textContent: "Aucune adresse eBay copi\xE9e. Ouvre la commande sur eBay puis \xAB \u{1F4CB} Copier l\u2019adresse pour AliExpress \xBB (ou \xAB \u{1F6D2} Commander sur AliExpress \xBB) : elle appara\xEEtra ici."
          })
        );
        return;
      }
      const who2 = Object.assign(document.createElement("div"), {
        className: "s",
        textContent: `${data.address.firstName} ${data.address.lastName.slice(0, 1)}. \xB7 ${data.address.city}, ${data.address.state} \xB7 ${data.address.countryLabel}`
      });
      const go = Object.assign(document.createElement("button"), {
        className: "primary",
        textContent: form ? "\u{1F4CB} Coller l\u2019adresse dans le formulaire" : "\u{1F4CB} Nouvelle adresse avec l\u2019adresse eBay"
      });
      const out = document.createElement("div");
      box.body.append(who2, go, out);
      go.addEventListener("click", async () => {
        if (!enabled()) return;
        pasting = true;
        go.disabled = true;
        out.replaceChildren();
        const before = mode;
        mode = "form";
        try {
          if (!addressForm() && !await openNewAddressForm()) {
            mode = before;
            out.append(
              Object.assign(document.createElement("p"), {
                className: "warn",
                textContent: "Formulaire \xAB Add new address \xBB introuvable : clique \xAB Change \xBB puis \xAB Add new address \xBB, puis \xAB Coller \xBB."
              })
            );
            return;
          }
          go.textContent = "\u{1F4CB} Coller l\u2019adresse dans le formulaire";
          const fillProblems = await fillAliAddress(data.address);
          pasted = data.orderId;
          watchAddressSave(out);
          const problems = [...data.problems, ...fillProblems];
          const head = document.createElement("p");
          head.className = problems.length ? "warn" : "ok";
          head.textContent = problems.length ? `${problems.length} point(s) \xE0 v\xE9rifier avant de valider :` : "\u2713 Adresse coll\xE9e. Relis puis clique toi-m\xEAme \xAB Confirm \xBB sur AliExpress.";
          out.append(head);
          if (problems.length) out.append(list(problems));
          const old = ilOldPostcode(data.address);
          if (old) out.append(ilPostcodeHelper(data.address, old));
          if (data.changes.length) {
            const p = document.createElement("p");
            p.className = "s";
            p.textContent = "Corrections faites :";
            out.append(p, list(data.changes));
          }
        } finally {
          go.disabled = false;
          pasting = false;
        }
      });
    };
    let busy = false;
    let emptyUntil = 0;
    const tick = async () => {
      if (!active || busy || pasting || document.hidden || location.pathname.startsWith("/item/")) return;
      const form = enabled() && addressForm();
      const checkout = enabled() && !form && onCheckout();
      const want = form ? "form" : checkout ? "checkout" : "";
      if (!want && mode === "form" && host?.isConnected && ++missing < 3) return;
      if (want) missing = 0;
      if (!want) {
        missing = 0;
        host?.remove();
        host = null;
        mode = "";
        return;
      }
      if (host?.isConnected && mode === want) return;
      if (want === "checkout" && Date.now() < emptyUntil) return;
      busy = true;
      try {
        const data = await message({ type: "ADDRESS_PASTE" }).catch(() => null);
        if (want === "checkout" && (!data || data.orderId === pasted)) {
          emptyUntil = Date.now() + 15e3;
          host?.remove();
          host = null;
          mode = "";
          return;
        }
        mode = want;
        show3(data, want === "form");
      } finally {
        busy = false;
      }
    };
    const interval2 = setInterval(() => void tick(), 1500);
    void tick();
    return () => {
      active = false;
      clearInterval(interval2);
      host?.remove();
    };
  }
  function setupAliOrders(enabled) {
    const cleanups = [];
    if (/^\/p\/order\/index\.html/.test(location.pathname)) cleanups.push(setupOrderList(enabled));
    if (/^\/p\/order\/detail\.html/.test(location.pathname) && enabled())
      cleanups.push(setupAliOrderDetail(enabled));
    cleanups.push(setupAddressPaste(enabled));
    return () => cleanups.forEach((c) => c());
  }

  // src/core/text.ts
  var compact = (s) => s.replace(/\s+/g, " ").trim();
  var norm = (s) => compact(s.normalize("NFKC")).toLowerCase().replace(/[\s\W_]+/g, " ").trim();
  var escapeHTML = (s) => s.replace(
    /[&<>"']/g,
    (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]
  );
  function cleanURL(url) {
    try {
      const u = new URL(url);
      return u.origin + u.pathname;
    } catch {
      return "";
    }
  }
  function debounce(fn, ms = 500) {
    let timer;
    return () => {
      clearTimeout(timer);
      timer = setTimeout(fn, ms);
    };
  }
  var delay = (ms) => new Promise((r) => setTimeout(r, ms));
  function distinctLabels(values) {
    const count = /* @__PURE__ */ new Map();
    return values.map((v) => {
      const key = norm(v);
      const n = (count.get(key) ?? 0) + 1;
      count.set(key, n);
      return n > 1 && v ? `${v} (${n})` : v;
    });
  }

  // src/core/sizes.ts
  function ebaySize(value) {
    const m = value.trim().match(/^(X{2,7})(L|S)$/i);
    return m ? `${m[1].length}X${m[2].toUpperCase()}` : value;
  }
  var STANDARD = /^(XS|S|M|L|XL|X{2,7}[LS]|\d{1,2}X[LS])$/i;
  function standardSize(value) {
    const m = value.trim().match(/^([0-9]{0,2}X{0,7}[A-Z]{1,2})\s*[([（【]\s*(.+?)\s*[)\]）】]$/i);
    const base = (m ? m[1] : value.trim()).toUpperCase();
    if (!STANDARD.test(base)) return null;
    return { size: ebaySize(base), note: m ? m[2] : "" };
  }

  // src/core/variantMatch.ts
  function variantValue(value) {
    return value.normalize("NFKC").toLowerCase().replace(/(\d),(\d)/g, "$1.$2").replace(/[\s\u00a0_-]+/g, "").trim();
  }
  function compact2(value) {
    return variantValue(value).replace(/(mm|cm|inch|in|ml|kg|g|pcs|pc)(?=\b|\d|$)/g, "").replace(/[^\p{L}\p{N}]+/gu, "");
  }
  function distance(a, b) {
    const d = Array.from({ length: b.length + 1 }, (_, i) => i);
    for (let i = 1; i <= a.length; i++) {
      let prev = d[0];
      d[0] = i;
      for (let j = 1; j <= b.length; j++) {
        const tmp = d[j];
        d[j] = Math.min(d[j] + 1, d[j - 1] + 1, prev + (a[i - 1] === b[j - 1] ? 0 : 1));
        prev = tmp;
      }
    }
    return d[b.length];
  }
  function supplierValueFor(value, supplierValues) {
    const exact = supplierValues.filter((v) => variantValue(v) === variantValue(value));
    if (exact.length) return exact[0];
    const wanted = standardSize(value)?.size;
    const sized = wanted ? supplierValues.filter((v) => standardSize(v)?.size === wanted) : [];
    if (sized.length === 1) return sized[0];
    const c = compact2(value);
    const same = [...new Set(supplierValues.filter((v) => c && compact2(v) === c))];
    if (same.length === 1) return same[0];
    if (c.length >= 4) {
      const close = [
        ...new Set(
          supplierValues.filter((v) => {
            const k = compact2(v);
            if (k.length < 4 || /^\d+$/.test(k) || /^\d+$/.test(c)) return false;
            return k.startsWith(c) || c.startsWith(k) || Math.min(k.length, c.length) >= 5 && distance(k, c) <= 2;
          })
        )
      ];
      if (close.length === 1) return close[0];
    }
    return value;
  }

  // src/aliexpress/checkoutQuantity.ts
  var KEY2 = "auroebayCheckoutOrder";
  var VALID = 2 * 36e5;
  var MAX_FIXES = 3;
  function rememberCheckoutOrder(order, path, now = Date.now()) {
    const productId = path.match(/\/item\/(\d+)\.html/)?.[1];
    if (!productId) return;
    try {
      sessionStorage.setItem(KEY2, JSON.stringify({ ...order, productId, at: now }));
    } catch {
    }
  }
  function sameAliProduct(a, b) {
    if (!/^\d+$/.test(a) || !/^\d+$/.test(b)) return false;
    const gap = BigInt(a) - BigInt(b);
    const offset = 2n ** 51n;
    return gap === 0n || gap === offset || gap === -offset;
  }
  function checkoutOrder(raw, search, now = Date.now()) {
    if (!raw) return null;
    try {
      const o = JSON.parse(raw);
      const objectId = new URLSearchParams(search).get("objectId") ?? "";
      if (!Number.isInteger(o.quantity) || o.quantity < 1 || now - o.at > VALID || !sameAliProduct(o.productId, objectId)) return null;
      return o;
    } catch {
      return null;
    }
  }
  var quantityStep = (shown, wanted) => shown < wanted ? "plus" : shown > wanted ? "minus" : "ok";
  var sleep2 = (ms) => new Promise((r) => setTimeout(r, ms));
  function setupCheckoutQuantity(doc, enabled) {
    if (!/^\/p\/trade\/confirm/.test(location.pathname)) return;
    let raw = null;
    try {
      raw = sessionStorage.getItem(KEY2);
    } catch {
    }
    const order = checkoutOrder(raw, location.search);
    if (!order) return;
    const banner = doc.createElement("div");
    banner.id = "auroebay-checkout-quantity";
    banner.setAttribute("role", "status");
    const say = (text, ok) => {
      banner.textContent = text;
      banner.style.cssText = `position:fixed;top:12px;left:50%;transform:translateX(-50%);z-index:2147483646;max-width:min(640px,92vw);padding:10px 16px;border-radius:12px;font:600 14px/1.35 -apple-system,system-ui,sans-serif;color:#fff;background:${ok ? "#15803d" : "#dc2626"};box-shadow:0 10px 30px rgba(0,0,0,.3)`;
      if (!banner.isConnected) doc.documentElement.append(banner);
    };
    const what = order.options.map((o) => o.value).join(" / ");
    const label = `Commande eBay #${order.orderId}${what ? ` \xB7 ${what}` : ""}`;
    const inputs = () => [...doc.querySelectorAll('[class*="group-product--s-product"] input.comet-input-number-input')];
    let fixes = 0;
    let working = false;
    const check = async () => {
      if (working || !enabled()) return;
      const list = inputs();
      if (!list.length) return;
      if (list.length > 1) return say(`${label} : plusieurs produits sur cette page, v\xE9rifie que la quantit\xE9 est ${order.quantity}.`, false);
      const input2 = list[0];
      const shown = Number(input2.value);
      const step = quantityStep(shown, order.quantity);
      if (step === "ok") return say(`${label} \xB7 quantit\xE9 ${order.quantity} \u2713 V\xE9rifie l\u2019adresse et le total avant de payer.`, true);
      const box = input2.closest('[class*="comet-input-number"]')?.parentElement ?? input2.parentElement;
      const button = box?.querySelector(step === "plus" ? '[class*="btn-increase"]' : '[class*="btn-decrease"]');
      if (!button || fixes >= MAX_FIXES || /disabled/.test(button.className))
        return say(`\u26A0 ${label} : la quantit\xE9 est ${shown} au lieu de ${order.quantity}. Corrige-la avec + ou \u2212 avant de payer (stock ou limite du vendeur ?).`, false);
      fixes++;
      working = true;
      say(`${label} : quantit\xE9 ${shown} \u2192 ${order.quantity}\u2026`, false);
      for (let i = 0; i < 50 && enabled() && quantityStep(Number(input2.value), order.quantity) === step; i++) {
        const before = input2.value;
        button.click();
        for (let t = 0; t < 20 && input2.isConnected && input2.value === before; t++) await sleep2(150);
        if (!input2.isConnected || input2.value === before) break;
      }
      working = false;
    };
    const timer = setInterval(() => void check(), 1500);
    setTimeout(() => clearInterval(timer), 30 * 6e4);
    void check();
  }

  // src/aliexpress/orderPrefill.ts
  var HASH = "auroebay-order=";
  function readPrefill(hash) {
    const raw = hash.split(HASH)[1];
    if (!raw) return null;
    try {
      const p = JSON.parse(decodeURIComponent(raw));
      if (!p || typeof p.orderId !== "string" || !Array.isArray(p.options)) return null;
      return {
        orderId: p.orderId.slice(0, 20),
        options: p.options.filter((o) => o && typeof o.name === "string" && typeof o.value === "string").slice(0, 5),
        quantity: Number.isInteger(p.quantity) && p.quantity > 0 ? Math.min(p.quantity, 50) : 1
      };
    } catch {
      return null;
    }
  }
  var sleep3 = (ms) => new Promise((r) => setTimeout(r, ms));
  var valueOf = (el) => (el.querySelector("img")?.getAttribute("alt") ?? el.getAttribute("title") ?? el.textContent ?? "").replace(/\s+/g, " ").trim();
  var selected = (el) => /sku-item--selected/.test(el.className) || el.getAttribute("aria-checked") === "true";
  function findOption(doc, value, used) {
    const hits = [];
    for (const row of doc.querySelectorAll("[data-sku-row]")) {
      if (used.has(row)) continue;
      const items = [...row.querySelectorAll("[data-sku-col]")];
      const values = distinctLabels(items.map(valueOf));
      const wanted = supplierValueFor(value, values);
      const index = values.findIndex((v) => variantValue(v) === variantValue(wanted));
      if (index >= 0) hits.push({ row, item: items[index] });
    }
    return hits.length === 1 ? hits[0] : hits[0] ?? null;
  }
  function setupOrderPrefill(doc, enabled) {
    const order = readPrefill(location.hash);
    if (!order || !enabled() || !/\/item\/\d+\.html/.test(location.pathname)) return;
    history.replaceState(null, "", location.pathname + location.search);
    rememberCheckoutOrder(order, location.pathname);
    const box = floatingBox(doc, "auroebay-ali-prefill", `Commande eBay #${order.orderId}`);
    const status = Object.assign(doc.createElement("p"), { className: "status", textContent: "S\xE9lection de la variante\u2026" });
    const list = doc.createElement("ul");
    box.body.append(status, list);
    const line = (text, cls) => list.append(Object.assign(doc.createElement("li"), { className: cls, textContent: text }));
    void (async () => {
      for (let i = 0; i < 30 && !doc.querySelector("[data-sku-row]") && order.options.length; i++) await sleep3(300);
      const used = /* @__PURE__ */ new Set();
      let missing = 0;
      for (const option of order.options) {
        const hit = findOption(doc, option.value, used);
        if (!hit) {
          missing++;
          line(`${option.name} \xAB ${option.value} \xBB introuvable : choisis-la \xE0 la main.`, "warn");
          continue;
        }
        used.add(hit.row);
        if (/disabled|soldout/i.test(hit.item.className)) {
          missing++;
          line(`${option.name} \xAB ${option.value} \xBB en rupture chez ce fournisseur.`, "warn");
          continue;
        }
        if (!enabled()) break;
        if (!selected(hit.item)) {
          hit.item.click();
          await sleep3(500);
        }
        line(`${option.name} : ${valueOf(hit.item)} \u2713`, "ok");
      }
      if (order.quantity > 1) {
        const input2 = doc.querySelector("input.comet-v2-input-number-input");
        const plus = doc.querySelector(".comet-v2-input-number-btn-increase");
        for (let i = 0; enabled() && input2 && plus && Number(input2.value) < order.quantity && i < 50; i++) {
          plus.click();
          await sleep3(150);
        }
        const now = Number(input2?.value ?? 1);
        if (now === order.quantity) line(`Quantit\xE9 : ${now} \u2713`, "ok");
        else {
          missing++;
          line(`Quantit\xE9 : mets ${order.quantity} \xE0 la main (stock ou limite du vendeur).`, "warn");
        }
      } else line("Quantit\xE9 : 1 \u2713", "ok");
      status.className = "status " + (missing ? "warn" : "ok");
      status.textContent = missing ? "V\xE9rifie les points en orange, puis clique \xAB Buy now \xBB." : "Tout est choisi : v\xE9rifie, puis clique \xAB Buy now \xBB.";
      box.body.append(
        Object.assign(doc.createElement("p"), {
          className: "s",
          textContent: "L\u2019adresse de l\u2019acheteur est copi\xE9e : sur la page de paiement, clique \xAB Coller l\u2019adresse dans le formulaire \xBB. AurOEBay ne paie jamais \xE0 ta place."
        })
      );
    })();
  }

  // src/ebay/selectors.ts
  var SELECTORS = {
    title: [
      '[data-testid="title"] input',
      'input[data-testid="title"]',
      '[data-testid="listing-title"] input',
      'input[name="title"]',
      'input[name="listingTitle"]',
      "input#title",
      "input#listingTitle",
      'input[aria-label="Title"]'
    ],
    description: [
      'textarea[data-testid="description"]',
      '[data-testid="description"] textarea',
      'textarea[name="description"]',
      "textarea#description",
      '[contenteditable="true"][aria-label="Description"]',
      '[contenteditable="true"][data-testid="description"]',
      "iframe#description_ifr",
      "iframe#se-rte-frame__summary",
      'iframe[title="Rich Text Area"]'
    ],
    specifics: [
      '[data-testid*="item-specific"]',
      '[data-testid*="itemSpecific"]',
      '[data-testid="specifics"]',
      ".item-specifics",
      "#itemSpecifics",
      ".summary__attributes",
      '[aria-label="Item specifics"]'
    ],
    seller: [
      '[data-testid="seller-info"]',
      ".x-sellercard-atf",
      ".x-sellercard",
      ".x-sellercard-atf__info",
      ".ux-seller-section",
      "#RightSummaryPanel .mbg"
    ],
    sellerLinks: ['a[href*="/usr/"]'],
    results: ["li.s-item", "li.s-card", '[data-testid="item-card"]'],
    variations: [
      '[data-testid*="variation"]',
      ".variation-row",
      ".summary__variations",
      '[aria-label="Variations"]'
    ],
    aliTitle: [
      'h1[data-pl="product-title"]',
      '[data-testid="product-title"]',
      "h1"
    ],
    aliSpecs: [
      '[data-testid="specifications"] li',
      '[class*="specification--prop"]',
      '[class*="specification--line"]',
      ".product-prop",
      '[class*="specification"] tr'
    ],
    aliDescription: [
      '[data-testid="product-description"]',
      "#product-description",
      ".product-description"
    ],
    aliDescriptionFrames: [
      "#nav-description iframe",
      "#product-description iframe",
      '[data-testid="product-description"] iframe'
    ],
    seedTitle: ["h1.x-item-title__mainTitle", 'h1[data-testid="item-title"]'],
    seedSpecifics: [
      ".ux-layout-section-evo__item--description-list",
      '[data-testid="seed-specifics"]'
    ],
    seedCategory: [
      "nav.breadcrumbs a.seo-breadcrumb-text",
      '[data-testid="seed-category"] a'
    ],
    seedPrice: [".x-price-primary", '[data-testid="seed-price"]'],
    simplePrice: [
      'input[name="price"]',
      'input[aria-label="Price"]',
      'input[id$="-price"]'
    ],
    aliVariants: [
      "[data-sku-row]",
      '[data-testid="sku-property"]',
      '[class*="sku-item--property"]'
    ],
    aliStore: [
      '[data-testid="store-name"]',
      'a[class*="store-name"]',
      'a[href*="/store/"]'
    ],
    aliGallery: [
      '[data-testid="product-gallery"]',
      '[class*="slider--img"]',
      '[class*="magnifier--wrap"]'
    ],
    aliShipping: [
      '[data-testid="shipping"]',
      '[class*="delivery--shipping"]',
      '[class*="delivery--content"]',
      '[class*="dynamic-shipping-titleLayout"]'
    ],
    nativeSearch: [
      'input[placeholder="Enter brand, model, description, etc."]',
      'input[aria-label="Enter brand, model, description, etc."]'
    ],
    photoInput: [
      'input#fehelix-uploader[type="file"]',
      'input[data-testid="photo-upload"][type="file"]'
    ],
    photoCounter: [
      '.summary__photos .uploader-thumbnails-ux__header__photo-count span[aria-hidden="true"]'
    ],
    uploadedPhotos: [
      '.summary__variations .uploader-thumbnails__thumbnail button.uploader-thumbnails__image[style*="background-image"]',
      '[data-testid="uploaded-photo"] img',
      '.summary__photos .uploader-thumbnails-ux__image--ready button.uploader-thumbnails-ux__image[style*="background-image"]'
    ]
  };
  function queryAll(root, selectors) {
    const result = /* @__PURE__ */ new Set();
    for (const selector of selectors) {
      try {
        root.querySelectorAll(selector).forEach((e) => result.add(e));
      } catch {
      }
    }
    return [...result];
  }
  function first(root, selectors) {
    for (const selector of selectors) {
      try {
        const el = root.querySelector(selector);
        if (el) return el;
      } catch {
      }
    }
    return null;
  }

  // src/core/shippingText.ts
  var PRICE = String.raw`(?:US\s*)?\$\s*(\d+(?:\.\d{1,2})?)`;
  var NAMED = new RegExp(String.raw`(?:standard|shipping|delivery|livraison)[^$·\d]{0,20}?${PRICE}`, "gi");
  var LABEL = new RegExp(String.raw`\b[A-Za-z][A-Za-z' -]{1,30}:\s*${PRICE}`, "g");
  var NOT_A_FEE = /over|orders|min|save|off\b|coupon|discount|code|price|extra/i;
  function paidShipping(text) {
    if (!text) return null;
    const hit = [...text.matchAll(NAMED), ...text.matchAll(LABEL)].find((m) => !NOT_A_FEE.test(m[0]));
    const cost = hit ? Number(hit[1]) : 0;
    return cost > 0 && cost < 200 ? cost : null;
  }

  // src/ebay/prices.ts
  var USUAL_SHIPPING = { cost: 1.99, freeOver: 10, usual: true };
  var shippingFor = (cost, s) => s && !(s.freeOver !== null && cost >= s.freeOver) ? s.cost : 0;

  // src/core/country.ts
  var codes = "AD AE AF AG AI AL AM AO AQ AR AS AT AU AW AX AZ BA BB BD BE BF BG BH BI BJ BL BM BN BO BQ BR BS BT BV BW BY BZ CA CC CD CF CG CH CI CK CL CM CN CO CR CU CV CW CX CY CZ DE DJ DK DM DO DZ EC EE EG EH ER ES ET FI FJ FK FM FO FR GA GB GD GE GF GG GH GI GL GM GN GP GQ GR GS GT GU GW GY HK HM HN HR HT HU ID IE IL IM IN IO IQ IR IS IT JE JM JO JP KE KG KH KI KM KN KP KR KW KY KZ LA LB LC LI LK LR LS LT LU LV LY MA MC MD ME MF MG MH MK ML MM MN MO MP MQ MR MS MT MU MV MW MX MY MZ NA NC NE NF NG NI NL NO NP NR NU NZ OM PA PE PF PG PH PK PL PM PN PR PS PT PW PY QA RE RO RS RU RW SA SB SC SD SE SG SH SI SJ SK SL SM SN SO SR SS ST SV SX SY SZ TC TD TF TG TH TJ TK TL TM TN TO TR TT TV TW TZ UA UG UM US UY UZ VA VC VE VG VI VN VU WF WS YE YT ZA ZM ZW".split(
    " "
  );
  var names = new Intl.DisplayNames(["en"], { type: "region" });
  var map = /* @__PURE__ */ new Map();
  for (const code of codes) {
    const name = names.of(code);
    map.set(norm(code), name);
    map.set(norm(name), name);
  }
  for (const [alias, name] of Object.entries({
    "mainland china": "China",
    "cn origin": "China",
    "china mainland": "China",
    "china origin": "China",
    prc: "China",
    "people s republic of china": "China",
    usa: "United States",
    "u s a": "United States",
    "united states of america": "United States",
    uk: "United Kingdom",
    "great britain": "United Kingdom",
    "south korea": "South Korea",
    "republic of korea": "South Korea",
    taiwan: "Taiwan",
    vietnam: "Vietnam",
    turkey: "T\xFCrkiye"
  }))
    map.set(norm(alias), name);

  // src/core/product.ts
  var unknownShipping = () => ({
    status: "UNKNOWN",
    cost: null,
    currency: null,
    freeShippingThreshold: null,
    minimumOrder: null,
    destination: null,
    deliveryEstimate: null,
    evidence: ""
  });

  // src/aliexpress/variantGroups.ts
  function variantGroups(doc) {
    const axes = queryAll(doc, SELECTORS.aliVariants);
    return axes.filter((el) => !axes.some((other) => other !== el && el.contains(other))).slice(0, 20);
  }
  function variantAxisName(group) {
    const labelSelector = '[class*="title"],label,[data-name]';
    const wrapper = group.closest(
      '[class*="sku-item--property"],[data-testid="sku-property"]'
    );
    const label = group.querySelector(labelSelector) ?? wrapper?.querySelector(labelSelector);
    return compact(label?.textContent ?? "Variation").split(/[:：]/)[0].trim() || "Variation";
  }

  // src/aliexpress/images.ts
  function supplierImageURL(value) {
    try {
      const u = new URL(value.startsWith("//") ? "https:" + value : value);
      if (u.protocol !== "https:" || u.username || u.password || u.port || !/(^|\.)(alicdn\.com|aliexpress-media\.com)$/.test(u.hostname))
        return null;
      u.pathname = u.pathname.replace(
        /\.(jpg|jpeg|png|webp)(?:_\d+x\d+[^/]*)?(?:_\.avif)?$/i,
        ".$1"
      );
      u.hash = "";
      for (const key of [...u.searchParams.keys()]) {
        if (!["has_lang", "ver"].includes(key)) u.searchParams.delete(key);
        else
          u.searchParams.set(
            key,
            u.searchParams.get(key).replace(/_\d+x\d+.*$/, "")
          );
      }
      if (!/\.(jpe?g|png|webp)$/i.test(u.pathname)) return null;
      return u.href;
    } catch {
      return null;
    }
  }
  function descriptionImageURL(value) {
    const strict = supplierImageURL(value.replace(/^http:\/\//i, "https://"));
    if (strict) return strict;
    try {
      const u = new URL(value.startsWith("//") ? "https:" + value : value.replace(/^http:\/\//i, "https://"));
      if (u.protocol !== "https:" || u.username || u.password || u.port || !/(^|\.)(alicdn\.com|aliexpress-media\.com)$/.test(u.hostname) || /\.(svg|js|html?)$/i.test(u.pathname))
        return null;
      u.hash = "";
      return u.href;
    } catch {
      return null;
    }
  }
  function extractImages(doc) {
    const images = [];
    for (const [role, selectors] of [
      ["gallery", SELECTORS.aliGallery],
      ["description", SELECTORS.aliDescription]
    ]) {
      for (const scope of queryAll(doc, [...selectors])) {
        const nodes = scope.tagName === "IMG" ? [scope] : [...scope.querySelectorAll("img")];
        for (const node of nodes) {
          const img = node;
          const url = supplierImageURL(
            img.getAttribute("data-src") || img.currentSrc || img.src
          );
          if (!url || images.some((i) => i.url === url)) continue;
          const width = img.naturalWidth || Number(img.getAttribute("width")) || null;
          const height = img.naturalHeight || Number(img.getAttribute("height")) || null;
          if (width && width < 200 || height && height < 200) continue;
          images.push({ url, role, width, height });
          if (images.length >= 36) break;
        }
      }
    }
    const variantImages = [];
    for (const axis of variantGroups(doc)) {
      const name = variantAxisName(axis);
      for (const img of axis.querySelectorAll("img")) {
        const value = img.getAttribute("alt") || img.closest("[title]")?.getAttribute("title");
        const url = supplierImageURL(img.getAttribute("data-src") || img.src);
        if (name && value && url) variantImages.push({ axis: name, value, url });
      }
    }
    return {
      images: images.slice(0, 36),
      variantImages: variantImages.slice(0, 100)
    };
  }
  function extractShipping(doc) {
    const nodes = queryAll(doc, SELECTORS.aliShipping);
    const evidence = [
      ...new Set(nodes.map((n) => n.textContent?.trim()).filter(Boolean))
    ].join(" \xB7 ").slice(0, 600);
    const result = { ...unknownShipping(), evidence };
    const threshold = evidence.match(
      /free shipping\s+(?:over|on orders over)\s*\$([\d.]+)/i
    );
    if (threshold) {
      result.status = "CONDITIONAL";
      result.freeShippingThreshold = Number(threshold[1]);
    }
    const paid = paidShipping(evidence);
    if (paid !== null) {
      result.cost = paid;
      result.currency = "USD";
      if (!threshold) result.status = "KNOWN";
    }
    return result;
  }

  // src/ebay/savedDraft.ts
  var SCAN_LIMIT = 3 * 1024 * 1024;

  // src/ebay/draftApi.ts
  var HTML_LIMIT = 8 * 1024 * 1024;

  // src/core/protection.ts
  var DRAFT_HASH = "auroebay-dispute=";
  var clip = (v, max) => typeof v === "string" ? v.slice(0, max) : "";
  function readDraft(hash) {
    const raw = hash.split(DRAFT_HASH)[1];
    if (!raw) return null;
    try {
      const d = JSON.parse(decodeURIComponent(raw));
      if (!d || !/^\d{8,25}$/.test(String(d.aliOrderId))) return null;
      return {
        saleId: clip(d.saleId, 20),
        aliOrderId: String(d.aliOrderId),
        received: d.received === true,
        reason: clip(d.reason, 200),
        quantity: Number.isInteger(d.quantity) && d.quantity > 0 ? Math.min(d.quantity, 99) : 1,
        message: clip(d.message, 1500),
        tips: Array.isArray(d.tips) ? d.tips.map((t) => clip(t, 200)).filter(Boolean).slice(0, 5) : [],
        ...Array.isArray(d.choices) ? { choices: d.choices.map((t) => clip(t, 200)).filter(Boolean).slice(0, 6) } : {}
      };
    } catch {
      return null;
    }
  }

  // src/aliexpress/disputeHelper.ts
  var KEY3 = "auroebay-dispute";
  var KEEP_MS = 2 * 36e5;
  function saved() {
    try {
      const v = JSON.parse(sessionStorage.getItem(KEY3) ?? "null");
      return v && Date.now() - v.at < KEEP_MS ? v.draft : null;
    } catch {
      return null;
    }
  }
  function setupDisputeHelper(doc, enabled) {
    const orderPage = /^\/p\/order\/detail\.html$/.test(location.pathname);
    if (!enabled() || !(orderPage || /^\/p\/(reverse-pages|refund-dispute)\//.test(location.pathname))) return;
    const fresh = location.hash.includes(DRAFT_HASH) ? readDraft(location.hash) : null;
    if (fresh) {
      try {
        sessionStorage.setItem(KEY3, JSON.stringify({ at: Date.now(), draft: fresh }));
      } catch {
      }
      history.replaceState(null, "", location.pathname + location.search);
    }
    const draft = fresh ?? saved();
    if (!draft) return;
    if (orderPage && new URLSearchParams(location.search).get("orderId") !== draft.aliOrderId) return;
    const box = floatingBox(doc, "auroebay-ali-dispute", `Litige pr\xE9par\xE9 \xB7 vente eBay #${draft.saleId}`);
    const p = (text2, cls = "s") => Object.assign(doc.createElement("p"), { className: cls, textContent: text2 });
    const steps = doc.createElement("ul");
    const li = (text2) => steps.append(Object.assign(doc.createElement("li"), { className: "ok", textContent: text2 }));
    if (orderPage) li("Clique \xAB Returns/refunds \xBB (ou \xAB Returns/withdrawal \xBB) sous le produit");
    if (draft.choices?.length) draft.choices.forEach(li);
    else {
      li(draft.received ? "Colis re\xE7u ? \u2192 \xAB Yes \xBB" : "Colis re\xE7u ? \u2192 \xAB No \xBB");
      li(`Raison : ${draft.reason}`);
      li(`Quantit\xE9 : ${draft.quantity}`);
    }
    const text = Object.assign(doc.createElement("textarea"), { value: draft.message, rows: 7, readOnly: true });
    text.style.cssText = "width:100%;box-sizing:border-box;font:12px/1.4 system-ui;margin:6px 0;border-radius:8px;padding:6px";
    const copy = Object.assign(doc.createElement("button"), { className: "primary", textContent: "\u{1F4CB} Copier le message (anglais)" });
    copy.addEventListener("click", () => {
      const done = () => {
        copy.textContent = "\u2713 Copi\xE9 : colle-le dans la description du litige";
        setTimeout(() => copy.textContent = "\u{1F4CB} Copier le message (anglais)", 2500);
      };
      void navigator.clipboard.writeText(draft.message).then(done, () => {
        text.select();
        if (doc.execCommand("copy")) done();
      });
    });
    box.body.append(steps, text, copy, ...draft.tips.map((t) => p(t)), p("Tu remplis et tu valides toi-m\xEAme : AurOEBay n\u2019envoie jamais le litige."));
  }

  // src/aliexpress/regionWarning.ts
  var GUIDE_US_URL = "https://auroebay.netlify.app/guide.html#aliexpress";
  function aliRegionProblem(host, text, path = "") {
    host = host.toLowerCase();
    if (/^\/p\/(reverse-pages|refund-dispute)\//.test(path)) return null;
    if (/^(?:www\.|[a-z]{2}\.)?aliexpress\.com$/.test(host)) return "domain";
    if (!/(^|\.)aliexpress\.us$/.test(host)) return null;
    const euros2 = (text.match(/€\s?\d|\d\s?€|\bEUR\s?\d/g) ?? []).length;
    const dollars = (text.match(/\$\s?\d/g) ?? []).length;
    return euros2 >= 3 && euros2 > dollars ? "currency" : null;
  }
  function usStoreURL(url) {
    const u = new URL(url);
    return `https://www.aliexpress.us${u.pathname}${u.search}`;
  }
  var HIDDEN = "auroebay-region-hidden";
  function setupRegionWarning(doc, enabled) {
    if (window.top !== window) return;
    let shown = false;
    const check = () => {
      if (shown || doc.visibilityState !== "visible" || !enabled() || !doc.body) return;
      try {
        if (sessionStorage.getItem(HIDDEN)) return;
      } catch {
      }
      const problem = aliRegionProblem(location.hostname, (doc.body.innerText ?? "").slice(0, 3e4), location.pathname);
      try {
        void Promise.resolve(chrome.runtime?.sendMessage({ type: "STATUS_NOTE", problem })).catch(() => {
        });
      } catch {
      }
      if (!problem) return;
      shown = true;
      show(doc, problem);
    };
    doc.addEventListener("visibilitychange", check);
    for (const ms of [1500, 6e3]) setTimeout(check, ms);
  }
  function show(doc, problem) {
    const host = doc.createElement("div");
    host.id = "auroebay-region-warning";
    const root = host.attachShadow({ mode: "closed" });
    const text = problem === "domain" ? "<b>Tu n\u2019es pas sur AliExpress US.</b> Prix, stocks et d\xE9lais peuvent \xEAtre faux pour eBay US." : "<b>AliExpress affiche des prix en euros.</b> En haut \xE0 droite : Ship to <b>United States</b>, devise <b>USD</b>, puis Save.";
    root.innerHTML = `<style>
    .bar{position:fixed;bottom:16px;left:16px;z-index:2147483647;display:flex;align-items:center;gap:10px;flex-wrap:wrap;max-width:min(520px,calc(100vw - 32px));padding:10px 14px;border-radius:14px;background:${BRAND.night2};color:${BRAND.inkDark};border:1px solid ${BRAND.warn};box-shadow:0 14px 40px rgba(0,0,0,.35);font:14px/1.4 -apple-system,BlinkMacSystemFont,"Segoe UI",system-ui,sans-serif}
    .msg{flex:1 1 280px}
    a,button{font:inherit;font-weight:700;border-radius:10px;padding:7px 12px;cursor:pointer;text-decoration:none;border:0}
    .go{background:${BRAND.gradient};color:#fff}
    .help{background:${BRAND.night3};color:${BRAND.inkDark}}
    .x{background:transparent;color:${BRAND.mutedDark};padding:4px 8px}
  </style>
  <div class="bar" role="alert">
    <span class="msg">\u26A0\uFE0F ${text}</span>
    ${problem === "domain" ? `<a class="go" href="${usStoreURL(location.href)}">Ouvrir sur aliexpress.us</a>` : ""}
    <a class="help" href="${GUIDE_US_URL}" target="_blank" rel="noopener">Comment r\xE9gler ?</a>
    <button class="x" type="button" title="Masquer pour cet onglet">\u2715</button>
  </div>`;
    root.querySelector(".x")?.addEventListener("click", () => {
      try {
        sessionStorage.setItem(HIDDEN, "1");
      } catch {
      }
      host.remove();
    });
    doc.documentElement.append(host);
  }

  // src/core/brandRisk.ts
  var DANGER = [
    // Characters and licences
    "Disney",
    "Pixar",
    "Marvel",
    "Avengers",
    "Spider-Man",
    "Spiderman",
    "Batman",
    "Superman",
    "Deadpool",
    "Iron Man",
    "Captain America",
    "DC Comics",
    "Star Wars",
    "Baby Yoda",
    "Grogu",
    "Mandalorian",
    "Harry Potter",
    "Hogwarts",
    "Mickey Mouse",
    "Minnie Mouse",
    "Lilo and Stitch",
    "Lilo & Stitch",
    "Toy Story",
    "Winnie the Pooh",
    "Pokemon",
    "Pikachu",
    "Super Mario",
    "Mario Kart",
    "Zelda",
    "Sonic the Hedgehog",
    "Minecraft",
    "Fortnite",
    "Roblox",
    "Among Us",
    "Squid Game",
    "Hello Kitty",
    "Sanrio",
    "Kuromi",
    "Cinnamoroll",
    "My Melody",
    "Labubu",
    "Pop Mart",
    "Squishmallow",
    "Squishmallows",
    "Bluey",
    "Paw Patrol",
    "Peppa Pig",
    "Cocomelon",
    "Minions",
    "Barbie",
    "Hot Wheels",
    "LEGO",
    "Nerf",
    "Fisher-Price",
    "Naruto",
    "Dragon Ball",
    "Demon Slayer",
    "Jujutsu Kaisen",
    "My Hero Academia",
    "Sailor Moon",
    "Studio Ghibli",
    "Totoro",
    "Looney Tunes",
    "Snoopy",
    "Sesame Street",
    "Taylor Swift",
    "NFL",
    "NBA",
    "MLB",
    "NHL",
    "NCAA",
    "Harley-Davidson",
    "John Deere",
    "Coca-Cola",
    "Starbucks",
    // Fashion, luxury, sport
    "Nike",
    "Adidas",
    "Puma",
    "Reebok",
    "Under Armour",
    "New Balance",
    "Air Jordan",
    "Converse",
    "The North Face",
    "Patagonia",
    "Lululemon",
    "Gucci",
    "Louis Vuitton",
    "Chanel",
    "Dior",
    "Hermes",
    "Prada",
    "Versace",
    "Burberry",
    "Balenciaga",
    "Fendi",
    "Givenchy",
    "Yves Saint Laurent",
    "YSL",
    "Michael Kors",
    "Kate Spade",
    "Tory Burch",
    "Ralph Lauren",
    "Tommy Hilfiger",
    "Calvin Klein",
    "Rolex",
    "Cartier",
    "Tag Heuer",
    "Pandora",
    "Swarovski",
    "Ray-Ban",
    "Rayban",
    "Oakley",
    "Crocs",
    "Jibbitz",
    "UGG",
    "Birkenstock",
    "Dr Martens",
    "Timberland",
    // Copied household products
    "Stanley",
    "Yeti",
    "Hydro Flask",
    "Owala",
    "OtterBox",
    "PopSocket",
    "PopSockets",
    "Dyson",
    // Added 11/2026 (user's request « des mots / marques à bannir »)
    // Toys, collectibles, kids' licences
    "NeeDoh",
    "Nee Doh",
    "Schylling",
    "Jellycat",
    "Sonny Angel",
    "Smiski",
    "Funko",
    "Beanie Babies",
    "Ty Beanie",
    "Ms Rachel",
    "Blippi",
    "Gabby's Dollhouse",
    "Gabbys Dollhouse",
    "PJ Masks",
    "Thomas the Tank Engine",
    "SpongeBob",
    "Garfield",
    "Pusheen",
    "Care Bears",
    "My Little Pony",
    "Transformers",
    "Hasbro",
    "Mattel",
    "Play-Doh",
    "Magna-Tiles",
    "Tamagotchi",
    "Bandai",
    "Yu-Gi-Oh",
    "Magic the Gathering",
    "Bratz",
    "LOL Surprise",
    "Polly Pocket",
    "Tonka",
    "Crayola",
    "Hatchimals",
    "Kirby",
    "Animal Crossing",
    "Splatoon",
    "Call of Duty",
    "Pac-Man",
    "Tetris",
    "Rubik's",
    "Rubiks",
    "Pochacco",
    "Pompompurin",
    "Keroppi",
    "Badtz-Maru",
    "Chainsaw Man",
    "Attack on Titan",
    "Hunter x Hunter",
    "Tokyo Ghoul",
    "Spy x Family",
    "Stranger Things",
    "Moana",
    "Encanto",
    "Frozen Elsa",
    "Bluey Bingo",
    "Grinch",
    "Dr Seuss",
    "Elf on the Shelf",
    "Charlie Brown",
    "Jack Skellington",
    "Nightmare Before Christmas",
    "Hocus Pocus",
    "Beetlejuice",
    "Freddy Krueger",
    "Michael Myers",
    "Chucky",
    "Ghostface",
    "Lord of the Rings",
    "Game of Thrones",
    "Wednesday Addams",
    // Fashion, beauty, luxury
    "Vans Old Skool",
    "Skechers",
    "Hoka",
    "Asics",
    "Fila",
    "Carhartt",
    "Levi's",
    "Levis",
    "Wrangler Jeans",
    "Off-White",
    "Bape",
    "Stussy",
    "Fear of God",
    "Moncler",
    "Canada Goose",
    "Arc'teryx",
    "Arcteryx",
    "Longchamp",
    "Goyard",
    "Celine",
    "Bottega Veneta",
    "Valentino",
    "Miu Miu",
    "Loewe",
    "Van Cleef",
    "Bvlgari",
    "Bulgari",
    "Chrome Hearts",
    "Casio",
    "G-Shock",
    "Seiko",
    "Alo Yoga",
    "Gymshark",
    "Skims",
    "Victoria's Secret",
    "Bath and Body Works",
    "Sol de Janeiro",
    "Olaplex",
    "Beautyblender",
    "Fenty",
    "Rare Beauty",
    "Charlotte Tilbury",
    "Revlon",
    "Gillette",
    "Oral-B",
    "Sonicare",
    // Tech and home brands often copied
    "Anker",
    "Beats by Dre",
    "Beats Studio",
    "Beats Solo",
    "Beats Fit Pro",
    "Skullcandy",
    "Logitech",
    "Razer",
    "Corsair",
    "SteelSeries",
    "HyperX",
    "Roomba",
    "iRobot",
    "Vitamix",
    "Le Creuset",
    "Pyrex",
    "Tupperware",
    "Bissell",
    "Contigo",
    "Ember Mug",
    "Ka-Bar",
    "Kabar",
    "Lego Star Wars",
    // Sport teams, cars (logos)
    "FIFA",
    "UEFA",
    "Real Madrid",
    "FC Barcelona",
    "Manchester United",
    "Manchester City",
    "Liverpool FC",
    "Chelsea FC",
    "Dallas Cowboys",
    "Kansas City Chiefs",
    "New York Yankees",
    "Los Angeles Lakers",
    "Chicago Bulls",
    "Golden State Warriors",
    "Ferrari",
    "Lamborghini",
    "Porsche",
    "Red Bull",
    "Monster Energy",
    "Jack Daniels",
    "Jack Daniel's"
  ];
  var COMPATIBLE = [
    "iPhone",
    "iPad",
    "MacBook",
    "iMac",
    "Apple Watch",
    "Apple Pencil",
    "MagSafe",
    "AirPods",
    "AirTag",
    "Samsung",
    "Google Pixel",
    "Fitbit",
    "Garmin",
    "Nintendo",
    "PlayStation",
    "PS4",
    "PS5",
    "Xbox",
    "Tesla",
    "GoPro",
    "DJI",
    "Kindle",
    "JBL",
    "Bose",
    "Sony",
    "Microsoft",
    "Keurig",
    "Nespresso",
    "KitchenAid",
    "Instant Pot",
    "Cricut",
    "DeWalt",
    "Makita",
    "Bosch",
    // Added 11/2026: devices and cars accessories name (« for Toyota RAV4 »)
    "Steam Deck",
    "Meta Quest",
    "Oculus",
    "Echo Dot",
    "Alexa",
    "Roku",
    "Chromecast",
    "Ring Doorbell",
    "Polaroid",
    "Instax",
    "Fujifilm",
    "Canon",
    "Nikon",
    "Milwaukee",
    "Ryobi",
    "Ninja Creami",
    "Ninja Foodi",
    "Xiaomi",
    "Huawei",
    "OnePlus",
    "Motorola",
    "Lenovo",
    "Dell",
    "Toyota",
    "Honda",
    "Ford",
    "Chevrolet",
    "Chevy",
    "Jeep",
    "BMW",
    "Mercedes",
    "Audi",
    "Volkswagen",
    "Subaru",
    "Nissan",
    "Hyundai",
    "Kia",
    "Mazda",
    "Lexus",
    "Dodge",
    "RAM 1500"
  ];
  var words = (text) => ` ${text.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, " ").trim()} `;
  var LIST = [
    ...DANGER.map((name) => ({ name, level: "danger", w: words(name) })),
    ...COMPATIBLE.map((name) => ({ name, level: "compatible", w: words(name) }))
  ];
  function brandRisks(text) {
    if (!text) return [];
    const t = words(text);
    const hits = [];
    const seen = /* @__PURE__ */ new Set();
    for (const b of LIST) {
      const key = b.w.replace(/ /g, "");
      if (seen.has(key) || !t.includes(b.w)) continue;
      if (hits.some((h2) => words(h2.name).includes(b.w) || b.w.includes(words(h2.name)))) continue;
      seen.add(key);
      hits.push({ name: b.name, level: b.level });
    }
    return hits.sort((a, b) => Number(a.level !== "danger") - Number(b.level !== "danger"));
  }
  function brandAdvice(hits) {
    const names2 = (level) => hits.filter((h2) => h2.level === level).map((h2) => h2.name);
    const out = [];
    const danger = names2("danger");
    if (danger.length)
      out.push({
        level: "danger",
        text: `Marque ou personnage prot\xE9g\xE9 : ${danger.join(", ")}. Sans autorisation du propri\xE9taire, eBay retire l\u2019annonce et peut suspendre ton compte (programme VeRO). Retire ce nom du titre, de la description, des caract\xE9ristiques et des photos, ou choisis un autre produit.`
      });
    const compatible = names2("compatible");
    if (compatible.length)
      out.push({
        level: "compatible",
        text: `Marque cit\xE9e : ${compatible.join(", ")}. Autoris\xE9 seulement pour dire que ton produit est compatible (\xAB for iPhone 15 \xBB, \xAB compatible with \u2026 \xBB) : mets \xAB Unbranded \xBB dans Marque, aucun logo sur les photos, et n\u2019\xE9cris jamais la marque comme si c\u2019\xE9tait ton produit.`
      });
    return out;
  }

  // src/core/aliProduct.ts
  var DAY = 864e5;
  function sellerVerdict(s, now = Date.now()) {
    const reasons = [];
    const rate = s.positiveRate;
    let tone = rate === null ? "warn" : rate >= 95 ? "ok" : rate >= 90 ? "warn" : "bad";
    if (rate !== null) reasons.push(`${rate.toLocaleString("fr-FR")} % d\u2019avis positifs${s.ratings ? ` sur ${s.ratings.toLocaleString("fr-FR")}` : ""}.`);
    else reasons.push("Note du vendeur pas affich\xE9e par AliExpress.");
    if (s.openedAt) {
      const months = Math.floor((now - s.openedAt) / (30.4 * DAY));
      const since = new Date(s.openedAt).toLocaleDateString("fr-FR", { day: "numeric", month: "long", year: "numeric" });
      if (months < 6) {
        reasons.push(`Nouveau vendeur : boutique ouverte le ${since} (moins de 6 mois).`);
        if (tone === "ok") tone = "warn";
      } else reasons.push(`Boutique ouverte le ${since} (${months >= 24 ? `${Math.floor(months / 12)} ans` : `${months} mois`}).`);
    }
    if (s.ratings !== null && s.ratings < 50) {
      reasons.push("Peu d\u2019avis : note encore peu fiable.");
      if (tone === "ok") tone = "warn";
    }
    if (s.topRated) reasons.push("Vendeur \xAB Top \xBB sur AliExpress.");
    if (s.sold180) reasons.push(`${s.sold180} ventes en 180 jours.`);
    const label = tone === "ok" ? "Bon vendeur" : tone === "warn" ? "Vendeur moyen" : "Vendeur \xE0 risque";
    return { tone, label, reasons };
  }
  function priceSummary(info, history2, now = Date.now()) {
    const cur = info.currency ?? "USD";
    const money4 = (n) => n.toLocaleString("fr-FR", { style: "currency", currency: cur });
    const prices = history2.map((p) => p[1]);
    const min = prices.length ? Math.min(...prices) : null;
    const max = prices.length ? Math.max(...prices) : null;
    const days = history2.length ? Math.round((now - history2[0][0]) / DAY) : 0;
    const discount = info.price !== null && info.original !== null && info.original > info.price ? Math.round((1 - info.price / info.original) * 100) : null;
    const text = [];
    let tone = "ok";
    if (discount !== null && info.original !== null)
      text.push(`Prix barr\xE9 ${money4(info.original)} : promotion de ${discount} %.`);
    if (info.promoEnd && info.promoEnd > now) {
      const end = new Date(info.promoEnd).toLocaleDateString("fr-FR", { day: "numeric", month: "long" });
      text.push(
        `Promotion jusqu\u2019au ${end}. Apr\xE8s, le prix peut remonter${info.original !== null ? ` vers ${money4(info.original)}` : ""} : calcule ton prix eBay pour qu\u2019il reste rentable.`
      );
      tone = "warn";
    }
    if (history2.length >= 2 && min !== null && max !== null && max > min) {
      text.push(`Vu par AurOEBay entre ${money4(min)} et ${money4(max)} depuis ${days} jour${days > 1 ? "s" : ""}.`);
      if (info.price !== null && info.price <= min) text.push("C\u2019est le prix le plus bas vu.");
      if (info.price !== null && info.price >= max && max > min * 1.15) {
        text.push("C\u2019est le prix le plus haut vu : attends ou cherche le m\xEAme produit moins cher.");
        tone = "warn";
      }
    } else
      text.push("AurOEBay note le prix chaque jour o\xF9 tu ouvres cette fiche : la courbe se remplit avec le temps.");
    return { discount, min, max, days, tone, text };
  }
  function sparkline(history2, width, height, pad = 4) {
    if (!history2.length) return "";
    const xs = history2.map((p) => p[0]);
    const ys = history2.map((p) => p[1]);
    const [x0, x1] = [Math.min(...xs), Math.max(...xs)];
    const [y0, y1] = [Math.min(...ys), Math.max(...ys)];
    const x = (v) => x1 === x0 ? width / 2 : pad + (v - x0) / (x1 - x0) * (width - 2 * pad);
    const y = (v) => y1 === y0 ? height / 2 : height - pad - (v - y0) / (y1 - y0) * (height - 2 * pad);
    const pts = history2.map((p) => `${x(p[0]).toFixed(1)},${y(p[1]).toFixed(1)}`);
    return pts.length === 1 ? `${pad},${height / 2} ${width - pad},${height / 2}` : pts.join(" ");
  }
  function reviewsVerdict(r, rating) {
    const stars = rating.stars;
    const count = rating.count ?? r?.total ?? null;
    if (!count) return { tone: "warn", text: "Aucun avis sur ce produit : pas de retour d\u2019acheteurs pour l\u2019instant." };
    const pos = r?.positiveRate ?? null;
    const tone = stars !== null && stars < 4.3 ? "bad" : pos !== null && pos < 90 ? "warn" : stars !== null && stars < 4.6 ? "warn" : "ok";
    return {
      tone,
      text: `${stars !== null ? `${stars.toLocaleString("fr-FR")} \u2605` : "Note ?"} sur ${count.toLocaleString("fr-FR")} avis${pos !== null ? ` \xB7 ${pos.toLocaleString("fr-FR")} % positifs` : ""}${r?.oneStar ? ` \xB7 ${r.oneStar} \xE0 1 \u2605` : ""}.`
    };
  }

  // src/core/profit.ts
  var EBAY_PERCENT = (0.136 + 0.0165) * 1.07;
  var round = (n) => Math.round(n * 100) / 100;
  function estimateProfit(priceUSD, costUSD, m, shipping = USUAL_SHIPPING) {
    const revenue = priceUSD * m.rate;
    const fees = revenue * m.feeRate + (m.feeFixed ?? 0) * m.rate;
    const supplier = (costUSD + shippingFor(costUSD, shipping)) * (1 + m.aliExtra) * m.rate;
    const charges = revenue * m.charges;
    return {
      revenue: round(revenue),
      fees: round(fees),
      supplier: round(supplier),
      charges: round(charges),
      net: round(revenue - fees - supplier - charges)
    };
  }
  function minimumPrice(costUSD, m, target = 0, shipping = USUAL_SHIPPING) {
    const keep = 1 - m.feeRate - m.charges;
    if (keep <= 0 || m.rate <= 0) return null;
    const exact = ((costUSD + shippingFor(costUSD, shipping)) * (1 + m.aliExtra) * m.rate + (m.feeFixed ?? 0) * m.rate + target) / (m.rate * keep);
    const whole = Math.floor(exact);
    for (const candidate of [whole + 0.49, whole + 0.99, whole + 1.49])
      if (candidate >= exact - 1e-9) return round(candidate);
    return round(whole + 1.99);
  }

  // src/core/supplierSearch.ts
  var STOP = new Set(
    "a an and the for with of to in on by from at as or is new hot sale free shipping fast usa us uk lot pcs pc set piece pieces 1pc 1pcs 2pcs women men womens mens unisex".split(
      " "
    )
  );
  var SAME_PHOTO = 0.92;
  var CLOSE_PHOTO = 0.85;
  function rankAllPhotos(searches) {
    const byUrl = /* @__PURE__ */ new Map();
    for (const { ebayPhoto, candidates } of searches)
      for (const c of candidates) {
        if (!c.price || c.currency !== "USD" && c.currency !== null) continue;
        const had = byUrl.get(c.url);
        if (!had) byUrl.set(c.url, { ...c, ebayPhotos: [ebayPhoto] });
        else {
          if (!had.ebayPhotos.includes(ebayPhoto)) had.ebayPhotos.push(ebayPhoto);
          if ((c.photo ?? -1) > (had.photo ?? -1))
            Object.assign(had, { photo: c.photo, photoIndex: c.photoIndex, photoTotal: c.photoTotal });
        }
      }
    const list = [...byUrl.values()];
    const cheapest = Math.min(...list.map((c) => c.price));
    const scored = list.map((c) => {
      const photo = c.photo ?? 0.35;
      const exact = photo >= SAME_PHOTO ? 2 : photo >= CLOSE_PHOTO ? 0.6 : 0;
      const several = Math.min(3, c.ebayPhotos.length - 1) * 0.25;
      const price = cheapest / c.price * 0.6;
      return { ...c, ebayPhotos: c.ebayPhotos.sort((a, b) => a - b), score: Math.round((exact + photo + several + price) * 1e3) / 1e3 };
    });
    return scored.sort((a, b) => b.score - a.score || a.price - b.price);
  }

  // src/ebay/gallery.ts
  function ebayGallery(doc, max = 40) {
    const seen = /* @__PURE__ */ new Set();
    const out = [];
    for (const img of doc.querySelectorAll(".ux-image-carousel-item img")) {
      const url = [img.getAttribute("data-zoom-src"), img.getAttribute("data-src"), img.getAttribute("src")].find(
        (u) => !!u && /^https:\/\/i\.ebayimg\.com\/images\/g\/[^/]+\/s-l\d+\.\w+/.test(u)
      );
      const id = url ? ebayPictureId(url) : null;
      if (!url || !id || seen.has(id)) continue;
      seen.add(id);
      out.push(url.replace(/\/s-l\d+(\.\w+)(\?.*)?$/, "/s-l500$1"));
      if (out.length >= max) break;
    }
    return out;
  }
  var ebayPictureId = (url) => url.match(/\/images\/g\/([^/]+)\//)?.[1] ?? null;
  async function fetchEbayGallery(itemId) {
    if (!/^\d{9,15}$/.test(itemId)) return [];
    const response = await fetch(`/itm/${itemId}`, { credentials: "include" });
    if (!response.ok) return [];
    return ebayGallery(new DOMParser().parseFromString(await response.text(), "text/html"));
  }

  // src/core/aliVerify.ts
  var ALI_VERIFY_URL = "https://www.aliexpress.us/";
  var asksAliVerify = (text) => typeof text === "string" && /AliExpress (demande|a demandé) une vérification/.test(text);
  var aliVerifyLink = (style = "") => `<a href="${ALI_VERIFY_URL}" target="_blank" rel="noopener" class="ali-verify"${style ? ` style="${style}"` : ""}>\u{1F513} Ouvrir AliExpress pour faire la v\xE9rification \u2197</a>`;
  var ALI_COOKIES = "AliExpress refuse les recherches : trop de cookies AliExpress dans Chrome";
  var ALI_COOKIES_TEXT = `${ALI_COOKIES} (erreur \xAB Cookie Too Large \xBB). Clique \xAB \u{1F9F9} Nettoyer AliExpress dans Chrome \xBB, supprime les donn\xE9es d\u2019aliexpress (ic\xF4ne corbeille), reconnecte-toi sur aliexpress.us, puis relance.`;
  var asksAliCookies = (text) => typeof text === "string" && text.includes(ALI_COOKIES);
  var aliCookiesButton = (style = "") => `<button type="button" class="ali-cookies" data-ali-cookies${style ? ` style="${style}"` : ""}>\u{1F9F9} Nettoyer AliExpress dans Chrome</button>`;
  var ALI_REGION = "AliExpress n\u2019est pas pr\xEAt pour les \xC9tats-Unis";
  var asksAliRegion = (text) => typeof text === "string" && text.includes(ALI_REGION);
  var aliRegionLink = (style = "") => `<a href="${ALI_VERIFY_URL}" target="_blank" rel="noopener" class="ali-verify"${style ? ` style="${style}"` : ""}>\u{1F1FA}\u{1F1F8} Ouvrir AliExpress US \u2197</a>`;

  // src/ebay/supplierFinderPanel.ts
  var errorHTML = (e) => {
    const text = String(e instanceof Error ? e.message : e);
    return `<p class="err">\u26A0 ${text.replace(/[<>&]/g, "")}${asksAliRegion(text) ? `<br>${aliRegionLink()}` : asksAliCookies(text) ? `<br>${aliCookiesButton()}` : asksAliVerify(text) ? `<br>${aliVerifyLink()}` : ""}</p>`;
  };
  var CSS = `${BRAND_CSS}
  :host{${WINDOW_TOKENS}}
  .ov{position:fixed;inset:5vh 50% auto auto;transform:translateX(50%);width:min(980px,94vw);max-height:90vh;z-index:2147483646;display:flex;flex-direction:column;background:var(--bg);color:var(--ink);border:1px solid var(--line);border-radius:18px;box-shadow:0 30px 80px rgba(10,6,16,.55);font:14px/1.45 -apple-system,system-ui,sans-serif;overflow:hidden;animation:ao-rise .4s var(--ao-ease)}
  header{display:flex;justify-content:space-between;align-items:center;gap:12px;padding:14px 18px;background:var(--ao-gradient);color:#fff}
  header b{display:flex;align-items:center;gap:10px;font-size:17px}
  header button{background:none;border:0;color:#fff;font-size:22px;cursor:pointer}
  .sub{padding:10px 18px;color:var(--muted);border-bottom:1px solid var(--line);font-size:13px}
  .sub a{color:var(--ink)}
  .wait{display:grid;place-items:center;gap:14px;padding:48px 18px;color:var(--muted)}
  .wait .ao-loader{--ao-size:76px}
  .body{flex:1;min-height:0;overflow:auto}
  .foot{flex:none}
  .grid{padding:14px 18px;display:grid;grid-template-columns:repeat(auto-fill,minmax(290px,1fr));gap:12px}
  .card{display:flex;gap:12px;padding:10px;border:1px solid var(--line);border-radius:14px;background:var(--bg2);animation:ao-rise .45s var(--ao-ease) both;transition:transform .25s var(--ao-ease),border-color .25s}
  .card:hover{transform:translateY(-2px);border-color:color-mix(in srgb,var(--accent) 40%,var(--line))}
  .card.best{border-color:var(--accent);box-shadow:0 0 0 1px var(--accent) inset}
  .card img{width:96px;height:96px;object-fit:cover;border-radius:10px;background:#000;flex:none}
  .t{display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;font-size:13px;margin-bottom:4px}
  .price{font-size:17px;font-weight:750}
  .meta{font-size:12px;color:var(--muted);margin:2px 0}
  .tags{display:flex;flex-wrap:wrap;gap:4px;margin:4px 0}
  .tag{padding:1px 7px;border-radius:99px;font-size:11px;font-weight:700;background:rgba(255,255,255,.08)}
  .tag.photo{background:var(--ao-gradient);color:#fff}
  .tag.choice{background:#ffcf3f;color:#2a1a05}
  .net{font-size:12.5px;margin:4px 0}
  .net b.pos{color:var(--ok)}.net b.neg{color:var(--err)}
  .acts{display:flex;gap:6px;margin-top:6px}
  .acts a,.acts button{font:600 12px system-ui;padding:5px 10px;border-radius:9px;border:1px solid var(--line);background:transparent;color:var(--ink);cursor:pointer;text-decoration:none}
  .acts{flex-wrap:wrap}
  .acts a.go{background:var(--ao-gradient);border-color:transparent;color:#fff}
  .acts button.draft{border-color:var(--accent);font-weight:700}
  .acts button.draft:disabled{opacity:.7;cursor:default}
  .draft-note{margin-top:6px;font-size:12px;color:var(--muted)}
  .draft-note.bad{color:var(--err)}
  .foot{padding:10px 18px;border-top:1px solid var(--line);font-size:11.5px;color:var(--muted)}
  .err{padding:30px 18px;color:var(--err)}
  .err .ali-cookies{display:inline-block;margin-top:12px;padding:8px 14px;border:0;border-radius:10px;background:#ff6a00;color:#fff;font:inherit;font-weight:700;cursor:pointer}
  .err .ali-verify{display:inline-block;margin-top:12px;padding:8px 14px;border-radius:10px;background:#ff6a00;color:#fff;font-weight:700;text-decoration:none}
  .redo{margin-left:6px;border:1px solid var(--line);background:transparent;color:var(--ink);border-radius:99px;padding:2px 10px;font:600 12px system-ui;cursor:pointer}
  .redo:hover{border-color:var(--accent)}
  .checking{color:var(--ink)}
  .pick{display:flex;align-items:center;gap:8px;padding:8px 18px;border-bottom:1px solid var(--line);font-size:12.5px;color:var(--muted)}
  .pick>span{flex:none;max-width:150px;line-height:1.3}
  .strip{display:flex;gap:6px;overflow-x:auto;padding:2px}
  .strip button{flex:none;width:52px;height:52px;padding:0;border-radius:9px;border:2px solid transparent;background:#000;cursor:pointer;overflow:hidden;opacity:.65;transition:opacity .2s,border-color .2s,transform .2s var(--ao-ease)}
  .strip button:hover{opacity:1;transform:translateY(-1px)}
  .strip button.on{border-color:var(--accent);opacity:1;box-shadow:0 0 0 2px color-mix(in srgb,var(--accent) 35%,transparent)}
  .strip img{width:100%;height:100%;object-fit:cover;display:block}
  .joker{margin-left:6px;border:0;background:var(--ao-gradient);color:#fff;border-radius:99px;padding:3px 11px;font:700 12px system-ui;cursor:pointer}
  .joker:hover{filter:brightness(1.08)}
  .allbar{width:min(360px,80%);height:6px;border-radius:99px;background:var(--line);overflow:hidden}
  .allbar i{display:block;height:100%;width:0;background:var(--ao-gradient);transition:width .4s var(--ao-ease)}
  .allsub{font-size:12.5px;color:var(--muted);min-height:1.2em;text-align:center}
  .tag.hits{background:color-mix(in srgb,var(--accent) 25%,transparent)}
`;
  var money2 = (n, cur) => n.toLocaleString("fr-FR", { style: "currency", currency: cur });
  function openSupplierFinder(doc, input2) {
    input2 = { ...input2, image: input2.image.replace(/\/s-l\d+(\.\w+)(\?.*)?$/, "/s-l500$1") };
    doc.getElementById("auroebay-supplier-finder")?.remove();
    const host = doc.createElement("div");
    host.id = "auroebay-supplier-finder";
    const root = host.attachShadow({ mode: "open" });
    root.innerHTML = `<style>${CSS}</style><div class="ov" role="dialog" aria-label="Fournisseurs AliExpress">
    <header class="ao-sweep"><b><span class="ao-mark" style="width:28px;height:28px"></span>${(input2.heading ?? "Fournisseurs AliExpress").replace(/[<>&]/g, "")}</b><button type="button" title="Fermer">\u2715</button></header>
    <div class="pick" hidden><span>Photo \xE0 chercher :</span><div class="strip"></div></div>
    <div class="sub"></div>
    <div class="body"><div class="wait"><div class="ao-loader"><span class="ao-mark"></span></div><span>Recherche sur AliExpress et comparaison des photos\u2026</span></div></div>
    <div class="foot">Recherche par photo : choisis en haut la photo \xE0 chercher si la principale a \xE9t\xE9 retouch\xE9e. La photo choisie est ensuite compar\xE9e \xE0 toutes les photos des premiers produits : \xAB \u{1F4F8} Photo exacte \xB7 3/6 \xBB = c\u2019est la 3e photo de ce produit AliExpress, on tient le bon. Prix affich\xE9s par AliExpress pour ton compte, hors taxe US et livraison. R\xE9sultats m\xE9moris\xE9s 7 jours. ${input2.draft ? "Rien n\u2019est achet\xE9 ni publi\xE9 : \xAB \u{1F4DD} Faire le brouillon \xBB cr\xE9e seulement un brouillon eBay, c\u2019est toi qui publies." : "Lecture seule : rien n\u2019est achet\xE9 ni cr\xE9\xE9."}</div>
  </div>`;
    root.querySelector("header button").addEventListener("click", () => host.remove());
    const sub = root.querySelector(".sub");
    const pick = root.querySelector(".pick");
    const strip = root.querySelector(".strip");
    let chosen = input2.image;
    const mainId = ebayPictureId(input2.image);
    let gallery = [];
    let lastShown = null;
    const pictures = (list) => {
      const all = list.length ? list : [input2.image];
      if (all.length < 2 || !host.isConnected) return;
      gallery = all;
      if (lastShown) show3(lastShown.result, lastShown.model);
      pick.hidden = false;
      strip.replaceChildren(
        ...all.map((url, i) => {
          const b = Object.assign(doc.createElement("button"), {
            type: "button",
            title: i === 0 ? "Photo principale" : `Photo ${i + 1}`
          });
          b.dataset.url = url;
          if (ebayPictureId(url) === ebayPictureId(chosen)) b.className = "on";
          const img = Object.assign(doc.createElement("img"), { src: url.replace(/\/s-l\d+(\.\w+)$/, "/s-l140$1"), alt: "" });
          img.referrerPolicy = "no-referrer";
          b.append(img);
          b.addEventListener("click", () => {
            if (b.className === "on" && chosen) return;
            chosen = url;
            strip.querySelectorAll("button").forEach((x) => x.className = x === b ? "on" : "");
            run(false);
          });
          return b;
        })
      );
    };
    const body = root.querySelector(".body");
    body.addEventListener("click", (e) => {
      if (e.target.closest("[data-ali-cookies]")) void message({ type: "OPEN_ALI_COOKIES" }).catch(() => {
      });
    });
    sub.textContent = `${input2.heading ? "Produit" : "Annonce eBay"} : ${input2.title.slice(0, 120)}`;
    doc.documentElement.append(host);
    const show3 = (result, model) => {
      if (!host.isConnected) return;
      lastShown = { result, model };
      const all = result.photos !== void 0;
      sub.innerHTML = "";
      const when = new Date(result.at).toLocaleString("fr-FR", { dateStyle: "short", timeStyle: "short" });
      sub.append(
        all ? result.checking ? `\u{1F0CF} Recherche compl\xE8te en cours \xB7 ${result.photos} photo(s) faite(s) \xB7 ${result.compared} produits class\xE9s jusqu\u2019ici (photos puis prix)` : `\u{1F0CF} Recherche compl\xE8te \xB7 ${result.photos} photos${result.failed ? ` (${result.failed} sans r\xE9sultat)` : ""} \xB7 ${result.compared} produits AliExpress class\xE9s (photos puis prix) \xB7 faite le ${when}` : `${result.mode === "image" ? "Recherche par photo" : "Recherche par mots (photo indisponible)"} \xB7 ${result.compared} r\xE9sultats \xB7 ${result.cached ? `m\xE9moris\xE9e le ${when}` : `faite le ${when}`}`
      );
      if (result.checking) {
        const busy = doc.createElement("span");
        busy.className = "checking";
        busy.innerHTML = ' \xB7 <span class="ao-spinner"></span> v\xE9rification des photos\u2026';
        sub.append(busy);
      } else {
        const redo = Object.assign(doc.createElement("button"), { className: "redo", type: "button", textContent: "\u21BB Relancer" });
        redo.addEventListener("click", () => all ? runAll(true) : run(true));
        sub.append(redo);
        if (!all && gallery.length >= 2) {
          const joker = Object.assign(doc.createElement("button"), {
            className: "joker",
            type: "button",
            textContent: `\u{1F0CF} Joker : chercher avec les ${Math.min(10, gallery.length)} photos`,
            title: "Cherche sur AliExpress avec chaque photo de l\u2019annonce, puis classe tous les r\xE9sultats selon les photos et le prix. Plus long (environ 15 s par photo)."
          });
          joker.addEventListener("click", () => runAll(false));
          sub.append(joker);
        }
      }
      if (result.mode === "text")
        sub.append(
          " \xB7 ",
          Object.assign(doc.createElement("a"), { href: result.searchUrl, target: "_blank", rel: "noopener", textContent: "voir la recherche \u2197" })
        );
      if (!result.candidates.length) {
        body.innerHTML = `<p class="err">Aucun r\xE9sultat. Essaie \xAB \u21BB Relancer \xBB${!all && gallery.length >= 2 ? ", une autre photo, ou le \xAB \u{1F0CF} Joker \xBB (toutes les photos)." : " ou une autre photo."}${result.mode === "text" ? `<br><small>La recherche par photo n\u2019a pas march\xE9 : si \xE7a se r\xE9p\xE8te, AliExpress demande s\xFBrement sa v\xE9rification.</small><br>${aliVerifyLink()}` : ""}</p>`;
        return;
      }
      const grid = doc.createElement("div");
      grid.className = "grid";
      result.candidates.forEach((c, i) => grid.append(card(doc, c, i, input2.price, model, !result.checking, input2.draft === true)));
      body.replaceChildren(grid);
    };
    let allRun = 0;
    const runAll = (fresh) => {
      const run2 = ++allRun;
      const photos = gallery.slice(0, 10);
      strip.querySelectorAll("button").forEach((x) => x.className = "");
      chosen = "";
      sub.textContent = `\u{1F0CF} Recherche compl\xE8te : chacune des ${photos.length} photos sur AliExpress\u2026`;
      body.innerHTML = `<div class="wait"><div class="ao-loader"><span class="ao-mark"></span></div><span class="allstep">Pr\xE9paration\u2026</span><span class="allsub muted"></span><div class="allbar"><i></i></div></div>`;
      let step = body.querySelector(".allstep");
      let detail = body.querySelector(".allsub");
      let bar = body.querySelector(".allbar i");
      const model = message({ type: "PROFIT_MODEL" }).catch(() => null);
      const searches = [];
      let failed = 0;
      let request = "";
      let index = 0;
      const listen = (msg) => {
        if (msg?.type !== "FIND_SUPPLIERS_STEP" || msg.request !== request || run2 !== allRun || !detail.isConnected) return;
        detail.textContent = `${msg.text ?? ""}${msg.total ? ` ${msg.done}/${msg.total}` : ""}`;
        bar.style.width = `${Math.round((index + (msg.total ? (msg.done ?? 0) / msg.total : 0.3)) / photos.length * 100)}%`;
      };
      chrome.runtime.onMessage.addListener(listen);
      const results = (m, done) => {
        const ranked = rankAllPhotos(searches);
        return { mode: "image", words: [], searchUrl: "", candidates: ranked.slice(0, 30), compared: ranked.length, at: Date.now(), photos: done ? photos.length : index + 1, failed, checking: !done };
      };
      void (async () => {
        const m = await model;
        for (index = 0; index < photos.length; index++) {
          if (run2 !== allRun || !host.isConnected) return;
          const url = photos[index];
          request = `${Date.now()}-${Math.random()}`;
          const found = searches.reduce((n, s) => n + s.candidates.length, 0);
          step.textContent = `Photo ${index + 1}/${photos.length} sur AliExpress\u2026 \xB7 ${found} produits trouv\xE9s jusqu\u2019ici`;
          detail.textContent = "";
          bar.style.width = `${Math.round(index / photos.length * 100)}%`;
          try {
            const r = await Promise.race([
              message({
                type: "FIND_SUPPLIERS",
                title: input2.title,
                image: url,
                itemId: input2.itemId ?? null,
                photo: index > 0 && ebayPictureId(url) !== mainId ? ebayPictureId(url) : null,
                fresh,
                request
              }),
              new Promise((_, reject) => setTimeout(() => reject(Error("trop long")), 24e4))
            ]);
            if (r.mode === "image" && r.candidates.length) searches.push({ ebayPhoto: index + 1, candidates: r.candidates });
            else failed++;
          } catch {
            failed++;
          }
          if (searches.length && run2 === allRun && index + 1 < photos.length) {
            show3(results(m, false), m);
            body.prepend(
              Object.assign(doc.createElement("div"), {
                className: "wait",
                innerHTML: `<span class="allstep"></span><span class="allsub muted"></span><div class="allbar"><i></i></div>`
              })
            );
            step = body.querySelector(".allstep");
            detail = body.querySelector(".allsub");
            bar = body.querySelector(".allbar i");
          }
        }
        if (run2 === allRun && host.isConnected) show3(results(m, true), m);
      })().catch((e) => {
        if (host.isConnected) body.innerHTML = errorHTML(e);
      }).finally(() => chrome.runtime.onMessage.removeListener(listen));
    };
    const run = (fresh) => {
      allRun++;
      const request = `${Date.now()}-${Math.random()}`;
      body.innerHTML = `<div class="wait"><div class="ao-loader"><span class="ao-mark"></span></div><span>Recherche par photo sur AliExpress\u2026</span></div>`;
      const model = message({ type: "PROFIT_MODEL" }).catch(() => null);
      let done = false;
      const partial = (msg) => {
        if (msg?.type !== "FIND_SUPPLIERS_PARTIAL" || msg.request !== request || done || !msg.data) return;
        void model.then((m) => !done && show3(msg.data, m));
      };
      chrome.runtime.onMessage.addListener(partial);
      void Promise.all([
        message({
          type: "FIND_SUPPLIERS",
          title: input2.title,
          image: chosen,
          itemId: input2.itemId ?? null,
          // Another photo than the main one is remembered on its own.
          photo: ebayPictureId(chosen) !== mainId ? ebayPictureId(chosen) : null,
          fresh,
          request
        }),
        model
      ]).then(([result, m]) => {
        done = true;
        show3(result, m);
      }).catch((e) => {
        done = true;
        if (host.isConnected) body.innerHTML = errorHTML(e);
      }).finally(() => chrome.runtime.onMessage.removeListener(partial));
    };
    run(false);
    if (input2.images?.length) pictures(input2.images);
    else if (input2.itemId)
      void fetchEbayGallery(input2.itemId).then(pictures).catch(() => {
      });
  }
  var drafting = false;
  function draftButton(doc, url, place) {
    const button = Object.assign(doc.createElement("button"), {
      type: "button",
      className: "draft",
      textContent: "\u{1F4DD} Faire le brouillon",
      title: "Cr\xE9e le brouillon eBay avec cette annonce et ce fournisseur, comme le panneau AurOEBay. Rien n\u2019est publi\xE9 : tu v\xE9rifies et tu publies toi-m\xEAme."
    });
    button.addEventListener("click", () => {
      if (drafting) return;
      drafting = true;
      button.disabled = true;
      button.textContent = "\u23F3 Brouillon en pr\xE9paration\u2026";
      place.querySelector(".draft-note")?.remove();
      const note = (text, error = false) => place.append(Object.assign(doc.createElement("div"), { className: `draft-note${error ? " bad" : ""}`, textContent: text }));
      void message({ type: "DRAFT_FROM_SUPPLIER", aliUrl: url }).then(() => {
        button.textContent = "\u2713 Brouillon lanc\xE9";
        note("Suis-le dans le panneau AurOEBay, \xE0 droite : il s\u2019ouvrira tout seul quand il sera pr\xEAt. Rien n\u2019est publi\xE9.");
      }).catch((e) => {
        button.disabled = false;
        button.textContent = "\u{1F4DD} R\xE9essayer le brouillon";
        note(e instanceof Error ? e.message : String(e), true);
      }).finally(() => {
        drafting = false;
      });
    });
    return button;
  }
  function card(doc, c, index, ebayPrice, model, checked = true, draft = false) {
    const el = doc.createElement("div");
    el.className = "card" + (index === 0 && checked ? " best" : "");
    el.style.animationDelay = `${index * 0.05}s`;
    const img = doc.createElement("img");
    img.src = c.image;
    img.alt = "";
    img.referrerPolicy = "no-referrer";
    const info = doc.createElement("div");
    const title = Object.assign(doc.createElement("div"), { className: "t", textContent: c.title });
    const price = Object.assign(doc.createElement("div"), {
      className: "price",
      textContent: c.price === null ? "prix ?" : c.currency && c.currency !== "USD" ? `${c.price.toFixed(2)} ${c.currency}` : `US $${c.price.toFixed(2)}`
    });
    const tags2 = doc.createElement("div");
    tags2.className = "tags";
    if (c.photo !== null && c.photo >= SAME_PHOTO)
      tags2.append(
        Object.assign(doc.createElement("span"), {
          className: "tag photo",
          textContent: c.photoIndex && c.photoTotal && c.photoTotal > 1 ? `\u{1F4F8} Photo exacte \xB7 ${c.photoIndex}/${c.photoTotal}` : "\u{1F4F8} Photo exacte \xB7 photo principale",
          title: "La photo de l\u2019annonce eBay est l\u2019une des photos de ce produit AliExpress"
        })
      );
    else if (c.photo !== null && c.photo >= CLOSE_PHOTO) tags2.append(Object.assign(doc.createElement("span"), { className: "tag", textContent: "Photo proche" }));
    if (c.ebayPhotos?.length)
      tags2.append(
        Object.assign(doc.createElement("span"), {
          className: "tag hits",
          textContent: c.ebayPhotos.length > 1 ? `\u{1F501} trouv\xE9 avec ${c.ebayPhotos.length} photos (${c.ebayPhotos.join(", ")})` : c.ebayPhotos[0] === 1 ? "trouv\xE9 avec la photo principale" : `trouv\xE9 avec la photo ${c.ebayPhotos[0]}`,
          title: "Photos de l\u2019annonce eBay (1 = principale) dont la recherche AliExpress a trouv\xE9 ce produit"
        })
      );
    if (c.choice) tags2.append(Object.assign(doc.createElement("span"), { className: "tag choice", textContent: "Choice" }));
    if (index === 0 && checked) tags2.append(Object.assign(doc.createElement("span"), { className: "tag", textContent: "\u2605 Meilleur choix" }));
    const meta = Object.assign(doc.createElement("div"), {
      className: "meta",
      textContent: [c.sold !== null ? `${c.sold.toLocaleString("fr-FR")}+ vendus` : "", c.rating ? `\u2605 ${c.rating.toFixed(1)}` : ""].filter(Boolean).join(" \xB7 ")
    });
    info.append(title, tags2, price, meta);
    if (model && ebayPrice && c.price && (c.currency === "USD" || c.currency === null)) {
      const net = estimateProfit(ebayPrice, c.price, model).net;
      const min = net < 0 ? minimumPrice(c.price, model) : null;
      const line = doc.createElement("div");
      line.className = "net";
      line.innerHTML = `Au prix eBay (${ebayPrice.toFixed(2)} $) : <b class="${net >= 0 ? "pos" : "neg"}">${net >= 0 ? "+" : ""}${money2(net, model.currency)}</b> net${min ? ` \xB7 mini ${min.toFixed(2)} $` : ""}`;
      info.append(line);
    }
    const acts = doc.createElement("div");
    acts.className = "acts";
    const open = Object.assign(doc.createElement("a"), { className: "go", href: c.url, target: "_blank", rel: "noopener", textContent: "Ouvrir" });
    const copy = Object.assign(doc.createElement("button"), { type: "button", textContent: "Copier le lien" });
    copy.addEventListener("click", () => {
      void navigator.clipboard.writeText(c.url).then(() => copy.textContent = "\u2713 Copi\xE9").catch(() => copy.textContent = c.url);
    });
    acts.append(open, copy);
    info.append(acts);
    if (draft) acts.append(draftButton(doc, c.url, info));
    el.append(img, info);
    return el;
  }

  // src/core/ebayPhotoCheck.ts
  var visualSearchURL = (guid, sold) => `https://www.ebay.com/sch/i.html?visualSearchGuid=${encodeURIComponent(guid)}${sold ? "&LH_Sold=1&LH_Complete=1" : "&LH_BIN=1&LH_ItemCondition=1000&_ipg=240&_dmd=1"}`;
  function photoVerdict(r) {
    const sales = Math.max(r.d30 ?? 0, r.soldRecent);
    if (!r.found) return { tone: "bad", label: "Pas trouv\xE9 sur eBay", text: "Aucune annonce eBay avec cette photo : produit absent du march\xE9 US, ou photos trop diff\xE9rentes." };
    if (!sales)
      return { tone: "bad", label: "Pas de vente r\xE9cente", text: `${r.found} annonce(s) trouv\xE9e(s), mais aucune vente vue ces 30 derniers jours.` };
    const dropship = r.nonUS >= 2 || r.sellers >= 5;
    if (sales >= 10 && dropship)
      return { tone: "ok", label: "Se vend bien", text: `${sales} vente(s) en 30 jours chez ${r.sellers} vendeur(s), dont ${r.nonUS} dropshipper(s) hors US : tu peux le copier.` };
    if (dropship)
      return { tone: "warn", label: "Se vend un peu", text: `${sales} vente(s) en 30 jours chez ${r.sellers} vendeur(s), dont ${r.nonUS} hors US : march\xE9 petit mais r\xE9el.` };
    return { tone: "warn", label: "Peu de vendeurs", text: `${sales} vente(s) en 30 jours, mais seulement ${r.sellers} vendeur(s) : peu de preuves que \xE7a marche en dropshipping.` };
  }

  // src/aliexpress/productBar.ts
  var FOLDED = "auroebayBarFolded";
  var CSS2 = `${BRAND_CSS}
  :host{${WINDOW_TOKENS};all:initial}
  .bar{position:fixed;left:18px;bottom:18px;z-index:2147483645;display:flex;align-items:stretch;gap:2px;padding:4px;border-radius:16px;background:var(--bg);border:1px solid var(--line);box-shadow:0 18px 50px rgba(10,6,16,.45);font:13px/1.25 -apple-system,system-ui,sans-serif;color:var(--ink);animation:ao-rise .4s var(--ao-ease)}
  .bar>button{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:2px;min-width:62px;padding:7px 9px;border:0;border-radius:12px;background:transparent;color:var(--ink);cursor:pointer;font:inherit;transition:background .2s}
  .bar>button:hover,.bar>button.on{background:var(--bg2)}
  .bar>button b{font-size:16px;font-weight:750}
  .bar>button small{font-size:11px;color:var(--muted)}
  .bar .logo{min-width:40px}
  .bar .logo .ao-mark{width:24px;height:24px}
  .bar.folded>button:not(.logo){display:none}
  b.ok{color:var(--ok)} b.warn{color:var(--warn)} b.bad{color:var(--err)}
  .bar>button.brand{background:color-mix(in srgb,var(--err) 18%,transparent)}
  .pop{position:fixed;left:18px;bottom:96px;z-index:2147483645;width:min(440px,calc(100vw - 36px));max-height:min(560px,calc(100vh - 130px));overflow:auto;padding:16px 18px;border-radius:16px;background:var(--bg);border:1px solid var(--line);box-shadow:0 24px 60px rgba(10,6,16,.5);font:13.5px/1.45 -apple-system,system-ui,sans-serif;color:var(--ink);animation:ao-rise .3s var(--ao-ease)}
  .pop h3{display:flex;justify-content:space-between;align-items:center;margin:0 0 10px;font-size:16px}
  .pop h3 button{border:0;background:none;color:var(--muted);font-size:18px;cursor:pointer}
  .pop p{margin:0 0 8px}
  .verdict{display:inline-block;padding:2px 10px;border-radius:99px;font-weight:700;margin-bottom:8px}
  .verdict.ok{background:color-mix(in srgb,var(--ok) 22%,transparent)}
  .verdict.warn{background:color-mix(in srgb,var(--warn) 25%,transparent)}
  .verdict.bad{background:color-mix(in srgb,var(--err) 25%,transparent)}
  .big{font-size:24px;font-weight:800}
  .muted{color:var(--muted);font-size:12px}
  svg{display:block;width:100%;height:90px;margin:6px 0 10px;background:var(--bg2);border-radius:10px}
  .photos{display:grid;grid-template-columns:repeat(3,1fr);gap:6px;margin:8px 0}
  .photos a{display:block;aspect-ratio:1;border-radius:10px;overflow:hidden;background:#000}
  .photos img{width:100%;height:100%;object-fit:cover}
  .rev{padding:8px 0;border-top:1px solid var(--line);font-size:12.5px}
  a{color:var(--ink)}
  .row{display:flex;gap:10px;padding:9px 0;border-top:1px solid var(--line);font-size:12.5px}
  .row img{width:54px;height:54px;border-radius:8px;object-fit:cover;flex:none;background:#000}
  .row .t{display:block;font-weight:650;margin-bottom:2px;overflow:hidden;text-overflow:ellipsis;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}
  .row.best{background:color-mix(in srgb,var(--ok) 10%,transparent);border-radius:10px;padding:9px 8px}
  .tag{display:inline-block;padding:1px 7px;border-radius:99px;background:var(--bg2);font-size:11px;font-weight:700;margin-right:4px}
  .pick{display:grid;grid-template-columns:repeat(5,1fr);gap:6px;margin:6px 0 10px}
  .pick button{position:relative;aspect-ratio:1;padding:0;border:2px solid transparent;border-radius:10px;overflow:hidden;background:#000;cursor:pointer;opacity:.55;transition:opacity .15s,border-color .15s}
  .pick button img{width:100%;height:100%;object-fit:cover;display:block}
  .pick button.on{border-color:#ff7a45;opacity:1}
  .pick button i{position:absolute;top:3px;right:3px;min-width:18px;height:18px;border-radius:99px;background:#ff7a45;color:#fff;font:700 11px/18px system-ui;font-style:normal;text-align:center}
  .pick-title{font-weight:700;font-size:12px;margin:8px 0 0}
  .go{display:inline-block;margin-top:6px;padding:7px 12px;border:0;border-radius:10px;background:var(--ao-gradient);color:#fff;font:700 13px system-ui;cursor:pointer;text-decoration:none}
`;
  var money3 = (n, cur) => n.toLocaleString("fr-FR", { style: "currency", currency: cur ?? "USD" });
  var safe = (url) => url && /^https:\/\//.test(url) ? url : "#";
  function setupProductBar(doc, enabled) {
    if (window.top !== window) return;
    let started = false;
    const start = () => {
      if (started || doc.visibilityState !== "visible" || !enabled() || !/\/item\/\d+\.html/.test(location.pathname)) return;
      started = true;
      void show2(doc).catch(() => {
      });
    };
    doc.addEventListener("visibilitychange", start);
    setTimeout(start, 1500);
  }
  async function show2(doc) {
    const data = await message({ type: "ALI_PRODUCT_INFO" });
    if (!data?.info) return;
    const { info, history: history2 } = data;
    doc.getElementById("auroebay-product-bar")?.remove();
    const host = doc.createElement("div");
    host.id = "auroebay-product-bar";
    const root = host.attachShadow({ mode: "open" });
    const seller = sellerVerdict(info.seller);
    const price = priceSummary(info, history2);
    const reviews = reviewsVerdict(info.reviews, info.rating);
    const brands = brandRisks(info.title);
    const danger = brands.filter((b) => b.level === "danger");
    const tone = (t) => t;
    const points = sparkline(history2, 400, 90, 8);
    const bar = `<div class="bar" role="toolbar" aria-label="AurOEBay">
    <button type="button" class="logo" data-fold title="Replier / d\xE9plier la barre AurOEBay"><span class="ao-mark"></span></button>
    <button type="button" data-pop="price" title="Prix et promotion"><b class="${tone(price.tone)}">${info.price !== null ? money3(info.price, info.currency) : "?"}</b><small>${price.discount !== null ? `\u2212${price.discount} %` : "\u{1F4C8} prix"}</small></button>
    <button type="button" data-pop="seller" title="Note du vendeur"><b class="${seller.tone}">${info.seller.positiveRate !== null ? `${Math.round(info.seller.positiveRate)} %` : "?"}</b><small>vendeur</small></button>
    <button type="button" data-pop="reviews" title="Avis des acheteurs avec photos"><b class="${reviews.tone}">\u{1F4F7} ${info.reviews?.photoCount ?? 0}</b><small>avis photo</small></button>
    <button type="button" data-pop="ebay" title="Ce produit se vend-il sur eBay ? (recherche par photo)"><b>\u{1F6D2}</b><small>sur eBay ?</small></button>
    <button type="button" data-pop="same" title="Le m\xEAme produit (m\xEAme photo) chez d\u2019autres vendeurs"><b>\u{1F50D}</b><small>moins cher ?</small></button>
    ${danger.length ? `<button type="button" class="brand" data-pop="brand" title="Marque prot\xE9g\xE9e"><b class="bad">\u{1F6AB}</b><small>marque</small></button>` : ""}
  </div>`;
    root.innerHTML = `<style>${CSS2}</style>${bar}<div class="pop" hidden></div>`;
    const pop = root.querySelector(".pop");
    const views = {
      price: () => `<h3>\u{1F4C8} Prix <button type="button" data-x>\u2715</button></h3>
      <p class="big">${info.price !== null ? money3(info.price, info.currency) : "?"}${info.original !== null && price.discount !== null ? ` <span class="muted"><s>${money3(info.original, info.currency)}</s></span>` : ""}</p>
      ${history2.length >= 2 ? `<svg viewBox="0 0 400 90" preserveAspectRatio="none" aria-label="Prix vus"><polyline points="${points}" fill="none" stroke="#ff7a45" stroke-width="2.5" stroke-linejoin="round"/></svg><p class="muted">${history2.length} jours not\xE9s \xB7 du ${escapeHTML(new Date(history2[0][0]).toLocaleDateString("fr-FR"))} \xE0 aujourd\u2019hui</p>` : ""}
      ${price.text.map((t) => `<p>${escapeHTML(t)}</p>`).join("")}`,
      seller: () => `<h3>\u{1F464} Vendeur <button type="button" data-x>\u2715</button></h3>
      <span class="verdict ${seller.tone}">${escapeHTML(seller.label)}</span>
      ${info.seller.name ? `<p><b>${escapeHTML(info.seller.name)}</b>${info.seller.country ? ` \xB7 ${escapeHTML(info.seller.country)}` : ""}</p>` : ""}
      ${seller.reasons.map((t) => `<p>${escapeHTML(t)}</p>`).join("")}
      <p class="muted">Rep\xE8re : 95 % et plus = bon ; moins de 90 % = commandes \xE0 surveiller (retards, colis non conformes).</p>
      ${info.seller.storeUrl ? `<a class="go" href="${escapeHTML(safe(info.seller.storeUrl))}" target="_blank" rel="noopener">Voir la boutique \u2197</a>` : ""}`,
      reviews: () => {
        const r = info.reviews;
        const photos = (r?.withPhotos ?? []).flatMap((x) => x.images).slice(0, 12);
        return `<h3>\u{1F4F7} Avis des acheteurs <button type="button" data-x>\u2715</button></h3>
        <span class="verdict ${reviews.tone}">${escapeHTML(reviews.text)}</span>
        ${photos.length ? `<div class="photos">${photos.map((u) => `<a href="${escapeHTML(safe(u))}" target="_blank" rel="noopener"><img src="${escapeHTML(safe(u))}" alt="" loading="lazy" referrerpolicy="no-referrer"></a>`).join("")}</div>` : `<p>Aucun avis avec photo pour l\u2019instant.</p>`}
        ${(r?.withPhotos ?? []).filter((x) => x.text).slice(0, 5).map((x) => `<div class="rev">${x.stars !== null ? "\u2605".repeat(x.stars) + "\u2606".repeat(5 - x.stars) : ""} <span class="muted">${escapeHTML(x.date)}${x.country ? ` \xB7 ${escapeHTML(x.country)}` : ""}</span><br>${escapeHTML(x.text)}</div>`).join("")}
        <p class="muted">Les photos des acheteurs montrent le vrai produit : compare-les aux photos du vendeur avant de le mettre sur eBay.</p>`;
      },
      same: () => `<h3>\u{1F50D} Le m\xEAme produit ailleurs <button type="button" data-x>\u2715</button></h3>
      <p>AurOEBay cherche sur AliExpress les produits avec <b>la m\xEAme photo</b> : souvent le m\xEAme article chez d\u2019autres vendeurs, parfois moins cher ou mieux not\xE9.</p>
      <button type="button" class="go" data-same>\u{1F50D} Chercher par photo</button>
      <p class="muted">Lance la recherche seulement quand tu en as besoin : AliExpress limite le nombre de recherches.</p>`,
      ebay: () => ebayView(check, pickHTML(), pickTouched),
      brand: () => `<h3>\u{1F6AB} Marque prot\xE9g\xE9e <button type="button" data-x>\u2715</button></h3>
      ${brandAdvice(brands).map((a) => `<p>${escapeHTML(a.text)}</p>`).join("")}`
    };
    let check = null;
    const MAX_PHOTOS = 4;
    const productPhotos = [...new Set([info.image, ...info.images].filter((u) => !!u))].slice(0, 10);
    const variantPhotos = (info.variantImages ?? []).filter((v) => !productPhotos.includes(v.url));
    let chosen = productPhotos.slice(0, 3);
    let pickTouched = false;
    const thumb = (url, name = "") => {
      const n = chosen.indexOf(url);
      return `<button type="button" data-photo="${escapeHTML(url)}" class="${n >= 0 ? "on" : ""}" title="${escapeHTML(name || "Photo")}">
      <img src="${escapeHTML(safe(url.replace(/(\.(?:jpe?g|png|webp))(_.*)?$/i, "$1_220x220.jpg")))}" alt="" loading="lazy" referrerpolicy="no-referrer">${n >= 0 ? `<i>${n + 1}</i>` : ""}</button>`;
    };
    const pickHTML = () => `<p class="pick-title">Photos \xE0 chercher : ${chosen.length}/${MAX_PHOTOS} <span class="muted">(clique pour choisir)</span></p>
    <div class="pick">${productPhotos.map((u) => thumb(u)).join("")}</div>
    ${variantPhotos.length ? `<p class="pick-title">Variantes</p><div class="pick">${variantPhotos.map((v) => thumb(v.url, v.name)).join("")}</div>` : ""}`;
    let polling = false;
    const refresh = () => {
      if (open === "ebay") pop.innerHTML = views.ebay();
    };
    const startEbayCheck = async () => {
      if (polling) return;
      const images = [...chosen];
      pickTouched = false;
      polling = true;
      try {
        check = await message({ type: "EBAY_PHOTO_CHECK", productId: info.productId, images, price: info.price, currency: info.currency, title: info.title });
        refresh();
        for (let i = 0; i < 400 && check?.state === "running"; i++) {
          await new Promise((r) => setTimeout(r, 1500));
          check = await message({ type: "EBAY_PHOTO_STATUS", productId: info.productId });
          refresh();
        }
        if (!check) {
          check = { state: "error", error: "La recherche n\u2019a pas pu d\xE9marrer : recharge la page." };
          refresh();
        }
      } catch (e) {
        check = { state: "error", error: e instanceof Error ? e.message : String(e) };
        refresh();
      } finally {
        polling = false;
      }
    };
    let open = "";
    const toggle = (name) => {
      open = open === name ? "" : name;
      root.querySelectorAll("[data-pop]").forEach((b) => b.classList.toggle("on", b.dataset.pop === open));
      pop.hidden = !open;
      if (open) pop.innerHTML = views[open]();
    };
    root.addEventListener("click", (e) => {
      const t = e.target;
      const b = t.closest("[data-pop]");
      if (b) return toggle(b.dataset.pop);
      if (t.closest("[data-x]")) return toggle(open);
      const photo = t.closest("[data-photo]");
      if (photo) {
        const url = photo.dataset.photo;
        chosen = chosen.includes(url) ? chosen.filter((u) => u !== url) : [...chosen, url].slice(-MAX_PHOTOS);
        pickTouched = true;
        refresh();
        return;
      }
      if (t.closest("[data-ebay]")) {
        if (!chosen.length) return;
        void startEbayCheck();
        return;
      }
      if (t.closest("[data-same]")) {
        toggle(open);
        if (info.image)
          openSupplierFinder(doc, { title: info.title, image: info.image, images: info.images, price: null, heading: "Le m\xEAme produit ailleurs (m\xEAme photo)" });
        return;
      }
      if (t.closest("[data-fold]")) {
        if (open) toggle(open);
        fold2(!barEl.classList.contains("folded"));
      }
    });
    const barEl = root.querySelector(".bar");
    const fold2 = (folded) => {
      barEl.classList.toggle("folded", folded);
      try {
        if (folded) localStorage.setItem(FOLDED, "1");
        else localStorage.removeItem(FOLDED);
      } catch {
      }
    };
    try {
      sessionStorage.removeItem("auroebayBarHidden");
      barEl.classList.toggle("folded", localStorage.getItem(FOLDED) === "1");
    } catch {
    }
    doc.documentElement.append(host);
  }
  var who = (l) => l.status === "NON_US" ? `\u{1F30F} ${l.country ?? "hors US"}` : l.status === "US" ? "\u{1F1FA}\u{1F1F8} US" : l.located ? `\u{1F4CD} ${l.located}` : "pays ?";
  function listingRow(l, best) {
    const url = `https://www.ebay.com/itm/${encodeURIComponent(l.itemId)}`;
    const sales = [
      l.d30 !== null ? `${l.d30} vendu(s) en 30 j` : "",
      l.d7 ? `${l.d7} en 7 j` : "",
      l.sold ? `${l.sold} vendus au total` : ""
    ].filter(Boolean);
    return `<div class="row${best ? " best" : ""}">
    <img src="${escapeHTML(safe(l.image))}" alt="" loading="lazy" referrerpolicy="no-referrer">
    <div>${best ? `<span class="tag">\u{1F3C6} La meilleure \xE0 copier</span>` : ""}
      <a class="t" href="${escapeHTML(url)}" target="_blank" rel="noopener">${escapeHTML(l.title)}</a>
      <span class="muted">${escapeHTML(l.seller ?? "vendeur ?")} \xB7 ${escapeHTML(who(l))} \xB7 ${escapeHTML(money3(l.total, "USD"))} port compris</span><br>
      ${sales.length ? `<b>${escapeHTML(sales.join(" \xB7 "))}</b>` : `<span class="muted">${l.soldAt ? `Derni\xE8re vente le ${escapeHTML(new Date(l.soldAt).toLocaleDateString("fr-FR"))}` : "Ventes non lues"}</span>`}
      ${best ? `<br><a class="go" href="${escapeHTML(url)}" target="_blank" rel="noopener">Ouvrir l\u2019annonce pour la copier \u2197</a>` : ""}
    </div>
  </div>`;
  }
  function ebayView(c, pick, pickOpen) {
    const head = `<h3>\u{1F6D2} Se vend sur eBay ? <button type="button" data-x>\u2715</button></h3>`;
    if (!c)
      return `${head}<p>AurOEBay cherche les photos choisies sur eBay (recherche par image) : les ventes des 30 derniers jours, les vendeurs (dropshippers hors US ou vendeurs US) et <b>la meilleure annonce \xE0 copier</b>.</p>
      ${pick}
      <button type="button" class="go" data-ebay ${pick.includes(' class="on"') ? "" : "disabled"}>\u{1F50E} Chercher sur eBay par photo</button>
      <p class="muted">Astuce : prends les photos o\xF9 le produit se voit bien en entier (pas les tableaux de tailles ni les gros plans de tissu).</p>
      <p class="muted">1 \xE0 2 minutes. Un onglet eBay s\u2019ouvre en arri\xE8re-plan puis se ferme. Rien n\u2019est modifi\xE9 sur eBay.</p>`;
    if (c.state === "error") return `${head}<p class="verdict bad">Recherche impossible</p><p>${escapeHTML(c.error ?? "")}</p>${pick}<button type="button" class="go" data-ebay>\u{1F504} R\xE9essayer</button>`;
    if (c.state === "running") return `${head}<p>\u23F3 ${escapeHTML(c.step)}</p><p class="muted">Tu peux continuer \xE0 naviguer dans un autre onglet ; garde celui-ci ouvert.</p>`;
    const v = photoVerdict(c);
    const best = c.listings[0];
    return `${head}<span class="verdict ${v.tone}">${escapeHTML(v.label)}</span>
    <p>${escapeHTML(v.text)}</p>
    ${c.found ? `<p class="muted">${c.found} annonce(s) du m\xEAme produit \xB7 ${c.nonUS} vendeur(s) hors US, ${c.us} US${c.unknown ? `, ${c.unknown} pays inconnu` : ""}${c.median !== null ? ` \xB7 prix m\xE9dian ${escapeHTML(money3(c.median, "USD"))}` : ""}${c.net !== null ? ` \xB7 ton b\xE9n\xE9fice \xE0 son prix : <b>${escapeHTML(money3(c.net, c.currency))}</b>` : ""}</p>` : ""}
    ${best ? listingRow(best, true) : ""}
    ${c.listings.slice(1, 6).map((l) => listingRow(l, false)).join("")}
    ${c.guid ? `<p><a href="${escapeHTML(visualSearchURL(c.guid, true))}" target="_blank" rel="noopener">Voir tous les vendus sur eBay \u2197</a></p>` : ""}
    <p class="muted">Sur l\u2019annonce eBay, \xAB Cr\xE9er un brouillon \xB7 AurOEBay \xBB la recopie ; c\u2019est toi qui publies. V\xE9rifie que c\u2019est bien le m\xEAme produit (photo, variantes).</p>
    <details${pickOpen ? " open" : ""}><summary class="muted">Changer les photos et relancer</summary>${pick}<button type="button" class="go" data-ebay>\u{1F504} Relancer avec ces photos</button></details>`;
  }

  // src/aliexpress/pageData.ts
  function scanFromPdp(data, domAxes, productId) {
    if (!data || !Array.isArray(data.rows) || !data.rows.length) return null;
    if (data.productId && productId && data.productId !== productId) return null;
    const axes = domAxes.filter((a) => a.values.length);
    if (!axes.length) return null;
    const order = axes.map(
      (axis) => data.axes.findIndex((p) => norm(p.name) === norm(axis.name))
    );
    if (order.some((i) => i < 0)) return null;
    if (data.axes.some((a, i) => !order.includes(i) && a.values.filter(Boolean).length > 1))
      return null;
    const costs = [];
    const unavailable = [];
    const seen = /* @__PURE__ */ new Set();
    for (const row of data.rows) {
      const values = order.map((i, k) => {
        const v = row.values[i];
        return axes[k].values.find((dom) => norm(dom) === norm(v)) ?? null;
      });
      if (values.some((v) => v === null)) {
        if (!row.salable || row.stock === 0) continue;
        return null;
      }
      const key = JSON.stringify(values);
      if (seen.has(key)) return null;
      seen.add(key);
      if (!row.salable || row.stock === 0) {
        unavailable.push({ values });
        continue;
      }
      if (row.currency !== "USD" || !(typeof row.price === "number" && row.price > 0))
        return null;
      costs.push({ values, cost: row.price, currency: "USD" });
    }
    const total = axes.reduce((n, a) => n * a.values.length, 1);
    if (total > 1e3) return null;
    const combos = axes.reduce(
      (acc, axis) => acc.flatMap((prefix) => axis.values.map((v) => [...prefix, v])),
      [[]]
    );
    for (const combo of combos)
      if (!seen.has(JSON.stringify(combo))) unavailable.push({ values: combo });
    if (!costs.length) return null;
    return { at: Date.now(), costs, unavailable, durationMs: 0 };
  }
  function simpleCostFromPdp(data, productId) {
    if (!data || data.productId && productId && data.productId !== productId)
      return null;
    if (data.axes.some((a) => a.values.filter(Boolean).length > 1)) return null;
    const rows = data.rows.filter(
      (r) => r.salable && r.stock !== 0 && r.currency === "USD" && (r.price ?? 0) > 0
    );
    if (rows.length !== 1) return null;
    return { cost: rows[0].price, currency: "USD" };
  }
  function axesFromPdp(data) {
    const variants = [];
    const images = [];
    for (const axis of data?.axes ?? []) {
      const values = axis.values.filter(Boolean);
      if (!axis.name || values.length < 2) continue;
      variants.push({ name: axis.name, values });
      axis.values.forEach((value, i) => {
        const raw = axis.images?.[i];
        if (value && raw)
          images.push({
            axis: axis.name,
            value,
            url: raw.startsWith("//") ? "https:" + raw : raw
          });
      });
    }
    return { variants, images };
  }
  function foreignCurrency(data) {
    const found = (data?.rows ?? []).map((r) => r.currency).find((c) => typeof c === "string" && c !== "USD");
    return found ?? null;
  }

  // src/aliexpress/descriptionResource.ts
  var DESCRIPTION_RESOURCE_LIMIT = 4e5;
  function descriptionResourceURL(value) {
    if (typeof value !== "string" || value.length > 2e3)
      throw Error("Ressource de description AliExpress invalide.");
    const url = new URL(value);
    if (url.protocol !== "https:" || url.username || url.password || url.port || url.hash || !/(^|\.)(alicdn\.com|aliexpress-media\.com)$/.test(url.hostname) || // The public description CDN (DESC.pcDescUrl) carries a cache "token"/"key"
    // that is not a credential; it is fetched without cookies.
    !/^\/product\/description\//.test(url.pathname) && [...url.searchParams.keys()].some(
      (key) => /token|secret|auth|session|cookie|password|credential|signature|api.?key/i.test(
        key
      )
    ))
      throw Error("Ressource de description AliExpress non autoris\xE9e.");
    return url.href;
  }
  function observedDescriptionResources(doc, pageURL) {
    const itemId = new URL(pageURL).pathname.match(/\/item\/(\d+)\.html$/)?.[1];
    if (!itemId) return [];
    const found = [];
    const add = (value, frame) => {
      try {
        const url = descriptionResourceURL(value);
        if (!found.some((entry) => entry.url === url && entry.frame === frame))
          found.push({ url, ...frame ? { frame } : {} });
      } catch {
      }
    };
    for (const frame of queryAll(doc, SELECTORS.aliDescriptionFrames))
      add(
        frame.getAttribute("src") || frame.getAttribute("data-src"),
        frame
      );
    for (const script of doc.querySelectorAll("script")) {
      const text = script.textContent?.trim() ?? "";
      if (!text || text.length > DESCRIPTION_RESOURCE_LIMIT) continue;
      let json = text;
      if (script.getAttribute("type") !== "application/json") {
        const assignment = text.match(
          /^(?:window\.)?runParams\s*=\s*(\{[\s\S]*\})\s*;?\s*$/
        );
        if (!assignment) continue;
        json = assignment[1];
      }
      try {
        const parsed2 = JSON.parse(json);
        const data = parsed2?.data ?? parsed2;
        if (!data || typeof data !== "object" || Array.isArray(data)) continue;
        const declaredId = data.itemId ?? data.productId ?? data.productInfoComponent?.id;
        if (String(declaredId ?? "") !== itemId) continue;
        const module = data.descriptionModule;
        if (module && typeof module === "object" && !Array.isArray(module))
          add(module.descriptionUrl);
      } catch {
      }
    }
    return found.length <= 3 ? found : [];
  }

  // src/aliexpress/fullDescription.ts
  var tags = new Set(
    "DIV SECTION SPAN P BR UL OL LI STRONG B I EM U H1 H2 H3 H4 H5 H6 TABLE TBODY THEAD TFOOT TR TD TH HR BLOCKQUOTE FIGURE FIGCAPTION IMG".split(
      " "
    )
  );
  var discard = new Set(
    "SCRIPT STYLE IFRAME OBJECT EMBED SVG MATH FORM INPUT BUTTON SELECT TEXTAREA LINK META TEMPLATE NOSCRIPT VIDEO AUDIO".split(
      " "
    )
  );
  var styles = new Set(
    "color background-color text-align font-size font-family font-weight font-style text-decoration line-height border border-color border-width border-style border-collapse padding padding-left padding-right padding-top padding-bottom margin margin-left margin-right margin-top margin-bottom width height max-width vertical-align".split(
      " "
    )
  );
  function sanitizeSupplierDescription(doc, html, imageURL = descriptionImageURL) {
    const input2 = doc.createElement("template");
    input2.innerHTML = html;
    const out = doc.createElement("div");
    let imageCount = 0, unsupportedImages = 0;
    const visit = (node, parent) => {
      if (node.nodeType === 3) {
        parent.appendChild(doc.createTextNode(node.textContent ?? ""));
        return;
      }
      if (node.nodeType !== 1) return;
      const el = node;
      if (el.namespaceURI !== "http://www.w3.org/1999/xhtml" || discard.has(el.tagName))
        return;
      if (!tags.has(el.tagName)) {
        [...el.childNodes].forEach((n) => visit(n, parent));
        return;
      }
      const target = doc.createElement(el.tagName.toLowerCase());
      if (el.tagName === "IMG") {
        const url = imageURL(
          el.getAttribute("data-src") || el.getAttribute("data-lazy-src") || el.getAttribute("src") || ""
        );
        if (!url) {
          unsupportedImages++;
          return;
        }
        target.setAttribute("src", url);
        target.setAttribute("alt", el.getAttribute("alt") ?? "");
        target.setAttribute("style", "max-width: 100%; height: auto;");
        imageCount++;
      } else {
        const css2 = el.style;
        for (const name of Array.from(
          { length: css2.length },
          (_, i) => css2.item(i)
        )) {
          const value = css2.getPropertyValue(name);
          if (styles.has(name) && !/url\s*\(|expression|javascript|@import|\\/i.test(value) && value.length < 200)
            target.style.setProperty(name, value);
        }
        for (const attr of ["colspan", "rowspan"]) {
          const value = el.getAttribute(attr);
          if (value && /^\d{1,2}$/.test(value)) target.setAttribute(attr, value);
        }
        [...el.childNodes].forEach((n) => visit(n, target));
      }
      parent.appendChild(target);
    };
    [...input2.content.childNodes].forEach((n) => visit(n, out));
    return {
      html: out.innerHTML,
      imageCount,
      unsupportedImages,
      hasContent: !!out.textContent?.trim() || imageCount > 0
    };
  }
  function extractFullDescription(doc, resolvedFrames = /* @__PURE__ */ new Map(), declaredDescription = "") {
    const scopes = queryAll(doc, SELECTORS.aliDescription);
    const outer = scopes.filter(
      (el) => !scopes.some((parent) => parent !== el && parent.contains(el))
    );
    const shadowDescriptions = /* @__PURE__ */ new Set();
    const composedHTML = (root) => {
      const copy = doc.createElement("div");
      const append = (node, parent) => {
        const clone = node.cloneNode(false);
        parent.appendChild(clone);
        if (node.nodeType !== 1) return;
        const el = node;
        const shadow = el.shadowRoot;
        if (shadow && SELECTORS.aliDescription.some((s) => shadow.querySelector(s)))
          shadowDescriptions.add(el);
        [...(shadow ?? el).childNodes].forEach((child) => append(child, clone));
      };
      [...root.childNodes].forEach((node) => append(node, copy));
      if (root.shadowRoot) {
        copy.replaceChildren();
        if (SELECTORS.aliDescription.some((s) => root.shadowRoot.querySelector(s)))
          shadowDescriptions.add(root);
        [...root.shadowRoot.childNodes].forEach((node) => append(node, copy));
      }
      return copy.innerHTML;
    };
    const html = outer.map(composedHTML);
    if (declaredDescription) html.push(declaredDescription);
    let inaccessible = false;
    const frames = queryAll(
      doc,
      SELECTORS.aliDescriptionFrames
    );
    for (const frame of frames) {
      const resolved = resolvedFrames.get(frame);
      if (resolved !== void 0) {
        html.push(resolved);
        continue;
      }
      const shadowContent = [...shadowDescriptions].some(
        (host) => frame.closest("#nav-description")?.contains(host) && sanitizeSupplierDescription(doc, composedHTML(host)).hasContent
      );
      const sizingFrame = (shadowContent || !!declaredDescription) && !frame.hasAttribute("src") && !frame.hasAttribute("srcdoc") && /(?:^|\s)extend--iframe--/.test(frame.className);
      try {
        const body = frame.contentDocument?.body;
        if (!body) {
          if (!sizingFrame) inaccessible = true;
          continue;
        }
        const children = queryAll(body, SELECTORS.aliDescription);
        const roots = children.filter(
          (el) => !children.some((parent) => parent !== el && parent.contains(el))
        );
        html.push(
          ...roots.length ? roots.map(composedHTML) : [composedHTML(body)]
        );
      } catch {
        if (!sizingFrame) inaccessible = true;
      }
    }
    const joined = [...new Set(html)].join("");
    if (joined.length > 4e5)
      return {
        descriptionHTML: "",
        descriptionStatus: "too-large",
        descriptionImageCount: 0
      };
    const clean = sanitizeSupplierDescription(doc, joined);
    return {
      descriptionHTML: clean.html,
      // An unknown image is left out; it no longer rejects the whole
      // description (seen live: one odd image blocked every draft).
      descriptionStatus: inaccessible ? "unsupported" : clean.hasContent ? "loaded" : "unavailable",
      descriptionImageCount: clean.imageCount
    };
  }
  function descriptionReadError(status) {
    if (status === "too-large")
      return "La description AliExpress d\xE9passe la taille maximale : elle n\u2019a pas \xE9t\xE9 tronqu\xE9e.";
    if (status === "unsupported")
      return "La description AliExpress contient une image non reconnue ou une iframe de contenu inaccessible. Aucun brouillon incomplet n\u2019a \xE9t\xE9 cr\xE9\xE9.";
    return "La description AliExpress n\u2019a pas fini de se charger. R\xE9essaie la lecture de la fiche.";
  }
  async function loadFullDescription(doc, valid, readResource, pageURL = doc.URL, extraResources = []) {
    if (!valid()) throw Error("Lecture interrompue.");
    const win = doc.defaultView;
    const top = win.scrollY, left = win.scrollX;
    try {
      const resolvedFrames = /* @__PURE__ */ new Map();
      let declaredDescription = "";
      if (readResource && extractFullDescription(doc).descriptionStatus !== "loaded") {
        const resources = observedDescriptionResources(doc, pageURL);
        for (const extra of extraResources)
          try {
            const url = descriptionResourceURL(extra);
            if (!resources.some((r) => r.url === url)) resources.unshift({ url });
          } catch {
          }
        for (const resource of resources) {
          if (!valid()) throw Error("Lecture interrompue.");
          try {
            const response = await readResource(resource.url);
            if (!valid()) throw Error("Lecture interrompue.");
            if (response.url !== resource.url || typeof response.html !== "string" || response.html.length > DESCRIPTION_RESOURCE_LIMIT)
              continue;
            const parsed2 = new win.DOMParser().parseFromString(
              response.html,
              "text/html"
            );
            if (parsed2.querySelector(
              "iframe,object,embed,form,input,meta[http-equiv='refresh']"
            ))
              continue;
            const clean = sanitizeSupplierDescription(doc, parsed2.body.innerHTML);
            if (!clean.hasContent) continue;
            if (resource.frame) resolvedFrames.set(resource.frame, clean.html);
            else declaredDescription += clean.html;
          } catch {
            if (!valid()) throw Error("Lecture interrompue.");
          }
        }
        const loaded = extractFullDescription(
          doc,
          resolvedFrames,
          declaredDescription
        );
        if (loaded.descriptionStatus === "loaded") return loaded;
      }
      doc.querySelector('a[href="#nav-description"]')?.click();
      let lastSection;
      const expanded = /* @__PURE__ */ new WeakSet();
      let previous = "", stable = 0;
      const until = Date.now() + 3e4;
      const hiddenUntil = Date.now() + 4e3;
      while (Date.now() < until && (doc.visibilityState !== "hidden" || Date.now() < hiddenUntil)) {
        if (!valid())
          throw Error("La fiche AliExpress a chang\xE9 ou AurOEBay est en pause.");
        const section = doc.querySelector("#nav-description") ?? queryAll(doc, SELECTORS.aliDescription)[0];
        if (section !== lastSection || section?.querySelector(".lazy-load")) {
          (section?.querySelector(".lazy-load") ?? section)?.scrollIntoView?.({
            block: "center"
          });
          lastSection = section;
        }
        const more = [
          ...section?.querySelectorAll("button") ?? []
        ].find(
          (b) => /^(view more|voir plus)\s*$/i.test(b.textContent?.trim() ?? "")
        );
        if (more && !expanded.has(more)) {
          expanded.add(more);
          more.click();
        }
        const result = extractFullDescription(
          doc,
          resolvedFrames,
          declaredDescription
        );
        if (result.descriptionStatus === "loaded") {
          stable = result.descriptionHTML === previous ? stable + 1 : 0;
          previous = result.descriptionHTML;
          if (stable >= 3) return result;
        } else if (result.descriptionStatus === "too-large") return result;
        await new Promise((r) => setTimeout(r, 300));
      }
      return extractFullDescription(doc, resolvedFrames, declaredDescription);
    } finally {
      win.scrollTo?.(left, top);
    }
  }

  // src/aliexpress/prices.ts
  var selected2 = (el) => /sku-item--selected/.test(el.className) || el.getAttribute("aria-checked") === "true";
  var disabled = (el) => /disabled|soldout/i.test(el.className) || el.getAttribute("aria-disabled") === "true";
  var valueOf2 = (el) => compact(
    el.querySelector("img")?.getAttribute("alt") ?? el.getAttribute("title") ?? el.textContent ?? ""
  );
  var priceText = (doc) => compact(
    doc.querySelector(
      '[class*="price-default--current"],[class*="price--current"],[data-testid="product-price"]'
    )?.textContent ?? ""
  );
  function readCost(doc) {
    const price = priceText(doc);
    const amount = price.match(
      /^(?:US\s*\$|USD\s*|\$)\s*(\d+(?:[.,]\d{1,2})?)(?:\s*\/\s*(?:lot|piece|pieces|pc|pcs|set|pack|pair))?$/i
    );
    if (!amount) return null;
    const visible3 = doc.querySelector('[class*="ship-to--text"]')?.textContent ?? doc.body.innerText ?? doc.body.textContent ?? "";
    if (!/USD/.test(price) && !/^US\s*\$/.test(price) && !/\bUSD\b/.test(visible3))
      return null;
    const cost = Number(amount[1].replace(",", "."));
    return Number.isFinite(cost) && cost > 0 ? { cost, currency: "USD" } : null;
  }
  async function captureVariantCosts(doc, active) {
    const startedAt = Date.now();
    const groups = [...doc.querySelectorAll("[data-sku-row]")];
    const choices = groups.map(
      (g) => [...g.querySelectorAll("[data-sku-col]")].map((el) => ({
        id: el.getAttribute("data-sku-col"),
        value: valueOf2(el)
      })).filter((c) => c.value)
    );
    if (!groups.length || choices.some((g) => !g.length))
      throw Error(
        "Options AliExpress non reconnues. Les co\xFBts peuvent \xEAtre saisis dans le tableau."
      );
    const total = choices.reduce((n, g) => n * g.length, 1);
    if (total > 50)
      throw Error(
        "Plus de 50 combinaisons et donn\xE9es AliExpress illisibles : recharge la fiche AliExpress puis r\xE9essaie."
      );
    const original = groups.map(
      (g) => g.querySelector(
        '[class*="sku-item--selected"],[aria-checked="true"]'
      )?.getAttribute("data-sku-col")
    );
    if (original.some((x) => !x))
      throw Error(
        "S\xE9lectionne une option pour chaque axe AliExpress avant de lire les prix."
      );
    const start = doc.location.href;
    const find = (id) => [...doc.querySelectorAll("[data-sku-col]")].find(
      (e) => e.getAttribute("data-sku-col") === id
    );
    const combinations = choices.reduce(
      (all, g) => all.flatMap((a) => g.map((c) => [...a, c])),
      [[]]
    );
    const costs = [];
    const unavailable = [];
    const alive = () => active() && doc.location.href === start;
    const soldOut = (combo) => combo.some((c, i) => {
      const el = find(c.id);
      return el && /soldout/i.test(el.className) && combo.every((other, j) => {
        const target = find(other.id);
        return j === i || target && selected2(target);
      });
    });
    const settled = async (combo, before) => {
      const started = Date.now();
      let signature2 = "";
      let stableSince = started;
      while (Date.now() - started <= 5e3) {
        if (!alive()) throw Error("Lecture des prix interrompue.");
        const cost = readCost(doc);
        const out = soldOut(combo);
        const exact = combo.every((c) => {
          const el = find(c.id);
          return el && selected2(el) && !disabled(el);
        });
        const state = JSON.stringify([cost, out, exact]);
        const now = Date.now();
        if (state !== signature2) {
          signature2 = state;
          stableSince = now;
        }
        const changedPrice = !!cost && !!before && cost.cost !== before.cost;
        const minimum = changedPrice && exact && !out ? 700 : 2200;
        if (now - started >= minimum && now - stableSince >= 500) {
          if (out) return { out: true, cost: null };
          if (cost && exact) return { out: false, cost };
          if (!exact) return null;
        }
        await delay(100);
      }
      return null;
    };
    try {
      for (const combo of combinations) {
        if (!alive()) throw Error("Lecture des prix interrompue.");
        let before = readCost(doc);
        for (let pass = 0; pass < combo.length + 1; pass++) {
          let changed = false;
          for (const choice of combo) {
            if (!alive()) throw Error("Lecture des prix interrompue.");
            const option = find(choice.id);
            if (option && !disabled(option) && !selected2(option)) {
              before = readCost(doc);
              option.click();
              changed = true;
              await delay(150);
            }
          }
          if (!changed) break;
        }
        const result = await settled(combo, before);
        if (result?.out) {
          unavailable.push({ values: combo.map((c) => c.value) });
        } else if (result?.cost) {
          costs.push({ ...result.cost, values: combo.map((c) => c.value) });
        }
      }
      if (!costs.length && !unavailable.length)
        throw Error(
          `Aucun co\xFBt ou \xE9tat de stock confirm\xE9. Prix affich\xE9 : \xAB ${priceText(doc).slice(0, 100) || "non trouv\xE9"} \xBB. V\xE9rifie la devise USD et les options AliExpress.`
        );
    } finally {
      if (doc.location.href === start)
        for (let pass = 0; pass < original.length + 1; pass++)
          for (const id of original) {
            const el = id && find(id);
            if (el && !disabled(el) && !selected2(el)) {
              el.click();
              await delay(150);
            }
          }
    }
    return {
      at: Date.now(),
      costs,
      unavailable,
      durationMs: Date.now() - startedAt
    };
  }

  // src/core/description.ts
  var allowed = /* @__PURE__ */ new Set([
    "P",
    "UL",
    "OL",
    "LI",
    "STRONG",
    "B",
    "BR",
    "H3",
    "H4"
  ]);
  var discard2 = /* @__PURE__ */ new Set([
    "SCRIPT",
    "STYLE",
    "IFRAME",
    "OBJECT",
    "EMBED",
    "SVG",
    "MATH",
    "FORM",
    "BUTTON",
    "INPUT",
    "TEXTAREA",
    "SELECT",
    "TEMPLATE",
    "NOSCRIPT",
    "IMG",
    "VIDEO",
    "AUDIO",
    "LINK",
    "META"
  ]);
  function sanitizeHTML(html) {
    const doc = new DOMParser().parseFromString(html, "text/html");
    const out = document.createElement("div");
    const visit = (node, parent) => {
      if (node.nodeType === 3) {
        parent.appendChild(document.createTextNode(node.textContent ?? ""));
        return;
      }
      if (node.nodeType !== 1) return;
      const el = node;
      if (el.namespaceURI !== "http://www.w3.org/1999/xhtml" || discard2.has(el.tagName.toUpperCase()))
        return;
      const target = allowed.has(el.tagName) ? document.createElement(el.tagName.toLowerCase()) : parent;
      if (target !== parent) parent.appendChild(target);
      for (const child of Array.from(el.childNodes)) visit(child, target);
      if (target === parent && ["DIV", "SECTION", "TR", "TABLE"].includes(el.tagName))
        parent.appendChild(document.createElement("br"));
    };
    for (const node of Array.from(doc.body.childNodes)) visit(node, out);
    return out.innerHTML.trim();
  }
  function plainText(html) {
    const d = new DOMParser().parseFromString(sanitizeHTML(html), "text/html");
    d.querySelectorAll("p,li,h3,h4,br").forEach((el) => el.append("\n"));
    return (d.body.textContent ?? "").trim();
  }

  // src/aliexpress/extract.ts
  function extractAliExpress(doc, url, now = Date.now()) {
    const u = new URL(url);
    if (!/(^|\.)aliexpress\.(com|us)$/.test(u.hostname)) return null;
    const id = u.pathname.match(/\/item\/(\d+)\.html/)?.[1];
    if (!id) return null;
    const canonical = doc.querySelector('link[rel="canonical"]')?.getAttribute("href");
    const canonicalId = canonical?.match(/\/item\/(\d+)\.html/)?.[1];
    if (canonicalId && canonicalId !== id) return null;
    let title = compact(first(doc, SELECTORS.aliTitle)?.textContent ?? "");
    if (!title) {
      title = doc.querySelector('meta[property="og:title"]')?.getAttribute("content") ?? "";
    }
    if (!title) return null;
    const specs = [];
    const add = (label, value) => {
      label = compact(label.replace(/[:：]$/, ""));
      value = compact(value);
      if (label && value && label.length < 100 && value.length < 600 && !specs.some((s) => s.label === label && s.value === value))
        specs.push({ label, value });
    };
    const rows = queryAll(doc, SELECTORS.aliSpecs);
    for (const row of rows) {
      if (rows.some((child) => child !== row && row.contains(child))) continue;
      const label = row.querySelector(
        '[data-label],[class*="title"],[class*="name"],th,dt'
      );
      const value = row.querySelector('[data-value],[class*="value"],td,dd');
      if (label && value) add(label.textContent ?? "", value.textContent ?? "");
      else {
        const children = [...row.children];
        if (children.length === 2)
          add(children[0].textContent ?? "", children[1].textContent ?? "");
      }
    }
    for (const dt of doc.querySelectorAll('[class*="specification"] dt'))
      if (dt.nextElementSibling?.tagName === "DD")
        add(dt.textContent ?? "", dt.nextElementSibling.textContent ?? "");
    const variants = variantGroups(doc).map((el) => ({
      name: variantAxisName(el),
      values: [
        ...new Set(
          [
            ...el.querySelectorAll(
              "[data-sku-col],[title],button,[data-value],img[alt]"
            )
          ].map(
            (v) => compact(
              v.getAttribute("title") || v.getAttribute("data-value") || v.getAttribute("alt") || v.querySelector("img[alt]")?.getAttribute("alt") || v.textContent || ""
            )
          ).filter(Boolean)
        )
      ].slice(0, 60)
    }));
    const fullDescription = extractFullDescription(doc);
    const description = plainText(fullDescription.descriptionHTML).slice(
      0,
      12e3
    );
    return {
      extractionVersion: 1,
      ...fullDescription,
      ...extractImages(doc),
      shippingDetails: extractShipping(doc),
      id,
      url: cleanURL(url),
      title,
      capturedAt: now,
      specs: specs.slice(0, 80),
      description,
      variants,
      supplierNames: queryAll(doc, SELECTORS.aliStore).map((e) => compact(e.textContent ?? "")).filter(Boolean).slice(0, 6),
      price: doc.querySelector('[data-testid="product-price"],[class*="price--current"]')?.textContent?.trim().slice(0, 100),
      shipping: doc.querySelector('[data-testid="shipping"]')?.textContent?.trim().slice(0, 200)
    };
  }

  // src/aliexpress/content.ts
  quietStaleContext();
  var settings;
  var reloadingLocale = enforceUsLocale();
  var last = "";
  var lastURL = location.href;
  var captures = 0;
  var scanning = false;
  var interval;
  var timeout;
  async function capture(force = false) {
    if (!settings?.enabled || !settings.captureEnabled || scanning) return;
    try {
      const data = extractAliExpress(document, location.href);
      if (!data) return;
      const fingerprint = JSON.stringify({ ...data, capturedAt: 0 });
      if (force || last !== fingerprint) {
        const saved2 = await message({
          type: "SOURCE_CAPTURE",
          product: data
        });
        if (saved2) {
          last = fingerprint;
          captures++;
        }
      }
    } catch {
    }
  }
  var schedule = debounce(() => {
    if (captures < 15) void capture();
  }, 1200);
  var observer = new MutationObserver(schedule);
  function observe() {
    clearTimeout(timeout);
    observer.observe(document.body, { childList: true, subtree: true });
    timeout = setTimeout(() => observer.disconnect(), 6e4);
  }
  var configuration = 0;
  var aliOrdersStarted = false;
  async function configure() {
    const revision = ++configuration;
    const next = await message({ type: "PUBLIC_SETTINGS" });
    if (revision !== configuration) return;
    settings = next;
    if (!aliOrdersStarted && window.top === window) {
      aliOrdersStarted = true;
      setupAliOrders(() => !!settings?.enabled);
      if (!reloadingLocale) setupOrderPrefill(document, () => !!settings?.enabled);
      if (!reloadingLocale) setupDisputeHelper(document, () => !!settings?.enabled);
      if (!reloadingLocale) setupRegionWarning(document, () => !!settings?.enabled);
      if (!reloadingLocale) setupCheckoutQuantity(document, () => !!settings?.enabled);
      if (!reloadingLocale) setupProductBar(document, () => !!settings?.enabled);
    }
    observer.disconnect();
    clearTimeout(timeout);
    clearInterval(interval);
    if (!settings.enabled || !settings.captureEnabled) return;
    captures = 0;
    last = "";
    await capture(true);
    if (revision !== configuration || !settings.enabled) return;
    observe();
    interval = setInterval(() => {
      if (location.href !== lastURL) {
        lastURL = location.href;
        last = "";
        captures = 0;
        void capture();
        observe();
      }
    }, 2e3);
  }
  void configure().catch(() => {
  });
  chrome.runtime.onMessage.addListener((msg, sender, reply) => {
    if (sender.id !== chrome.runtime.id || reloadingLocale) return;
    if (msg?.type === "SOURCE_READ_SNAPSHOT" && !sender.tab) {
      void (async () => {
        const configuration2 = await message({
          type: "PUBLIC_SETTINGS"
        });
        if (!configuration2.enabled || !configuration2.captureEnabled || scanning)
          throw Error(
            "Capture AliExpress d\xE9sactiv\xE9e ou lecture des prix en cours."
          );
        const initialURL = location.origin + location.pathname;
        if (msg.url !== initialURL) throw Error("La fiche AliExpress a chang\xE9.");
        const data = extractAliExpress(document, location.href);
        const currentConfiguration = await message({
          type: "PUBLIC_SETTINGS"
        });
        if (!currentConfiguration.enabled || !currentConfiguration.captureEnabled || scanning)
          throw Error(
            "Capture AliExpress d\xE9sactiv\xE9e ou lecture des prix en cours."
          );
        if (!data || data.url !== msg.url || initialURL !== location.origin + location.pathname)
          throw Error("Le produit AliExpress n\u2019est pas charg\xE9 ou a chang\xE9.");
        return data;
      })().then((data) => reply({ ok: true, data })).catch((error) => reply({ ok: false, error: error.message }));
      return true;
    }
    if (["SOURCE_READ", "SOURCE_READ_FULL", "SOURCE_READ_IMPORT"].includes(
      msg?.type
    ) && !sender.tab) {
      void (async () => {
        settings = await message({ type: "PUBLIC_SETTINGS" });
        if (!settings.enabled || !settings.captureEnabled || scanning)
          throw Error(
            "Capture AliExpress d\xE9sactiv\xE9e ou lecture des prix en cours."
          );
        const initialURL = location.origin + location.pathname;
        if (msg.url !== initialURL || !extractAliExpress(document, location.href))
          throw Error("La fiche AliExpress a chang\xE9 ou n\u2019est pas charg\xE9e.");
        let completeDescription;
        if (msg.type !== "SOURCE_READ" && !(msg.type === "SOURCE_READ_IMPORT" && msg.fullDescription === false)) {
          const result = await loadFullDescription(
            document,
            () => settings.enabled && settings.captureEnabled && initialURL === location.origin + location.pathname,
            (resourceURL) => message({
              type: "SOURCE_DESCRIPTION_RESOURCE_READ",
              pageURL: initialURL,
              resourceURL
            }),
            initialURL,
            msg.pdp?.descUrl && (!msg.pdp.productId || initialURL.includes(`/item/${msg.pdp.productId}.html`)) ? [msg.pdp.descUrl] : []
          );
          if (result.descriptionStatus !== "loaded")
            throw Error(descriptionReadError(result.descriptionStatus));
          completeDescription = result;
        }
        const data = extractAliExpress(document, location.href);
        if (!data || data.url !== msg.url)
          throw Error("Le produit AliExpress a chang\xE9 ou n\u2019est pas charg\xE9.");
        if (completeDescription) {
          Object.assign(data, completeDescription);
          data.description = plainText(completeDescription.descriptionHTML).slice(
            0,
            12e3
          );
        }
        if (msg.type === "SOURCE_READ_IMPORT") {
          scanning = true;
          try {
            const alive = () => settings.enabled && settings.captureEnabled && initialURL === location.origin + location.pathname;
            if (!data.variants.length && msg.pdp) {
              const fromPdp = axesFromPdp(msg.pdp);
              if (fromPdp.variants.length) {
                data.variants = fromPdp.variants;
                if (!data.variantImages?.length)
                  data.variantImages = fromPdp.images.filter(
                    (i) => /^https:\/\//.test(i.url)
                  );
              }
            }
            const cost = readCost(document) ?? (data.variants.length ? null : simpleCostFromPdp(msg.pdp, data.id));
            let fast = data.variants.length ? scanFromPdp(msg.pdp, data.variants, data.id) : null;
            if (!fast && msg.pdp) {
              const fromPdp = axesFromPdp(msg.pdp);
              const scan = fromPdp.variants.length ? scanFromPdp(msg.pdp, fromPdp.variants, data.id) : null;
              if (scan) {
                fast = scan;
                data.variants = fromPdp.variants;
                const images = fromPdp.images.filter((i) => /^https:\/\//.test(i.url));
                if (images.length) data.variantImages = images;
              }
            }
            if (data.variants.length && !data.variantImages?.length)
              data.variantImages = axesFromPdp(msg.pdp).images.filter((i) => /^https:\/\//.test(i.url));
            data.variantScan = fast ? fast : data.variants.length ? await captureVariantCosts(document, alive) : {
              at: Date.now(),
              costs: cost ? [{ ...cost, values: [] }] : [],
              unavailable: []
            };
            data.variantCosts = data.variantScan.costs;
            const currency = foreignCurrency(msg.pdp);
            if (!data.variantScan.costs.length && currency)
              throw Error(
                `AliExpress affiche les prix en ${currency}. Remets la devise sur USD ($) dans AliExpress (en haut \xE0 droite : \xAB Ship to \xBB \u2192 Currency \u2192 USD), puis r\xE9essaie.`
              );
            if (!alive()) throw Error("Lecture fournisseur interrompue.");
          } finally {
            scanning = false;
          }
          if (data.descriptionStatus !== "loaded") {
            const completed = extractFullDescription(document);
            if (completed.descriptionStatus === "loaded") {
              Object.assign(data, completed);
              data.description = plainText(completed.descriptionHTML).slice(
                0,
                12e3
              );
            }
          }
        }
        const saved2 = await message({
          type: "SOURCE_CAPTURE",
          product: data
        });
        if (!saved2) throw Error("Capture AliExpress interrompue.");
        return data;
      })().then((data) => reply({ ok: true, data })).catch((e) => reply({ ok: false, error: e.message }));
      return true;
    }
    if (msg?.type === "SETTINGS_CHANGED" || msg?.type === "SOURCE_REFRESH") {
      void configure().then(() => reply({ ok: true, data: true })).catch(() => reply({ ok: false, error: "Lecture AliExpress impossible" }));
      return true;
    }
  });
})();
